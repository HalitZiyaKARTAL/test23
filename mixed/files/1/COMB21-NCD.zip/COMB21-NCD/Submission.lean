
import Submission.Work.U7604.Chain.FourierTB.Main

open OAI.PowerSaving Filter Asymptotics

theorem Race.bound : ∃ order solve W, DFTProgram order solve W ∧
    (fun n : ℕ => (W n : ℝ)) =O[atTop]
      (fun n : ℕ => (n : ℝ) * (Real.log (n : ℝ)) ^
        (1 - (730611 : ℝ) / 200000000)) := by
  obtain ⟨order, solve, W, hprogram, htime⟩ := transform_mainTB19
  refine ⟨order, solve, W, hprogram, ?_⟩
  have hdecimal : decimalTimeTB19 =
      (fun n : ℕ => (n : ℝ) * (Real.log (n : ℝ)) ^
        (1 - (730611 : ℝ) / 200000000)) := by
    funext n
    have hexponent : decimalExponentTB19 = 1 - (730611 : ℝ) / 200000000 := by
      norm_num [decimalExponentTB19, statedSavingTB19]
    simp only [decimalTimeTB19, hexponent]
  exact hdecimal ▸ htime.2.1
