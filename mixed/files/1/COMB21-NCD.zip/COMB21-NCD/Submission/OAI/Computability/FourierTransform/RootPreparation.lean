import Mathlib.Algebra.Field.ZMod
import Submission.OAI.Computability.FourierTransform.FourierIdentities
import Submission.OAI.Computability.FourierTransform.CompilerEnvironment
import Submission.OAI.Computability.FourierTransform.LocalPreparation
import Submission.Work.Prep.NewtonFree

namespace OAI

namespace PowerSaving
open Matrix Finset

variable {J : Type*} [Fintype J]
variable {κ : J → Type*} {μ : J → Type*} {ν : J → Type*}
variable {R : Type*} [CommSemiring R]

def digitProd (M : ∀ j, Matrix (κ j) (μ j) R) :
    Matrix ((j:J) → κ j) ((j:J) → μ j) R :=
  fun x y => ∏ j, M j (x j) (y j)

@[simp] theorem digitProd_apply (M : ∀ j, Matrix (κ j) (μ j) R) x y :
    digitProd M x y = ∏ j, M j (x j) (y j) := rfl

theorem prod_delta [∀ j, DecidableEq (κ j)] [DecidableEq ((j:J) → κ j)]
    (x y : (j:J) → κ j) :
    ∏ j:J, (if x j = y j then (1:R) else 0)
    = if x=y then 1 else 0 := by
  classical
  by_cases h : x = y
  · simp [h]
  · rw [ite_eq_right h]
    replace h : ∃ j, x j ≠ y j := Classical.byContradiction (by
      intro nh
      apply h
      push Not at nh
      exact funext nh)
    rcases h with ⟨j,hj⟩
    exact Finset.prod_eq_zero (Finset.mem_univ j) (ite_eq_right hj)

theorem digitProd_one [∀ j, DecidableEq (κ j)] [DecidableEq ((j:J) → κ j)] :
    digitProd (fun j:J => (1:Matrix (κ j) (κ j) R)) = 1 := by
  ext x y
  simp only [digitProd_apply, one_apply]
  apply prod_delta

theorem digitProd_diagonal [∀ j, DecidableEq (κ j)] [DecidableEq ((j:J) → κ j)]
    (d : ∀ j, κ j → R) :
    digitProd (fun j => Matrix.diagonal (d j))
      = Matrix.diagonal (fun x => ∏ j, d j (x j)) := by
  classical
  ext x y
  by_cases h : x = y
  · subst y; simp
  · simp only [digitProd_apply, diagonal_apply]
    -- diagonal if i=j then ... else 0
    rw [ite_eq_right h]
    replace h : ∃ j, x j ≠ y j := Classical.byContradiction (by
      intro nh
      apply h
      push Not at nh
      exact funext nh)
    obtain ⟨j,hj⟩ := h
    exact Finset.prod_eq_zero (Finset.mem_univ j) (ite_eq_right hj)

theorem digitProd_mul [∀ j, Fintype (μ j)] [DecidableEq J]
    (M : ∀ j, Matrix (κ j) (μ j) R) (N : ∀ j, Matrix (μ j) (ν j) R) :
    digitProd M * digitProd N = digitProd (fun j => M j * N j) := by
  classical
  ext x z
  simp only [digitProd_apply, Matrix.mul_apply, ← Finset.prod_mul_distrib]
  exact (Fintype.prod_sum (fun j y => M j (x j) y * N j y (z j))).symm

end PowerSaving

end OAI
namespace OAI

namespace PowerSaving.Binary
open Finset Matrix

abbrev F := ZMod 2
abbrev Space (α : Type*) := α → F

lemma bit_cases (x : F) : x=0 ∨ x=1 := by
  fin_cases x
  · left; rfl
  · right; rfl

@[simp] theorem cancel (x : F) : x+x=0 := by
  rcases bit_cases x with rfl | rfl <;> decide

@[simp] theorem binary_cancel {α : Type*} (x : Space α) : x+x=0 := by ext; exact cancel _

section Dot
variable {α : Type*} [Fintype α]

def dot (x y : Space α) := ∑ i : α, x i * y i

theorem dot_symm (x y : Space α) : dot x y = dot y x := by simp [dot, mul_comm]

@[simp] theorem dot_add_left (x y z : Space α) :
    dot (x+y) z = dot x z + dot y z := by simp [dot, add_mul, sum_add_distrib]

@[simp] theorem dot_add_right (x y z : Space α) :
    dot x (y+z) = dot x y + dot x z := by simp [dot, mul_add, sum_add_distrib]

@[simp] theorem dot_smul_left (a : F) (x y : Space α) :
    dot (a • x) y = a * dot x y := by simp [dot, mul_sum, mul_assoc]
@[simp] theorem dot_smul_right (a : F) (x y : Space α) :
    dot x (a • y) = a * dot x y := by rw [dot_symm, dot_smul_left, dot_symm]

@[simp] theorem dot_zero_left (x : Space α) : dot 0 x=0 := by simp [dot]

@[simp] theorem dot_zero_right (x : Space α) : dot x 0=0 := by simp [dot]

theorem dot_sum {β : Type*} (x : Space α) (s : Finset β) (f : β → Space α) :
    dot x (∑ j ∈ s, f j) = ∑ j ∈ s, dot x (f j) := by
  classical
  induction s using Finset.induction with
  | empty => simp
  | insert i s h ih => simp [h, ih]

variable [DecidableEq α]

def eu (i : α) : Space α := fun j => if i=j then 1 else 0

@[simp] theorem dot_eu_left (x : Space α) (i : α) : dot (eu i) x = x i := by
  simp [dot, eu, ite_mul]
@[simp] theorem dot_eu_right (x : Space α) (i : α) : dot x (eu i) = x i := by
  rw [dot_symm]; simp

end Dot

lemma mat_comm_F {n : Type*} [Fintype n] [DecidableEq n] {M N : Matrix n n F}
    (h : N * M = 1) : M * N = 1 := by
  have hinj : Function.Injective (M *ᵥ ·) := fun v w e => by
    have e' := congrArg (N *ᵥ ·) e
    simp only [Matrix.mulVec_mulVec, h, Matrix.one_mulVec] at e'
    exact e'
  have hv : ∀ v, M *ᵥ (N *ᵥ v) = v := fun v => by
    obtain ⟨w, rfl⟩ := Finite.injective_iff_surjective.mp hinj v
    show M *ᵥ (N *ᵥ (M *ᵥ w)) = M *ᵥ w
    simp only [Matrix.mulVec_mulVec, h, Matrix.one_mulVec]
  ext i j
  have e := congrFun (hv (Pi.single j 1)) i
  rw [Matrix.mulVec_mulVec] at e
  simpa [Matrix.mulVec, dotProduct, Pi.single_apply, Matrix.one_apply] using e

structure OBase (α : Type*) [Fintype α] [DecidableEq α] where
  v : α → Space α
  rows : ∀ i j, dot (v i) (v j) = if i=j then 1 else 0

namespace OBase
variable {α : Type*} [Fintype α] [DecidableEq α]

@[simp] theorem self (A : OBase α) (i : α) : dot (A.v i) (A.v i)=1 := by
  simp [A.rows]

theorem nz (A : OBase α) (i : α) : A.v i ≠ 0 := by
  intro h
  have := A.self i
  simp [h] at this

theorem cols (A : OBase α) (i j : α) :
    ∑ k, A.v k i * A.v k j = if i=j then 1 else 0 := by
  let M : Matrix α α F := Matrix.of A.v
  have h : M * Mᵀ = 1 := by
    ext i j
    simpa [M, Matrix.mul_apply, one_apply, dot] using A.rows i j
  have g : Mᵀ * M = 1 := mat_comm_F h
  simpa [M, Matrix.mul_apply, one_apply] using congr_fun (congr_fun g i) j

def canonical (α : Type*) [Fintype α] [DecidableEq α] : OBase α :=
  ⟨eu, fun i j => by simp [eu]⟩

def mat (A : OBase α) (s : Finset α) : Matrix α α F :=
  fun i j => ∑ k ∈ s, A.v k i * A.v k j

@[simp] theorem mat_univ (A : OBase α) : A.mat univ = 1 := by
  ext i j
  simpa only [mat, one_apply] using A.cols i j

theorem mat_sub (A : OBase α) (s t : Finset α) (h : t ⊆ s) :
    A.mat (s \ t) = A.mat s - A.mat t := by
  ext i j
  simpa [mat, eq_sub_iff_add_eq] using
    Finset.sum_sdiff h (f:=fun k => A.v k i * A.v k j)

def proj (A : OBase α) (s : Finset α) (x : Space α) : Space α :=
  ∑ k ∈ s, dot (A.v k) x • A.v k

theorem proj_apply (A : OBase α) (s : Finset α) (x : Space α) (i : α) :
    A.proj s x i = ∑ j, A.mat s i j*x j := by
  simp only [mat, proj, Finset.sum_apply, dot, sum_mul, Pi.smul_apply, smul_eq_mul]
  rw [sum_comm]
  apply Finset.sum_congr rfl
  intro j hj
  apply Finset.sum_congr rfl
  intro k hk
  ac_rfl

@[simp] theorem proj_univ (A : OBase α) (x : Space α) : A.proj univ x = x := by
  ext i; simp [proj_apply, one_apply, ite_mul]

theorem dot_proj_omit (A : OBase α) {s : Finset α} {i : α} (x : Space α) (hi : i ∉ s) :
    dot (A.v i) (A.proj s x) = 0 := by
  rw [proj, dot_sum]
  apply sum_eq_zero
  intro j hj
  have h : i ≠ j := by intro hh; exact hi (hh ▸ hj)
  simp [A.rows, h]

section Adapt

def tv (w x : Space α) := x + dot w x • w

omit [DecidableEq α] in
theorem tv_isom (w x y : Space α) (h : dot w w = 0) :
    dot (tv w x) (tv w y) = dot x y := by
  simp only [tv, dot_add_right, dot_add_left, dot_smul_right, dot_smul_left, h,
    mul_zero, add_zero]
  rw [dot_symm x w, mul_comm (dot w y), add_assoc, cancel, add_zero]

def acted (A : OBase α) (w : Space α) (h : dot w w=0) : OBase α :=
  ⟨fun i => tv w (A.v i), fun i j => by rw [tv_isom _ _ _ h]; apply A.rows⟩

def adapt (A : OBase α) (i : α) (t : Space α) (h1 : dot t t=1)
    (h2 : dot t (A.v i) = 0) : OBase α :=
  acted A (t + A.v i) (by simp [h1, h2, dot_symm (A.v i) t])

theorem adapt_pivot (A : OBase α) (i : α) (t : Space α)
    (h1 : dot t t=1) (h2 : dot t (A.v i) = 0) :
    (adapt A i t h1 h2).v i = t := by
  simp only [adapt, acted, tv, dot_add_left, h2, A.self, zero_add, one_smul]
  rw [add_comm t, ← add_assoc, binary_cancel, zero_add]

end Adapt

end OBase

end PowerSaving.Binary

end OAI
namespace OAI

namespace PowerSaving.Binary
open Matrix Finset Complex
noncomputable section

def sign (i : F) : ℂ := if i=0 then 1 else -1
def tint (i : F) : ℂ := if i=0 then 1 else I

lemma sign_add (i j : F) : sign (i+j) = sign i * sign j := by
  rcases bit_cases i with rfl|rfl <;>
    rcases bit_cases j with rfl|rfl <;> simp [sign]

lemma sign_sq (i : F) : sign i * sign i = 1 := by
  rw [← sign_add, cancel]; simp [sign]

lemma tint_add (i j : F) : tint (i+j) = tint i * tint j * sign (i*j) := by
  rcases bit_cases i with rfl|rfl <;>
    rcases bit_cases j with rfl|rfl <;> simp [sign,tint]

lemma tint_sq (i : F) : tint i * tint i = sign i := by
  rcases bit_cases i with rfl|rfl <;> simp [sign,tint]

lemma sign_sum {α : Type*} (v : α → F) (s : Finset α) :
    sign (∑ i ∈ s, v i) = ∏ i ∈ s, sign (v i) := by
  classical
  induction s using Finset.induction with
  | empty => simp [sign]
  | insert i s h ih => simp [h, sign_add, ih]

variable {α : Type*} [Fintype α]

def lum (x : Space α) : ℂ := ∏ i, tint (x i)

@[simp] lemma lum_zero : lum (0 : Space α)=1 := by
  simp [lum,tint]

lemma lum_add (x y : Space α) :
    lum (x+y) = lum x * lum y * sign (dot x y) := by
  simp only [dot, lum, Pi.add_apply, tint_add, prod_mul_distrib, sign_sum]

lemma lum_sq (x : Space α) : lum x * lum x = sign (dot x x) := by
  simp only [dot, lum, ← prod_mul_distrib, sign_sum, tint_sq]
  apply prod_congr rfl
  intro j hj
  rcases bit_cases (x j) with h|h <;> simp [h]

lemma lum_nonzero (x : Space α) : lum x ≠ 0 := by
  have h := lum_sq x
  intro ha
  rw [ha, zero_mul, sign] at h
  split at h <;> norm_num at h

lemma lum_of_unit (x : Space α) (h : dot x x=1) :
    lum x = I ∨ lum x = -I := by
  apply sq_eq_sq_iff_eq_or_eq_neg.mp
  rw [pow_two, lum_sq, h]; simp [sign]

def littleH : Matrix F F ℂ := fun i j => sign (i*j)

def littleH' : Matrix F F ℂ := fun i j => sign (i*j)/2

def ca : ℂ := (1+I)/2
def cb : ℂ := (1-I)/2
def littleC : Matrix F F ℂ := fun i j => if i=j then ca else cb

lemma sum_bits (v : F → ℂ) : ∑ i, v i = v 0 + v 1 := by
  have h : (univ : Finset F) = {0,1} := by
    ext i; rcases bit_cases i with rfl|rfl <;> simp
  rw [h]
  simp

lemma littleH_H' : littleH * littleH' = 1 := by
  ext i j
  rw [Matrix.mul_apply,sum_bits,one_apply]
  rcases bit_cases i with rfl|rfl <;> rcases bit_cases j with rfl|rfl <;>
    norm_num [littleH, littleH', sign]

lemma little_phase :
    littleC * littleH = littleH * diagonal tint := by
  ext i j
  rw [Matrix.mul_apply,sum_bits,Matrix.mul_diagonal]
  rcases bit_cases i with rfl|rfl <;> rcases bit_cases j with rfl|rfl <;>
    simp [littleC, ca, cb, littleH, tint, sign] <;> ring

abbrev CMat (α : Type*) := Matrix (Space α) (Space α) ℂ

def kernel (α : Type*) [Fintype α] : CMat α := digitProd fun _ => littleC

def wal (α : Type*) [Fintype α] : CMat α := digitProd fun _ => littleH
def walI (α : Type*) [Fintype α] : CMat α := digitProd fun _ => littleH'

lemma wal_apply (x y : Space α) : wal α x y = sign (dot x y) := by
  simp [wal, littleH, dot, sign_sum]

variable [DecidableEq α]

lemma wal_right (α : Type*) [Fintype α] [DecidableEq α] :
    wal α * walI α = 1 := by rw [wal, walI, digitProd_mul]; simp_rw [littleH_H',digitProd_one]

lemma littleH'_H : littleH' * littleH = 1 := by
  ext i j
  rw [Matrix.mul_apply,sum_bits,one_apply]
  rcases bit_cases i with rfl|rfl <;> rcases bit_cases j with rfl|rfl <;>
    norm_num [littleH, littleH', sign]

lemma wal_left (α : Type*) [Fintype α] [DecidableEq α] :
    walI α * wal α = 1 := by rw [wal, walI, digitProd_mul]; simp_rw [littleH'_H,digitProd_one]

def wrap (f : Space α → ℂ) : CMat α := wal α * diagonal f * walI α

lemma wrap_of (M : CMat α) (f : Space α → ℂ)
    (h : M * wal α = wal α * diagonal f) : wrap f = M := by
  rw [wrap, ← h, Matrix.mul_assoc, wal_right, mul_one]

lemma wrap_one : wrap (fun _ : Space α => 1) = 1 := by
  simp_rw [wrap, diagonal_one, mul_one, wal_right]

lemma wrap_mul (f g : Space α → ℂ) :
    wrap f * wrap g = wrap fun x => f x * g x := by
  unfold wrap
  rw [show wal α * diagonal f * walI α * (wal α * diagonal g * walI α) =
        wal α * (diagonal f * (walI α * wal α) * diagonal g) * walI α by
      simp only [Matrix.mul_assoc]]
  rw [wal_left, mul_one]
  simp only [diagonal_mul_diagonal]

lemma wrap_comm (f g : Space α → ℂ) : wrap f * wrap g = wrap g * wrap f := by
  rw [wrap_mul, wrap_mul]; simp_rw [mul_comm]

lemma wrap_lum : wrap (lum : Space α → ℂ) = kernel α := by
  apply wrap_of
  unfold kernel wal
  rw [show diagonal (lum : Space α → ℂ) = digitProd (fun _ => diagonal tint) from
      (digitProd_diagonal fun _ : α => tint).symm,
      digitProd_mul, digitProd_mul]
  simp_rw [little_phase]

def shift (z : Space α) : CMat α :=
  fun i j => if i+z = j then 1 else 0

lemma shift_phase (z : Space α) : shift z = wrap (fun x => sign (dot z x)) := by
  symm
  apply wrap_of
  ext i j
  rw [Matrix.mul_apply, Matrix.mul_diagonal]
  simp [shift, wal_apply, ite_mul, sign_add]

lemma shift_sq (z : Space α) : shift z * shift z = 1 := by
  rw [shift_phase, wrap_mul]
  simp only [sign_sq, wrap_one]

def dir (z : Space α) : CMat α := ca • 1 + cb • shift z

lemma dir_phase (z : Space α) : dir z = wrap (fun x => tint (dot z x)) := by
  symm
  apply wrap_of
  have hs : shift z * wal α = wal α * diagonal (fun x => sign (dot z x)) := by
    rw [shift_phase, wrap, Matrix.mul_assoc, wal_left, mul_one]
  unfold dir
  rw [add_mul, Matrix.smul_mul, Matrix.smul_mul, one_mul, hs]
  ext i j
  simp only [Matrix.add_apply, Matrix.smul_apply, Matrix.mul_diagonal, smul_eq_mul]
  rcases bit_cases (dot z j) with h|h <;> simp [ca, cb, tint, sign, h] <;> ring

lemma dir_sq (z : Space α) : dir z * dir z = shift z := by
  rw [dir_phase, wrap_mul, shift_phase]; simp only [tint_sq]

def frame (A : OBase α) (s : Finset α) := wrap fun x => lum (A.proj s x)

@[simp] lemma frame_univ (A : OBase α) : frame A univ = kernel α := by
  simp [frame, wrap_lum]

@[simp] lemma frame_zero (A : OBase α) : frame A ∅ = 1 := by
  simp [frame, OBase.proj, wrap_one]

def unframe (A : OBase α) (s : Finset α) := wrap fun x => (lum (A.proj s x))⁻¹

lemma unframe_right (A : OBase α) (s : Finset α) : frame A s * unframe A s = 1 := by
  rw [frame, unframe, wrap_mul]
  simp [lum_nonzero, wrap_one]

def delta (z : Space α) := wrap fun x => lum (dot z x • z)

lemma frame_ins (A : OBase α) (s : Finset α) (i : α) (hi : i ∉ s) :
    frame A (insert i s) = delta (A.v i) * frame A s := by
  rw [delta, frame, frame, wrap_mul]
  have hh (x : Space α) :
      lum (A.proj (insert i s) x) = lum (dot (A.v i) x • A.v i) * lum (A.proj s x) := by
    rw [show A.proj (insert i s) x = dot (A.v i) x • A.v i + A.proj s x by
      unfold OBase.proj; rw [sum_insert hi], lum_add]
    simp [OBase.dot_proj_omit A x hi, sign]
  simp_rw [hh]

lemma delta_pos (z : Space α) (h : lum z = I) :
    delta z = dir z := by
  rw [dir_phase, delta]
  apply congrArg wrap
  funext x
  rcases bit_cases (dot z x) with g|g <;> simp [tint, g, h]

lemma delta_neg (z : Space α) (h : lum z = -I) :
    delta z = shift z * dir z := by
  rw [delta, dir_phase, shift_phase, wrap_mul]
  apply congrArg wrap
  funext x
  rcases bit_cases (dot z x) with g|g <;> simp [tint, sign, g, h]

lemma delta_sq (z : Space α) (h : dot z z=1) : delta z * delta z = shift z := by
  obtain hp|hn := lum_of_unit z h
  · rw [delta_pos z hp, dir_sq]
  · have hh : dir z * shift z = shift z * dir z := by
      rw [dir_phase, shift_phase]; apply wrap_comm
    rw [delta_neg z hn, ← mul_assoc, mul_assoc (shift z) (dir z), hh]
    simp [← Matrix.mul_assoc, shift_sq, dir_sq]

end
end PowerSaving.Binary

end OAI
namespace OAI

namespace PowerSaving.Slant

open Binary Spectral Matrix Finset
noncomputable section

structure Stroke where
  ix : ℕ → ℕ
  dye : Line
  partner : ℕ → ℕ

namespace Stroke

def applyM (u : Stroke) (x : Line) : Line := fun i => u.dye i * x (u.ix i)

def applyC (u : Stroke) (x : Line) : Line := fun i =>
  if u.partner i = i then x i else ca * x i + cb * x (u.partner i)

def send (u : Stroke) (x : Line) := u.applyC (u.applyM x)

structure Sound (u : Stroke) (n : ℕ) : Prop where
  bdix : ∀ i < n, u.ix i < n
  bdp : ∀ i < n, u.partner i < n
  pair : ∀ i, u.partner (u.partner i)=i
  awayix : ∀ i, n ≤ i → u.ix i=i
  awayp : ∀ i, n ≤ i → u.partner i=i
  awayd : ∀ i, n ≤ i → u.dye i=1

namespace Sound
variable {u : Stroke} {n n' : ℕ}

lemma wider (h : u.Sound n) (h' : n ≤ n') : u.Sound n' := by
  refine ⟨fun i hi => ?_, fun i hi => ?_, h.pair, fun i hi => h.awayix i (by omega),
    fun i hi => h.awayp i (by omega), fun i hi => h.awayd i (by omega)⟩
  · rcases lt_or_ge i n with g|g
    · exact (h.bdix i g).trans_le h'
    · rwa [h.awayix i g]
  · rcases lt_or_ge i n with g|g
    · exact (h.bdp i g).trans_le h'
    · rwa [h.awayp i g]

theorem same (h : u.Sound n) (x : Line) (i : ℕ) (hi : n ≤ i) :
    u.send x i=x i := by simp [send,applyC,h.awayp i hi,applyM,h.awayix i hi,h.awayd i hi]

theorem send_congr (h : u.Sound n) {x y : Line} (H : ∀ i<n, x i=y i) :
    ∀ i<n, u.send x i=u.send y i := by
  have g (i : ℕ) (hi : i<n) : u.applyM x i=u.applyM y i :=
    congr_arg (u.dye i * ·) (H _ (h.bdix i hi))
  intro i hi
  simp only [send,applyC, g i hi,g _ (h.bdp i hi)]

end Sound

def unmark : Stroke := ⟨id,fun _ => 1,id⟩

@[simp] theorem send_unmark (x : Line) : unmark.send x=x := by ext i; simp [send,unmark,applyC,applyM]

theorem sound_unmark (n : ℕ) : unmark.Sound n :=
  ⟨fun _ hi => hi, fun _ hi => hi,fun _ => rfl,fun _ _ => rfl,fun _ _ => rfl,fun _ _ => rfl⟩

def plain (n : ℕ) (l : ℕ→ℕ) (d : Line) : Stroke :=
  ⟨fun i => if i < n then l i else i, fun i => if i < n then d i else 1, id⟩

theorem plain_sound (n : ℕ) (l : ℕ→ℕ) (d : Line)
    (h : ∀ i<n, l i<n) : (plain n l d).Sound n := by
  refine ⟨fun i hi => ?_,fun i hi => hi,fun i => rfl,fun i hi => ?_,
    fun i hi => rfl,fun i hi => ?_⟩ <;> simp [plain, hi, h, Nat.not_lt.mpr]

theorem plain_send (n : ℕ) (l : ℕ→ℕ) (d : Line) (x : Line) (i : ℕ) :
    (plain n l d).send x i=if i<n then d i*x (l i) else x i := by
  by_cases h : i<n <;> simp [send,plain,applyM,applyC,h]

-- parallel sum
def beside (p : ℕ) (u v : Stroke) : Stroke where
  ix i := if i<p then u.ix i else p+v.ix (i-p)
  dye i := if i<p then u.dye i else v.dye (i-p)
  partner i := if i<p then u.partner i else p+v.partner (i-p)

theorem Sound.beside {p q : ℕ} {u v : Stroke} (hu : u.Sound p) (hv : v.Sound q) :
    (Stroke.beside p u v).Sound (p+q) := by
  refine ⟨fun i hi => ?_, fun i hi => ?_, fun i => ?_, fun i hi => ?_,
    fun i hi => ?_, fun i hi => ?_⟩
  · unfold Stroke.beside; dsimp; split
    · rename_i h
      have := hu.bdix i h
      omega
    · have := hv.bdix (i-p) (by omega)
      omega
  · unfold Stroke.beside; dsimp; split
    · rename_i h
      have := hu.bdp i h
      omega
    · have := hv.bdp (i-p) (by omega)
      omega
  · by_cases h : i<p
    · simp only [Stroke.beside,h,↓reduceIte, hu.bdp i h, hu.pair]
    · have HH := hv.pair (i-p)
      simp [Stroke.beside,h,HH,Nat.not_lt.mpr]
      omega
  · simp only [Stroke.beside, ite_eq_right (show ¬i<p by omega),
      hv.awayix _ (show q ≤ i-p by omega)]
    omega
  · simp only [Stroke.beside, ite_eq_right (show ¬i<p by omega),
      hv.awayp _ (show q ≤ i-p by omega)]
    omega
  · simp only [Stroke.beside, ite_eq_right (show ¬i<p by omega),
      hv.awayd _ (show q ≤ i-p by omega)]

def drift (p : ℕ) (x : Line) : Line := fun i => x (p+i)

theorem beside_left (p : ℕ) (u v : Stroke) (hu : u.Sound p) (x : Line)
    (i : ℕ) (hi : i<p) : (beside p u v).send x i=u.send x i := by
  simp only [send,applyM,applyC,beside,ite_eq_left hi,ite_eq_left (hu.bdp i hi)]

theorem beside_right (p : ℕ) (u v : Stroke) (x : Line) :
    drift p ((beside p u v).send x)=v.send (drift p x) := by
  ext i
  simp [send,applyC,applyM,beside,drift,Nat.not_lt.mpr]

end Stroke

open Stroke

structure Reel where
  beats : ℕ
  atBeat : ℕ → Stroke

namespace Reel

def reach (p : Reel) (x : Line) : ℕ → Line
  | 0 => x
  | t+1 => (p.atBeat t).send (reach p x t)

def go (p : Reel) (x : Line) := p.reach x p.beats

def Sound (p : Reel) (n : ℕ) : Prop := ∀ t<p.beats, (p.atBeat t).Sound n

namespace Sound

variable {u : Reel} {n n' : ℕ}

lemma wider (h : u.Sound n) (g : n ≤ n') : u.Sound n' :=
  fun t ht => (h t ht).wider g

theorem still (h : u.Sound n) (x : Line) (i : ℕ) (hi : n ≤ i) :
    u.go x i=x i := by
  have H (t : ℕ) (ht : t ≤ u.beats) :
      u.reach x t i=x i := by
    induction t with
    | zero => rfl
    | succ t ih =>
      rw [reach,(h t (by omega)).same _ i hi, ih (by omega)]
  exact H u.beats le_rfl

end Sound

def wait (d : ℕ) : Reel := ⟨d,fun _ => unmark⟩

@[simp] theorem go_wait (d : ℕ) (x : Line) : (wait d).go x=x := by
  have H (t : ℕ) : (wait d).reach x t=x := by
    induction t <;> simp_all [reach,wait]
  exact H _

theorem sound_wait (d n : ℕ) : (wait d).Sound n := fun _ _ => sound_unmark n

def tick (s : Stroke) : Reel := ⟨1,fun _ => s⟩

@[simp] theorem go_tick (s : Stroke) (x : Line) :
    (tick s).go x=s.send x := rfl

lemma sound_tick {n : ℕ} {s : Stroke} (h : s.Sound n) : (tick s).Sound n := fun _ _ => h

def stack (a b : Reel) : Reel :=
  ⟨a.beats+b.beats,fun i => if i<a.beats then a.atBeat i else b.atBeat (i-a.beats)⟩

@[simp] lemma go_stack (a b : Reel) (x : Line) :
    (a.stack b).go x=b.go (a.go x) := by
  have H (t : ℕ) (ht : t ≤ a.beats) :
      (a.stack b).reach x t=a.reach x t := by
    induction t with
    | zero => rfl
    | succ t ih =>
      rw [reach,reach,ih (by omega)]
      simp only [stack,ite_eq_left (show t<a.beats by omega)]
  have G (t : ℕ) :
      (a.stack b).reach x (a.beats+t)=b.reach (a.go x) t := by
    induction t with
    | zero => simpa [go,reach] using H _ le_rfl
    | succ t ih =>
      rw [← add_assoc,reach,reach,ih]
      simp [stack]
  exact G b.beats

lemma Sound.stack {n : ℕ} {a b : Reel} (h : a.Sound n) (g : b.Sound n) :
    (a.stack b).Sound n := by
  intro t ht
  change t<a.beats+b.beats at ht
  unfold Reel.stack; dsimp; split
  · rename_i H; exact h t H
  · exact g _ (by omega)

def parallel (p : ℕ) (a b : Reel) : Reel :=
  ⟨a.beats, fun i => beside p (a.atBeat i) (b.atBeat i)⟩

theorem Sound.parallel {p q : ℕ} {a b : Reel} (h : a.Sound p) (g : b.Sound q)
    (hl : a.beats=b.beats) :
    (Reel.parallel p a b).Sound (p+q) :=
  fun i hi => (h i hi).beside (g i (hl ▸ (by exact hi)))

theorem parallel_left (p : ℕ) (a b : Reel) (h : a.Sound p)
    (x : Line) : ∀ i<p, (parallel p a b).go x i=a.go x i := by
  have H (t : ℕ) (ht : t ≤ a.beats) :
      ∀ i<p, (parallel p a b).reach x t i=a.reach x t i := by
    induction t with
    | zero => intros; rfl
    | succ t ih =>
      intro i hi
      have g := h t (by omega)
      exact (beside_left p _ (b.atBeat t) g _ i hi).trans (g.send_congr (ih (by omega)) i hi)
  exact H a.beats le_rfl

theorem parallel_right (p : ℕ) (a b : Reel) (hl : a.beats=b.beats) (x : Line) :
    drift p ((parallel p a b).go x)=b.go (drift p x) := by
  have H (t : ℕ) : drift p ((parallel p a b).reach x t)=b.reach (drift p x) t := by
    induction t with
    | zero => rfl
    | succ t ih =>
      exact (beside_right p _ _ _).trans (congr_arg ((b.atBeat t).send) ih)
  change drift p ((parallel p a b).reach x a.beats)=_
  rw [H,hl]; rfl

def atBase (p : ℕ) (a : Reel) : Reel := parallel p (wait a.beats) a

lemma Sound.atBase {q : ℕ} {a : Reel} (h : a.Sound q) (p : ℕ) :
    (Reel.atBase p a).Sound (p+q) :=
  (sound_wait _ _).parallel h rfl

lemma atBase_left (p : ℕ) (a : Reel) (x : Line) (i : ℕ) (hi : i<p) :
    (atBase p a).go x i=x i := by
  rw [atBase,parallel_left p _ a (sound_wait a.beats p) x i hi,go_wait]

lemma atBase_right (p : ℕ) (a : Reel) (x : Line) (i : ℕ) :
    (atBase p a).go x (p+i)=a.go (drift p x) i :=
  congr_fun (parallel_right p (wait a.beats) a rfl x) i

-- layer singleton builders
def swatch (n : ℕ) (d : Line) : Reel :=
  tick (Stroke.plain n id d)

def lace (n : ℕ) (q : ℕ→ℕ) : Reel :=
  tick (Stroke.plain n q (fun _ => 1))

lemma sound_swatch (n : ℕ) (d : Line) : (swatch n d).Sound n :=
  sound_tick (Stroke.plain_sound n _ _ fun _ hi => hi)

lemma go_swatch (n : ℕ) (d : Line) (x : Line) (i : ℕ) (hi : i<n) :
    (swatch n d).go x i=d i*x i := by
  rw [swatch,go_tick, plain_send,ite_eq_left hi]; rfl

lemma sound_lace (n : ℕ) (q : ℕ→ℕ) (h : ∀ i<n, q i<n) : (lace n q).Sound n :=
  sound_tick (Stroke.plain_sound n q _ h)

lemma go_lace (n : ℕ) (q : ℕ→ℕ) (x : Line) (i : ℕ) (hi : i<n) :
    (lace n q).go x i=x (q i) := by
  rw [lace,go_tick, plain_send,ite_eq_left hi,one_mul]

end Reel

end
end PowerSaving.Slant

end OAI
namespace OAI

namespace PowerSaving.Slant
open Reel Stroke Spectral
noncomputable section

structure Zone where
  lo : ℕ
  wide : ℕ

namespace Zone
def has (u : Zone) (i : ℕ) : Prop := u.lo ≤ i ∧ i < u.lo+u.wide

instance instDecidableHas (u : Zone) (i : ℕ) : Decidable (u.has i) := by
  unfold has
  infer_instance

def Fits (u : Zone) (v : ℕ) : Prop := ∀ i, u.has i → i<v

lemma fits_of (u : Zone) (n : ℕ) (h : u.lo+u.wide ≤ n) : u.Fits n :=
  fun _ hi => hi.2.trans_le h

def Sep (u v : Zone) : Prop := ∀ i, u.has i → ¬ v.has i

lemma sep_of (u v : Zone) (h : u.lo+u.wide ≤ v.lo) : u.Sep v :=
  fun _ hi hj => Nat.not_lt.mpr (h.trans hj.1) hi.2

lemma Sep.symm {u v : Zone} (h : u.Sep v) : v.Sep u := fun i hi g => h i g hi

lemma inside (u : Zone) {i : ℕ} (hi : i<u.wide) : u.has (u.lo+i) :=
  ⟨by omega,by omega⟩

lemma enter (u : Zone) {i : ℕ} (hi : u.has i) :
    i-u.lo < u.wide := by
  unfold has at hi; omega

lemma identify (u : Zone) {i} (hi : u.has i) : u.lo+(i-u.lo)=i := by
  unfold has at hi; omega

lemma boundary (u : Zone) {i : ℕ} (hi : ¬ u.has i) : i<u.lo ∨ u.lo+u.wide ≤ i := by
  unfold has at hi; omega

def peek (u : Zone) (x : Line) : Line := drift u.lo x

def slim (u : Zone) (n : ℕ) : Zone := ⟨u.lo,n⟩

lemma slim_has (u : Zone) {n i : ℕ} (hn : n ≤ u.wide)
    (hi : (u.slim n).has i) : u.has i := ⟨hi.1,hi.2.trans_le (by change u.lo+n ≤ _; omega)⟩

lemma Fits.slim {u : Zone} {v n : ℕ} (h : u.Fits v) (hn : n ≤ u.wide) :
    (u.slim n).Fits v := fun i hi => h i (slim_has u hn hi)

lemma Sep.slim_left {u v : Zone} (h : u.Sep v) {n : ℕ} (hn : n ≤ u.wide) :
    (u.slim n).Sep v := fun i hi => h i (slim_has u hn hi)

lemma Sep.slim_right {u v : Zone} (h : u.Sep v) {n : ℕ} (hn : n ≤ v.wide) :
    u.Sep (v.slim n) := (h.symm.slim_left hn).symm

end Zone

def Reads (p q : ℕ) (f : Line → Line) : Prop :=
  ∀ x y, (∀ i<p, x i=y i) → ∀ i<q, f x i=f y i

def AdditiveOn (q : ℕ) (f : Line → Line) : Prop :=
  ∀ x y, ∀ i<q, f (x+y) i=f x i+f y i

def minusFn (f : Line→Line) : Line → Line := fun x i => -f x i

structure Spill (r : Reel) (u v : Zone) (f : Line→Line) : Prop where
  adds : ∀ (x : Line) (i), i<v.wide → v.peek (r.go x) i=v.peek x i + f (u.peek x) i
  keeps : ∀ (x : Line) (i), ¬ v.has i → r.go x i=x i

namespace Spill
variable {r : Reel} {u v z : Zone} {f g : Line→Line}

lemma preserves (h : Spill r u v f) (hz : z.Sep v) (x : Line) :
    ∀ i<z.wide, z.peek (r.go x) i=z.peek x i :=
  fun _ hi => h.keeps x _ (hz _ (z.inside hi))

lemma congr (h : Spill r u v f) (hg : ∀ (x : Line), ∀ i<v.wide, f x i = g x i) :
    Spill r u v g :=
  ⟨fun x i hi => (h.adds x i hi).trans (by rw [hg _ i hi]),h.keeps⟩

end Spill

open Zone
def cameo (a b c d : Reel) : Reel := ((a.stack b).stack c).stack d

lemma sound_cameo (a b c d : Reel) (n) (h : a.Sound n) (g : b.Sound n)
    (p : c.Sound n) (q : d.Sound n) :
    (cameo a b c d).Sound n :=
  ((h.stack g).stack p).stack q

theorem spill_cameo {a b c d : Reel} {u v z : Zone}
    {f g : Line→Line}
    (ha : Spill a u z f) (hb : Spill b z v g)
    (hc : Spill c u z (minusFn f)) (hd : Spill d z v (minusFn g))
    (rf : Reads u.wide z.wide f) (rg : Reads z.wide v.wide g)
    (hh : AdditiveOn v.wide g)
    (huv : u.Sep v) (huz : u.Sep z) (hzv : z.Sep v) :
    Spill (cameo a b c d) u v (g ∘ f) := by
  have middle (x : Line) :
      ∀ i < z.wide, z.peek (c.go (b.go (a.go x))) i = z.peek x i := by
    intro i hi
    have H (j : ℕ) (hj : j < u.wide) :
        u.peek (b.go (a.go x)) j = u.peek x j :=
      (hb.preserves huv _ j hj).trans (ha.preserves huz _ j hj)
    rw [hc.adds _ i hi, hb.preserves hzv _ i hi, ha.adds _ i hi, minusFn, rf _ _ H i hi]
    ring
  constructor
  · intro x i hi
    have H := rg _ _ (middle x) i hi
    have mid : g (z.peek (a.go x)) i=g (z.peek x + f (u.peek x)) i := by
      apply rg
      · intro j hj
        exact ha.adds x j hj
      · exact hi
    simp only [cameo,Reel.go_stack]
    rw [hd.adds _ i hi,minusFn,H, hc.preserves hzv.symm _ i hi, hb.adds _ i hi,
      ha.preserves hzv.symm _ i hi,mid, hh _ _ i hi,Function.comp_apply]
    ring
  · intro x i hi
    simp only [cameo,Reel.go_stack]
    rw [hd.keeps _ i hi]
    by_cases h : z.has i
    · have G := middle x (i-z.lo) (z.enter h)
      simpa [Zone.peek, Stroke.drift,z.identify h] using G
    · rw [hc.keeps _ i h,hb.keeps _ i hi,ha.keeps _ i h]

end
end PowerSaving.Slant

end OAI
namespace OAI
namespace PowerSaving.Slant

open Zone Reel Stroke Spectral Binary Complex
noncomputable section

def shade (u v : Zone) (f g : Line) : Reel :=
  tick ⟨id, (fun i => if u.has i then f (i-u.lo) else if v.has i then g (i-v.lo)
          else 1),id⟩

def jumps (u v : Zone) (i : ℕ) :=
  if u.has i then v.lo+(i-u.lo)
  else if v.has i then u.lo+(i-v.lo) else i

def snap (u v : Zone) : Reel := tick ⟨id,fun _ => 1,jumps u v⟩

theorem sound_shade {u v : Zone} {f g : Line} {n : ℕ} (h : u.Fits n) (k : v.Fits n) :
    (shade u v f g).Sound n := by
  apply Reel.sound_tick
  refine ⟨fun _ hi => hi,fun _ hi => hi,fun _ => rfl,fun _ _ => rfl,
    fun _ _ => rfl,fun i hi => ?_⟩
  exact (ite_eq_right_iff.mpr fun hu => by
    have := h _ hu; omega).trans (ite_eq_right (fun hv => by have := k _ hv; omega))

lemma jumps_u {u v : Zone} {i} (h : i<u.wide) :
    jumps u v (u.lo+i)=v.lo+i := by simp [jumps,u.inside h]

lemma jumps_v {u v : Zone} (h : u.Sep v) {i} (g : i<v.wide) :
    jumps u v (v.lo+i)=u.lo+i := by
  simp [jumps, v.inside g, h.symm _ (v.inside g)]

lemma sound_snap {u v : Zone} {n : ℕ} (h : u.Fits n) (g : v.Fits n)
    (hv : u.wide=v.wide) (hw : u.Sep v) : (snap u v).Sound n := by
  have H1 (i : ℕ) (hi : u.has i) : jumps u v i=v.lo+(i-u.lo) := by rw [jumps,ite_eq_left hi]
  have H2 (i : ℕ) (hi : v.has i) : jumps u v i=u.lo+(i-v.lo) := by
    rw [jumps,ite_eq_right (hw.symm _ hi), ite_eq_left hi]
  apply sound_tick
  refine ⟨fun i hi => hi, fun i hi => ?_, fun i => ?_, fun i hi => rfl,fun i hi => ?_,
    fun i hi => rfl⟩
  · change jumps u v i<n
    by_cases hk : u.has i
    · rw [H1 i hk]; exact g _ (v.inside (hv ▸ u.enter hk))
    by_cases hk' : v.has i
    · rw [H2 i hk']; exact h _ (u.inside (hv.symm ▸ v.enter hk')) -- dep rewrite?
    · simpa only [jumps,ite_eq_right hk,ite_eq_right hk']
  · change jumps u v (jumps u v i)=i
    by_cases hk : u.has i
    · rw [H1 i hk, jumps_v hw (hv ▸ u.enter hk),u.identify hk]
    by_cases hk' : v.has i
    · rw [H2 i hk', jumps_u (hv.symm ▸ v.enter hk'),v.identify hk']
    · simp only [jumps,ite_eq_right hk,ite_eq_right hk']
  · unfold jumps; dsimp
    split
    · rename_i hk; have := h _ hk; omega
    split
    · rename_i hk; have := g _ hk; omega
    · rfl

abbrev Bicolor := ℂ × ℂ

def twinsAt (u v : Zone) (x : Line) (i : ℕ) : Bicolor := (u.peek x i,v.peek x i)

structure Twins (r : Reel) (u v : Zone) (f : ℕ → Bicolor → Bicolor) : Prop where
  acts : ∀ x i, i<u.wide → twinsAt u v (r.go x) i=f i (twinsAt u v x i)
  waits : ∀ x i, ¬u.has i → ¬v.has i → r.go x i=x i

lemma Twins.stack {r s : Reel} {u v f g} (h : Twins r u v f) (k : Twins s u v g) :
    Twins (r.stack s) u v (fun i x => g i (f i x)) :=
  ⟨fun x i hi => by rw [go_stack, k.acts _ i hi,h.acts _ i hi],fun x i hi gi => by
    rw [go_stack,k.waits _ _ hi gi,h.waits _ _ hi gi]⟩

lemma Twins.congr {r : Reel} {u v f g} (h : Twins r u v f)
    (k : ∀ i<u.wide, ∀ t, f i t=g i t) :
    Twins r u v g :=
  ⟨fun x i hi => (h.acts x i hi).trans (k i hi _),h.waits⟩

section
variable {u v : Zone} (hv : u.wide=v.wide) (hw : u.Sep v)

include hv hw

lemma twins_shade (f g : Line) :
    Twins (shade u v f g) u v (fun i t => (f i * t.1, g i * t.2)) := by
  constructor
  · intro x i hi
    have hp := u.inside hi
    have hh := v.inside (hv ▸ hi)
    simp [shade,twinsAt,Zone.peek,drift,send,applyM,applyC,hp,hh,hw.symm _ hh]
  · intro x i hi hk
    simp [shade,send,applyM,applyC,hi,hk]

lemma twins_snap :
    Twins (snap u v) u v (fun _ t => (ca*t.1+cb*t.2,ca*t.2+cb*t.1)) := by
  constructor
  · intro x i hi
    have hh : u.lo ≠ v.lo := by
      intro g
      have H (i) := hw.symm i
      exact H (v.lo+i) (v.inside (hv ▸ hi)) (by rw [← g]; exact u.inside hi)
    simp [snap,twinsAt,Zone.peek,drift,send,applyC,applyM,
      jumps_u (v:=v) hi,jumps_v hw (hv ▸ hi),hh,Ne.symm hh]
  · intro x i hi hk
    simp [snap,send,applyC,applyM,jumps,hi,hk]

end

def hinge (u v : Zone) : Reel :=
  ((shade u v (fun _ => 1) (fun _ => I)).stack (snap u v)).stack
    (shade u v (fun _ => 1-I) (fun _ => 1+I))

def brick (u v : Zone) : Reel :=
  ((((hinge u v).stack (shade u v (fun _ => -3) (fun _ => 1))).stack
      (hinge u v)).stack (shade u v (fun _ => 2) (fun _ => 1))).stack (hinge u v)

def spark (u v : Zone) (f : Line) : Reel :=
  ((shade u v (fun i => (4*f i/5)⁻¹) (fun _ => 1)).stack (brick u v)).stack
    (shade u v (fun i => (-1/8)*(4*f i/5)) (fun _ => -1/6))

def blaze (f : Line) : Line := fun i => 1+ f i * starRingEnd ℂ (f i)

def flash (dst src : Zone) (f : Line) : Reel :=
  (spark dst src (blaze f)).stack (spark dst src (fun i => f i-blaze f i))

section
variable {u v : Zone} {n : ℕ} (h : u.Fits n) (g : v.Fits n)
  (hv : u.wide=v.wide) (hw : u.Sep v)

include h g hv hw

lemma sound_hinge : (hinge u v).Sound n :=
  ((sound_shade h g).stack (sound_snap h g hv hw)).stack (sound_shade h g)

lemma sound_brick : (brick u v).Sound n :=
  have hp := sound_hinge h g hv hw
  ((((hp.stack (sound_shade h g)).stack hp).stack (sound_shade h g)).stack hp)

lemma sound_spark (f : Line) : (spark u v f).Sound n :=
  ((sound_shade h g).stack (sound_brick h g hv hw)).stack (sound_shade h g)

lemma sound_flash (f : Line) : (flash u v f).Sound n :=
  (sound_spark h g hv hw _).stack (sound_spark h g hv hw _)

omit h g

lemma twins_hinge :
    Twins (hinge u v) u v (fun _ t => (t.1+t.2,t.1-t.2)) := by
  unfold hinge
  refine (((twins_shade hv hw _ _).stack (twins_snap hv hw)).stack
    (twins_shade hv hw _ _)).congr ?_
  intro i hi t
  apply Prod.ext
  · apply Complex.ext <;> norm_num [ca,cb,mul_re,mul_im] <;> ring
  · apply Complex.ext <;> norm_num [ca,cb,mul_re,mul_im] <;> ring

lemma twins_brick :
    Twins (brick u v) u v (fun _ t => (-8*t.1-10*t.2,-6*t.2)) := by
  unfold brick
  have hp := twins_hinge hv hw
  refine (((((hp.stack (twins_shade hv hw _ _)).stack hp).stack (twins_shade hv hw _ _)).stack hp)).congr ?_
  intro i hi t
  apply Prod.ext <;> dsimp <;> ring

lemma twins_spark (f : Line) (hh : ∀ i<u.wide, f i ≠ 0) :
    Twins (spark u v f) u v (fun i t => (t.1+f i*t.2,t.2)) := by
  unfold spark
  refine (((twins_shade hv hw _ _).stack (twins_brick hv hw)).stack
    (twins_shade hv hw _ _)).congr ?_
  intro i hi t
  have hz := hh i hi
  apply Prod.ext <;> dsimp
  · field_simp
    ring
  · ring

omit hv hw

lemma blaze_ne (f : Line) (i : ℕ) : blaze f i ≠ 0 := by
  rw [blaze,Complex.mul_conj]
  intro h
  have H := congrArg re h
  simp [normSq_apply] at H
  nlinarith

lemma after_ne (f : Line) (i : ℕ) : f i-blaze f i ≠ 0 := by
  rw [blaze,Complex.mul_conj]
  intro h
  have H := congrArg re h
  simp [normSq_apply] at H
  nlinarith

include hv hw

lemma twins_flash (f : Line) :
    Twins (flash u v f) u v (fun i t => (t.1+f i*t.2,t.2)) := by
  unfold flash
  refine ((twins_spark hv hw (blaze f) (fun i _ => blaze_ne f i)).stack (twins_spark hv hw
    (fun i => f i-blaze f i) (fun i _ => after_ne f i))).congr ?_
  intro i hi t
  apply Prod.ext
  · dsimp; ring
  · rfl

lemma spill_flash (f : Line) :
    Spill (flash u v f) v u (fun x i => f i * x i) := by
  have h := twins_flash hv hw f
  constructor
  · intro x i hi
    exact congrArg Prod.fst (h.acts x i hi)
  · intro x i hi
    by_cases hk : v.has i
    · have hh := congrArg Prod.snd (h.acts x (i-v.lo) (hv.symm ▸ v.enter hk))
      simpa [Zone.peek,drift,twinsAt, v.identify hk] using hh
    · exact h.waits x i hi hk

end

@[simp] lemma beats_shade (u v : Zone) (f g : Line) : (shade u v f g).beats=1 := rfl
@[simp] lemma beats_snap (u v : Zone) : (snap u v).beats=1 := rfl
@[simp] lemma beats_hinge (u v : Zone) : (hinge u v).beats=3 := rfl
@[simp] lemma beats_brick (u v : Zone) : (brick u v).beats=11 := rfl
@[simp] lemma beats_spark (u v : Zone) (f : Line) : (spark u v f).beats=13 := rfl
@[simp] lemma beats_flash (u v : Zone) (f : Line) : (flash u v f).beats=26 := rfl

end
end PowerSaving.Slant

end OAI
namespace OAI

namespace PowerSaving.Slant
open Reel Stroke Zone Spectral
noncomputable section

def initial (n : ℕ) : Zone := ⟨0,n⟩
def ending (n : ℕ) : Zone := ⟨n,n⟩

lemma half_fits (n : ℕ) : (initial n).Fits (n+n) ∧ (ending n).Fits (n+n) :=
  ⟨fits_of _ _ (by change 0+n ≤ _; omega),fits_of _ _ le_rfl⟩
lemma half_sep (n : ℕ) : (initial n).Sep (ending n) :=
  sep_of _ _ (by change 0+n ≤ n; omega)

def deal (n i : ℕ) := if i<n then 2*i else 2*(i-n)+1

def foldPair (n : ℕ) (u : ℂ) : Reel :=
  (shade (initial n) (ending n) (fun _ => 1) (fun i => u^i)).stack
    (hinge (initial n) (ending n))

def duo (n : ℕ) (u : ℂ) (r : Reel) : Reel :=
  ((lace (n+n) (deal n)).stack (parallel n r r)).stack (foldPair n u)

def pulse : ℕ → ℂ → Reel
  | 0,_ => wait 0
  | d+1,u => duo (2^d) u (pulse d (u^2))

lemma sound_foldPair (n : ℕ) (u : ℂ) : (foldPair n u).Sound (n+n) :=
  ((sound_shade (half_fits n).1 (half_fits n).2).stack
    (sound_hinge (half_fits n).1 (half_fits n).2 rfl (half_sep n)))

lemma sound_duo (n : ℕ) (u : ℂ) (r : Reel) (h : r.Sound n) :
    (duo n u r).Sound (n+n) :=
  ((sound_lace (n+n) (deal n) (by
    intro i hi
    unfold deal
    split <;> omega)).stack (h.parallel h rfl)).stack (sound_foldPair n u)

lemma sound_pulse (d : ℕ) (u : ℂ) : (pulse d u).Sound (2^d) := by
  induction d generalizing u with
  | zero => exact sound_wait 0 _
  | succ d ih =>
    rw [pulse, pow_succ (2:ℕ) d, mul_two]
    exact sound_duo _ u _ (ih _)

lemma beats_duo (n : ℕ) (u : ℂ) (r : Reel) : (duo n u r).beats=r.beats+5 := by
  change 1+r.beats+(1+3)=_
  omega

lemma beats_pulse (d : ℕ) (u : ℂ) : (pulse d u).beats=5*d := by
  induction d generalizing u with
  | zero => rfl
  | succ d ih =>
    rw [pulse, beats_duo,ih]; omega

def Flows (r : Reel) (n : ℕ) (f : Line→Line) : Prop :=
  ∀ x, ∀ i<n, r.go x i=f x i

lemma go_foldPair (n : ℕ) (u : ℂ) (x : Line) (i : ℕ) (h : i<n) :
    let z := (foldPair n u).go x
    z i = x i + u^i*x (n+i) ∧
    z (n+i) = x i - u^i*x (n+i) := by
  have hh := ((twins_shade (u:=initial n) (v:=ending n) rfl (half_sep n) (fun _ => 1)
    (fun i => u^i)).stack (twins_hinge rfl (half_sep n))).acts x i h
  simpa [foldPair,twinsAt,Zone.peek,drift,initial,ending,
    Prod.mk.injEq] using hh

lemma flows_duo (n : ℕ) (u : ℂ) (r : Reel) (hn : 0<n)
    (hu : IsPrimitiveRoot u (n+n)) (h : r.Sound n) (hf : Flows r n (freq n (u^2))) :
    Flows (duo n u r) (n+n) (freq (n+n) u) := by
  intro x
  let y := (lace (n+n) (deal n)).go x
  let z := (parallel n r r).go y
  have A (i : ℕ) (hi : i<n) : y i=x (2*i) := by
    rw [show y=(lace (n+n) (deal n)).go x from rfl,go_lace _ _ _ _ (by omega),
      deal,ite_eq_left hi]
  have B (i : ℕ) (hi : i<n) : drift n y i=x (2*i+1) := by
    unfold drift y
    rw [go_lace _ _ _ _ (by omega),deal]
    simp
  have U (i : ℕ) (hi : i<n) : z i=freq n (u^2) (fun j => x (2*j)) i := by
    unfold z
    rw [parallel_left n r r h y i hi,hf y i hi, freq_congr (y:=fun j => x (2*j)) A]
  have V (i : ℕ) (hi : i<n) : z (n+i)=freq n (u^2) (fun j => x (2*j+1)) i := by
    change drift n ((parallel n r r).go y) i=_
    rw [parallel_right n r r rfl,hf _ i hi,freq_congr B]
  intro i hi
  simp only [duo,go_stack]
  change (foldPair n u).go z i=_
  rcases lt_or_ge i n with hg|hg
  · rw [(go_foldPair n u z i hg).1, U i hg,V i hg,freq_eo]
  · obtain ⟨j,rfl⟩ := Nat.exists_eq_add_of_le hg
    have HH : j<n := by omega
    rw [(go_foldPair n u z j HH).2,U j HH,V j HH,freq_eo' hn hu]

lemma flows_pulse (d : ℕ) (u : ℂ) (h : IsPrimitiveRoot u (2^d)) :
    Flows (pulse d u) (2^d) (freq (2^d) u) := by
  induction d generalizing u with
  | zero =>
    intro x i hi
    simp at hi
    simp [pulse,freq,hi]
  | succ d ih =>
    rw [pulse,pow_succ (2:ℕ) d,mul_two]
    rw [pow_succ,mul_two] at h
    exact flows_duo _ u _ (by positivity) h (sound_pulse d _) (ih _ (even_prim h))

def backPulse (d : ℕ) (u : ℂ) : Reel :=
  (pulse d u⁻¹).stack (swatch (2^d) (fun _ => (((2^d:ℕ):ℂ))⁻¹))

lemma sound_back (d : ℕ) (u : ℂ) : (backPulse d u).Sound (2^d) :=
  (sound_pulse d _).stack (sound_swatch _ _)

lemma beats_back (d : ℕ) (u : ℂ) : (backPulse d u).beats=5*d+1 := by
  change (pulse d u⁻¹).beats+1=_
  rw [beats_pulse]

lemma flows_back (d : ℕ) (u : ℂ) (h : IsPrimitiveRoot u (2^d)) :
    Flows (backPulse d u) (2^d) (fun x i => (((2^d:ℕ):ℂ))⁻¹ * freq (2^d) u⁻¹ x i) := by
  intro x i hi
  rw [backPulse,go_stack,go_swatch _ _ _ _ hi, flows_pulse d _ h.inv _ i hi]

structure Retrace (r : Reel) (u : Zone) (f : Line→Line) : Prop where
  draws : ∀ x, ∀ i<u.wide, u.peek (r.go x) i=f (u.peek x) i
  waits : ∀ x i, ¬u.has i → r.go x i=x i

lemma atBase_retrace {a : Reel} {z : Zone} {f : Line→Line} (h : a.Sound z.wide)
    (g : Flows a z.wide f) :
    Retrace (atBase z.lo a) z f := by
  refine ⟨fun x i hi => ?_,fun x i hi => ?_⟩
  · unfold Zone.peek drift
    rw [atBase_right]
    exact g _ i hi
  · cases z.boundary hi with
    | inl hp => exact atBase_left z.lo a x i hp
    | inr hp => exact (h.atBase z.lo).still x i hp

lemma retrace_preserve {a : Reel} {u v : Zone} {f : Line→Line} (h : Retrace a u f)
    (g : v.Sep u) (x : Line) (i : ℕ) (hi : i<v.wide) :
    v.peek (a.go x) i=v.peek x i := h.waits x _ (g _ (v.inside hi))

end
end PowerSaving.Slant

end OAI
namespace OAI

namespace PowerSaving.Slant
open Reel Zone Stroke Spectral Finset
noncomputable section

def eddy (d : ℕ) (r : ℂ) (u v : Zone) (h : Line) : Reel :=
  let p := pulse d r; let b := backPulse d r
  let f := flash v u (freq (2^d) r h)
  ((((atBase u.lo p).stack (atBase v.lo p)).stack f).stack (atBase u.lo b)).stack
    (atBase v.lo b)

lemma beat_mounted (p : ℕ) (r : Reel) : (atBase p r).beats=r.beats := rfl

lemma beats_eddy (d : ℕ) (r : ℂ) (u v : Zone) (h : Line) :
    (eddy d r u v h).beats=20*d+28 := by
  unfold eddy; dsimp only
  simp only [stack,beat_mounted,beats_pulse,beats_flash,beats_back]
  omega

lemma Zone.Fits.end_le {v : Zone} {n : ℕ} (hv : v.Fits n) (hp : 0<v.wide) :
    v.lo+v.wide ≤ n := by
  have := hv _ (v.inside (by omega : v.wide-1<v.wide))
  omega

lemma Zone.Fits.mount {v : Zone} {n : ℕ} (hv : v.Fits n) (hp : 0<v.wide)
    {r : Reel} (h : r.Sound v.wide) :
    (atBase v.lo r).Sound n :=
  (h.atBase _).wider (hv.end_le hp)

section
variable {u v : Zone} {d n : ℕ} (r : ℂ) (h : Line) (hu : u.wide=2^d)
  (hv : v.wide=2^d) (hs : u.Sep v)

include hu hv hs
theorem sound_eddy (pu : u.Fits n) (pv : v.Fits n) :
    (eddy d r u v h).Sound n := by
  have HU {a : Reel} (h : a.Sound (2^d)) :=
    pu.mount (by rw [hu]; positivity) (show a.Sound u.wide by rwa [hu])
  have HV {a : Reel} (h : a.Sound (2^d)) :=
    pv.mount (by rw [hv]; positivity) (show a.Sound v.wide by rwa [hv])
  have hq : v.wide=u.wide := hv.trans hu.symm
  exact ((((HU (sound_pulse d r)).stack (HV (sound_pulse d r))).stack
    (sound_flash pv pu hq hs.symm _)).stack (HU (sound_back d r))).stack
    (HV (sound_back d r))

theorem spill_eddy (hr : IsPrimitiveRoot r (2^d)) :
    Spill (eddy d r u v h) u v (cyclic (2^d) h) := by
  let q := 2^d
  let f := freq q r
  let g := fun (x : Line) (i : ℕ) => (q:ℂ)⁻¹ * freq q r⁻¹ x i
  let p := pulse d r; let b := backPulse d r
  let pa := atBase u.lo p; let pb := atBase v.lo p
  let ba := atBase u.lo b; let bb := atBase v.lo b
  let fl := flash v u (f h)
  have hq : v.wide=u.wide := hv.trans hu.symm
  have h1 : Retrace pa u f := atBase_retrace (by rw [hu]; exact sound_pulse d _)
    (by rw [hu]; exact flows_pulse d _ hr)
  have h2 : Retrace pb v f := atBase_retrace (by rw [hv]; exact sound_pulse d _)
    (by rw [hv]; exact flows_pulse d _ hr)
  have h4 : Retrace ba u g := atBase_retrace (by rw [hu]; exact sound_back d _)
    (by rw [hu]; exact flows_back d _ hr)
  have h5 : Retrace bb v g := atBase_retrace (by rw [hv]; exact sound_back d _)
    (by rw [hv]; exact flows_back d _ hr)
  have h3 : Spill fl u v (fun x i => f h i*x i) := spill_flash hq hs.symm (f h)
  have gf (x y : Line) (i : ℕ) (hi : i<q) (H : ∀ i<q, x i=f y i) :
      g x i=y i := by
    unfold g
    rw [freq_congr H]
    exact freq_inv hr y i hi
  change u.wide=q at hu; change v.wide=q at hv
  have clean (x : Line) (i : ℕ) (hi : i<u.wide) :
      u.peek ((eddy d r u v h).go x) i=u.peek x i := by
    change u.peek (((((pa.stack pb).stack fl).stack ba).stack bb).go x) i=_
    simp only [go_stack]
    rw [retrace_preserve h5 hs _ i hi,h4.draws _ i hi]
    refine gf _ _ i (hu ▸ hi) ?_
    intro j hj
    have hk : j<u.wide := hu.symm ▸ hj
    rw [h3.preserves hs _ j hk,retrace_preserve h2 hs _ j hk,h1.draws _ j hk]
  constructor
  · intro x i hi
    change v.peek (((((pa.stack pb).stack fl).stack ba).stack bb).go x) i=_
    simp only [go_stack]
    rw [h5.draws _ i hi]
    refine gf _ (v.peek x + cyclic q h (u.peek x)) i (hv ▸ hi) ?_
    intro j hj
    have hk : j<v.wide := hv.symm ▸ hj
    have hp : j<u.wide := hq ▸ hk
    rw [retrace_preserve h4 hs.symm _ j hk,h3.adds _ j hk,h2.draws _ j hk]
    rw [retrace_preserve h2 hs _ j hp, h1.draws _ j hp]
    have hx : freq q r (v.peek (pa.go x)) = f (v.peek x) := freq_congr
      (fun j hj => retrace_preserve h1 hs.symm _ j (hv.symm ▸ hj)) r
    unfold f
    rw [hx, freq_add]
    exact congr_arg (freq q r (v.peek x) j + ·) (freq_cyclic hr.pow_eq_one _ _ _).symm
  · intro x i hi
    by_cases hh : u.has i
    · have H := clean x (i-u.lo) (u.enter hh)
      simpa [Zone.peek,Stroke.drift,u.identify hh] using H
    · change ((((pa.stack pb).stack fl).stack ba).stack bb).go x i=_
      simp only [go_stack]
      rw [h5.waits _ i hi,h4.waits _ i hh,h3.keeps _ i hi,h2.waits _ i hi,h1.waits _ i hh]

end

lemma cyclic_reads (v : ℕ) (h : Line) : Reads v v (cyclic v h) := by
  intro x y hxy i hi
  unfold cyclic
  exact sum_congr rfl fun _ hj => congr_arg (_*·) (hxy _ (mem_range.mp hj))

lemma cyclic_add (v : ℕ) (h : Line) : AdditiveOn v (cyclic v h) := by
  intro x y i _
  simp [cyclic,mul_add,sum_add_distrib]

lemma cyclic_neg (v : ℕ) (h : Line) :
    cyclic v (fun i => -h i) = minusFn (cyclic v h) := by
  ext x i
  simp [cyclic,minusFn]

end
end PowerSaving.Slant

end OAI
namespace OAI

namespace PowerSaving.Slant
open Reel Stroke Zone Spectral Finset
noncomputable section

def trail (u a : Zone) (t : ℂ) : Reel :=
  flash (a.slim u.wide) u (fun _ => t)

def slice (a v : Zone) (t : ℂ) : Reel :=
  flash v (a.slim v.wide) (fun _ => t)

def pad (s : ℕ) (t : ℂ) (x : Line) : Line :=
  fun i => if i<s then t*x i else 0

def trim (t : ℂ) (x : Line) : Line := fun i => t*x i

lemma Reads.chain {m n l : ℕ} {f g : Line→Line}
    (h : Reads m n f) (hh : Reads n l g) : Reads m l (g ∘ f) :=
  fun x y hx => hh _ _ (h x y hx)

lemma reads_pad (s n : ℕ) (t : ℂ) : Reads s n (pad s t) := by
  intro x y hx i _
  by_cases h : i<s
  · simp only [pad, ite_eq_left h]
    rw [hx i h]
  · simp [pad, h]

lemma reads_trim (n v : ℕ) (t : ℂ) (hp : v ≤ n) : Reads n v (trim t) :=
  fun _ _ h i hi => congr_arg (t*·) (h i (hi.trans_le hp))

lemma additive_trim (n : ℕ) (t : ℂ) : AdditiveOn n (trim t) :=
  fun x y i _ => mul_add t (x i) (y i)

lemma pad_neg (s : ℕ) (t : ℂ) : pad s (-t) = minusFn (pad s t) := by
  ext x i
  by_cases i<s <;> simp [pad,minusFn, *]

lemma trim_neg (t : ℂ) : trim (-t) = minusFn (trim t) := by
  ext x i
  simp [trim,minusFn]

lemma broader_pad {u a : Zone} {r : Reel} (h : u.wide ≤ a.wide) (t : ℂ)
    (hh : Spill r u (a.slim u.wide) (fun x i => t*x i)) :
    Spill r u a (pad u.wide t) := by
  constructor
  · intro x i hi
    by_cases hq : i<u.wide
    · simp only [pad,ite_eq_left hq]
      exact hh.adds x i hq
    · simp only [pad,ite_eq_right hq,add_zero]
      change r.go x (a.lo+i)=_
      exact hh.keeps x _ (by simp [Zone.has,Zone.slim,hq])
  · intro x i hi
    exact hh.keeps x i fun hg => hi (slim_has a h hg)

lemma broader_trim {u a : Zone} {r : Reel} (t : ℂ)
    (hh : Spill r (a.slim u.wide) u (fun x i => t*x i)) :
    Spill r a u (trim t) := ⟨hh.adds,hh.keeps⟩

section
variable {u a : Zone} (t : ℂ) (h : u.wide ≤ a.wide) (hs : u.Sep a)
include h hs

lemma sound_trail {n : ℕ} (hu : u.Fits n) (ha : a.Fits n) :
    (trail u a t).Sound n :=
  sound_flash (ha.slim h) hu rfl (hs.slim_right h).symm _

lemma sound_slice {n : ℕ} (hu : u.Fits n) (ha : a.Fits n) :
    (slice a u t).Sound n :=
  sound_flash hu (ha.slim h) rfl (hs.slim_right h) _

lemma spill_trail : Spill (trail u a t) u a (pad u.wide t) := by
  unfold trail
  exact broader_pad h _ (spill_flash (u:=a.slim u.wide) (v:=u) rfl (hs.slim_right h).symm
    (fun _ => t))

lemma spill_slice : Spill (slice a u t) a u (trim t) := by
  unfold slice
  exact broader_trim _ (spill_flash (u:=u) (v:=a.slim u.wide) rfl (hs.slim_right h)
    (fun _ => t))

end

def duct (d : ℕ) (r : ℂ) (u a b : Zone) (h : Line) : Reel :=
  cameo (trail u a 1) (eddy d r a b h) (trail u a (-1))
    (eddy d r a b (fun i => -h i))

def well (d : ℕ) (r : ℂ) (u v a b : Zone) (h : Line) : Reel :=
  cameo (duct d r u a b h) (slice b v 1)
    (duct d r u a b (fun i => -h i)) (slice b v (-1))

lemma beats_cameo (a b c d : Reel) :
    (cameo a b c d).beats=a.beats+b.beats+c.beats+d.beats := rfl
lemma beats_duct (d : ℕ) (r : ℂ) (u a b : Zone) (h : Line) :
    (duct d r u a b h).beats=40*d+108 := by
  unfold duct; rw [beats_cameo]; simp_rw [trail,beats_flash,beats_eddy]; omega
lemma beats_well (d : ℕ) (r : ℂ) (u v a b : Zone) (h : Line) :
    (well d r u v a b h).beats=80*d+268 := by
  unfold well; rw [beats_cameo]; simp_rw [beats_duct,slice,beats_flash]; omega

section
variable {d n : ℕ} (r : ℂ) {u a b : Zone} (h : Line)
  (hu : u.wide ≤ a.wide)
  (ha : a.wide=2^d) (hb : b.wide=2^d)
  (hua : u.Sep a) (hab : a.Sep b)

include hu ha hb hua hab

lemma sound_duct (pu : u.Fits n) (pa : a.Fits n) (pb : b.Fits n) :
    (duct d r u a b h).Sound n :=
  sound_cameo _ _ _ _ n (sound_trail _ hu hua pu pa)
    (sound_eddy _ _ ha hb hab pa pb)
    (sound_trail _ hu hua pu pa) (sound_eddy _ _ ha hb hab pa pb)

lemma spill_duct (hr : IsPrimitiveRoot r (2^d)) (hub : u.Sep b) :
    Spill (duct d r u a b h) u b (cyclic (2^d) h ∘ pad u.wide 1) := by
  apply spill_cameo (spill_trail 1 hu hua) (spill_eddy r h ha hb hab hr)
  · rw [← pad_neg]; exact spill_trail _ hu hua
  · rw [← cyclic_neg]; exact spill_eddy r _ ha hb hab hr
  · exact reads_pad _ _ _
  · rw [ha,hb]; exact cyclic_reads _ h
  · rw [hb]; exact cyclic_add _ h
  · exact hub
  · exact hua
  · exact hab

variable {v : Zone} (hv : v.wide ≤ b.wide) (hvb : v.Sep b)
include hv hvb

lemma sound_well (pu : u.Fits n) (pv : v.Fits n) (pa : a.Fits n) (pb : b.Fits n) :
    (well d r u v a b h).Sound n :=
  sound_cameo _ _ _ _ n
    (sound_duct _ _ hu ha hb hua hab pu pa pb) (sound_slice _ hv hvb pv pb)
    (sound_duct _ _ hu ha hb hua hab pu pa pb) (sound_slice _ hv hvb pv pb)

lemma spill_well (hr : IsPrimitiveRoot r (2^d)) (hub : u.Sep b) (huv : u.Sep v) :
    Spill (well d r u v a b h) u v (trim 1 ∘ (cyclic (2^d) h ∘ pad u.wide 1)) := by
  apply spill_cameo (spill_duct _ h hu ha hb hua hab hr hub) (spill_slice 1 hv hvb)
  · have hz : minusFn (cyclic (2^d) h ∘ pad u.wide 1) =
        cyclic (2^d) (fun i => -h i) ∘ pad u.wide 1 := by
      rw [cyclic_neg]
      rfl
    rw [hz]; exact spill_duct _ _ hu ha hb hua hab hr hub
  · rw [← trim_neg]; exact spill_slice _ hv hvb
  · rw [hb]
    exact (reads_pad u.wide _ 1).chain (cyclic_reads _ h)
  · exact reads_trim _ _ _ hv
  · exact additive_trim _ _
  · exact huv
  · exact hub
  · exact hvb.symm

end

-- logical lower Toeplitz between offsets l (source), m (target), in different physical chunks.
def spout (e l m : ℕ) (h : Line) (x : Line) : Line :=
  fun i => ∑ j ∈ range e, rise h (m+i) (l+j)*x j

def skirt (b e s l m : ℕ) (h : Line) : Line :=
  fun k =>
    if k<b then
      if k<s then rise h (m+k) l else 0
    else
      if 0<s ∧ 2*b-k<e then rise h m (l+(2*b-k)) else 0

lemma skirt_spec (b e s l m : ℕ) (h : Line) (ha : e ≤ b) (hb : s ≤ b) (i j : ℕ)
    (hi : i<s) (hj : j<e) :
    skirt b e s l m h (predAt (2*b) i j)=rise h (m+i) (l+j) := by
  rcases lt_or_ge i j with hp|hp
  · simp only [predAt,ite_eq_right (show ¬j ≤ i by omega),
      skirt,ite_eq_right (show ¬i+2*b-j<b by omega),ite_eq_left (show 0<s ∧ 2*b-(i+2*b-j)<e
      from ⟨by omega,by omega⟩)]
    rw [show m+i=i+m by omega, show l+j=i+(l+(2*b-(i+2*b-j))) by omega, rise_both]
  · simp only [predAt,ite_eq_left hp,
      skirt,ite_eq_left (show i-j<b by omega),ite_eq_left (show i-j<s by omega)]
    rw [show m+i=j+(m+(i-j)) by omega, show l+j=j+l by omega, rise_both]

lemma trim_spout (b e s l m : ℕ) (h : Line) (ha : e ≤ b) (hb : s ≤ b)
    (x : Line) (i : ℕ) (hi : i<s) :
    trim 1 (cyclic (2*b) (skirt b e s l m h) (pad e 1 x)) i=spout e l m h x i := by
  unfold trim cyclic spout
  rw [one_mul]
  let f (j : ℕ) := skirt b e s l m h (predAt (2*b) i j)*pad e 1 x j
  change (∑ j ∈ range (2*b), f j)=_
  have H (j : ℕ) : f (e+j)=0 := by simp [f,pad]
  conv_lhs => rw [show 2*b=e+(2*b-e) by omega, sum_range_add]
  simp only [H,sum_const_zero,add_zero]
  refine sum_congr rfl ?_
  intro j hj
  replace hj := mem_range.mp hj
  simp only [f,skirt_spec b e s l m h ha hb i j hi hj,pad,ite_eq_left hj,one_mul]

lemma reads_spout (e l m s : ℕ) (h : Line) : Reads e s (spout e l m h) := by
  intro x y hp i hi
  exact sum_congr rfl fun j hj => congr_arg (_*·) (hp j (mem_range.mp hj))
lemma additive_spout (e l m s : ℕ) (h : Line) :
    AdditiveOn s (spout e l m h) := by
  intro x y i _
  simp [spout,sum_add_distrib,mul_add]
lemma spout_neg (e l m : ℕ) (h : Line) :
    spout e l m (fun i => -h i) = minusFn (spout e l m h) := by
  have H (i j : ℕ) : rise (fun a => -h a) i j = -rise h i j := by
    by_cases j ≤ i <;> simp [rise, *]
  ext x i
  simp [spout,H,minusFn]

def bore (k : ℕ) (r : ℂ) (u v a b : Zone) (l m : ℕ) (h : Line) : Reel :=
  well (k+1) r u v a b (skirt (2^k) u.wide v.wide l m h)

lemma beats_bore (k : ℕ) (r : ℂ) (u v a b : Zone) (l m : ℕ) (h : Line) :
    (bore k r u v a b l m h).beats=80*k+348 := by
  rw [bore,beats_well]; omega

section
variable {k n : ℕ} (r : ℂ) {u v a b : Zone} (l m : ℕ) (h : Line)
  (hu : u.wide ≤ 2^k) (hv : v.wide ≤ 2^k)
  (ha : a.wide=2^(k+1)) (hb : b.wide=2^(k+1))
  (hua : u.Sep a) (hab : a.Sep b) (hvb : v.Sep b)

include hu hv ha hb hua hab hvb

lemma sound_bore (pu : u.Fits n) (pv : v.Fits n) (pa : a.Fits n) (pb : b.Fits n) :
    (bore k r u v a b l m h).Sound n :=
  sound_well r _ (by rw [ha,pow_succ]; omega) ha hb hua hab
    (by rw [hb,pow_succ]; omega) hvb pu pv pa pb

lemma spill_bore (hr : IsPrimitiveRoot r (2^(k+1))) (hub : u.Sep b) (huv : u.Sep v) :
    Spill (bore k r u v a b l m h) u v (spout u.wide l m h) := by
  unfold bore
  refine (spill_well r _ (by rw [ha,pow_succ]; omega) ha hb hua hab
    (by rw [hb,pow_succ]; omega) hvb hr hub huv).congr ?_
  intro x i hi
  simp only [Function.comp_apply,pow_succ']
  exact trim_spout _ _ _ _ _ _ hu hv x i hi

end
end
end PowerSaving.Slant

end OAI
namespace OAI

namespace PowerSaving.Slant
open Reel Stroke Zone Spectral Finset
noncomputable section

def strand (a : ℕ → Reel) : ℕ → Reel
  | 0 => wait 0
  | i+1 => (strand a i).stack (a i)

lemma beat_strand {a : ℕ→Reel} (n d : ℕ) (h : ∀ i<n,(a i).beats=d) :
    (strand a n).beats=n*d := by
  induction n with
  | zero => simp [strand,wait]
  | succ n ih =>
    change (strand a n).beats+(a n).beats=_
    rw [ih (by intro i hi; exact h i (by omega)),h n (by omega),add_mul,one_mul]

lemma sound_strand {a : ℕ→Reel} (n m : ℕ) (h : ∀ i<n,(a i).Sound m) :
    (strand a n).Sound m := by
  induction n with
  | zero => exact sound_wait 0 m
  | succ n ih =>
    exact (ih (fun i hi => h i (by omega))).stack (h n (by omega))

def summary (n : ℕ) (f : ℕ → Line → Line) (x : Line) : Line :=
  fun i => ∑ j ∈ range n, f j x i

lemma reads_summary {a b : ℕ} (n : ℕ) (f : ℕ → Line→Line)
    (h : ∀ i<n, Reads a b (f i)) :
    Reads a b (summary n f) :=
  fun x y hx i hi => sum_congr rfl fun j hj => h j (mem_range.mp hj) x y hx i hi

lemma spill_strand {a : ℕ→Reel} (n : ℕ) (u v : Zone) (f : ℕ→Line→Line)
    (h : ∀ i<n, Spill (a i) u v (f i)) (hs : u.Sep v)
    (hr : ∀ i<n, Reads u.wide v.wide (f i)) :
    Spill (strand a n) u v (summary n f) := by
  induction n with
  | zero =>
    constructor
    · intro x i hi; simp [strand,summary]
    · intro x i hi; simp [strand]
  | succ n ih =>
    have hp := ih (fun i hi => h i (by omega)) (fun i hi => hr i (by omega))
    have hh := h n (by omega)
    constructor
    · intro x i hi
      rw [strand,go_stack,hh.adds _ i hi, hr n (by omega) _ _ (hp.preserves hs x) i hi,
        hp.adds x i hi]
      simp [summary,sum_range_succ,add_assoc]
    · intro x i hi
      rw [strand,go_stack,hh.keeps _ i hi,hp.keeps _ i hi]

def quay (b j : ℕ) : Zone := ⟨j*b,b⟩
def coast (p w : ℕ) : Zone := ⟨p,w⟩
def jetty (p w b s : ℕ) : Zone := ⟨p+s*b,min b (w-s*b)⟩

lemma quay_fits (l b j w : ℕ) (hj : j<l) : (quay b j).Fits (l*b+w) :=
  fits_of _ _ (by
    have h := Nat.mul_le_mul_right b hj
    change j*b+b ≤ _
    change (j+1)*b ≤ _ at h; rw [add_mul,one_mul] at h; omega)

lemma jetty_has (p w b s i : ℕ) (hi : (jetty p w b s).has i) :
    (coast p w).has i := by
  change p+s*b ≤ i ∧ i < p+s*b+min b (w-s*b) at hi
  change p ≤ i ∧ i < p+w
  omega

lemma jetty_fits (p w b s : ℕ) :
    (jetty p w b s).Fits (p+w) :=
  fun i hi => (jetty_has p w b s i hi).2

lemma body_sep (p w : ℕ) : (initial p).Sep (coast p w) :=
  sep_of _ _ (by change 0+p ≤ p; omega)

lemma quay_sep (l w b s j : ℕ) (hj : j<l) :
    (quay b j).Sep (jetty (l*b) w b s) := by
  intro i hi hk
  have h1 : i<l*b := by simpa using quay_fits l b j 0 hj i hi
  have h2 : l*b ≤ i := (jetty_has _ _ _ _ i hk).1
  omega

lemma quay_peek (b j p : ℕ) (x : Line) :
    (quay b j).peek ((initial p).peek x)=(quay b j).peek x := by
  ext i; simp [initial,Zone.peek,drift]

lemma spill_quay {u : Reel} {v : Zone} {p b j : ℕ} {f : Line→Line}
    (h : Spill u (quay b j) v f) :
    Spill u (initial p) v (fun x => f ((quay b j).peek x)) := by
  constructor
  · intro x i hi; rw [h.adds x i hi,quay_peek]
  · exact h.keeps

lemma reads_quay {l b j p : ℕ} {f : Line→Line} (hj : j<l) (h : Reads b p f) :
    Reads (initial (l*b)).wide p (fun x => f ((quay b j).peek x)) := by
  intro x y hx
  apply h
  intro i hi
  apply hx
  exact (by simpa [initial] using
    quay_fits l b j 0 hj _ ((quay b j).inside hi))

-- extend a jetty effect f (given with whole target indexing)
def jet_effect (p w b s : ℕ) (f : Line→Line) (x : Line) : Line :=
  fun i => if (jetty p w b s).has (p+i) then f x i else 0

lemma spill_jet {u : Reel} {v : Zone} {p w b s : ℕ} {f : Line→Line}
    (h : Spill u v (jetty p w b s) (fun x i => f x (s*b+i))) :
    Spill u v (coast p w) (jet_effect p w b s f) := by
  let M := jetty p w b s
  constructor
  · intro x i hi
    change u.go x (p+i) = _ + if M.has (p+i) then _ else _
    by_cases H : M.has (p+i)
    · simp only [ite_eq_left H]
      have hh := h.adds x (p+i-M.lo) (M.enter H)
      change u.go x (M.lo+(p+i-M.lo)) = x (M.lo+(p+i-M.lo))+_ at hh
      rw [M.identify H] at hh
      have hh' : s*b+(p+i-M.lo)=i := by
        have := M.identify H
        change p+s*b+(_-(p+s*b))=_ at this
        change s*b+(_-(p+s*b))=_
        omega
      rw [hh'] at hh
      exact hh
    · simp only [ite_eq_right H,add_zero]
      exact h.keeps x (p+i) H
  · intro x i hi
    exact h.keeps x i fun H => hi (jetty_has _ _ _ _ i H)

lemma reads_jet {p w b s n : ℕ} {f : Line→Line} (h : Reads n w f) :
    Reads n w (jet_effect p w b s f) := by
  intro x y H i hi
  simp only [jet_effect,h x y H i hi]

lemma sum_mult (f : ℕ→ℂ) (l b : ℕ) :
    ∑ j ∈ range (l*b), f j =
    ∑ j ∈ range l, ∑ k ∈ range b, f (j*b+k) := by
  induction l with
  | zero => simp
  | succ l ih =>
    rw [add_mul,one_mul,sum_range_add,ih,sum_range_succ]

lemma summary_jet (l p w b : ℕ) (hb : 0<b) (hw : w ≤ l*b) (f : Line→Line) :
    ∀ x, ∀ i<w, summary l (fun s => jet_effect p w b s f) x i = f x i := by
  intro x i hi
  let j := i/b
  have hl : j<l := (Nat.div_lt_iff_lt_mul hb).mpr (hi.trans_le hw)
  have hp : i=j*b+i%b := by
    unfold j; rw [mul_comm]; exact (Nat.div_add_mod i b).symm
  have hq : i%b<b := Nat.mod_lt _ hb
  have h (s : ℕ) : (jetty p w b s).has (p+i) ↔ s=j := by
    change (p+s*b ≤ p+i ∧ p+i < p+s*b+min b (w-s*b)) ↔ _
    constructor
    · intro H
      by_contra HH
      rcases lt_or_ge s j with hk|hk
      · have hh := Nat.mul_le_mul_right b hk
        change (s+1)*b ≤ _ at hh; rw [add_mul,one_mul] at hh
        omega
      · have hg := Nat.mul_le_mul_right b (show j+1 ≤ s by omega)
        rw [add_mul,one_mul] at hg
        omega
    · intro H; rw [H]; omega
  unfold summary
  simp [jet_effect,h,hl]

-- A piece effect for a target chunk s, intermediary chunk c and source chunk j.
def wave (p b s c j : ℕ) (h g : Line) : Line → Line :=
  (spout b (c*b) (p+s*b) h) ∘ (spout b (j*b) (c*b) g)

def surf (p : ℕ) (h g : Line) (x : Line) : Line :=
  fun i => stencil p h (stencil p g x) (p+i)

lemma wave_reads (p b s c j v : ℕ) (h g : Line) :
    Reads b v (wave p b s c j h g) :=
  (reads_spout b (j*b) (c*b) b g).chain (reads_spout b (c*b) (p+s*b) v h)

lemma surf_reads (p w : ℕ) (h g : Line) :
    Reads p w (surf p h g) := by
  intro x y hx i hi
  unfold surf; rw [stencil_congr _ g hx]

lemma wave_sum (l b s : ℕ) (h g x : Line) (i : ℕ) :
    (∑ c ∈ range l, ∑ j ∈ range l, wave (l*b) b s c j h g ((quay b j).peek x) i) =
    surf (l*b) h g x (s*b+i) := by
  simp only [wave, surf, Function.comp_apply, spout,stencil]
  -- expand RHS over corresponding chunks
  rw [sum_mult _ l b]
  have hp (k : ℕ) :
      ∑ j ∈ range (l*b), rise g k j*x j =
      ∑ j ∈ range l, ∑ a ∈ range b, rise g k (j*b+a) * x (j*b+a) := sum_mult ..
  simp only [hp,mul_sum]
  refine sum_congr rfl ?_
  intro c hc
  rw [sum_comm]
  simp only [add_assoc,quay,Zone.peek,drift]

def riprap (a : ℕ → ℕ → ℕ → Reel) (l : ℕ) : Reel :=
  strand (fun s => strand (fun c => strand (fun j => a s c j) l) l) l

lemma beats_riprap (a : ℕ → ℕ → ℕ → Reel) (l n : ℕ)
    (h : ∀ s<l, ∀ c<l, ∀ j<l, (a s c j).beats=n) :
    (riprap a l).beats=l*(l*(l*n)) :=
  beat_strand _ _ fun s hs => beat_strand _ _ fun c hc => beat_strand _ _ (h s hs c hc)

lemma sound_riprap (a : ℕ → ℕ → ℕ → Reel) (l n : ℕ)
    (h : ∀ s<l, ∀ c<l, ∀ j<l, (a s c j).Sound n) :
    (riprap a l).Sound n :=
  sound_strand _ _ fun s hs => sound_strand _ _ fun c hc => sound_strand _ _ (h s hs c hc)

lemma spill_riprap (a : ℕ → ℕ → ℕ → Reel) (l b w : ℕ) (h g : Line)
    (hb : 0<b) (hw : w ≤ l*b)
    (H : ∀ s<l, ∀ c<l, ∀ j<l,
      Spill (a s c j) (quay b j) (jetty (l*b) w b s) (wave (l*b) b s c j h g)) :
    Spill (riprap a l) (initial (l*b)) (coast (l*b) w) (surf (l*b) h g) := by
  let p := l*b
  let W s := jetty p w b s
  let f := surf p h g
  let q s := strand (fun c => strand (fun j => a s c j) l) l
  let T s c j (x : Line) := wave p b s c j h g ((quay b j).peek x)
  have hu (s : ℕ) (hs : s<l) :
      Spill (q s) (initial p) (W s) (fun x i => f x (s*b+i)) := by
    have hS : (initial p).Sep (W s) := fun i hi hg => body_sep p w _ hi (jetty_has _ _ _ _ i hg)
    have ht (c j : ℕ) (hj : j<l) :
        Reads (initial p).wide (W s).wide (T s c j) :=
      reads_quay hj (wave_reads _ _ _ _ _ _ h g)
    have G := spill_strand (a:=fun c => strand (fun j => a s c j) l) l (initial p)
      (W s) (fun c => summary l (T s c))
      (fun c hc => spill_strand l _ _ (T s c) (fun j hj => spill_quay
        (H s hs c hc j hj)) hS (ht c))
      hS (fun c _ => reads_summary l (T s c) (ht c))
    exact G.congr (fun x i _ => wave_sum l b s h g x i)
  have hh := spill_strand l (initial p) (coast p w) (fun s => jet_effect p w b s f)
    (a:=q) (fun s hs => spill_jet (hu s hs)) (body_sep p w)
    (fun _ _ => reads_jet (surf_reads p w h g))
  exact hh.congr (summary_jet l p w b hb hw f)

end
end PowerSaving.Slant

end OAI
namespace OAI

namespace PowerSaving.Slant
open Reel Stroke Zone Spectral Finset
noncomputable section

def far (b j : ℕ) := if j<8 then 8*b else 0

def trestle (b j : ℕ) : Zone := ⟨far b j, b⟩
def barrier (b j : ℕ) : Zone := ⟨far b j + b, 2*b⟩
def lockBay (b j : ℕ) : Zone := ⟨far b j + 3*b,2*b⟩

structure Wharf (p : ℕ) (u v z l m : Zone) : Prop where
  fitsU : u.Fits p
  fitsV : v.Fits p
  fitsZ : z.Fits p
  fitsL : l.Fits p
  fitsM : m.Fits p
  uz : u.Sep z
  ul : u.Sep l
  um : u.Sep m
  lm : l.Sep m
  zl : z.Sep l
  zm : z.Sep m
  uv : u.Sep v
  zv : z.Sep v
  vm : v.Sep m

lemma wharf (b j w s : ℕ) (hj : j<16) :
    Wharf (16*b+w) (quay b j) (jetty (16*b) w b s)
      (trestle b j) (barrier b j) (lockBay b j) := by
  let o := far b j
  have h := quay_fits 16 b j w hj
  have ho : o+8*b ≤ 16*b := by unfold o far; split <;> omega
  have bed (v t : ℕ) (hv : o ≤ v) (ht : v+t ≤ o+8*b) :
      (quay b j).Sep ⟨v,t⟩ := by
    rcases lt_or_ge j 8 with g|g
    · apply sep_of
      change j*b+b ≤ v
      have H := Nat.mul_le_mul_right b g
      change (j+1)*b ≤ _ at H; rw [add_mul,one_mul] at H
      simp only [o,far,ite_eq_left g] at hv
      omega
    · apply Zone.Sep.symm; apply sep_of
      change v+t ≤ j*b
      have H := Nat.mul_le_mul_right b g
      simp only [o,far,ite_eq_right (by omega : ¬j<8)] at ht; omega
  change Wharf (16*b+w) _ _ ⟨o,b⟩ ⟨o+b,2*b⟩ ⟨o+3*b,2*b⟩
  refine ⟨h,jetty_fits (16*b) w b s,
    fits_of _ _ (by change o+b ≤ _; omega),fits_of _ _ (by change o+b+2*b ≤ _; omega),
    fits_of _ _ (by change o+3*b+2*b ≤ _; omega),bed _ _ le_rfl (by omega),bed _ _ (by omega)
    (by omega),bed _ _ (by omega) (by omega),
    sep_of _ _ (by change o+b+2*b ≤ o+3*b; omega), sep_of _ _ le_rfl,
    sep_of _ _ (by change o+b ≤ o+3*b; omega),quay_sep 16 w b s j hj, ?_, ?_⟩
  · apply sep_of
    change o+b ≤ 16*b+_
    omega
  · apply Zone.Sep.symm; apply sep_of
    change o+3*b+2*b ≤ 16*b+_
    omega

def cliff (k : ℕ) (r : ℂ) (u v z l m : Zone) (b e y : ℕ) (h g : Line) : Reel :=
  cameo (bore k r u z l m b e g) (bore k r z v l m e y h)
    (bore k r u z l m b e (fun i => -g i)) (bore k r z v l m e y (fun i => -h i))

structure Slips (k : ℕ) (u v z l m : Zone) : Prop where
  uw : u.wide ≤ 2^k
  vw : v.wide ≤ 2^k
  zw : z.wide ≤ 2^k
  lw : l.wide=2^(k+1)
  mw : m.wide=2^(k+1)

lemma slips (k j w s : ℕ) :
    let b := 2^k
    Slips k (quay b j) (jetty (16*b) w b s) (trestle b j)
      (barrier b j) (lockBay b j) := by
  intro b
  refine ⟨le_rfl,min_le_left _ _,le_rfl,(pow_succ' _ _).symm,(pow_succ' _ _).symm⟩

section
variable {u v z l m : Zone} {k n : ℕ} (r : ℂ) (b e y : ℕ) (h g : Line)
  (H : Slips k u v z l m) (hf : Wharf n u v z l m)

include H hf

lemma sound_cliff :
    (cliff k r u v z l m b e y h g).Sound n := by
  have ha (g : Line) := sound_bore r b e g H.uw H.zw H.lw H.mw hf.ul hf.lm hf.zm
    hf.fitsU hf.fitsZ hf.fitsL hf.fitsM
  have hb (g : Line) := sound_bore r e y g H.zw H.vw H.lw H.mw hf.zl hf.lm hf.vm
    hf.fitsZ hf.fitsV hf.fitsL hf.fitsM
  exact sound_cameo _ _ _ _ n (ha _) (hb _) (ha _) (hb _)

lemma spill_cliff (hr : IsPrimitiveRoot r (2^(k+1))) :
    Spill (cliff k r u v z l m b e y h g) u v
      (spout z.wide e y h ∘ spout u.wide b e g) := by
  have ha (g : Line) := spill_bore r b e g H.uw H.zw H.lw H.mw hf.ul hf.lm hf.zm
    hr hf.um hf.uz
  have hb (h : Line) := spill_bore r e y h H.zw H.vw H.lw H.mw hf.zl hf.lm hf.vm
    hr hf.zm hf.zv
  apply spill_cameo (ha g) (hb h)
  · rw [← spout_neg]; exact ha _
  · rw [← spout_neg]; exact hb _
  · exact reads_spout _ b e _ g
  · exact reads_spout _ e y _ h
  · exact additive_spout _ e y _ h
  · exact hf.uv
  · exact hf.uz
  · exact hf.zv

end

def gravel (k : ℕ) (r : ℂ) (w : ℕ) (h g : Line) (s c j : ℕ) : Reel :=
  let b := 2^k
  let p := 16*b
  cliff k r (quay b j) (jetty p w b s) (trestle b j) (barrier b j)
    (lockBay b j) (j*b) (c*b) (p+s*b) h g

def reef (k : ℕ) (r : ℂ) (w : ℕ) (h g : Line) : Reel :=
  riprap (gravel k r w h g) 16

lemma beats_gravel (k : ℕ) (r : ℂ) (w : ℕ) (h g : Line) (s c j : ℕ) :
    (gravel k r w h g s c j).beats=4*(80*k+348) := by
  unfold gravel cliff
  dsimp only
  simp only [beats_cameo,beats_bore]; omega
lemma beats_reef (k : ℕ) (r : ℂ) (w : ℕ) (h g : Line) :
    (reef k r w h g).beats=16*(16*(16*(4*(80*k+348)))) :=
  beats_riprap _ _ _ (fun _ _ _ _ _ _ => beats_gravel k _ _ _ _ _ _ _)

lemma sound_gravel (k : ℕ) (r : ℂ) (w : ℕ) (h g : Line) (s c j : ℕ) (hj : j<16) :
    (gravel k r w h g s c j).Sound (16*2^k+w) :=
  sound_cliff r (j*_ ) (c*_) (16*2^k+s*_) h g (slips k j w s) (wharf (2^k) j w s hj)
lemma sound_reef (k : ℕ) (r : ℂ) (w : ℕ) (h g : Line) :
    (reef k r w h g).Sound (16*2^k+w) :=
  sound_riprap _ _ _ (fun _ _ _ _ j hj => sound_gravel k _ _ _ _ _ _ j hj)

lemma spill_gravel (k : ℕ) (r : ℂ) (w : ℕ) (h g : Line) (s c j : ℕ) (hj : j<16)
    (hr : IsPrimitiveRoot r (2^(k+1))) :
    Spill (gravel k r w h g s c j) (quay (2^k) j)
      (jetty (16*2^k) w (2^k) s) (wave (16*2^k) (2^k) s c j h g) :=
  spill_cliff r (j*2^k) (c*2^k) (16*2^k+s*2^k) h g (slips k j w s)
    (wharf (2^k) j w s hj) hr
lemma spill_reef (k : ℕ) (r : ℂ) (w : ℕ) (h g : Line) (hw : w ≤ 16*2^k)
    (hr : IsPrimitiveRoot r (2^(k+1))) :
    Spill (reef k r w h g) (initial (16*2^k)) (coast (16*2^k) w) (surf (16*2^k) h g) :=
  spill_riprap _ 16 _ w h g (by positivity) hw
    (fun s _ c _ j hj => spill_gravel k r w h g s c j hj hr)

-- b=1 small cross
def speck (p w : ℕ) (h g : Line) (s c j : ℕ) : Reel :=
  if s<w then flash (jetty p w 1 s) (quay 1 j) (fun _ => rise h (p+s) c*rise g c j)
  else wait 26

def sand (p w : ℕ) (h g : Line) : Reel := riprap (speck p w h g) p

lemma beats_speck (p w : ℕ) (h g : Line) (s c j : ℕ) :
    (speck p w h g s c j).beats=26 := by unfold speck; split; exact beats_flash _ _ _; rfl
lemma beats_sand (p w : ℕ) (h g : Line) : (sand p w h g).beats=p*(p*(p*26)) :=
  beats_riprap _ _ _ fun _ _ _ _ _ _ => beats_speck _ _ _ _ _ _ _

lemma quay_jet (p w j s : ℕ) (hj : j<p) :
    (jetty p w 1 s).Sep (quay 1 j) := by
  simpa only [mul_one] using (quay_sep p w 1 s j hj).symm
lemma sound_speck (p w : ℕ) (h g : Line) (s c j : ℕ) (hj : j<p) :
    (speck p w h g s c j).Sound (p+w) := by
  unfold speck; split
  · rename_i hs
    refine sound_flash (jetty_fits p w 1 s) ?_ ?_ (quay_jet p w j s hj) _
    · simpa only [mul_one] using quay_fits p 1 j w hj
    · change min 1 (w-s*1) = 1; omega
  · exact sound_wait 26 _
lemma sound_sand (p w : ℕ) (h g : Line) : (sand p w h g).Sound (p+w) :=
  sound_riprap _ _ _ fun _ _ _ _ j hj => sound_speck _ _ _ _ _ _ j hj

lemma spill_speck (p w : ℕ) (h g : Line) (s c j : ℕ) (hj : j<p) :
    Spill (speck p w h g s c j) (quay 1 j) (jetty p w 1 s) (wave p 1 s c j h g) := by
  unfold speck
  split
  · rename_i hs
    have hh : (jetty p w 1 s).wide = (quay 1 j).wide := by
      change min 1 (w-s*1)=1; omega
    refine (spill_flash hh (quay_jet p w j s hj) _).congr ?_
    intro x i hi
    rw [hh] at hi
    change i<1 at hi
    have h0 : i=0 := by omega
    simp only [wave,Function.comp_apply,h0,spout,sum_range_one,mul_one,add_zero,mul_assoc]
  · rename_i hs
    constructor
    · intro x i hi
      change i < min 1 (w-s*1) at hi; omega
    · intro x i hi; rw [go_wait]
lemma spill_sand (p w : ℕ) (h g : Line) (hw : w ≤ p) :
    Spill (sand p w h g) (initial p) (coast p w) (surf p h g) := by
  have hh s (_ : s<p) c (_ : c<p) j (hj : j<p) :
      Spill (speck p w h g s c j) (quay 1 j) (jetty (p*1) w 1 s) (wave (p*1) 1 s c j h g) :=
    by simpa only [mul_one] using spill_speck p w h g s c j hj
  unfold sand
  simpa only [mul_one] using
    spill_riprap (speck p w h g) p 1 w h g (by omega) (by omega) hh

end
end PowerSaving.Slant

end OAI
namespace OAI

namespace PowerSaving.Slant
open Reel Stroke Zone Spectral Finset
noncomputable section

def reachSize (e : ℕ) : ℕ :=
  if e<4 then let p := 2^e; p*(p*(p*26))
  else 16*(16*(16*(4*(80*(e-4)+348))))

def bridgeSpan (e w : ℕ) (h g r : Line) : Reel :=
  if e<4 then sand (2^e) w h g else reef (e-4) (r (e-4+1)) w h g

def Springs (e : ℕ) (r : Line) : Prop :=
  ∀ i ≤ e, IsPrimitiveRoot (r i) (2^i)

lemma beats_span (e w : ℕ) (h g r : Line) :
    (bridgeSpan e w h g r).beats = reachSize e := by
  unfold bridgeSpan reachSize; split
  · exact beats_sand _ _ _ _
  · exact beats_reef _ _ _ _ _

lemma desc_num (e : ℕ) (h : ¬ e<4) : 2^e=16*(2:ℕ)^(e-4) := by
  have hk : (2:ℕ)^e=2^(4+(e-4)) := by rw [show 4+(e-4)=e by omega]
  rw [hk,pow_add]; norm_num

lemma sound_span (e w : ℕ) (h g r : Line) :
    (bridgeSpan e w h g r).Sound (2^e+w) := by
  unfold bridgeSpan
  split
  · exact sound_sand _ _ _ _
  · rename_i hk
    rw [desc_num e hk]
    exact sound_reef _ _ _ _ _

lemma spill_span (e w : ℕ) (h g r : Line) (hw : w ≤ 2^e) (hr : Springs (e+1) r) :
    Spill (bridgeSpan e w h g r) (initial (2^e)) (coast (2^e) w) (surf (2^e) h g) := by
  unfold bridgeSpan; split
  · exact spill_sand (2^e) w h g hw
  · rename_i hk
    rw [desc_num e hk] at *
    exact spill_reef _ _ _ _ _ hw (hr _ (by omega))

lemma reach_le (e : ℕ) :
    reachSize e ≤ 10000000*(e+1) := by
  unfold reachSize; split
  · rename_i h
    interval_cases e <;> norm_num
  · omega

def chorus : ℕ → ℕ
  | 0 => 1
  | e+1 => chorus e + reachSize e

def hoop (e v : ℕ) (h g r : Line) (a b : Reel) : Reel :=
  let n := 2^e
  (parallel (min n v) a b).stack
    (if n<v then bridgeSpan e (v-n) h g r else wait (reachSize e))

def harp (h g r : Line) : ℕ → ℕ → Reel
  | 0,v => swatch v (fun _ => h 0)
  | e+1,v => hoop e v h g r (harp h g r e (min (2^e) v)) (harp h g r e (v-2^e))

lemma beats_hoop (e v : ℕ) (h g r : Line) (a b : Reel) :
    (hoop e v h g r a b).beats=a.beats+reachSize e := by
  unfold hoop; dsimp only
  split
  · exact congr_arg (a.beats+·) (beats_span _ _ _ _ _)
  · rfl

lemma beats_harp (h g r : Line) (e v : ℕ) :
    (harp h g r e v).beats=chorus e := by
  induction e generalizing v with
  | zero => rfl
  | succ e ih =>
    rw [harp,beats_hoop,ih,chorus]

lemma chorus_le (e : ℕ) :
    chorus e ≤ 10000000*(e+1)^2 := by
  induction e with
  | zero => simp [chorus]
  | succ e ih =>
    rw [chorus]
    have := reach_le e
    nlinarith

lemma sound_hoop (e v : ℕ) (h g r : Line) (a b : Reel) (hl : a.beats=b.beats)
    (ha : a.Sound (min (2^e) v)) (hb : b.Sound (v-2^e)) :
    (hoop e v h g r a b).Sound v := by
  have hs := ha.parallel hb hl
  have hp : min (2^e) v + (v-2^e)=v := by omega
  rw [hp] at hs
  unfold hoop; dsimp only
  apply hs.stack
  split
  · have H := sound_span e (v-2^e) h g r
    rwa [show 2^e+(v-2^e)=v by omega] at H
  · exact sound_wait _ _

lemma branch_smaller (e v : ℕ) (hv : v ≤ 2^(e+1)) : v-2^e ≤ 2^e := by
  rw [pow_succ,mul_two] at hv; omega

lemma sound_harp (h g r : Line) (e v : ℕ) (hv : v ≤ 2^e) :
    (harp h g r e v).Sound v := by
  induction e generalizing v with
  | zero => exact sound_swatch _ _
  | succ e ih =>
    rw [harp]
    apply sound_hoop
    · rw [beats_harp,beats_harp]
    · exact ih _ (min_le_left ..)
    · exact ih _ (branch_smaller e v hv)

lemma spill_after (v w : ℕ) (a b c : Reel) (h : Line) (hz : h 0 ≠ 0)
    (ha : a.Sound v) (hl : a.beats=b.beats)
    (fa : Flows a v (stencil v h)) (fb : Flows b w (stencil w h))
    (hh : Spill c (initial v) (coast v w) (surf v h (recoil h))) :
    Flows ((parallel v a b).stack c) (v+w) (stencil (v+w) h) := by
  intro x i hi
  let y := (parallel v a b).go x
  have A (j : ℕ) (hj : j<v) : y j=stencil v h x j :=
    (parallel_left v a b ha x j hj).trans (fa x j hj)
  have H := stencil_congr v (recoil h) (x:=(initial v).peek y) (y:=stencil v h x)
    (fun j hj => by simpa only [initial,Zone.peek,Stroke.drift,zero_add] using A j hj)
  rw [go_stack]
  change c.go y i=_
  rcases lt_or_ge i v with hp|hp
  · have hn : ¬ (coast v w).has i := by
      intro hh
      have gg : v ≤ i := hh.1; omega
    rw [hh.keeps y i hn,A i hp,stencil_left _ _ _ _ _ hp]
  · obtain ⟨j,rfl⟩ := Nat.exists_eq_add_of_le hp
    have hj : j<w := by omega
    have hs := hh.adds y j hj
    change c.go y (v+j) = y (v+j)+stencil _ h _ _ at hs
    rw [hs,H,stencil_right]
    have hz' := stencil_congr v h (x:=stencil v (recoil h) (stencil v h x))
      (y:=x) (recoil_back v h x hz)
    have hh' : y (v+j)=stencil w h (drift v x) j := by
      change drift v ((parallel v a b).go x) j=_
      rw [parallel_right v a b hl, fb (drift v x) j hj]
    rw [hz',hh']
    exact add_comm _ _

lemma flows_hoop (e v : ℕ) (h r : Line) (hz : h 0 ≠ 0)
    (a b : Reel) (hl : a.beats=b.beats) (hv : v ≤ 2^(e+1))
    (ha : a.Sound (min (2^e) v))
    (fa : Flows a (min (2^e) v) (stencil (min (2^e) v) h))
    (fb : Flows b (v-2^e) (stencil (v-2^e) h)) (hr : Springs (e+1) r) :
    Flows (hoop e v h (recoil h) r a b) v (stencil v h) := by
  unfold hoop; dsimp only
  split
  · rename_i hk
    have hg : min (2^e) v=2^e := by omega
    rw [hg] at ha fa ⊢
    have ht := spill_after (2^e) (v-2^e) a b _ h hz ha hl fa fb
      (spill_span e _ h (recoil h) r (branch_smaller e v hv) hr)
    rwa [show 2^e+(v-2^e)=v by omega] at ht
  · have hg : min (2^e) v=v := by omega
    rw [hg] at ha fa ⊢
    intro x i hi
    rw [go_stack, go_wait, parallel_left v a b ha x i hi]
    exact fa x i hi

lemma flows_harp (h r : Line) (e v : ℕ) (hv : v ≤ 2^e) (hz : h 0 ≠ 0)
    (hr : Springs e r) :
    Flows (harp h (recoil h) r e v) v (stencil v h) := by
  induction e generalizing v with
  | zero =>
    intro x i hi
    rw [harp,go_swatch v _ x i hi]
    have h1 : v=1 := by rw [pow_zero] at hv; omega
    simp only [h1, show i=0 by omega, stencil, sum_range_one,rise,le_refl,↓reduceIte,
      Nat.sub_self]
  | succ e ih =>
    rw [harp]
    have g : Springs e r := fun i hi => hr i (by omega)
    apply flows_hoop _ _ _ _ hz _ _ _ hv _ _ _ hr
    · rw [beats_harp,beats_harp]
    · exact sound_harp _ _ _ _ _ (min_le_left ..)
    · exact ih _ (min_le_left ..) g
    · exact ih _ (branch_smaller _ _ hv) g

end
end PowerSaving.Slant

end OAI
namespace OAI

namespace PowerSaving.Slant
open Reel Stroke Spectral Zone Matrix Finset
noncomputable section

def Creates (p : Reel) (n : ℕ) (M : RootMat n) : Prop :=
  ∀ x, front n (p.go x)=M *ᵥ front n x

lemma Creates.stack {p q : Reel} {n} {M N : RootMat n}
    (h : Creates p n M) (g : Creates q n N) :
    Creates (p.stack q) n (N*M) :=
  fun x => by rw [go_stack,g,h,Matrix.mulVec_mulVec]

lemma creates_swatch (n : ℕ) (f : Line) :
    Creates (swatch n f) n (fade n f) := by
  intro x; ext i
  change (swatch n f).go x i.val = _
  rw [go_swatch n f x _ i.isLt]
  change f i.val*x i.val=∑ j : Fin n, Matrix.diagonal (front n f) i j*front n x j
  simp [ite_mul, diagonal_apply,front]

lemma front_flows {p : Reel} {n : ℕ} {f : Line→Line} (h : Flows p n f) (x : Line) :
    front n (p.go x)=front n (f x) :=
  funext fun i => h x _ i.isLt

def echo (n : ℕ) : Reel := lace n fun i => n-1-i

lemma sound_echo (n : ℕ) : (echo n).Sound n :=
  sound_lace _ _ (fun i hi => by omega)
lemma echo_go (n : ℕ) (i : ℕ) (hi : i<n) (x : Line) :
    (echo n).go x i=x (n-1-i) := go_lace n _ x i hi

def coda (n : ℕ) (u : Reel) : Reel := ((echo n).stack u).stack (echo n)

lemma sound_coda (n : ℕ) (u : Reel) (h : u.Sound n) : (coda n u).Sound n :=
  ((sound_echo n).stack h).stack (sound_echo n)

lemma creep_coda (n : ℕ) (u : Reel) (h : Line) (hh : Flows u n (stencil n h)) :
    Flows (coda n u) n (creep n h) := by
  intro x i hi
  unfold coda
  rw [go_stack,go_stack,echo_go n i hi,hh _ _ (by omega)]
  exact (congrFun (stencil_congr n h (x:=(echo n).go x) (y:=fun j => x (n-1-j))
    (fun j hj => echo_go n j hj x)) _).trans (stencil_reversed n h x i hi)

def voices (n : ℕ) (u : ℂ) (p : Reel) : Reel :=
  ((swatch n (roof u)).stack p).stack (swatch n (gap u))

def repeatV (n : ℕ) (u : ℂ) (p : Reel) : Reel :=
  ((swatch n (gap u)).stack (coda n p)).stack (swatch n (roof u))

def ode (n : ℕ) (u : ℂ) (p : Reel) : Reel :=
  ((repeatV n u p).stack (swatch n (fun i => (cog u i)⁻¹))).stack (voices n u p)

def ballad (n : ℕ) (e : ℕ) (u : ℂ) (r : Line) : Reel :=
  let h := floorH u
  ode n u (harp h (recoil h) r e n)

lemma sound_ode (n : ℕ) (u : ℂ) (p : Reel) (h : p.Sound n) : (ode n u p).Sound n :=
  ((((sound_swatch n _).stack (sound_coda n p h)).stack (sound_swatch n _)).stack
    (sound_swatch n _)).stack (((sound_swatch n _).stack h).stack (sound_swatch n _))

lemma beats_ode (n : ℕ) (u : ℂ) (p : Reel) :
    (ode n u p).beats=2*p.beats+7 := by
  change 1+(1+p.beats+1)+1+1+(1+p.beats+1)=_
  omega

lemma fade_flip (n : ℕ) (d : Line) : (fade n d)ᵀ = fade n d := by
  ext i j
  rcases eq_or_ne i j with rfl|h <;> simp [fade, eq_comm, *]

lemma creates_voices (n : ℕ) (u : ℂ) (p : Reel) (h : Flows p n (stencil n (floorH u))) :
    Creates (voices n u p) n (steps n u) := by
  have hp : Creates p n (stairs n (floorH u)) :=
    fun x => (front_flows h x).trans (front_stencil _ _ x)
  have H := ((creates_swatch n (roof u)).stack hp).stack (creates_swatch n (gap u))
  rw [steps,Matrix.mul_assoc]
  exact H

lemma creates_repeatV (n : ℕ) (u : ℂ) (p : Reel) (h : Flows p n (stencil n (floorH u))) :
    Creates (repeatV n u p) n (steps n u)ᵀ := by
  have hp : Creates (coda n p) n (stairs n (floorH u))ᵀ :=
    fun x => (front_flows (creep_coda n p _ h) x).trans (front_creep _ _ x)
  have H := ((creates_swatch n (gap u)).stack hp).stack (creates_swatch n (roof u))
  rw [steps,transpose_mul,transpose_mul,fade_flip,fade_flip]
  exact H

lemma creates_ode (n : ℕ) (u : ℂ) (p : Reel) (h : Flows p n (stencil n (floorH u)))
    (hu : IsPrimitiveRoot u n) :
    Creates (ode n u p) n (winds n u) := by
  have H := ((creates_repeatV n u p h).stack (creates_swatch n (fun i => (cog u i)⁻¹))).stack
    (creates_voices n u p h)
  rw [winds_factor n u hu, Matrix.mul_assoc]
  exact H

lemma sound_ballad (n e : ℕ) (u : ℂ) (r : Line) (h : n ≤ 2^e) :
    (ballad n e u r).Sound n :=
  sound_ode n u _ (sound_harp _ _ r e n h)

lemma creates_ballad (n e : ℕ) (u : ℂ) (r : Line) (h : n ≤ 2^e) (hr : Springs e r)
    (hu : IsPrimitiveRoot u n) :
    Creates (ballad n e u r) n (winds n u) :=
  creates_ode _ _ _ (flows_harp _ _ _ _ h (by simp [floorH,gap]) hr) hu

def score (e : ℕ) := 2*chorus e+7

lemma beats_ballad (n e : ℕ) (u : ℂ) (r : Line) :
    (ballad n e u r).beats=score e := by
  unfold ballad
  dsimp only; rw [beats_ode,beats_harp]; rfl

lemma score_le (e : ℕ) : score e ≤ 20000000*(e+1)^2+7 := by
  have := chorus_le e
  unfold score; omega

end
end PowerSaving.Slant

end OAI
namespace OAI

namespace PowerSaving
noncomputable section

namespace Grove
open Slant Stroke Reel Spectral Matrix Finset Binary

abbrev Axes := ℕ → ℕ

def extent (r : Axes) : ℕ → ℕ
  | 0 => 1
  | j+1 => extent r j*r j

def Splits (r : Axes) (l : ℕ) := ∀ t<l, 2≤r t

namespace Splits
variable {r : Axes} {l : ℕ}

lemma cut (h : Splits r l) {j : ℕ} (g : j ≤ l) :
    Splits r j :=
  fun t ht => h t (ht.trans_le g)

lemma here (h : Splits r (l+1)) :
    0<r l := Nat.lt_of_lt_of_le (by norm_num) (h l (by omega))

lemma extent_pow (h : Splits r l) :
    2^l ≤ extent r l := by
  induction l with
  | zero => rfl
  | succ l ih => exact (pow_succ ..).le.trans (Nat.mul_le_mul
      (ih (h.cut (by omega))) (h l (by omega)))

lemma extent_pos (h : Splits r l) :
    0<extent r l :=
  Nat.lt_of_lt_of_le (by positivity) h.extent_pow

lemma extent_le {j : ℕ} (h : Splits r l) (hj : j≤l) :
    extent r j ≤ extent r l := by
  induction l with
  | zero =>
    obtain rfl : j=0 := by omega
    rfl
  | succ l ih =>
    by_cases hk : j=l+1
    · rw [hk]
    · refine le_trans (ih (h.cut (by omega)) (by omega)) ?_
      exact Nat.le_mul_of_pos_right _ h.here

lemma axes_le (h : Splits r l) :
    l < extent r l :=
  Nat.lt_of_lt_of_le (Nat.lt_two_pow_self) h.extent_pow

lemma tree_bound (h : Splits r l) :
    ∑ j ∈ range (l+1), extent r j < 2*extent r l := by
  induction l with
  | zero => simp [extent]
  | succ l ih =>
    rw [sum_range_succ]
    have hh := ih (h.cut (by omega))
    have hg : 2 * extent r l ≤ extent r (l+1) := by
      rw [extent,mul_comm]
      exact Nat.mul_le_mul_left _ (h l (by omega))
    omega

lemma div_lt (h : Splits r (l+1)) {i} (hi : i<extent r (l+1)) :
    i / r l < extent r l :=
  (Nat.div_lt_iff_lt_mul h.here).mpr hi

lemma mod_lt (h : Splits r (l+1)) (i : ℕ) :
    i%r l < r l := Nat.mod_lt _ h.here

lemma join_lt (_h : Splits r (l+1)) {a b} (ha : a < extent r l) (hb : b < r l) :
    a*r l+b < extent r (l+1) := by
  have hg := Nat.mul_le_mul_right (r l) (show a+1 ≤ extent r l from ha)
  rw [add_mul,one_mul] at hg
  rw [extent]
  omega

end Splits

lemma joined (i r : ℕ) : i/r*r+i%r=i := by rw [mul_comm]; exact Nat.div_add_mod i r
lemma chops (i j r : ℕ) (hj : j<r) :
    (i*r+j)/r=i := by
  rw [Nat.add_comm, Nat.add_mul_div_right _ _ (by omega),Nat.div_eq_of_lt hj,zero_add]
lemma chips (i j r : ℕ) (hj : j<r) :
    (i*r+j)%r=j := by
  simp [add_comm, Nat.mod_eq_of_lt hj]

abbrev Wood := ℕ → ℕ → ℂ

def knot (r : ℕ) (X Y : Wood) : Wood := fun i j =>
  ∑ k ∈ range r, X i k*Y k j

def graft (r : ℕ) (X : Wood) (v : Line) : Line := fun i =>
  ∑ k ∈ range r, X i k*v k

def white : Wood := fun i j => if j=i then 1 else 0

def frame (n : ℕ) (X : Wood) : RootMat n := fun i j => X i.val j.val

lemma front_graft (n : ℕ) (X : Wood) (x : Line) :
    front n (graft n X x) = frame n X *ᵥ front n x := by
  ext i
  exact (Fin.sum_univ_eq_sum_range _ _).symm

lemma graft_knot (r : ℕ) (X Y : Wood) (v : Line) :
    graft r (knot r X Y) v=graft r X (graft r Y v) := by
  ext i
  simp only [graft,knot,mul_sum,sum_mul]
  rw [sum_comm]
  simp only [mul_assoc]

lemma graft_white (r : ℕ) (v : Line) (i : ℕ) (hi : i<r) :
    graft r white v i = v i := by simp [white,graft,ite_mul,hi]

lemma graft_congr (r : ℕ) (X : Wood) (v w : Line) (h : ∀ i<r, v i=w i) :
    graft r X v=graft r X w := by
  ext i
  exact sum_congr rfl fun j hj => by rw [h j (mem_range.mp hj)]

def canopy (r : Axes) (X : ℕ → Wood) : ℕ → Wood
  | 0 => fun _ _ => 1
  | j+1 => fun i k => canopy r X j (i/r j) (k/r j) * X j (i%r j) (k%r j)

lemma canopy_knot (r : Axes) (X Y : ℕ → Wood) (l : ℕ) (h : Splits r l) :
    knot (extent r l) (canopy r X l) (canopy r Y l) =
    canopy r (fun i => knot (r i) (X i) (Y i)) l := by
  induction l with
  | zero => ext i j; simp [knot,extent,canopy]
  | succ l ih =>
    let U := canopy r X l
    let V := canopy r Y l
    rw [funext (show ∀ i, canopy r (fun i => knot (r i) (X i) (Y i)) (l+1) i = _
        from fun i => funext fun k => show canopy _ _ _ i k =
        knot _ U V (i/r l) (k/r l) * _ from by
          rw [ih (h.cut (by omega))]; rfl)]
    ext i j
    simp only [extent, canopy, knot]
    rw [sum_mult]
    simp only [U,V,sum_mul,mul_sum]
    conv_rhs => rw [sum_comm]
    refine sum_congr rfl ?_
    intro a ha
    refine sum_congr rfl ?_
    intro b hb
    rw [chops _ _ _ (mem_range.mp hb),chips _ _ _ (mem_range.mp hb)]
    ring

lemma canopy_white (r : Axes) (l : ℕ) (h : Splits r l) :
    ∀ i<extent r l, ∀ j<extent r l,
      canopy r (fun _ => white) l i j=white i j := by
  induction l with
  | zero =>
    intro i hi j hj
    change i<1 at hi; change j<1 at hj
    have h : i=j := by omega
    simp [h,white,canopy]
  | succ l ih =>
    intro i hi j hj
    simp only [canopy]; rw [ih (h.cut (by omega)) _ (h.div_lt hi) _ (h.div_lt hj)]
    unfold white
    have H : j/r l=i/r l → j%r l=i%r l → j=i := fun H J =>
      (joined j _).symm.trans (by rw [H,J,joined])
    split_ifs <;> simp_all

-- synchronization for a reel at every axis
def leafM (u : Stroke) : Wood :=
  fun i j => if j=u.ix i then u.dye i else 0

def leafC (u : Stroke) : Wood :=
  fun i j =>
    if u.partner i=i then white i j
    else (if j=i then ca else 0)+(if j=u.partner i then cb else 0)

lemma graft_leafM {n : ℕ} {u : Stroke} (h : u.Sound n) (v : Line) :
    ∀ i<n, graft n (leafM u) v i=u.applyM v i := by
  intro i hi; simp [graft,leafM,Stroke.applyM,ite_mul,h.bdix i hi]
lemma graft_leafC {n : ℕ} {u : Stroke} (h : u.Sound n) (v : Line) :
    ∀ i<n, graft n (leafC u) v i=u.applyC v i := by
  intro i hi
  by_cases g : u.partner i=i <;>
    simp [graft,leafC,white,Stroke.applyC,g,ite_mul,h.bdp i hi,hi,add_mul,sum_add_distrib]

def trunk (n : ℕ) (p : Reel) : ℕ → Wood
  | 0 => white
  | t+1 =>
    let u := p.atBeat t
    knot n (leafC u) (knot n (leafM u) (trunk n p t))

lemma graft_trunk (n : ℕ) (p : Reel) (h : p.Sound n) (t : ℕ) (ht : t≤p.beats) (v : Line) :
    ∀ i<n, graft n (trunk n p t) v i=p.reach v t i := by
  induction t with
  | zero => exact graft_white n v
  | succ t ih =>
    let u := p.atBeat t
    let g := graft n (leafM u) (graft n (trunk n p t) v)
    have hh := h t (by omega)
    have hg (i : ℕ) (hi : i<n) : g i=u.applyM (p.reach v t) i := by
      unfold g; rw [graft_leafM hh _ _ hi]; unfold Stroke.applyM
      rw [ih (by omega) _ (hh.bdix i hi)]
    intro i hi
    rw [trunk]
    rw [graft_knot,graft_knot,graft_leafC hh _ i hi]
    change u.applyC g i=u.applyC _ i
    unfold Stroke.applyC; rw [hg i hi,hg _ (hh.bdp i hi)]

def forest (r : Axes) (l : ℕ) (p : ℕ → Reel) (x : Line) : ℕ → Line
  | 0 => x
  | t+1 =>
    let M := canopy r (fun i => leafM ((p i).atBeat t)) l
    let C := canopy r (fun i => leafC ((p i).atBeat t)) l
    graft (extent r l) C (graft (extent r l) M (forest r l p x t))

lemma graft_forest (r : Axes) (l : ℕ) (p : ℕ → Reel) (h : Splits r l)
    (x : Line) (t : ℕ) :
    ∀ i<extent r l, graft (extent r l) (canopy r (fun j => trunk (r j) (p j) t) l) x i =
      forest r l p x t i := by
  induction t with
  | zero =>
    intro i hi
    change graft _ (canopy _ (fun _ => white) _) _ i = _
    rw [show graft _ (canopy _ (fun _ => white) _) _ i = graft (extent r l) white x i from
        sum_congr rfl fun j hj => by rw [canopy_white r l h i hi j (mem_range.mp hj)],
      graft_white _ _ i hi]
    rfl
  | succ t ih =>
    intro i _
    simp only [forest,trunk]
    rw [← canopy_knot _ _ _ _ h,← canopy_knot _ _ _ _ h,graft_knot,graft_knot]
    rw [graft_congr _ _ _ _ ih]

lemma trunk_creates {n : ℕ} {X : Wood} {p : Reel} (h : p.Sound n)
    (g : Creates p n (frame n X)) :
    ∀ i<n, ∀ j<n, trunk n p p.beats i j=X i j := by
  intro i hi j hj
  let v : Line := fun s => if s=j then 1 else 0
  have hh := graft_trunk n p h p.beats le_rfl v i hi
  have hg := congr_fun ((g v).trans (front_graft n X v).symm) (⟨i,hi⟩ : Fin n)
  change p.reach v p.beats i = graft n X v i at hg
  have ev (A : Wood) : graft n A v i=A i j := by simp [v,graft,mul_ite,hj]
  exact ((ev _).symm.trans hh).trans (hg.trans (ev X))

lemma canopy_congr (r : Axes) (l : ℕ) (h : Splits r l)
    (X Y : ℕ →Wood) (g : ∀ j<l, ∀ a<r j, ∀ b<r j, X j a b=Y j a b) :
    ∀ i<extent r l, ∀ j<extent r l,
      canopy r X l i j=canopy r Y l i j := by
  induction l with
  | zero => intros; rfl
  | succ l ih =>
    intro i hi k hk
    simp only [canopy]; rw [ih (h.cut (by omega)) (fun j hj => g j (by omega)) _ (h.div_lt hi) _
      (h.div_lt hk),g l (by omega) _ (h.mod_lt i) _ (h.mod_lt k)]

theorem forest_completes (r : Axes) (l : ℕ) (p : ℕ → Reel) (h : Splits r l) (b : ℕ)
    (hs : ∀ j<l, (p j).Sound (r j)) (hb : ∀ j<l, (p j).beats=b)
    (X : ℕ → Wood) (hx : ∀ j<l, Creates (p j) (r j) (frame (r j) (X j)))
    (x : Line) (i : ℕ) (hi : i<extent r l) :
    forest r l p x b i = graft (extent r l) (canopy r X l) x i := by
  rw [← graft_forest r l p h x b i hi]
  have hh (j : ℕ) (hj : j<l) :
      ∀ a<r j, ∀ c<r j, trunk (r j) (p j) b a c=X j a c := by
    rw [← hb j hj]; exact trunk_creates (hs j hj) (hx j hj)
  refine sum_congr rfl ?_
  intro c hc
  rw [canopy_congr r l h _ X hh i hi c (mem_range.mp hc)]

end Grove
end
end PowerSaving

end OAI
namespace OAI

namespace PowerSaving.Grove
open Slant Finset
noncomputable section

structure Reloc (n : ℕ) (q : ℕ → ℕ) : Prop where
  bd : ∀ j<n, q j<n
  inj : ∀ i<n, ∀ j<n, q i=q j → i=j

def seek (n : ℕ) (q : ℕ → ℕ) (i : ℕ) : ℕ := by
  classical
  exact if h : ∃ j : ℕ, j<n ∧ q j=i then Classical.choose h else 0

namespace Reloc
variable {n : ℕ} {q : ℕ→ℕ}

lemma onto (h : Reloc n q) : ∀ j<n, ∃ i<n, q i=j := by
  let f : Fin n → Fin n := fun i => ⟨q i.val,h.bd _ i.isLt⟩
  have g : Function.Injective f := by
    intro i j hij
    exact Fin.ext (h.inj _ i.isLt _ j.isLt (Fin.mk.inj hij))
  intro j hj
  obtain ⟨i,hi⟩ := (Finite.surjective_of_injective g) ⟨j,hj⟩
  exact ⟨i.val,i.isLt,Fin.mk.inj hi⟩

lemma seeks (h : Reloc n q) {i : ℕ} (hi : i<n) :
    seek n q i < n ∧ q (seek n q i) = i := by
  classical
  unfold seek; simp only [dite_eq_left (h.onto i hi)]
  exact Classical.choose_spec (h.onto i hi)

lemma seeks_at (h : Reloc n q) {i : ℕ} (hi : i<n) :
    seek n q (q i) = i :=
  let g := h.seeks (h.bd _ hi); h.inj _ g.1 i hi g.2

lemma sum {A : Type*} [AddCommMonoid A] (h : Reloc n q) (f : ℕ → A) :
    ∑ i ∈ range n, f (q i) = ∑ i ∈ range n, f i :=
  sum_bij (fun i _ => q i) (fun i hi => mem_range.mpr (h.bd i (mem_range.mp hi)))
    (fun a ha b hb hab => h.inj a (mem_range.mp ha) b (mem_range.mp hb) hab)
    (fun i hi => by
      obtain ⟨j,hj,g⟩ := h.onto i (mem_range.mp hi); exact ⟨j,mem_range.mpr hj,g⟩)
    (fun _ _ => rfl)

lemma sow {A : Type*} (h : Reloc n q) (f : ℕ → A) (z : A) :
    Tape.sow n n z (fun i => (q i,f i)) = Tape.tab n (fun i => f (seek n q i)) := by
  apply Tape.ext_look (by simp) z
  intro i hi
  have hi' : i<n := by simpa using hi
  rw [Tape.look_tab, ite_eq_left hi']
  have g := h.seeks hi'
  refine Tape.sow_look_written hi' g.1 g.2 ?_
  intro s hs hk hsi
  have hh := h.inj _ hk _ g.1 (Eq.trans hsi g.2.symm)
  omega

end Reloc

structure Shard where
  start : ℕ
  width : ℕ
  height : ℕ
  seat : ℕ
deriving DecidableEq

namespace Shard

def tip (s : Shard) := s.start+s.width
def addr (s : Shard) := s.start+s.seat

structure Mark (s : Shard) (n l : ℕ) : Prop where
  endsBy : s.tip ≤ n
  size : s.width=2^s.height
  tall : s.height ≤ l
  place : s.seat < s.width

namespace Mark
variable {s : Shard} {n l : ℕ}
lemma small (h : Mark s n l) : s.addr < s.tip :=
  Nat.add_lt_add_left h.place _
lemma positive (h : Mark s n l) : 0<s.width := by rw [h.size]; positivity
lemma starts (h : Mark s n l) : s.start < s.tip :=
  Nat.lt_add_of_pos_right h.positive
end Mark

def same (s t : Shard) : Prop :=
  s.start=t.start ∧ s.width=t.width ∧ s.height=t.height

def fits (s t : Shard) : Prop :=
  same s t ∨ s.tip ≤ t.start ∨ t.tip ≤ s.start

structure Quilt (n l : ℕ) (f : ℕ → Shard) : Prop where
  mark : ∀ i<n, (f i).Mark n l
  seam : ∀ i<n, ∀ j<n, (f i).fits (f j)
  fiber : ∀ i<n, ∀ j<n, (f i).addr=(f j).addr → i=j

def patch (n : ℕ) (f : ℕ → Shard) (j : ℕ) :=
  f (seek n (fun i => (f i).addr) j)

namespace Quilt
variable {n l : ℕ} {f : ℕ → Shard}

lemma reloc (h : Quilt n l f) : Reloc n fun i => (f i).addr :=
  ⟨fun i hi => ((h.mark i hi).small).trans_le (h.mark i hi).endsBy,h.fiber⟩

lemma aligns (h : Quilt n l f) {i j : ℕ} (hi : i<n) (hj : j<n)
    (H : (f i).start < (f j).tip) (G : (f j).start < (f i).tip) :
    (f i).same (f j) :=
  (h.seam i hi j hj).resolve_right fun hh => hh.elim (not_le.mpr G) (not_le.mpr H)

lemma matches_of_eq (h : Quilt n l f) {i j : ℕ} (hi : i<n) (hj : j<n)
    (H : (f i).start=(f j).start) :
    (f i).same (f j) :=
  h.aligns hi hj (by rw [H]; exact (h.mark j hj).starts)
    (by rw [← H]; exact (h.mark i hi).starts)

lemma patch_addr (h : Quilt n l f) {i : ℕ} (hi : i<n) :
    (patch n f i).addr=i := (h.reloc.seeks hi).2

lemma patch_mark (h : Quilt n l f) {i : ℕ} (hi : i<n) :
    (patch n f i).Mark n l := h.mark _ (h.reloc.seeks hi).1

lemma patch_at (h : Quilt n l f) {i : ℕ} (hi : i<n) :
    patch n f (f i).addr=f i := by unfold patch; rw [h.reloc.seeks_at hi]

lemma patch_seam (h : Quilt n l f) {i j : ℕ} (hi : i<n) (hj : j<n) :
    (patch n f i).fits (patch n f j) :=
  h.seam _ (h.reloc.seeks hi).1 _ (h.reloc.seeks hj).1

lemma patch_align (h : Quilt n l f) {i j : ℕ} (hi : i<n) (H : (f i).start ≤ j)
    (G : j < (f i).tip) : (patch n f j).same (f i) ∧ (patch n f j).seat=j-(f i).start := by
  have hj : j<n := G.trans_le (h.mark i hi).endsBy
  let F := seek n (fun i => (f i).addr) j
  have hF : F<n := (h.reloc.seeks hj).1
  have h1 : (f F).addr=j := h.patch_addr hj
  have h2 : j<(f F).tip := h1 ▸ (h.mark F hF).small
  have h3 : (f F).start ≤ j := by rw [← h1,addr]; omega
  have hh := h.aligns hF hi (lt_of_le_of_lt h3 G) (lt_of_le_of_lt H h2)
  refine ⟨hh,?_⟩
  have hs := hh.1
  unfold addr at h1
  change (f F).seat = _
  omega
end Quilt

def fringe (r : ℕ) (s t : Shard) : Shard :=
  ⟨s.start*r + s.width*t.start, s.width*t.width, s.height+t.height,
    s.seat*t.width + t.seat⟩

lemma fr_tip (r : ℕ) (s t : Shard) : (fringe r s t).tip = s.start*r+s.width*t.tip := by
  change _+_+(s.width*t.width)=_+s.width*(t.start+t.width)
  ring

lemma tip_steps (s t : Shard) (r j : ℕ) (h : Mark t r j) :
    (fringe r s t).tip ≤ s.tip*r := by
  rw [fr_tip,show s.tip=s.start+s.width from rfl, add_mul]
  simpa only [mul_comm r] using (Nat.add_le_add_left
    (Nat.mul_le_mul_left s.width h.endsBy) (s.start*r))

lemma Mark.fringe {s t : Shard} {n i r j : ℕ} (h : Mark s n i) (g : Mark t r j) :
    Mark (fringe r s t) (n*r) (i+j) := by
  refine ⟨(tip_steps s t r j g).trans (Nat.mul_le_mul_right r h.endsBy),
    ?_,Nat.add_le_add h.tall g.tall,?_⟩
  · change s.width*t.width=_
    change s.width*t.width=2^(s.height+t.height)
    rw [pow_add,h.size,g.size]
  · change s.seat*t.width + t.seat < s.width*t.width
    calc
      _ < s.seat*t.width+t.width := Nat.add_lt_add_left g.place _
      _ ≤ _ := by simpa only [add_mul,one_mul] using Nat.mul_le_mul_right t.width (show s.seat+1 ≤ s.width from h.place)

lemma fr_same {s t s' t' : Shard} (r : ℕ) (hs : s.same s') (ht : t.same t') :
    (fringe r s t).same (fringe r s' t') := by
  unfold same fringe at *; dsimp
  rw [hs.1,hs.2.1,hs.2.2,ht.1,ht.2.1,ht.2.2]; simp

lemma fr_before {s t s' t' : Shard} (r j : ℕ) (hs : s.tip ≤ s'.start) (hg : Mark t r j) :
    (fringe r s t).tip ≤ (fringe r s' t').start :=
  le_trans ((tip_steps s t r j hg).trans (Nat.mul_le_mul_right r hs)) (Nat.le_add_right ..)

lemma fr_within {s t s' t' : Shard} (r : ℕ) (hs : s.same s') (ht : t.tip ≤ t'.start) :
    (fringe r s t).tip ≤ (fringe r s' t').start := by
  rw [fr_tip]; change _ ≤ s'.start*r + s'.width*t'.start
  rw [hs.1,hs.2.1]; exact Nat.add_le_add_left (Nat.mul_le_mul_left _ ht) _

lemma same_sym {s t : Shard} (h : s.same t) : t.same s :=
  ⟨h.1.symm,h.2.1.symm,h.2.2.symm⟩

lemma fr_fits {s t s' t' : Shard} (r j : ℕ) (hg : Mark t r j) (hg' : Mark t' r j)
    (hs : s.fits s') (ht : t.fits t') :
    (fringe r s t).fits (fringe r s' t') := by
  rcases hs with H|H|H
  · rcases ht with G|G|G
    · exact Or.inl (fr_same r H G)
    · exact Or.inr (Or.inl (fr_within r H G))
    · exact Or.inr (Or.inr (fr_within r (same_sym H) G))
  · exact Or.inr (Or.inl (fr_before r j H hg))
  · exact Or.inr (Or.inr (fr_before r j H hg'))

lemma fr_unique {s t s' t' : Shard} (r j : ℕ) (hg : Mark t r j) (hg' : Mark t' r j)
    {n i : ℕ} (_ha : Mark s n i) (_ha' : Mark s' n i) (hs : s.fits s') (ht : t.fits t')
    (H : (fringe r s t).start < (fringe r s' t').tip)
    (G : (fringe r s' t').start < (fringe r s t).tip) :
    s.same s' ∧ t.same t' := by
  rcases hs with h|h|h
  · rcases ht with g|g|g
    · exact ⟨h,g⟩
    · exact absurd (fr_within r h g) (not_le.mpr G)
    · exact absurd (fr_within r (same_sym h) g) (not_le.mpr H)
  · exact absurd (fr_before r j h hg) (not_le.mpr G)
  · exact absurd (fr_before r j h hg') (not_le.mpr H)

def attach (r : ℕ) (u v : ℕ → Shard) : ℕ → Shard := fun i =>
  fringe r (u (i/r)) (v (i%r))

lemma Quilt.attach {m n i j : ℕ} {f g : ℕ→Shard} (h : Quilt m i f) (k : Quilt n j g)
    (hn : 0<n) :
    Quilt (m*n) (i+j) (Shard.attach n f g) := by
  have top (s : ℕ) (hs : s < m*n) : s/n < m := (Nat.div_lt_iff_lt_mul hn).mpr hs
  have lo (s : ℕ) : s%n<n := Nat.mod_lt s hn
  have hh (s : ℕ) (hs : s < m*n) :
      (Shard.attach n f g s).Mark (m*n) (i+j) :=
    (h.mark _ (top s hs)).fringe (k.mark _ (lo s))
  refine ⟨hh,?_,?_⟩
  · intro a ha b hb
    exact fr_fits n j (k.mark _ (lo a)) (k.mark _ (lo b))
      (h.seam _ (top a ha) _ (top b hb)) (k.seam _ (lo a) _ (lo b))
  · intro a ha b hb hab
    let T := Shard.attach n f g
    change (T a).addr=(T b).addr at hab
    have h1 : (T a).start < (T b).tip :=
      lt_of_le_of_lt (Nat.le_add_right (T a).start (T a).seat)
        (Eq.subst (motive:=fun z => z < (T b).tip) hab.symm (hh b hb).small)
    have h2 : (T b).start < (T a).tip :=
      lt_of_le_of_lt (Nat.le_add_right (T b).start (T b).seat)
        (Eq.subst (motive:=fun z => z < (T a).tip) hab (hh a ha).small)
    obtain ⟨ht,hg⟩ := fr_unique n j (k.mark _ (lo a)) (k.mark _ (lo b))
      (h.mark _ (top a ha)) (h.mark _ (top b hb)) (h.seam _ (top a ha) _ (top b hb))
      (k.seam _ (lo a) _ (lo b)) h1 h2
    have ht' : (T a).same (T b) := fr_same n ht hg
    unfold addr at hab; rw [ht'.1] at hab
    have H := Nat.add_left_cancel hab
    change (f (a/n)).seat*(g (a%n)).width+(g (a%n)).seat =
      (f (b/n)).seat*(g (b%n)).width+(g (b%n)).seat at H
    have diy (b : ℕ) := (k.mark _ (lo b)).place
    have hD := congr_arg (· / (g (a%n)).width) H
    have hM := congr_arg (· % (g (a%n)).width) H
    rw [chops _ _ _ (diy a),hg.2.1,chops _ _ _ (diy b)] at hD
    rw [chips _ _ _ (diy a),hg.2.1,chips _ _ _ (diy b)] at hM
    have IH := h.fiber _ (top a ha) _ (top b hb) (congr_arg₂ Nat.add ht.1 hD)
    have IL := k.fiber _ (lo a) _ (lo b) (congr_arg₂ Nat.add hg.1 hM)
    exact (joined a n).symm.trans (by rw [IH,IL,joined])

end Shard

namespace Hem
open Slant Stroke Shard

variable (u : Stroke)
def crown (i : ℕ) := min i (u.partner i)
def thickness (i : ℕ) := if i=u.partner i then 1 else 2
def up (i : ℕ) := if i=u.partner i then 0 else 1
def trim (i : ℕ) := if i=crown u i then thickness u i else 0
def tier (i : ℕ) := if i=crown u i then 0 else 1
def sums (i : ℕ) := ∑ a ∈ range i, trim u a

def hem (i : ℕ) : Shard :=
  ⟨sums u (crown u i), thickness u i, up u i, tier u i⟩

variable {u}

lemma crown_partner {n i : ℕ} (h : u.Sound n) : crown u (u.partner i)=crown u i := by
  unfold crown; rw [h.pair]; omega

lemma thickness_partner {n i : ℕ} (h : u.Sound n) :
    thickness u (u.partner i)=thickness u i := by
  simp [thickness,h.pair,eq_comm]

lemma crown_closed {n i : ℕ} (h : u.Sound n) : crown u (crown u i)=crown u i := by
  rcases le_or_gt i (u.partner i) with g|g
  · have H : crown u i=i := min_eq_left g; rw [H,H]
  · have H : crown u i=u.partner i := min_eq_right g.le
    exact (congr_arg (crown u) H).trans (crown_partner h)

lemma crown_class {n i j : ℕ} (h : u.Sound n) (g : crown u i=crown u j) :
    j=i ∨ j=u.partner i := by
  rcases min_choice i (u.partner i) with H|H <;> rcases min_choice j (u.partner j) with G|G
  · unfold crown at g; exact Or.inl (by omega)
  · unfold crown at g
    have h' : u.partner j=i := by omega
    exact Or.inr ((h.pair _).symm.trans (congr_arg u.partner h'))
  · unfold crown at g; exact Or.inr (by omega)
  · unfold crown at g
    have h' : u.partner j=u.partner i := by omega
    exact Or.inl ((h.pair _).symm.trans ((congr_arg u.partner h').trans (h.pair i)))

lemma thick_tip {n i : ℕ} (h : u.Sound n) :
    trim u (crown u i)=thickness u i := by
  rw [trim,ite_eq_left (crown_closed h).symm]
  rcases (crown_class h (crown_closed h).symm) with k|k
  · rw [k]
  · rw [k,thickness_partner h]

lemma tier_lt (u : Stroke) (i : ℕ) : tier u i < thickness u i := by
  by_cases h : i=u.partner i
  · simp only [tier,crown,thickness,← h,min_self,↓reduceIte]
    omega
  · unfold tier thickness; split_ifs <;> omega

lemma sum_trim {n : ℕ} (h : u.Sound n) :
    sums u n=n := by
  let H := u.partner
  have step (i : ℕ) : trim u i + trim u (u.partner i) = 2 := by
    unfold trim; rw [thickness_partner h,crown_partner h]
    unfold crown thickness
    split_ifs <;> omega
  have hh : Reloc n H :=
    ⟨h.bdp,fun i _ j _ g => (h.pair i).symm.trans ((congr_arg H g).trans (h.pair j))⟩
  have HG : sums u n+sums u n=n*2 := calc
    _ = sums u n + ∑ j ∈ range n, trim u (H j) := congr_arg (sums u n+·) (hh.sum _).symm
    _ = n*2 := by
      unfold sums; rw [← sum_add_distrib]
      dsimp only [H]; simp [step]
  omega

lemma tip_hem {n i : ℕ} (h : u.Sound n) :
    (hem u i).tip=sums u (crown u i+1) := by
  change sums _ _+_ = ∑ a ∈ _, _
  rw [sum_range_succ,thick_tip h]; rfl

lemma sums_mono (u : Stroke) : Monotone (sums u) := by
  apply monotone_nat_of_le_succ
  intro i; unfold sums; rw [sum_range_succ]; omega

lemma marked {n i : ℕ} (h : u.Sound n) (hi : i<n) : (hem u i).Mark n 1 := by
  refine ⟨?_,?_,?_,tier_lt u i⟩
  · rw [tip_hem h]
    exact le_trans (sums_mono u
      (show crown u i+1≤n from by unfold crown; omega)) (sum_trim h).le
  · change thickness u i=2^up u i; unfold thickness up; split_ifs <;> rfl
  · change up u i ≤ 1; unfold up; split <;> omega

lemma same_class {n i j : ℕ} (h : u.Sound n) (g : crown u i=crown u j) :
    (hem u i).same (hem u j) := by
  rcases crown_class h g with rfl|rfl
  · exact ⟨rfl,rfl,rfl⟩
  · refine ⟨congr_arg (sums u) g, (thickness_partner h).symm,?_⟩
    simp [hem,up,h.pair,eq_comm]

lemma hem_before {n i j : ℕ} (h : u.Sound n) (g : crown u i<crown u j) :
    (hem u i).tip≤(hem u j).start := by
  rw [tip_hem h]; exact sums_mono u g

lemma class_of_start {n i j : ℕ} (h : u.Sound n) (hi : i<n) (hj : j<n)
    (g : (hem u i).start=(hem u j).start) :
    crown u i=crown u j := by
  rcases lt_trichotomy (crown u i) (crown u j) with k|k|k
  · have := (marked h hi).starts; have := hem_before h k; omega
  · exact k
  · have := (marked h hj).starts; have := hem_before h k; omega

lemma tier_partner_ne {n i : ℕ} (h : u.Sound n) (g : u.partner i ≠ i) :
    tier u (u.partner i) ≠ tier u i := by
  unfold tier; rw [crown_partner h]; unfold crown; split_ifs <;> omega

lemma quilt {n : ℕ} (h : u.Sound n) : Quilt n 1 (hem u) := by
  refine ⟨fun _ hi => marked h hi,?_,?_⟩
  · intro i hi j hj
    rcases lt_trichotomy (crown u i) (crown u j) with k|k|k
    · exact Or.inr (Or.inl (hem_before h k))
    · exact Or.inl (same_class h k)
    · exact Or.inr (Or.inr (hem_before h k))
  · intro i hi j hj g
    rcases lt_trichotomy (crown u i) (crown u j) with k|k|k
    · have hh := hem_before h k
      have hu := (marked h hi).small
      unfold addr at hu g; omega
    · unfold addr at g; rw [(same_class h k).1] at g
      have hh : tier u i=tier u j := Nat.add_left_cancel g
      rcases crown_class h k with rfl|rfl
      · rfl
      · by_contra hz; exact (tier_partner_ne h (Ne.symm hz)) hh.symm
    · have hh := hem_before h k
      have hu := (marked h hj).small
      unfold addr at hu g; omega

end Hem

open Shard Hem

def seed : Shard := ⟨0,1,0,0⟩
def mosaic (r : Axes) (u : ℕ → Stroke) : ℕ → ℕ → Shard
  | 0 => fun _ => seed
  | l+1 => attach (r l) (mosaic r u l) (hem (u l))

lemma seed_quilt : Shard.Quilt 1 0 fun _ => seed := by
  refine ⟨fun i _ => ⟨by decide,by decide,le_rfl,by decide⟩,
    fun _ _ _ _ => Or.inl ⟨rfl,rfl,rfl⟩,fun i hi j hj _ => by omega⟩

lemma mosaic_quilt (r : Axes) (l : ℕ) (u : ℕ→Stroke)
    (h : Splits r l) (g : ∀ i<l, (u i).Sound (r i)) :
    Quilt (extent r l) l (mosaic r u l) := by
  induction l with
  | zero => exact seed_quilt
  | succ l ih =>
    exact (ih (h.cut (by omega)) (fun i hi => g i (by omega))).attach
      (Hem.quilt (g l (by omega))) h.here

end
end PowerSaving.Grove

end OAI
namespace OAI
namespace PowerSaving.Grove
open Finset Spectral
noncomputable section

structure Isles (r : Axes) (l : ℕ) : Prop where
  good : Splits r l
  apart : ∀ i<l, (r i).Coprime (extent r i)

lemma Isles.cut {r : Axes} {l : ℕ} (h : Isles r l) {i : ℕ} (hi : i ≤ l) :
    Isles r i := ⟨h.good.cut hi,fun j hj => h.apart j (lt_of_lt_of_le hj hi)⟩

lemma Isles.axis_dvd {r : Axes} {l : ℕ} (h : Isles r l) :
    ∀ i<l,r i ∣ extent r l := by
  induction l with
  | zero => intro i hi; omega
  | succ l ih =>
    intro i hi; rw [extent]
    by_cases hz : i=l
    · simp [hz]
    · exact dvd_mul_of_dvd_left (ih (h.cut (by omega)) _ (by omega)) _

def tide (p r a b : ℕ) := (a*r+b*p)%(p*r)

def ford (r : Axes) : ℕ → ℕ → ℕ
  | 0 => fun _ => 0
  | l+1 => fun i =>
    tide (extent r l) (r l) (ford r l (i/r l)) (i%r l)

def spray (Z : ℂ) (N q : ℕ) := Z^((N/q)*(N/q))

def gale (Z : ℂ) : Wood := fun i j => Z^(i*j)

lemma spray_here (Z : ℂ) (n q : ℕ) (h : 0<q) : spray Z (n*q) q=Z^(n*n) := by
  rw [spray,Nat.mul_div_cancel _ h]

lemma spray_tide {Z : ℂ} {n q : ℕ} (hq : 0<q) (hp : n.Coprime q)
    (h : IsPrimitiveRoot Z (n*q)) :
    IsPrimitiveRoot (Z^(q*q)) n := by
  have hh := h.pow_of_dvd (p:=q) (by omega) (by simp)
  rw [Nat.mul_div_cancel _ hq] at hh
  rw [pow_mul]; exact hh.pow_of_coprime q hp.symm

lemma spray_sec {Z : ℂ} {N p r : ℕ} (hr : r ∣ N) (hh : 0<r) :
    spray Z (N*p) r=spray (Z^(p*p)) N r := by
  unfold spray
  obtain ⟨d,rfl⟩ := hr
  rw [Nat.mul_assoc,Nat.mul_div_cancel_left _ hh,Nat.mul_div_cancel_left _ hh,← pow_mul]
  ring_nf

lemma spray_axis {Z : ℂ} {r : Axes} {l : ℕ} (h : Isles r l)
    (hh : IsPrimitiveRoot Z (extent r l)) :
    ∀ i<l, IsPrimitiveRoot (spray Z (extent r l) (r i)) (r i) := by
  induction l generalizing Z with
  | zero => intro i hi; omega
  | succ l ih =>
    intro i hi
    have H := h.cut (i:=l) (by omega)
    have HR := h.apart l (by omega)
    by_cases hg : i=l
    · subst i
      rw [extent,spray_here Z _ _ h.good.here]
      have he : IsPrimitiveRoot Z (r l*extent r l) := by rw [mul_comm]; exact hh
      exact spray_tide H.good.extent_pos HR he
    · have hx : i<l := by omega
      have h1 := H.axis_dvd i hx
      have h2 : 0<r i := lt_of_lt_of_le (by norm_num) (H.good i hx)
      rw [extent,spray_sec h1 h2]
      exact ih H (spray_tide h.good.here HR.symm hh) i hx

lemma gale_mod {Z : ℂ} {n : ℕ} (h : Z^n=1) (i j : ℕ) :
    gale Z (i%n) (j%n)=gale Z i j := by
  unfold gale
  rw [pow_mul,power_mod h i]
  have ht : (Z^i)^n=1 := by rw [← pow_mul,mul_comm,pow_mul,h,one_pow]
  rw [power_mod ht,← pow_mul]

lemma gale_tide {Z : ℂ} {p r : ℕ} (h : Z^(p*r)=1)
    (a b c d : ℕ) :
    gale Z (tide p r a b) (tide p r c d) =
    gale (Z^(r*r)) a c * gale (Z^(p*p)) b d := by
  rw [tide,tide,gale_mod h]; unfold gale
  rw [← pow_mul,← pow_mul,← pow_add]
  rw [show (a*r+b*p)*(c*r+d*p)=r*r*(a*c)+p*p*(b*d)+(p*r)*(a*d+b*c) by ring]
  rw [pow_add,pow_mul Z (p*r),h,one_pow,mul_one]

lemma canopy_gale {Z : ℂ} {r : Axes} {l : ℕ} (h : Isles r l)
    (hh : IsPrimitiveRoot Z (extent r l)) :
    ∀ i<extent r l, ∀ j<extent r l,
    Grove.canopy r (fun x => gale (spray Z (extent r l) (r x))) l i j =
    gale Z (ford r l i) (ford r l j) := by
  induction l generalizing Z with
  | zero => intros; simp [canopy,gale,ford]
  | succ l ih =>
    intro i hi j hj
    have H := h.cut (i:=l) (by omega)
    have HR := h.apart l (by omega)
    have he := spray_tide h.good.here HR.symm hh
    have HG (i : ℕ) (hi : i<l) :
        spray Z (extent r (l+1)) (r i) =
        spray (Z^(r l*r l)) (extent r l) (r i) :=
      spray_sec (H.axis_dvd _ hi) (lt_of_lt_of_le (by norm_num) (H.good i hi))
    have ha := h.good.div_lt hi; have hb := h.good.div_lt hj
    simp only [canopy,ford]
    rw [canopy_congr r l H.good _ (fun i => gale (spray (Z^(r l*r l)) (extent r l) (r i)))
      (by intro i hx a ha b hb; rw [HG i hx]) _ ha _ hb,ih H he _ ha _ hb]
    rw [extent,spray_here Z _ _ h.good.here,gale_tide hh.pow_eq_one]

lemma tide_left {a b c d m n : ℕ} (h : (tide m n a b)=(tide m n c d)) :
    a*n≡c*n [MOD m] := by
  have ht : (a*n+b*m)≡(c*n+d*m) [MOD (m*n)] := h
  have hx := ht.of_dvd (dvd_mul_right m n)
  simpa [Nat.ModEq] using hx

lemma tide_right {a b c d m n : ℕ} (h : (tide m n a b)=(tide m n c d)) :
    b*m ≡ d*m [MOD n] := by
  apply tide_left (b:=a) (d:=c)
  simpa only [tide,add_comm, Nat.mul_comm n m] using h

lemma tide_inj {a b c d m n : ℕ} (h : (tide m n a b)=(tide m n c d))
    (H : m.Coprime n) (ha : a < m) (hc : c < m) (hb : b<n) (hd : d<n) :
    a=c ∧ b=d := by
  have hx := Nat.ModEq.cancel_right_of_coprime H (tide_left h)
  have hy := Nat.ModEq.cancel_right_of_coprime H.symm (tide_right h)
  simp only [Nat.ModEq,Nat.mod_eq_of_lt ha, Nat.mod_eq_of_lt hb,Nat.mod_eq_of_lt hc,Nat.mod_eq_of_lt hd] at hx hy
  exact ⟨hx,hy⟩

theorem ford_rel {r : Axes} {l : ℕ} (h : Isles r l) :
    Reloc (extent r l) (ford r l) := by
  induction l with
  | zero =>
    refine ⟨fun i _ => by simp [ford,extent],fun i hi j hj _ => ?_⟩
    change i<1 at hi; change j<1 at hj; omega
  | succ l ih =>
    have H := h.cut (i:=l) (by omega)
    have he := ih H
    refine ⟨fun i _ => Nat.mod_lt _ h.good.extent_pos,fun i hi j hj ht => ?_⟩
    have ha := h.good.div_lt hi; have hb := h.good.div_lt hj
    obtain ⟨hg,hk⟩ := tide_inj ht (h.apart l (by omega)).symm (he.bd _ ha) (he.bd _ hb)
      (h.good.mod_lt i) (h.good.mod_lt j)
    have hh := he.inj _ ha _ hb hg
    exact (joined i _).symm.trans (by rw [hh,hk,joined])

lemma graft_ford {r : Axes} {l : ℕ} {z : ℂ} (h : Isles r l)
    (hh : IsPrimitiveRoot z (extent r l)) (x : Line) (i : ℕ) (hi : i<extent r l) :
    graft (extent r l) (canopy r (fun i => gale (spray z (extent r l) (r i))) l)
      (fun j => x (ford r l j)) i =
    freq (extent r l) z x (ford r l i) := by
  unfold graft freq
  conv_rhs => rw [← (ford_rel h).sum]
  refine sum_congr rfl ?_
  intro j hj
  rw [canopy_gale h hh _ hi _ (mem_range.mp hj)]; rfl

end
end PowerSaving.Grove

end OAI
namespace OAI

namespace PowerSaving.Selection
open Finset Real
noncomputable section

def stackN (n : ℕ) := Nat.log 2 (2*n)+1

lemma stack_above (n : ℕ) :
    2*n < 2^stackN n :=
  Nat.lt_pow_succ_log_self Nat.one_lt_two _

lemma stack_pow (n : ℕ) (hn : 0<n) :
    2^stackN n ≤ 4*n := by
  have hh : 2^(Nat.log 2 (2*n)) ≤ 2*n := Nat.pow_log_le_self _ (by omega)
  rw [stackN,pow_succ]; omega

lemma stack_le (n : ℕ) (hn : 0<n) :
    stackN n ≤ 4*n := Nat.lt_two_pow_self.le.trans (stack_pow n hn)

def silo (k : ℕ) := (16*(k+4))^2

lemma silo_big (k : ℕ) : 2 < silo k := by
  have hh : 2 < 16*(k+4) := by omega
  unfold silo; nlinarith [hh]

-- odd primes up to and excluding limit
def Bar (i : ℕ) := Nat.Prime i ∧ i>2
instance (i) : Decidable (Bar i) := inferInstanceAs (Decidable (_ ∧ _))
def bars (p : ℕ) : ℕ := ∑ i ∈ range p, if Bar i then 1 else 0
lemma bars_step (i : ℕ) : bars (i+1)=bars i+(if Bar i then 1 else 0) := sum_range_succ ..
lemma bars_zero : bars 0=0 := by simp [bars]

private lemma legendre {p : ℕ} (hp : p.Prime) : ∀ {m b : ℕ}, Nat.log p m < b →
    (Nat.factorial m).factorization p = ∑ i ∈ Ico 1 b, m / p ^ i
  | 0, b, _ => by simp
  | m + 1, b, hb => by
    rw [Nat.factorial_succ, Nat.factorization_mul (Nat.succ_ne_zero m) m.factorial_ne_zero,
      Finsupp.coe_add, Pi.add_apply,
      legendre hp ((Nat.log_mono_right (Nat.le_succ _)).trans_lt hb),
      Nat.factorization_eq_card_pow_dvd_of_lt hp (Nat.succ_pos m)
        (Nat.lt_pow_of_log_lt hp.one_lt hb), card_filter, ← sum_add_distrib]
    exact sum_congr rfl fun i _ => by rw [Nat.succ_div, add_comm]

private lemma choose_fact_le {p n : ℕ} (hp : p.Prime) :
    (Nat.choose (2*n) n).factorization p ≤ Nat.log p (2*n) := by
  have hC : Nat.choose (2*n) n * (Nat.factorial n * Nat.factorial n) = Nat.factorial (2*n) := by
    have := Nat.choose_mul_factorial_mul_factorial (show n ≤ 2*n by omega)
    rw [show 2*n - n = n by omega] at this; rw [← this, Nat.mul_assoc]
  have hv : (Nat.choose (2*n) n * (Nat.factorial n * Nat.factorial n)).factorization p =
      (Nat.factorial (2*n)).factorization p := by rw [hC]
  rw [Nat.factorization_mul (Nat.choose_pos (by omega)).ne'
      (Nat.mul_ne_zero (Nat.factorial_ne_zero n) (Nat.factorial_ne_zero n)), Finsupp.coe_add,
    Pi.add_apply, Nat.factorization_mul (Nat.factorial_ne_zero n) (Nat.factorial_ne_zero n),
    Finsupp.coe_add, Pi.add_apply,
    legendre hp (show Nat.log p n < Nat.log p (2*n) + 1 from
      Nat.lt_succ_of_le (Nat.log_mono_right (by omega))),
    legendre hp (show Nat.log p (2*n) < Nat.log p (2*n) + 1 from Nat.lt_succ_self _)] at hv
  have key : ∑ i ∈ Ico 1 (Nat.log p (2*n) + 1), (2*n) / p^i ≤
      ∑ i ∈ Ico 1 (Nat.log p (2*n) + 1), (2 * (n / p^i) + 1) :=
    sum_le_sum fun i _ => by
      have hq : 0 < p^i := pow_pos hp.pos i
      have h1 := Nat.div_add_mod n (p^i)
      have h2 := Nat.mod_lt n hq
      exact Nat.lt_succ_iff.mp ((Nat.div_lt_iff_lt_mul hq).mpr (by nlinarith))
  rw [sum_add_distrib, ← mul_sum, sum_const, Nat.card_Ico, smul_eq_mul, mul_one] at key
  omega

private lemma choose_le_pow (n : ℕ) (hn : 0 < n) :
    Nat.choose (2*n) n ≤ (2*n) ^ ((range (2*n+1)).filter Nat.Prime).card := by
  have hC : Nat.choose (2*n) n ≠ 0 := (Nat.choose_pos (by omega)).ne'
  have hpr : ∀ p ∈ (Nat.choose (2*n) n).factorization.support, p.Prime := fun p hp => by
    by_contra h
    exact (Finsupp.mem_support_iff.mp hp) (Nat.factorization_eq_zero_of_not_prime _ h)
  have hle : ∀ p ∈ (Nat.choose (2*n) n).factorization.support,
      p ^ (Nat.choose (2*n) n).factorization p ≤ 2*n := fun p hp =>
    Nat.pow_le_of_le_log (by omega) (choose_fact_le (hpr p hp))
  have hsub : (Nat.choose (2*n) n).factorization.support ⊆ (range (2*n+1)).filter Nat.Prime :=
    fun p hp => by
      have hpos : (Nat.choose (2*n) n).factorization p ≠ 0 := Finsupp.mem_support_iff.mp hp
      have : p ≤ 2*n := le_trans (Nat.le_self_pow hpos p) (hle p hp)
      exact mem_filter.mpr ⟨mem_range.mpr (by omega), hpr p hp⟩
  calc Nat.choose (2*n) n = (Nat.choose (2*n) n).factorization.prod (· ^ ·) :=
        (Nat.prod_factorization_pow_eq_self hC).symm
    _ ≤ ∏ _p ∈ (Nat.choose (2*n) n).factorization.support, (2*n) := prod_le_prod' hle
    _ = (2*n) ^ (Nat.choose (2*n) n).factorization.support.card := prod_const _
    _ ≤ _ := Nat.pow_le_pow_right (by omega) (card_le_card hsub)

private lemma four_pow_le (n : ℕ) : 4^n ≤ (2*n+1) * Nat.choose (2*n) n := by
  have hs := Nat.sum_range_choose (2*n)
  have hm : ∀ m ∈ range (2*n+1), Nat.choose (2*n) m ≤ Nat.choose (2*n) n := fun m _ => by
    have := Nat.choose_le_middle m (2*n)
    rwa [Nat.mul_div_cancel_left n (by norm_num)] at this
  have := sum_le_sum hm
  rw [hs, sum_const, card_range, smul_eq_mul] at this
  rw [show (4:ℕ)^n = 2^(2*n) by rw [pow_mul]; norm_num]
  exact this

private lemma card_primes (p : ℕ) (hp : 2 ≤ p) :
    ((range (p+1)).filter Nat.Prime).card = bars (p+1) + 1 := by
  have h (i : ℕ) : (if Bar i then 1 else 0)+(if i=2 then 1 else 0)=
      (if i.Prime then 1 else 0) := by
    by_cases g : i.Prime
    · have ht := g.two_le; simp only [Bar,g,true_and,ite_true]; split_ifs <;> omega
    · have hh : i≠2 := by intro H; rw [H] at g; exact g Nat.prime_two
      simp [g,hh,Bar]
  have hh1 : ∑ i ∈ range (p+1), (if i=2 then 1 else 0)=1 := by
    simp [show 2 < p+1 by omega]
  have e : ∑ i ∈ range (p+1), (if i.Prime then 1 else 0) =
      bars (p+1) + ∑ i ∈ range (p+1), (if i=2 then 1 else 0) := by
    rw [bars, ← sum_add_distrib]; exact sum_congr rfl fun i _ => (h i).symm
  rw [card_filter, e, hh1]

lemma bar_bounds (k : ℕ) :
    k < bars (silo k+1) := by
  by_contra hcon
  have hb : bars (silo k+1) ≤ k := by omega
  have ha : 0 < k+4 := by omega
  have hs : silo k = 2*(128*(k+4)^2) := by unfold silo; ring
  have hn : 0 < 128*(k+4)^2 := Nat.mul_pos (by norm_num) (pow_pos ha 2)
  have h1 := four_pow_le (128*(k+4)^2)
  have h2 := choose_le_pow (128*(k+4)^2) hn
  rw [← hs, card_primes _ (silo_big k).le] at h2
  rw [← hs] at h1
  have hx : 2 ≤ silo k := (silo_big k).le
  -- (x+1)·x^(bars+1) ≤ x^(k+3)
  have h3 : (silo k+1) * silo k ^ (bars (silo k+1)+1) ≤ silo k ^ (k+3) := by
    calc (silo k+1) * silo k ^ (bars (silo k+1)+1) ≤ silo k^2 * silo k ^ (k+1) :=
          Nat.mul_le_mul (by nlinarith) (Nat.pow_le_pow_right (by omega) (by omega))
      _ = silo k ^ (k+3) := by rw [← pow_add]; ring_nf
  -- x ≤ 4^(k+8)
  have h4 : silo k ≤ 4^(k+8) := by
    have hl : (k+4)^2 ≤ 4^(k+4) := by
      calc (k+4)^2 ≤ (2^(k+4))^2 := Nat.pow_le_pow_left Nat.lt_two_pow_self.le 2
        _ = 4^(k+4) := by rw [← pow_mul, mul_comm, pow_mul]; norm_num
    rw [hs, show k+8 = 4+(k+4) by omega, pow_add]
    norm_num; omega
  have h5 : silo k ^ (k+3) ≤ 4^((k+8)*(k+3)) := by
    rw [pow_mul]; exact Nat.pow_le_pow_left h4 _
  have h6 : 4^((k+8)*(k+3)) < 4^(128*(k+4)^2) := Nat.pow_lt_pow_right (by norm_num) (by nlinarith)
  have := le_trans h1 (Nat.mul_le_mul_left _ h2)
  omega

end
end PowerSaving.Selection

end OAI
namespace OAI

namespace PowerSaving.Selection
open Grove
noncomputable section

structure Cart where
  l : ℕ
  q : Axes
  vol : ℕ

namespace Cart

def empty : Cart := ⟨0,fun _ => 0,1⟩
def pushQ (x : Cart) (p : ℕ) : Cart :=
  ⟨x.l+1,fun i => if i=x.l then p else x.q i, x.vol*p⟩

structure Square (x : Cart) : Prop where
  agrees : x.vol=extent x.q x.l
  isles : Isles x.q x.l

lemma Square.empty : empty.Square := by
  exact ⟨rfl,fun i hi => by change i<0 at hi; omega,
    fun i hi => by change i<0 at hi; omega⟩

variable {x : Cart}
lemma push_eq (p : ℕ) {i : ℕ} (h : i<x.l) :
    (x.pushQ p).q i=x.q i := ite_eq_right (Nat.ne_of_lt h)

lemma push_ext (p : ℕ) {i : ℕ} (h : i≤x.l) :
    extent (x.pushQ p).q i=extent x.q i := by
  induction i with
  | zero => rfl
  | succ i ih => rw [extent,ih (by omega),extent,push_eq p (by omega)]

lemma at_push (x : Cart) (p : ℕ) :
    (x.pushQ p).q x.l=p := ite_eq_left rfl

lemma Square.pushQ (h : x.Square) {p : ℕ} (hp : p≥2) (hq : p.Coprime x.vol) :
    (x.pushQ p).Square := by
  let y := x.pushQ p
  refine ⟨?_,?_,?_⟩
  · change x.vol*p=extent y.q x.l*y.q x.l
    rw [push_ext _ le_rfl,at_push,h.agrees]
  · intro i hi
    change i<x.l+1 at hi
    by_cases g : i=x.l
    · rw [g,at_push]; exact hp
    · rw [push_eq _ (by omega)]
      exact h.isles.good _ (by omega)
  · intro i hi
    change i<x.l+1 at hi
    by_cases g : i=x.l
    · rw [g,at_push,push_ext _ le_rfl,← h.agrees]; exact hq
    · rw [push_eq _ (by omega),push_ext _ (by omega)]
      exact h.isles.apart i (by omega)

end Cart

open Cart

def reap (N : ℕ) : ℕ → Cart
  | 0 => Cart.empty
  | p+1 =>
    let x := reap N p
    if Bar p ∧ x.vol*p ≤ N then x.pushQ p else x

structure Baler (N p : ℕ) (x : Cart) : Prop where
  square : x.Square
  odd : Odd x.vol
  top : x.vol ≤ N
  count : x.l≤p
  vars : ∀ i<x.l, Bar (x.q i) ∧ x.q i<p
  more : ∀ q, p≤q → Bar q → q.Coprime x.vol
  hit : x.l=bars p ∨ ∃ q<p,N<x.vol*q

namespace Baler
variable {N p : ℕ} {x : Cart}

lemma empty (N : ℕ) (h : 0<N) : Baler N 0 Cart.empty :=
  ⟨.empty,odd_one,h,Nat.le_refl _,fun i hi => by change i<0 at hi; omega,
    fun p _ _ => Nat.coprime_one_right _,Or.inl bars_zero.symm⟩

lemma push (h : Baler N p x) (g : Bar p) (hp : x.vol*p ≤ N) :
    Baler N (p+1) (x.pushQ p) := by
  have ht : p>2 := g.2
  refine ⟨h.square.pushQ ht.le (h.more p le_rfl g),
    h.odd.mul (g.1.odd_of_ne_two (by omega)),hp,
    Nat.add_le_add_right h.count 1,?_,?_,?_⟩
  · intro i hi
    change i<x.l+1 at hi
    by_cases k : i=x.l
    · rw [k,at_push]; exact ⟨g,by omega⟩
    · rw [push_eq _ (by omega)]
      have hf := h.vars i (by omega)
      exact ⟨hf.1,Nat.lt_trans hf.2 (by omega)⟩
  · intro q hq hg
    change q.Coprime (x.vol*p)
    have hh := h.more q (by omega) hg
    apply hh.mul_right
    apply hg.1.coprime_iff_not_dvd.mpr
    intro ht'
    have := Nat.le_of_dvd (by omega : 0<p) ht'
    omega
  · rcases h.hit with hh|⟨q,hq,hg⟩
    · left; rw [bars_step,ite_eq_left g,← hh]; rfl
    · right
      have hh : x.vol*q≤x.vol*p := Nat.mul_le_mul_left _ hq.le
      omega

lemma pass (h : Baler N p x) (g : ¬ (Bar p ∧ x.vol*p≤N)) :
    Baler N (p+1) x := by
  refine ⟨h.square,h.odd,h.top,h.count.trans (Nat.le_succ _),?_,fun q hq hg =>
    h.more q (by omega) hg,?_⟩
  · intro i hi; have H := h.vars i hi
    exact ⟨H.1,H.2.trans (by omega)⟩
  · by_cases H : Bar p
    · exact Or.inr ⟨p,by omega,Nat.lt_of_not_ge fun hx => g ⟨H,hx⟩⟩
    · rw [bars_step,ite_eq_right H,Nat.add_zero]
      exact h.hit.imp id fun ⟨q,hq,hk⟩ => ⟨q,by omega,hk⟩
end Baler

lemma reap_baler (N p : ℕ) (h : 0<N) : Baler N p (reap N p) := by
  induction p with
  | zero => exact Baler.empty _ h
  | succ p ih =>
    simp only [reap]; split
    · rename_i hk; exact ih.push hk.1 hk.2
    · rename_i hg; exact ih.pass hg

def harvestN (n : ℕ) := silo (stackN n)
def bed (n : ℕ) := reap (2*n) (harvestN n+1)

-- choose dyad by doubling until ≥N
def fill (N p : ℕ) : ℕ→ℕ
  | 0 => 1
  | k+1 => let q := fill N p k
           if p*q<N then q*2 else q

namespace Fill

lemma capacity (N p i : ℕ) : fill N p i ≤ 2^i := by
  induction i with
  | zero => rfl
  | succ i ih =>
    rw [fill,pow_succ]; split <;> omega

lemma fills (N p i : ℕ) : N ≤ p*fill N p i ∨ fill N p i=2^i := by
  induction i with
  | zero => exact Or.inr rfl
  | succ i ih =>
    rw [fill,pow_succ]; split
    · rename_i H; right; rw [ih.resolve_left (not_le.mpr H)]
    · rename_i H; exact Or.inl (Nat.le_of_not_lt H)

lemma radius (N p i : ℕ) (hp : p<N) : p*fill N p i < 2*N := by
  induction i with
  | zero => simp only [fill,mul_one]; omega
  | succ i ih =>
    rw [fill]; split
    · rename_i hk; rw [← mul_assoc]; omega
    · exact ih
lemma dyad (N p i : ℕ) : ∃ j,fill N p i=2^j := by
  induction i with
  | zero => exact ⟨0,rfl⟩
  | succ i ih =>
    rw [fill]; split
    · obtain ⟨j,hj⟩ := ih; exact ⟨j+1,by rw [pow_succ,hj]⟩
    · exact ih

end Fill

def bead (n : ℕ) := fill (2*n) (bed n).vol (stackN n)

def barge (n : ℕ) := (bed n).pushQ (bead n)

def orderE (n : ℕ) := Nat.log 2 (2*harvestN n)+2

lemma orderE_big (n : ℕ) :
    2*harvestN n ≤ 2^orderE n :=
  (Nat.lt_pow_succ_log_self (by omega : 1<2) _).le.trans
    (Nat.pow_le_pow_right (by omega) (Nat.le_succ _))

lemma orderE_small (n : ℕ) :
    2^orderE n ≤ 8*harvestN n := by
  have h : 0<harvestN n := lt_trans (by omega) (silo_big _)
  have hh : 2^(Nat.log 2 (2*harvestN n))≤2*harvestN n := Nat.pow_log_le_self _ (by omega)
  unfold orderE; rw [pow_add]
  norm_num at *
  omega

structure Harbor (n : ℕ) (x : Cart) : Prop where
  square : x.Square
  lower : 2*n ≤ x.vol
  upper : x.vol < 4*n
  count : x.l ≤ stackN n
  sizes : ∀ i<x.l,x.q i≤2^orderE n

theorem barge_spec (n : ℕ) (hn : 0<n) :
    Harbor n (barge n) := by
  let K := stackN n
  let X := bed n
  let S := harvestN n
  let R := 2*n
  let f := bead n
  have hK : R<2^K := stack_above _
  have HT : Baler R (S+1) X := reap_baler R (S+1) (by unfold R; omega)
  have hp : X.vol<R := by
    have H := HT.top
    have hg := HT.odd
    obtain ⟨k,hk⟩ := hg; unfold R at *; omega
  have hh : 2^X.l≤X.vol := HT.square.agrees.symm ▸ HT.square.isles.good.extent_pow
  have hx : X.l<K := Nat.lt_of_not_ge fun H =>
    not_lt.mpr (Nat.pow_le_pow_right (by omega : 0<2) H) (hh.trans_lt (hp.trans hK))
  have hV : 1≤X.vol := HT.square.agrees.symm ▸ HT.square.isles.good.extent_pos
  have hf : R ≤ X.vol*f := by
    rcases Fill.fills R X.vol K with h|h
    · exact h
    · change f=2^K at h
      rw [h]; exact hK.le.trans (Nat.le_mul_of_pos_left _ hV)
  have hg : X.vol*f < 4*n := by
    have : X.vol*f < 2*(2*n) := Fill.radius R X.vol K hp
    omega
  have ht : f≥2 := Nat.le_of_not_lt fun H =>
    not_lt.mpr hf (lt_of_le_of_lt (by
      simpa only [mul_one] using Nat.mul_le_mul_left X.vol (show f≤1 by omega)) hp)
  have hu : f ≤ 2*S := by
    have hf' : X.vol*f < 2*R := Fill.radius R X.vol K hp
    rcases HT.hit with h|⟨q,hq,H⟩
    · have hy : K < bars (S+1) := bar_bounds _
      omega
    · have hy : q ≤ S := by omega
      have hb : R<X.vol*S := H.trans_le (Nat.mul_le_mul_left _ hy)
      by_contra hh
      have H1 := Nat.mul_le_mul_left X.vol (show 2*S ≤ f by omega)
      rw [show X.vol*(2*S)=2*(X.vol*S) by ring] at H1
      omega
  have hF : f.Coprime X.vol := by
    obtain ⟨k,hk⟩ := Fill.dyad R X.vol K
    change f=2^k at hk
    rw [hk]
    exact HT.odd.coprime_two_left.pow_left k
  refine ⟨HT.square.pushQ ht hF,hf,hg,hx,?_⟩
  intro i hi
  change i<X.l+1 at hi
  change (pushQ X f).q i ≤ _
  by_cases H : i=X.l
  · rw [H,at_push]; exact hu.trans (orderE_big n)
  · rw [push_eq _ (by omega)]
    have hy : X.q i < S+1 := (HT.vars i (by omega)).2
    exact le_trans (show _≤2*S by omega) (orderE_big n)

-- explicitly chosen root-order depending on size branch
def Ports (n : ℕ) := 2^orderE n ≤ n
instance (n) : Decidable (Ports n) := inferInstanceAs (Decidable (_ ≤ _))
def express (n : ℕ) := (2*n)*(barge n).vol*2^orderE n
def receipt (n : ℕ) := if Ports n then express n else n

theorem receipt_bound (n : ℕ) (hn : 0<n) :
    0<receipt n ∧ receipt n < 8*n^3 := by
  unfold receipt; split
  · rename_i H
    have hh := barge_spec n hn
    have hx := hh.lower; have hk := hh.upper
    unfold express; unfold Ports at H
    have hg : 0<(barge n).vol := by omega
    refine ⟨by positivity,?_⟩
    calc
      _ ≤ (2*n)*(barge n).vol*n := by gcongr
      _ < (2*n)*(4*n)*n := by gcongr
      _ = 8*n^3 := by ring
  · refine ⟨hn,?_⟩
    have he : 1 ≤ n := hn
    calc
      n ≤ n*n^2 := Nat.le_mul_of_pos_right _ (by positivity)
      _ < 8*n^3 := by
        rw [show n*n^2=n^3 by ring]
        have : 0<n^3 := by positivity
        omega

lemma express_eta (n : ℕ) : 2*n ∣ express n := dvd_mul_of_dvd_left (dvd_mul_right ..) _
lemma express_volume (n : ℕ) : (barge n).vol ∣ express n := dvd_mul_of_dvd_left (dvd_mul_left ..) _
lemma express_halo (n : ℕ) (j : ℕ) (hj : j≤orderE n) : 2^j ∣ express n :=
  dvd_mul_of_dvd_right (pow_dvd_pow _ hj) _
lemma express_I (n : ℕ) : 4 ∣ express n :=
  express_halo n 2 (by unfold orderE; omega)
end
end PowerSaving.Selection

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Selection Grove
noncomputable section

namespace Bench
universe U V
variable {ι : Type U} {κ : Type V} {m : Bool} {b : Bench m ι} {q : Bench m κ}
  {N k S : ι→ℕ}

-- check nondivisibility for j = 2 to n-1
def clearP (n : ℕ) : ℕ→ℕ
  | 0 => 1
  | j+1 => if 1<j ∧ n%j=0 then 0 else clearP n j

lemma clearP_eq (n k : ℕ) :
    clearP n k = if ∀ j<k,2 ≤ j → ¬ j ∣ n then 1 else 0 := by
  induction k with
  | zero => simp [clearP]
  | succ k ih =>
    have hh : (∀ j<k+1,2≤j → ¬ j∣n) ↔ ((∀ j<k,2≤j → ¬ j∣n) ∧ ¬ (1<k ∧ n%k=0)) := by
      simp only [Nat.dvd_iff_mod_eq_zero]
      constructor
      · intro h
        exact ⟨fun j hj => h j (by omega),fun ⟨hk,ht⟩ => h k (by omega) hk ht⟩
      · rintro ⟨h,g⟩ j hj ht
        obtain e|e : j<k ∨ j=k := by omega
        · exact h j e ht
        · subst j; exact fun hp => g ⟨ht,hp⟩
    rw [clearP,ih]
    simp_rw [hh]
    split_ifs <;> tauto

lemma Grain.isBar (h : b.Grain S k) (g : Small S k) :
    b.Grain S fun i => if Bar (k i) then 1 else 0 := by
  refine ⟨?_,(Small.const _ 1).mono fun i => by split <;> omega⟩
  let f (i : ι) (j) : T w := clearP (k i) j
  have F := Instant.climbs b k f (t:=w)
  have hu := strideG h f
  have hp := Dry.token b k S f
  have HH := cycleG h g f (Dry.wc 1)
    ((((Grain.wc 1).cmp hu).dry.branch hp
      (((h.transfer F).residue hu).dry.branch (Dry.wc 0) hp)).congr (fun i => by
      by_cases e : 1 < i.j <;> by_cases e' : k i.i % i.j=0 <;>
        simp [f,clearP,e,e']))
  refine ((((Grain.wc 2).cmp h).dry.branch (Dry.wc 0) HH)).congr fun i => ?_
  dsimp only [f]; rw [clearP_eq]
  simp_rw [Bar,Nat.prime_def_lt']
  by_cases e : 2 < k i
  · have H : (∀ j < k i, 2 ≤ j → ¬ j ∣ k i) ↔ (∀ j, 2 ≤ j → j < k i → ¬ j∣k i) :=
      ⟨fun h j hj hg => h j hg hj,fun h j hj hg => h j hg hj⟩
    simp [e,e.le,H]
  · simp [e]

def cartTy := p (p w w) (a w)
def cartT (x : Cart) : T cartTy := ((x.l,x.vol),Tape.tab x.l x.q)

structure Lade (b : Bench m ι) (S : ι→ℕ) (x : ι→Cart) : Prop where
  tape : b.Dry S cartTy fun i => cartT (x i)
  countB : Small b.size fun i => (x i).l
  volume : Small b.size fun i => (x i).vol
  countS : Small S fun i => (x i).l

namespace Lade

variable {x : ι→Cart}
lemma emptyL (b : Bench m ι) (S : ι→ℕ) :
    b.Lade S fun _ => Cart.empty :=
  ⟨((Dry.wc 0).pair (Dry.wc 1)).pair (arrayG (t:=w) (Grain.wc 0) (Small.const _ 0)
     (fun _ => Cart.empty.q) (Dry.wc 0)),Small.const _ 0,Small.const _ 1,Small.const _ 0⟩

lemma dimL (h : b.Lade S x) : b.Grain S fun i => (x i).l :=
  ⟨(Dry.fst (t:=a w) h.tape).fst,h.countB⟩
lemma volL (h : b.Lade S x) : b.Grain S fun i => (x i).vol :=
  ⟨(Dry.fst (t:=a w) h.tape).snd,h.volume⟩
lemma dataL (h : b.Lade S x) :
    b.Dry S (a w) fun i => Tape.tab (x i).l (x i).q :=
  (Dry.snd h.tape)

lemma push (h : b.Lade S x) (g : b.Grain S k) :
    b.Lade S fun i => (x i).pushQ (k i) := by
  let l i := (x i).l
  let e i := l i+1
  have hk := h.dimL.add (Grain.wc 1)
  have hs := h.countS.add (Small.const S 1)
  have F := Instant.scan b e
  have hj := chopG hk
  refine ⟨(hk.dry.pair (h.volL.mul g).dry).pair (arrayG hk hs
    (t:=w) (fun i => ((x i).pushQ (k i)).q)
    (((hj.cmp (h.dimL.transfer F)).dry.branch (g.transfer F).dry
      ((h.dataL.transfer F).look hj.dry)).congr ?_)),hk.small,(h.volL.mul g).small,hs⟩
  intro i
  simp only [Tape.look_tab, Cart.pushQ]
  have HH : i.j < (x i.i).l+1 := i.hj
  by_cases e : i.j < (x i.i).l
  · simp [e,Nat.ne_of_lt e]
  · simp [show i.j=(x i.i).l by omega]
end Lade

lemma reapL (h : b.Grain S N) (hp : ∀ i, 0 < N i) (g : b.Grain S k) (u : Small S k) :
    b.Lade S fun i => reap (N i) (k i) := by
  have hh (i) (j) := reap_baler (N i) j (hp i)
  let R (i : ι) (j) := reap (N i) j
  let f (i : ι) (j) : T cartTy := cartT (R i j)
  have F := Instant.climbs b k f (t:=cartTy)
  have B := (h.transfer F)
  have hj := strideG g f
  let D := b.climbs k cartTy f
  have hy : Small (fun i : During k => S i.i) During.j :=
    (u.reindex _).mono (fun i => i.hj.le)
  have ht : D.Lade (fun i => S i.i) fun i => R i.i i.j :=
    ⟨Dry.token b k S f,hj.small.mono (fun i => (hh _ _).count),
      B.small.mono fun i => (hh _ _).top, hy.mono fun i => (hh _ _).count⟩
  refine ⟨cycleG g u f (Lade.emptyL b S).tape
    ((((hj.isBar hy).dry.branch ht.tape
      ((B.cmp (ht.volL.mul hj)).dry.branch (ht.push hj).tape ht.tape))).congr ?_),
    g.small.mono fun i => (hh _ _).count,h.small.mono fun i => (hh _ _).top,
    u.mono fun i => (hh _ _).count⟩
  intro i
  by_cases e : Bar i.j
  · by_cases H : (reap (N i.i) i.j).vol * i.j ≤ N i.i
    · simp [f,R,reap,e,H,not_lt.mpr H]
    · simp [f,R,reap,e,H,Nat.lt_of_not_ge H]
  · simp [f,R,reap,e]

lemma fillerL (h : b.Grain S N) (g : b.Grain S k) {v : ι→ℕ} (u : b.Grain S v)
    (hh : Small S v) (hk : Small b.size fun i => 2^v i) :
    b.Grain S fun i => fill (N i) (k i) (v i) := by
  let f (i : ι) (j) : T w := fill (N i) (k i) j
  have F := Instant.climbs b v f (t:=w)
  have hg : (b.climbs v w f).Grain (fun i => S i.i) fun i => f i.i i.j :=
    ⟨Dry.token b v S f,(hk.reindex _).mono (fun i => (Fill.capacity _ _ _).trans
      (Nat.pow_le_pow_right (by omega) i.hj.le))⟩
  refine ⟨cycleG u hh f (Dry.wc 1)
    (((((g.transfer F).mul hg).cmp (h.transfer F)).dry.branch hg.dry
      (hg.mul (Grain.wc 2)).dry).congr ?_),hk.mono (fun i => Fill.capacity _ _ _)⟩
  intro i
  by_cases H : k i.i*fill (N i.i) (k i.i) i.j < N i.i <;> simp [f,fill,H]

structure Neaps (b : Bench m ι) (S n : ι→ℕ) : Prop where
  num : b.Nick n
  tidal : b.Nick S
  stack_eq : ∀ i, stackN (n i)=S i
  pos : ∀ i, 0<n i

namespace Neaps
variable {n : ι→ℕ} {f : ι→κ}

lemma transfer {S n : κ→ℕ} (h : q.Neaps S n) (g : b.Instant q f) :
    b.Neaps (fun i => S (f i)) fun i => n (f i) :=
  ⟨h.num.transfer g,h.tidal.transfer g,fun _ => h.stack_eq _,fun _ => h.pos _⟩

lemma stackPow (h : b.Neaps S n) : Small b.size fun i => 2^S i :=
  ((Small.const _ 4).mul h.num.small).mono fun i => h.stack_eq i ▸ stack_pow _ (h.pos _)

lemma siloS (h : b.Neaps S n) : Small S fun i => harvestN (n i) :=
  (((Small.const _ 16).mul ((Small.self S).add (Small.const _ 4))).pow 2).mono
    fun i => by rw [harvestN,silo,h.stack_eq]
lemma siloG (h : b.Neaps S n) : b.Grain S fun i => harvestN (n i) := by
  have hg := (Nick.wc 16).mul (h.tidal.add (Nick.wc 4))
  exact ((hg.mul hg).grain S).congr fun i => by rw [harvestN,silo,h.stack_eq,pow_two]

lemma powOrderS (h : b.Neaps S n) : Small S fun i => 2^orderE (n i) :=
  ((Small.const _ 8).mul h.siloS).mono fun _ => orderE_small _

lemma orderS (h : b.Neaps S n) : Small S fun i => orderE (n i) :=
  h.powOrderS.mono fun _ => Nat.lt_two_pow_self.le
lemma orderG (h : b.Neaps S n) : b.Grain S fun i => orderE (n i) :=
  (((Grain.wc 2).mul h.siloG).logtwo ((Small.const _ 2).mul h.siloS)).add (Grain.wc 2)
lemma powOrderG (h : b.Neaps S n) : b.Grain S fun i => 2^orderE (n i) :=
  h.orderG.twoPow h.orderS (h.powOrderS.trans h.tidal.small)

lemma bedL (h : b.Neaps S n) : b.Lade S fun i => bed (n i) :=
  reapL ((Grain.wc 2).mul (h.num.grain S)) (fun i => by have := h.pos i; omega)
    (h.siloG.add (Grain.wc 1)) (h.siloS.add (Small.const _ 1))

lemma bargeL (h : b.Neaps S n) : b.Lade S fun i => barge (n i) :=
  h.bedL.push ((fillerL ((Grain.wc 2).mul (h.num.grain S)) h.bedL.volL
    (h.tidal.grain S) (Small.self S) h.stackPow).congr fun i => by rw [bead,h.stack_eq])

lemma expressG (h : b.Neaps S n) :
    b.Grain S fun i => express (n i) :=
  (((Grain.wc 2).mul (h.num.grain S)).mul h.bargeL.volL).mul h.powOrderG

lemma portG (h : b.Neaps S n) :
    b.Grain S fun i => if Ports (n i) then 0 else 1 :=
  ((h.num.grain S).cmp h.powOrderG).congr fun i => by
    by_cases hn : n i < 2^orderE (n i)
    · simp [Ports, hn, show ¬2^orderE (n i) ≤ n i from (by omega)]
    · simp [Ports, hn, show 2^orderE (n i) ≤ n i from (by omega)]

lemma receiptG (h : b.Neaps S n) :
    b.Grain S fun i => receipt (n i) :=
  ⟨(h.portG.dry.branch h.expressG.dry (h.num.grain S).dry).congr fun i => by
    by_cases H : Ports (n i) <;> simp [receipt,H],
   ((Small.const _ 8).mul (h.num.small.pow 3)).mono fun i => (receipt_bound _ (h.pos _)).2.le⟩
end Neaps

lemma Nick.stackH (h : b.Nick N) (g : ∀ i, 0<N i) :
    b.Moves N w (fun i => stackN (N i)) ∧
    (b.extend w (fun i => stackN (N i))).Neaps (fun i => stackN (N i)) N := by
  have hk := (Nick.wc 2).mul h
  have hu := ((Small.const _ 4).mul h.small).mono (G:=fun i => stackN (N i))
    (fun i => stack_le _ (g i))
  have hd := Can.wadd hk.logM (Can.wc 1) hu
  exact ⟨Can.weaken hd ⟨2,fun i => by dsimp; omega⟩,
    ⟨h.transfer (Instant.extend b _),⟨cherry b _ (t:=w),hu⟩,fun i => rfl,g⟩⟩

lemma Nick.planOrder (h : b.Nick N) (g : ∀ i,0<N i) :
    ∃ d : ℕ,b.Moves (fun i => N i + (stackN (N i)+2)^d) w fun i => receipt (N i) := by
  obtain ⟨hu,hk⟩ := h.stackH g
  obtain ⟨d,hd⟩ := hk.receiptG.dry
  exact ⟨d,Can.save hu hd⟩
end Bench
end
end PowerSaving.RAM

end OAI
