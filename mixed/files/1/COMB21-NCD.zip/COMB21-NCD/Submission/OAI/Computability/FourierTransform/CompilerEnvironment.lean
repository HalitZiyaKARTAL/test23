import Submission.OAI.Computability.FourierTransform.RAM
import Mathlib.Algebra.BigOperators.Group.Finset.Basic

namespace OAI
namespace PowerSaving
open Finset

universe u v U V Z

local macro "ce_omega" : tactic => `(tactic| ((try dsimp only at *); omega))

variable {α β : Type*}

namespace Tape

theorem ext_look {a b : Tape α} (hlen : a.len = b.len)
    (z : α) (h : ∀ i, i<a.len → a.look i z = b.look i z) : a=b := by
  obtain ⟨n, f⟩ := a
  obtain ⟨n', g⟩ := b
  change n = n' at hlen
  subst hlen
  refine congrArg (Tape.mk n) (funext fun i => ?_)
  have := h i.val i.isLt
  rwa [look_of_lt (Tape.mk n f) z i.isLt, look_of_lt (Tape.mk n g) z i.isLt] at this

theorem look_tab (n : ℕ) (f : ℕ → α) (i z) :
    (tab n f).look i z = if i<n then f i else z := by
  unfold look tab
  by_cases h : i < n <;> simp [h]

theorem look_set (v : Tape α) (k i : ℕ) (x o : α) :
    (v.set k x).look i o = if i = k ∧ i < v.len then x else v.look i o := by
  unfold Tape.set Tape.look
  by_cases h : i < v.len <;> by_cases e : i = k <;> simp_all

theorem sow_zero (n : ℕ) (z : α) (f : ℕ → ℕ × α) : sow n 0 z f = tab n (fun _ => z) := rfl

theorem sow_succ (n c : ℕ) (z : α) (f : ℕ → ℕ × α) :
    sow n (c+1) z f = (sow n c z f).set (f c).1 (f c).2 := rfl

@[simp] theorem len_tab (n : ℕ) (f : ℕ → α) : (tab n f).len = n := rfl

@[simp] theorem len_set (v : Tape α) (k : ℕ) (x : α) : (v.set k x).len = v.len := rfl

@[simp] theorem len_sow (n c : ℕ) (z : α) (f : ℕ → ℕ × α) : (sow n c z f).len = n := by
  induction c with
  | zero => rfl
  | succ c ih => rw [sow_succ]; exact ih

theorem sow_look_written {n k i j : ℕ} {z out : α} {f : ℕ → ℕ × α}
    (hin : i<n) (hj : j<k) (hf : (f j).1 = i)
    (hlast : ∀ s, j<s → s<k → (f s).1 ≠ i) :
    (sow n k z f).look i out = (f j).2 := by
  have key : ∀ d, j + 1 + d ≤ k → (sow n (j+1+d) z f).look i out = (f j).2 := by
    intro d
    induction d with
    | zero =>
      intro _
      rw [Nat.add_zero, sow_succ, look_set, if_pos ⟨hf.symm, by rw [len_sow]; exact hin⟩]
    | succ d ih =>
      intro hd
      rw [show j+1+(d+1) = (j+1+d)+1 by omega, sow_succ, look_set, if_neg]
      · exact ih (by omega)
      · rintro ⟨e, _⟩
        exact hlast (j+1+d) (by omega) (by omega) e.symm
  have := key (k - (j+1)) (by omega)
  rwa [show j+1+(k-(j+1)) = k by omega] at this

theorem sow_consecutive (n : ℕ) (z : α) (f : ℕ → α) :
    sow n n z (fun i => (i, f i)) = tab n f := by
  refine ext_look (len_sow n n z _) z (fun i hi => ?_)
  rw [len_sow] at hi
  rw [sow_look_written hi hi rfl (fun s h1 _ => by show s ≠ i; omega), look_tab, if_pos hi]

end Tape

namespace RAM
open Ty

namespace Bill

structure OK (b : Bill α) (x : α) (w p : ℕ) : Prop where
  result : b.val = x
  time : b.work ≤ w
  bound : b.peak ≤ p
  valid : b.valid

variable {x : α} {y : β} {w w' p p' z t : ℕ}

theorem OK.mono {b : Bill α} (h : b.OK (x:α) w p) (u : w ≤ w') (v : p ≤ p') :
    b.OK x w' p' :=
  ⟨h.1, Nat.le_trans h.2 u, Nat.le_trans h.3 v, h.4⟩

theorem OK.pass {b : Bill α} (h : b.OK (x:α) w p) {f : α → Bill β}
    (g : (f x).OK y w' p) : (b.pass f).OK y (w+w') p := by
  obtain ⟨h1, h2, h3, h4⟩ := h
  subst h1
  exact ⟨g.1, Nat.add_le_add h2 g.2, max_le h3 g.3, And.intro h4 g.4⟩

theorem OK.pay {b : Bill α} (h : b.OK (x:α) w p) (h' : z ≤ p) :
    (b.pay t z).OK x (w+t) p :=
  ⟨h.1, Nat.add_le_add_right h.2 t, max_le h.3 h', h.4⟩

theorem one_ok : (Bill.one x).OK x 1 p := ⟨rfl, Nat.le_refl 1, Nat.zero_le p, trivial⟩

theorem word_ok {n : ℕ} (h : n ≤ p) : (Bill.word n).OK n 1 p := ⟨rfl, Nat.le_refl 1, h, trivial⟩

theorem steps_ok {init : α} {g : ℕ → α → Bill α} {v : ℕ → α} {U : ℕ → ℕ} {n : ℕ}
    (h0 : v 0 = init) (hn : n ≤ p)
    (h : ∀ i, i < n → (g i (v i)).OK (v (i+1)) (U i) p) :
    (Bill.steps init g n).OK (v n) (1 + ∑ i ∈ range n, (U i + 1)) p := by
  induction n with
  | zero =>
    subst h0
    exact ⟨rfl, by simp [Bill.steps, Bill.one], Nat.zero_le _, trivial⟩
  | succ n ih =>
    have H := ((ih (by omega) (fun i hi => h i (by omega))).pass (h n (by omega))).pay
      (t := 1) (Nat.le_trans (Nat.le_refl (n+1)) hn)
    refine H.mono (Nat.le_of_eq ?_) (Nat.le_refl _)
    rw [Finset.sum_range_succ]; omega

theorem sow_ok {q : ℕ → ℕ × α} {f : ℕ → Bill (ℕ × α)} (U : ℕ → ℕ) (len n p : ℕ) (z : α)
    (hl : len ≤ p) (hn : n ≤ p) (h : ∀ i, i < n → (f i).OK (q i) (U i) p) :
    (Bill.sow len n z f).OK (Tape.sow len n z q) ((1 + ∑ i ∈ range n, (U i + 2)) + (1+len)) p := by
  unfold Bill.sow
  -- CHECK: `U i + 1 + 1` (from `steps_ok`) against `U i + 2` is closed by defeq (Nat offsets)
  exact OK.pay (steps_ok (v := fun c => Tape.sow len c z q) (U := fun i => U i + 1) rfl hn
    (fun i hi => (h i hi).pass (f := fun s => Bill.one ((Tape.sow len i z q).set s.1 s.2))
      Bill.one_ok)) hl

theorem tab_ok {v : ℕ → α} {f : ℕ → Bill α}
    (W : ℕ → ℕ) (len p : ℕ) (z : α) (hl : len ≤ p)
    (h : ∀ i, i<len → (f i).OK (v i) (W i) p) :
    (tab len z f).OK (Tape.tab len v)
      ((1+∑ i ∈ range len, (W i+3))+(1+len)) p := by
  have H : (Bill.tab len z f).OK (Tape.sow len len z (fun i => (i, v i)))
      ((1 + ∑ i ∈ range len, (W i + 1 + 2)) + (1+len)) p :=
    sow_ok (fun i => W i + 1) len len p z hl hl
      (fun i hi => (h i hi).pass (f := fun y => Bill.one (i, y)) Bill.one_ok)
  rw [Tape.sow_consecutive] at H
  refine H.mono (Nat.le_of_eq ?_) (Nat.le_refl _)
  rw [Finset.sum_congr rfl (fun i _ => (show W i + 1 + 2 = W i + 3 by omega))]

end Bill

theorem mulle (c : ℕ) {a b : ℕ} (h : a ≤ b) : c*a ≤ c*b := Nat.mul_le_mul (Nat.le_refl c) h

theorem le_pow_self (b n : ℕ) : n ≤ (b+2)^n := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Nat.pow_succ]
    have := mulle ((b+2)^n) (show 2 ≤ b+2 by omega)
    have h1 : 1 ≤ (b+2)^n := Nat.le_trans (by simp) (Nat.pow_le_pow_right (show 0 < b+2 by omega) (Nat.zero_le n))
    omega

theorem base_lift {b c e : ℕ} (h : b ≤ (c+2)^e) : b+2 ≤ (c+2)^(e+2) := by
  have h1 : 1 ≤ (c+2)^e := Nat.le_trans (by simp) (Nat.pow_le_pow_right (show 0 < c+2 by omega) (Nat.zero_le e))
  rw [Nat.pow_add, Nat.pow_two]
  have h3 := mulle ((c+2)^e) (Nat.mul_le_mul (show 2 ≤ c+2 by omega) (show 2 ≤ c+2 by omega))
  omega

theorem pow_lift {b c e : ℕ} (d : ℕ) (h : b ≤ (c+2)^e) : (b+2)^d ≤ (c+2)^((e+2)*d) := by
  rw [Nat.pow_mul]; exact Nat.pow_le_pow_left (base_lift h) d

theorem four_le (b D : ℕ) : 4*(b+2)^D ≤ (b+2)^(D+2) := by
  rw [Nat.pow_add, Nat.pow_two]
  have := mulle ((b+2)^D) (Nat.mul_le_mul (show 2 ≤ b+2 by omega) (show 2 ≤ b+2 by omega))
  omega

theorem sum_const' (n c : ℕ) : ∑ _j ∈ range n, c = n*c := by
  induction n with
  | zero => simp
  | succ n ih => rw [Finset.sum_range_succ, ih, Nat.add_mul, Nat.one_mul]

theorem sum_time (a k : ℕ) (U V : ℕ → ℕ) (n : ℕ) :
    ∑ j ∈ range n, (a*(U j+1)+V j+k) ≤ (a+k)*(n + ∑ j ∈ range n, U j) + ∑ j ∈ range n, V j := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Finset.sum_range_succ, Finset.sum_range_succ, Finset.sum_range_succ]
    have e : (a+k)*(n+1+(∑ j ∈ range n, U j + U n)) =
        (a+k)*(n+∑ j ∈ range n, U j) + (a*(U n+1) + k*(U n+1)) := by
      rw [← Nat.add_mul a k (U n + 1), ← Nat.mul_add]; congr 1; omega
    have f : k*1 ≤ k*(U n+1) := mulle k (by omega)
    omega

theorem lin2 (a b k x y : ℕ) : a*(x+1)+b*(y+1)+k ≤ (a+b+k)*(x+y+1) := by
  rw [Nat.add_mul, Nat.add_mul]
  have h1 := mulle a (show x+1 ≤ x+y+1 by omega)
  have h2 := mulle b (show y+1 ≤ x+y+1 by omega)
  have h3 := mulle k (show 1 ≤ x+y+1 by omega)
  omega

theorem tabA (a b x y q : ℕ) : a*(x+1) + b*(y+q) + y + 3 ≤ (a+b+3)*(x+y+q+1) := by
  rw [Nat.add_mul, Nat.add_mul]
  have h1 := mulle a (show x+1 ≤ x+y+q+1 by omega)
  have h2 := mulle b (show y+q ≤ x+y+q+1 by omega)
  omega

theorem loopA (a a' b x x' y q : ℕ) :
    a*(x+1) + a'*(x'+1) + b*(y+q) + 2 ≤ (a+a'+b+2)*(x+x'+y+q+1) := by
  rw [Nat.add_mul, Nat.add_mul, Nat.add_mul]
  have h1 := mulle a (show x+1 ≤ x+x'+y+q+1 by omega)
  have h1' := mulle a' (show x'+1 ≤ x+x'+y+q+1 by omega)
  have h2 := mulle b (show y+q ≤ x+x'+y+q+1 by omega)
  omega

theorem sowA (a a' b x x' l y q : ℕ) :
    a*(x+1) + a'*(x'+1) + b*(y+q) + l + 4 ≤ (a+a'+b+4)*(x+x'+l+y+q+1) := by
  rw [Nat.add_mul, Nat.add_mul, Nat.add_mul]
  have h1 := mulle a (show x+1 ≤ x+x'+l+y+q+1 by omega)
  have h1' := mulle a' (show x'+1 ≤ x+x'+l+y+q+1 by omega)
  have h2 := mulle b (show y+q ≤ x+x'+l+y+q+1 by omega)
  omega

def Small {ι : Type u} (B F : ι → ℕ) : Prop := ∃ d : ℕ, ∀ i, F i ≤ (B i+2)^d

namespace Small
variable {ι : Type u} {κ : Type v} {B C F G : ι → ℕ}

theorem const (B : ι → ℕ) (n : ℕ) : Small B (fun _ => n) := ⟨n, fun i => le_pow_self (B i) n⟩

theorem self (B : ι → ℕ) : Small B B := ⟨1, fun i => by rw [Nat.pow_one]; omega⟩

theorem reindex (h : Small B F) (f : κ → ι) : Small (fun j => B (f j)) (fun j => F (f j)) :=
  let ⟨d, hd⟩ := h; ⟨d, fun j => hd (f j)⟩

theorem mono (h : Small B F) (hh : ∀ i, G i ≤ F i) : Small B G :=
  let ⟨d, hd⟩ := h; ⟨d, fun i => Nat.le_trans (hh i) (hd i)⟩

theorem mul (h : Small B F) (g : Small B G) : Small B (fun i => F i * G i) :=
  let ⟨d, hd⟩ := h
  let ⟨e, he⟩ := g
  ⟨d+e, fun i => by rw [Nat.pow_add]; exact Nat.mul_le_mul (hd i) (he i)⟩

theorem pow_mono_degree (b : ℕ) {d e : ℕ} (h : d ≤ e) :
    (b+2)^d ≤ (b+2)^e := Nat.pow_le_pow_right (by omega) h

theorem add (h : Small B F) (g : Small B G) : Small B (fun i => F i + G i) := by
  obtain ⟨d, hd⟩ := h
  obtain ⟨e, he⟩ := g
  refine ⟨d+e+1, fun i => ?_⟩
  show F i + G i ≤ (B i+2)^(d+e+1)
  have h1 := pow_mono_degree (B i) (Nat.le_add_right d e)
  have h2 := pow_mono_degree (B i) (Nat.le_add_left e d)
  have h4 := mulle ((B i+2)^(d+e)) (show 2 ≤ B i+2 by omega)
  have h5 := hd i
  have h6 := he i
  rw [Nat.pow_succ]
  omega

theorem max (h : Small B F) (g : Small B G) :
    Small B (fun i => Max.max (F i) (G i)) :=
  (h.add g).mono fun _ => max_le (Nat.le_add_right _ _) (Nat.le_add_left _ _)

theorem pow (h : Small B F) (n : ℕ) : Small B (fun i => (F i)^n) :=
  let ⟨d, hd⟩ := h
  ⟨d*n, fun i => by rw [Nat.pow_mul]; exact Nat.pow_le_pow_left (hd i) n⟩

theorem trans (h : Small B F) (g : Small C B) : Small C F :=
  let ⟨d, hd⟩ := h
  let ⟨e, he⟩ := g
  ⟨(e+2)*d, fun i => Nat.le_trans (hd i) (pow_lift d (he i))⟩

end Small

def Dom {ι : Type u} (W F : ι → ℕ) : Prop :=
  ∃ C : ℕ, ∀ i, F i+1 ≤ C*(W i+1)

namespace Dom
variable {ι : Type u} {W F G : ι → ℕ}

theorem of_le (h : ∀ i, F i ≤ W i) : Dom W F := ⟨1, fun i => by have := h i; omega⟩

theorem self (W : ι → ℕ) : Dom W W := of_le fun _ => Nat.le_refl _

theorem const (W : ι → ℕ) (n : ℕ) : Dom W (fun _ => n) :=
  ⟨n+1, fun i => by show n + 1 ≤ (n+1)*(W i+1); have := mulle (n+1) (show 1 ≤ W i+1 by omega); omega⟩

theorem add (a : Dom W F) (b : Dom W G) : Dom W (fun i => F i + G i) :=
  let ⟨C1, h1⟩ := a
  let ⟨C2, h2⟩ := b
  ⟨C1+C2, fun i => by
    show F i + G i + 1 ≤ (C1+C2)*(W i+1)
    have := h1 i; have := h2 i; rw [Nat.add_mul]; omega⟩

theorem trans (a : Dom W F) (b : Dom F G) : Dom W G :=
  let ⟨C1, h1⟩ := a
  let ⟨C2, h2⟩ := b
  ⟨C2*C1, fun i => Nat.le_trans (h2 i) (by rw [Nat.mul_assoc]; exact mulle C2 (h1 i))⟩

end Dom

structure Bank (r : Port) (ι : Type U) where
  B : ι → ℕ
  ext : ι → ℕ             -- additional bound allowed on words of external calls
  use : ι → Handler r

section
variable {ι : Type U} {r : Port}

def Bank.cap (b : Bank r ι) (d : ℕ) (i : ι) : ℕ :=
  max ((b.B i+2)^d) (b.ext i)

theorem Bank.cm (b : Bank r ι) {d e} (h : d ≤ e) (i : ι) : b.cap d i ≤ b.cap e i :=
  max_le (Nat.le_trans (Small.pow_mono_degree _ h) (le_max_left _ _)) (le_max_right _ _)

def Bank.closed {ι : Type U} (B : ι → ℕ) : Bank none ι := ⟨B, fun _ => 0, fun _ => ()⟩

def Bank.comap {ι : Type U} {κ : Type V} (b : Bank r ι) (f : κ → ι) : Bank r κ :=
  ⟨fun i => b.B (f i), fun i => b.ext (f i), fun i => b.use (f i)⟩

def Able {r} {ι : Type U} (m : Bool) (b : Bank r ι) (s t)
    (x : ι → T s) (y : ι → T t) (W Z : ι → ℕ) : Prop :=
  ∃ (f : Code m r s t) (C d : ℕ), ∀ i,
    (f.run (b.use i) (x i)).OK (y i) (C*(W i+1)+Z i) (b.cap d i)

abbrev Can {ι : Type U} (m : Bool) (B : ι → ℕ) (s t)
    (x : ι → T s) (y : ι → T t) (W : ι → ℕ) : Prop :=
  Able m (Bank.closed B) s t x y W (fun _ => 0)

end

structure During {ι : Type U} (n : ι → ℕ) where
  i : ι
  j : ℕ
  hj : j < n i

namespace Able
variable {ι : Type U} {κ : Type V} {r : Port} {m : Bool} {b : Bank r ι} {s t u : Ty}
  {x : ι → T s} {y : ι → T t} {z : ι → T u} {W W' Z Z' : ι → ℕ}

theorem reindex (h : Able m b s t x y W Z) (f : κ → ι) :
    Able m (b.comap f) s t (fun i => x (f i)) (fun i => y (f i))
      (fun i => W (f i)) (fun i => Z (f i)) :=
  let ⟨g, C, d, hg⟩ := h; ⟨g, C, d, fun j => hg (f j)⟩

theorem cong (h : Able m b s t x y W Z) {x' y'} (hx : ∀ i, x i = x' i)
    (hy : ∀ i, y i = y' i) : Able m b s t x' y' W Z := by
  obtain rfl : x = x' := funext hx
  obtain rfl : y = y' := funext hy
  exact h

theorem weaken (h : Able m b s t x y W Z) (hW : Dom W' W)
    (hZ : ∀ i, Z i ≤ Z' i) : Able m b s t x y W' Z' := by
  obtain ⟨f, C, d, hf⟩ := h
  obtain ⟨D, hD⟩ := hW
  exact ⟨f, C*D, d, fun i => (hf i).mono
    (Nat.add_le_add (by rw [Nat.mul_assoc]; exact mulle C (hD i)) (hZ i)) (Nat.le_refl _)⟩

theorem mono (h : Able m b s t x y W Z) (hW : ∀ i, W i ≤ W' i)
    (hZ : ∀ i, Z i ≤ Z' i) : Able m b s t x y W' Z' :=
  h.weaken (Dom.of_le hW) hZ

theorem atom_ok {t' : Ty} {q : ι → T t'} (o : Atom m s t') (d : ℕ)
    (ho : ∀ i, (o.run (x i)).OK (q i) 1 (b.cap d i)) : Able m b s t' x q W Z :=
  ⟨.atom o, 1, d, fun i => (ho i).mono (by ce_omega) (Nat.le_refl _)⟩

theorem comp (h : Able m b s t x y W Z) (g : Able m b t u y z W' Z') :
    Able m b s u x z (fun i => W i + W' i) (fun i => Z i + Z' i) := by
  obtain ⟨f1, C1, d1, h1⟩ := h
  obtain ⟨f2, C2, d2, h2⟩ := g
  refine ⟨.comp f1 f2, C1+C2+1, d1+d2, fun i => ?_⟩
  have a1 := (h1 i).mono (Nat.le_refl _) (b.cm (Nat.le_add_right d1 d2) i)
  have a2 := (h2 i).mono (Nat.le_refl _) (b.cm (Nat.le_add_left d2 d1) i)
  have L := lin2 C1 C2 1 (W i) (W' i)
  exact ((a1.pass a2).pay (t := 1) (Nat.zero_le _)).mono (by ce_omega) (Nat.le_refl _)

theorem fork (h : Able m b s t x y W Z) (g : Able m b s u x z W' Z') :
    Able m b s (p t u) x (fun i => (y i,z i)) (fun i => W i+W' i) (fun i => Z i+Z' i) := by
  obtain ⟨f1, C1, d1, h1⟩ := h
  obtain ⟨f2, C2, d2, h2⟩ := g
  refine ⟨.fork f1 f2, C1+C2+1, d1+d2, fun i => ?_⟩
  have a1 := (h1 i).mono (Nat.le_refl _) (b.cm (Nat.le_add_right d1 d2) i)
  have a2 := (h2 i).mono (Nat.le_refl _) (b.cm (Nat.le_add_left d2 d1) i)
  have L := lin2 C1 C2 1 (W i) (W' i)
  -- CHECK: higher-order unification of the two `pass` continuations from the goal
  exact (a1.pass (f := fun y' => (f2.run (b.use i) (x i)).pass (fun z' => Bill.one (y', z')))
    (a2.pass (f := fun z' => Bill.one (y i, z')) Bill.one_ok)).mono (by ce_omega) (Nat.le_refl _)

theorem use_call {b : Bank (some (s,t)) ι}
    (h : ∀ i, (b.use i (x i)).OK (y i) (Z i) (b.ext i)) :
    Able m b s t x y (fun _ => 0) Z :=
  ⟨.call, 1, 0, fun i => ((h i).pay (t := 1) (Nat.zero_le _)).mono (by ce_omega) (le_max_right _ _)⟩

theorem of_can (h : Can m b.B s t x y W) :
    Able m b s t x y W (fun _ => 0) := by
  obtain ⟨f, C, d, hf⟩ := h
  refine ⟨.importClosed f, C+1, d, fun i => ((hf i).pay (t := 1) (Nat.zero_le _)).mono ?_ ?_⟩
  · have e := Nat.add_mul C 1 (W i + 1)
    ce_omega
  · exact max_le (le_max_left _ _) (Nat.zero_le _)

theorem id : Able m b s s x x W Z := atom_ok .id 0 (fun _ => Bill.one_ok)

theorem first {v : ι → T (p s t)} : Able m b (p s t) s v (fun i => (v i).1) W Z :=
  atom_ok .fst 0 (fun _ => Bill.one_ok)

theorem second {v : ι → T (p s t)} : Able m b (p s t) t v (fun i => (v i).2) W Z :=
  atom_ok .snd 0 (fun _ => Bill.one_ok)

theorem comp0 (h : Able m b s t x y W Z) (g : Able m b t u y z (fun _ => 0) (fun _ => 0)) :
    Able m b s u x z W Z :=
  (h.comp g).weaken (Dom.of_le fun i => Nat.le_of_eq (Nat.add_zero (W i)))
    (fun i => Nat.le_of_eq (Nat.add_zero (Z i)))

theorem fst {v : ι → T (p t u)} (h : Able m b s (p t u) x v W Z) :
    Able m b s t x (fun i => (v i).1) W Z := h.comp0 first

theorem snd {v : ι → T (p t u)} (h : Able m b s (p t u) x v W Z) :
    Able m b s u x (fun i => (v i).2) W Z := h.comp0 second

theorem save (h : Able m b s t x y W Z)
    (g : Able m b (p s t) u (fun i => (x i,y i)) z W' Z') :
    Able m b s u x z (fun i => W i + W' i) (fun i => Z i + Z' i) :=
  (((id (W := fun _ => 0) (Z := fun _ => 0)).fork h).comp g).mono
    (fun _ => by ce_omega) (fun _ => by ce_omega)

theorem ifz {n : ι → ℕ}
    (hx : Able m b s w x n W' Z')
    (hz : Able m (b.comap (fun i : {i // n i = 0} => i.val)) s t
      (fun i => x i.val) (fun i => y i.val) (fun i => W i.val) (fun i => Z i.val))
    (hn : Able m (b.comap (fun i : {i // n i ≠ 0} => i.val)) s t
      (fun i => x i.val) (fun i => y i.val) (fun i => W i.val) (fun i => Z i.val)) :
    Able m b s t x y (fun i => W' i+W i) (fun i => Z' i+Z i) := by
  obtain ⟨fq, Cq, dq, hq⟩ := hx
  obtain ⟨fz, Cz, dz, hz⟩ := hz
  obtain ⟨fn, Cn, dn, hn⟩ := hn
  refine ⟨.ifz fq fz fn, Cq+(Cz+Cn)+1, dq+dz+dn, fun i => ?_⟩
  have a1 := (hq i).mono (Nat.le_refl _) (b.cm (show dq ≤ dq+dz+dn by omega) i)
  have hsel : (if n i = 0 then fz.run (b.use i) (x i) else fn.run (b.use i) (x i)).OK (y i)
      ((Cz+Cn)*(W i+1)+Z i) (b.cap (dq+dz+dn) i) := by
    by_cases e : n i = 0
    · rw [if_pos e]
      exact (hz ⟨i, e⟩).mono (Nat.add_le_add_right (Nat.mul_le_mul (Nat.le_add_right _ _)
        (Nat.le_refl _)) _) (b.cm (show dz ≤ dq+dz+dn by omega) i)
    · rw [if_neg e]
      exact (hn ⟨i, e⟩).mono (Nat.add_le_add_right (Nat.mul_le_mul (Nat.le_add_left _ _)
        (Nat.le_refl _)) _) (b.cm (show dn ≤ dq+dz+dn by omega) i)
  have L := lin2 Cq (Cz+Cn) 1 (W' i) (W i)
  exact ((a1.pass (f := fun l => if l = 0 then fz.run (b.use i) (x i) else fn.run (b.use i) (x i))
    hsel).pay (t := 1) (Nat.zero_le _)).mono (by ce_omega) (Nat.le_refl _)

theorem loop {n : ι → ℕ} {v : ι → ℕ → T t} {Wb Zb : ι → ℕ → ℕ}
    (h : Able m b s w x n W Z)
    (hi : Able m b s t x (fun i => v i 0) W' Z')
    (hs : Able m (b.comap (During.i (n:=n))) (p s (p w t)) t
      (fun d => (x d.i,d.j,v d.i d.j)) (fun d => v d.i (d.j+1))
      (fun d => Wb d.i d.j) (fun d => Zb d.i d.j))
    (hc : Small b.B n) :
    Able m b s t x (fun i => v i (n i))
      (fun i => W i + W' i + n i + ∑ j ∈ range (n i), Wb i j)
      (fun i => Z i + Z' i + ∑ j ∈ range (n i), Zb i j) := by
  obtain ⟨f1, C1, d1, h1⟩ := h
  obtain ⟨f2, C2, d2, h2⟩ := hi
  obtain ⟨f3, C3, d3, h3⟩ := hs
  obtain ⟨e, he⟩ := hc
  refine ⟨.loop f1 f2 f3, C1+C2+(C3+1)+2, d1+d2+d3+e, fun i => ?_⟩
  have hP : n i ≤ b.cap (d1+d2+d3+e) i :=
    Nat.le_trans (he i) (Nat.le_trans (Small.pow_mono_degree _ (by omega)) (le_max_left _ _))
  have a1 := (h1 i).mono (Nat.le_refl _) (b.cm (show d1 ≤ d1+d2+d3+e by omega) i)
  have a2 := (h2 i).mono (Nat.le_refl _) (b.cm (show d2 ≤ d1+d2+d3+e by omega) i)
  have a3 := Bill.steps_ok (g := fun j z => f3.run (b.use i) (x i, (j, z))) (v := v i)
    (U := fun j => C3*(Wb i j+1)+Zb i j) rfl hP
    (fun j hj => (h3 ⟨i, j, hj⟩).mono (Nat.le_refl _) (b.cm (show d3 ≤ d1+d2+d3+e by omega) i))
  have S := sum_time C3 1 (Wb i) (Zb i) (n i)
  have L := loopA C1 C2 (C3+1) (W i) (W' i) (n i) (∑ j ∈ range (n i), Wb i j)
  exact ((a1.pass (f := fun l => (f2.run (b.use i) (x i)).pass
      (fun y => Bill.steps y (fun j z => f3.run (b.use i) (x i, (j, z))) l))
    (a2.pass (f := fun y => Bill.steps y (fun j z => f3.run (b.use i) (x i, (j, z))) (n i)) a3)).pay
    (t := 1) (Nat.zero_le _)).mono (by ce_omega) (Nat.le_refl _)

theorem sow {n : ι → ℕ} {v : ι → ℕ → ℕ × T t} {len : ι → ℕ} {Wl Zl : ι → ℕ} {Wb Zb : ι → ℕ → ℕ}
    (hx : Able m b s w x len Wl Zl)
    (h : Able m b s w x n W Z)
    (hs : Able m (b.comap (During.i (n:=n))) (p s w) (p w t)
      (fun d => (x d.i,d.j)) (fun d => v d.i d.j) (fun d => Wb d.i d.j) (fun d => Zb d.i d.j))
    (hg : Small b.B len) (hc : Small b.B n) :
    Able m b s (a t) x (fun i => Tape.sow (len i) (n i) t.blank (v i))
      (fun i => Wl i + W i + len i + n i + ∑ j ∈ range (n i), Wb i j)
      (fun i => Zl i + Z i + ∑ j ∈ range (n i), Zb i j) := by
  obtain ⟨f0, C0, d0, h0⟩ := hx
  obtain ⟨f1, C1, d1, h1⟩ := h
  obtain ⟨f3, C3, d3, h3⟩ := hs
  obtain ⟨e, he⟩ := hc
  obtain ⟨e', he'⟩ := hg
  refine ⟨.sow f0 f1 f3, C0+C1+(C3+2)+4, d0+d1+d3+e+e', fun i => ?_⟩
  have hP : n i ≤ b.cap (d0+d1+d3+e+e') i :=
    Nat.le_trans (he i) (Nat.le_trans (Small.pow_mono_degree _ (by omega)) (le_max_left _ _))
  have hL : len i ≤ b.cap (d0+d1+d3+e+e') i :=
    Nat.le_trans (he' i) (Nat.le_trans (Small.pow_mono_degree _ (by omega)) (le_max_left _ _))
  have a0 := (h0 i).mono (Nat.le_refl _) (b.cm (show d0 ≤ d0+d1+d3+e+e' by omega) i)
  have a1 := (h1 i).mono (Nat.le_refl _) (b.cm (show d1 ≤ d0+d1+d3+e+e' by omega) i)
  have a3 := Bill.sow_ok (f := fun j => f3.run (b.use i) (x i, j)) (q := v i)
    (fun j => C3*(Wb i j+1)+Zb i j) (len i) (n i) _ t.blank hL hP
    (fun j hj => (h3 ⟨i, j, hj⟩).mono (Nat.le_refl _) (b.cm (show d3 ≤ d0+d1+d3+e+e' by omega) i))
  have S := sum_time C3 2 (Wb i) (Zb i) (n i)
  have L := sowA C0 C1 (C3+2) (Wl i) (W i) (len i) (n i) (∑ j ∈ range (n i), Wb i j)
  exact ((a0.pass (f := fun l => (f1.run (b.use i) (x i)).pass
      (fun k => Bill.sow l k t.blank (fun j => f3.run (b.use i) (x i, j))))
    (a1.pass (f := fun k => Bill.sow (len i) k t.blank (fun j => f3.run (b.use i) (x i, j))) a3)).pay
    (t := 1) (Nat.zero_le _)).mono (by ce_omega) (Nat.le_refl _)

theorem tab {n : ι → ℕ} {v : ι → ℕ → T t} {Wb Zb : ι → ℕ → ℕ}
    (h : Able m b s w x n W Z)
    (hs : Able m (b.comap (During.i (n:=n))) (p s w) t
      (fun d => (x d.i,d.j)) (fun d => v d.i d.j) (fun d => Wb d.i d.j) (fun d => Zb d.i d.j))
    (hc : Small b.B n) :
    Able m b s (a t) x (fun i => Tape.tab (n i) (v i))
      (fun i => W i + n i + ∑ j ∈ range (n i), Wb i j)
      (fun i => Z i + ∑ j ∈ range (n i), Zb i j) := by
  obtain ⟨f1, C1, d1, h1⟩ := h
  obtain ⟨f3, C3, d3, h3⟩ := hs
  obtain ⟨e, he⟩ := hc
  refine ⟨.tab f1 f3, C1+(C3+3)+3, d1+d3+e, fun i => ?_⟩
  have hP : n i ≤ b.cap (d1+d3+e) i :=
    Nat.le_trans (he i) (Nat.le_trans (Small.pow_mono_degree _ (by omega)) (le_max_left _ _))
  have a1 := (h1 i).mono (Nat.le_refl _) (b.cm (show d1 ≤ d1+d3+e by omega) i)
  have a3 := Bill.tab_ok (f := fun j => f3.run (b.use i) (x i, j)) (v := v i)
    (fun j => C3*(Wb i j+1)+Zb i j) (n i) _ t.blank hP
    (fun j hj => (h3 ⟨i, j, hj⟩).mono (Nat.le_refl _) (b.cm (show d3 ≤ d1+d3+e by omega) i))
  have S := sum_time C3 3 (Wb i) (Zb i) (n i)
  have L := tabA C1 (C3+3) (W i) (n i) (∑ j ∈ range (n i), Wb i j)
  exact ((a1.pass (f := fun l => Bill.tab l t.blank (fun j => f3.run (b.use i) (x i, j))) a3).pay
    (t := 1) (Nat.zero_le _)).mono (by ce_omega) (Nat.le_refl _)

end Able

namespace Can
variable {ι : Type U} {κ : Type V} {m : Bool} {B B' : ι → ℕ} {s t u : Ty}
  {x : ι → T s} {y : ι → T t} {z : ι → T u} {W W' : ι → ℕ}

theorem unfold_bound (h : Can m B s t x y W) :
    ∃ (f : Prog m s t) (C d : ℕ), ∀ i,
      (run f (x i)).OK (y i) (C*(W i+1)) ((B i+2)^d) :=
  let ⟨f, C, d, hf⟩ := h
  ⟨f, C, d, fun i => (hf i).mono (Nat.le_of_eq (Nat.add_zero _)) (max_le (Nat.le_refl _) (Nat.zero_le _))⟩

theorem reindex (h : Can m B s t x y W) (f : κ → ι) :
    Can m (fun j => B (f j)) s t (fun j => x (f j)) (fun j => y (f j))
      (fun j => W (f j)) := Able.reindex h f

theorem cong (h : Can m B s t x y W) {x' y'} (hx : ∀ i, x i = x' i)
    (hy : ∀ i, y i = y' i) : Can m B s t x' y' W := Able.cong h hx hy

theorem weaken (h : Can m B s t x y W) (h' : Dom W' W) :
    Can m B s t x y W' := Able.weaken h h' (fun _ => Nat.le_refl _)

theorem mono (h : Can m B s t x y W) (h' : ∀ i, W i ≤ W' i) :
    Can m B s t x y W' := Able.mono h h' (fun _ => Nat.le_refl _)

theorem ambient (h : Can m B s t x y W) (h' : Small B' B) :
    Can m B' s t x y W := by
  obtain ⟨f, C, d, hf⟩ := h
  obtain ⟨e, he⟩ := h'
  exact ⟨f, C, (e+2)*d, fun i => (hf i).mono (Nat.le_refl _)
    (max_le (Nat.le_trans (pow_lift d (he i)) (le_max_left _ _)) (Nat.zero_le _))⟩

theorem pipe (h : Can m B s t x y W) (g : Can m B t u y z W') :
    Can m B s u x z (fun i => W i+ W' i) :=
  (Able.comp h g).mono (fun _ => Nat.le_refl _) (fun _ => by simp)

theorem then_do (h : Can m B s t x y W) (g : Can m B t u y z W) :
    Can m B s u x z W :=
  (Able.comp h g).weaken (Dom.add (Dom.self W) (Dom.self W)) (fun _ => by simp)

theorem fork (h : Can m B s t x y W) (g : Can m B s u x z W') :
    Can m B s (p t u) x (fun i => (y i,z i)) (fun i => W i+W' i) :=
  (Able.fork h g).mono (fun _ => Nat.le_refl _) (fun _ => by simp)

theorem pair (h : Can m B s t x y W) (g : Can m B s u x z W) :
    Can m B s (p t u) x (fun i => (y i,z i)) W :=
  (Able.fork h g).weaken (Dom.add (Dom.self W) (Dom.self W)) (fun _ => by simp)

theorem save (h : Can m B s t x y W) (g : Can m B (p s t) u (fun i => (x i,y i)) z W') :
    Can m B s u x z (fun i => W i+ W' i) :=
  (Able.save h g).mono (fun _ => Nat.le_refl _) (fun _ => by simp)

theorem bind (h : Can m B s t x y W) (g : Can m B (p s t) u (fun i => (x i,y i)) z W) :
    Can m B s u x z W :=
  (Able.save h g).weaken (Dom.add (Dom.self W) (Dom.self W)) (fun _ => by simp)

theorem id : Can m B s s x x W := Able.id

theorem first {v : ι → T (p s t)} : Can m B (p s t) s v (fun i => (v i).1) W := Able.first

theorem second {v : ι → T (p s t)} : Can m B (p s t) t v (fun i => (v i).2) W := Able.second

theorem fst {v : ι → T (p t u)} (h : Can m B s (p t u) x v W) :
    Can m B s t x (fun i => (v i).1) W := Able.fst h

theorem snd {v : ι → T (p t u)} (h : Can m B s (p t u) x v W) :
    Can m B s u x (fun i => (v i).2) W := Able.snd h

theorem wc (n : ℕ) : Can m B s w x (fun _ => n) W :=
  Able.atom_ok (.lit n) n (fun i => Bill.word_ok (Nat.le_trans (le_pow_self (B i) n) (le_max_left _ _)))

theorem zero {cl} : Can m B s (c cl) x (fun _ => 0) W := Able.atom_ok (.cz cl) 0 (fun _ => Bill.one_ok)

theorem one : Can m B s sc x (fun _ => 1) W := Able.atom_ok .cone 0 (fun _ => Bill.one_ok)

theorem op2 {v' : Ty} {q : ι → T v'} (h : Can m B s t x y W) (g : Can m B s u x z W)
    (o : Atom m (p t u) v') (d : ℕ) (ho : ∀ i, (o.run (y i, z i)).OK (q i) 1 ((B i+2)^d)) :
    Can m B s v' x q W :=
  (h.pair g).then_do (Able.atom_ok o d (fun i => (ho i).mono (Nat.le_refl _) (le_max_left _ _)))

section
variable {cl : Paint} {f g : ι → ℂ}

theorem add (h : Can m B s (c cl) x f W) (k : Can m B s (c cl) x g W) :
    Can m B s (c cl) x (fun i => f i + g i) W := op2 h k (.add cl) 0 (fun _ => Bill.one_ok)

theorem sub (h : Can m B s (c cl) x f W) (k : Can m B s (c cl) x g W) :
    Can m B s (c cl) x (fun i => f i - g i) W := op2 h k (.sub cl) 0 (fun _ => Bill.one_ok)

theorem mul (h : Can m B s sc x f W) (k : Can m B s (c cl) x g W) :
    Can m B s (c cl) x (fun i => f i * g i) W := op2 h k (.scale cl) 0 (fun _ => Bill.one_ok)

theorem cross (h : Can true B s (c .left) x f W)
    (k : Can true B s (c .right) x g W) :
    Can true B s (c .both) x (fun i => f i * g i) W := op2 h k (.cross rfl) 0 (fun _ => Bill.one_ok)

theorem inv (h : Can m B s sc x f W) (k : ∀ i, f i ≠ 0) :
    Can m B s sc x (fun i => (f i)⁻¹) W :=
  h.then_do (Able.atom_ok .inv 0 (fun i => ⟨rfl, Nat.le_refl 1, Nat.zero_le _, k i⟩))

variable {n q : ι → ℕ} {v : ι → Tape (T t)}

theorem look (h : Can m B s (a t) x v W) (k : Can m B s w x n W) :
    Can m B s t x (fun i => (v i).look (n i) t.blank) W := op2 h k .look 0 (fun _ => Bill.one_ok)

theorem len (h : Can m B s (a t) x v W) (k : Small B fun i => (v i).len) :
    Can m B s w x (fun i => (v i).len) W :=
  let ⟨e, he⟩ := k
  h.then_do (Able.atom_ok .len e (fun i => Bill.word_ok (Nat.le_trans (he i) (le_max_left _ _))))

theorem wop (o : NOp) (F : ℕ → ℕ → ℕ) (hF : ∀ i j, o.run (i,j) = Bill.word (F i j))
    (h : Can m B s w x n W) (k : Can m B s w x q W)
    (hb : Small B (fun i => F (n i) (q i))) :
    Can m B s w x (fun i => F (n i) (q i)) W :=
  let ⟨e, he⟩ := hb
  op2 h k (.int o) e (fun i => by
    show (o.run (n i, q i)).OK _ _ _
    rw [hF]; exact Bill.word_ok (he i))

theorem wadd (h : Can m B s w x n W) (k : Can m B s w x q W)
    (hb : Small B (fun i => n i + q i)) :
    Can m B s w x (fun i => n i + q i) W := wop .add (· + ·) (fun _ _ => rfl) h k hb

theorem wsub (h : Can m B s w x n W) (k : Can m B s w x q W)
    (hb : Small B (fun i => n i - q i)) :
    Can m B s w x (fun i => n i - q i) W := wop .sub (· - ·) (fun _ _ => rfl) h k hb

theorem wmul (h : Can m B s w x n W) (k : Can m B s w x q W)
    (hb : Small B (fun i => n i * q i)) :
    Can m B s w x (fun i => n i * q i) W := wop .mul (· * ·) (fun _ _ => rfl) h k hb

theorem wdiv (h : Can m B s w x n W) (k : Can m B s w x q W)
    (hb : Small B (fun i => n i / q i)) :
    Can m B s w x (fun i => n i / q i) W := wop .div (· / ·) (fun _ _ => rfl) h k hb

theorem wmod (h : Can m B s w x n W) (k : Can m B s w x q W)
    (hb : Small B (fun i => n i % q i)) :
    Can m B s w x (fun i => n i % q i) W := wop .mod (· % ·) (fun _ _ => rfl) h k hb

theorem wlt (h : Can m B s w x n W) (k : Can m B s w x q W) :
    Can m B s w x (fun i => if n i < q i then 1 else 0) W :=
  wop .lt (fun i j => if i < j then 1 else 0) (fun _ _ => rfl) h k
    ((Small.const B 1).mono fun i => by show (if n i < q i then 1 else 0) ≤ 1; split <;> omega)

theorem testz (h : Can m B s w x n W)
    (g : Can m (fun i : {i // n i = 0} => B i.val) s t
      (fun i => x i.val) (fun i => y i.val) (fun i => W i.val))
    (j : Can m (fun i : {i // n i ≠ 0} => B i.val) s t
      (fun i => x i.val) (fun i => y i.val) (fun i => W i.val)) :
    Can m B s t x y W :=
  (Able.ifz (W := W) (Z := fun _ => 0) h g j).weaken (Dom.add (Dom.self W) (Dom.self W)) (fun _ => by simp)

variable {uB : ι → ℕ → ℕ}

theorem loop {v : ι → ℕ → T t}
    (h : Can m B s w x n W)
    (hi : Can m B s t x (fun i => v i 0) W')
    (hs : Can m (fun d : During n => B d.i) (p s (p w t)) t
      (fun d => (x d.i,d.j,v d.i d.j)) (fun d => v d.i (d.j+1)) (fun d => uB d.i d.j))
    (hc : Small B n) :
    Can m B s t x (fun i => v i (n i))
      (fun i => W i + W' i + n i + ∑ j ∈ range (n i), uB i j) :=
  (Able.loop (Wb := uB) (Zb := fun _ _ => 0) h hi hs hc).mono (fun _ => Nat.le_refl _)
    (fun _ => by simp)

theorem tab {v : ι → ℕ → T t}
    (h : Can m B s w x n W)
    (hs : Can m (fun d : During n => B d.i) (p s w) t
      (fun d => (x d.i,d.j)) (fun d => v d.i d.j) (fun d => uB d.i d.j))
    (hc : Small B n) :
    Can m B s (a t) x (fun i => Tape.tab (n i) (v i))
      (fun i => W i + n i + ∑ j ∈ range (n i), uB i j) :=
  (Able.tab (Wb := uB) (Zb := fun _ _ => 0) h hs hc).mono (fun _ => Nat.le_refl _)
    (fun _ => by simp)

theorem sow {v : ι → ℕ → ℕ × T t}
    (hl : Can m B s w x q W')
    (h : Can m B s w x n W)
    (hs : Can m (fun d : During n => B d.i) (p s w) (p w t)
      (fun d => (x d.i,d.j)) (fun d => v d.i d.j) (fun d => uB d.i d.j))
    (hg : Small B q) (hc : Small B n) :
    Can m B s (a t) x (fun i => Tape.sow (q i) (n i) t.blank (v i))
      (fun i => W' i + W i + q i + n i + ∑ j ∈ range (n i), uB i j) :=
  (Able.sow (Wb := uB) (Zb := fun _ _ => 0) hl h hs hg hc).mono (fun _ => Nat.le_refl _)
    (fun _ => by simp)

end
end Can

def PolyCan {ι : Type U} (m : Bool) (B S : ι → ℕ) (s t) (x : ι → T s) (y : ι → T t) : Prop :=
  ∃ d : ℕ, Can m B s t x y (fun i => (S i+2)^d)

namespace PolyCan
variable {ι : Type U} {κ : Type V} {m : Bool} {B B' S S' : ι → ℕ} {s t u : Ty}
  {x : ι → T s} {y : ι → T t} {z : ι → T u} {W : ι → ℕ}

theorem up {S : ι → ℕ} {d e : ℕ} (h : Can m B s t x y (fun i => (S i+2)^d)) (hde : d ≤ e) :
    Can m B s t x y (fun i => (S i+2)^e) :=
  h.mono fun i => Small.pow_mono_degree _ hde

theorem of_can (h : Can m B s t x y W) (g : Small S W) :
    PolyCan m B S s t x y :=
  let ⟨d, hd⟩ := g; ⟨d, h.mono hd⟩

theorem cong (h : PolyCan m B S s t x y) {x' y'} (hx : ∀ i, x i = x' i)
    (hy : ∀ i, y i = y' i) : PolyCan m B S s t x' y' :=
  let ⟨d, hd⟩ := h; ⟨d, hd.cong hx hy⟩

theorem reindex (h : PolyCan m B S s t x y) (f : κ → ι) :
    PolyCan m (fun j => B (f j)) (fun j => S (f j)) s t (fun j => x (f j)) (fun j => y (f j)) :=
  let ⟨d, hd⟩ := h; ⟨d, hd.reindex f⟩

theorem weaken (h : PolyCan m B S s t x y) (a : Small B' B) (b : Small S' S) :
    PolyCan m B' S' s t x y :=
  let ⟨d, hd⟩ := h
  let ⟨e, he⟩ := b
  ⟨(e+2)*d, (hd.ambient a).mono fun i => pow_lift d (he i)⟩

theorem lift1 {t1 t2 : Ty} {y1 : ι → T t1} {y2 : ι → T t2}
    (op : ∀ {W : ι → ℕ}, Can m B s t1 x y1 W → Can m B s t2 x y2 W)
    (h : PolyCan m B S s t1 x y1) : PolyCan m B S s t2 x y2 :=
  let ⟨d, hd⟩ := h; ⟨d, op hd⟩

theorem lift2 {t1 t2 t3 : Ty} {y1 : ι → T t1} {y2 : ι → T t2} {y3 : ι → T t3}
    (op : ∀ {W : ι → ℕ}, Can m B s t1 x y1 W → Can m B s t2 x y2 W → Can m B s t3 x y3 W)
    (h : PolyCan m B S s t1 x y1) (g : PolyCan m B S s t2 x y2) : PolyCan m B S s t3 x y3 :=
  let ⟨d, hd⟩ := h
  let ⟨e, he⟩ := g
  ⟨d+e, op (up hd (Nat.le_add_right d e)) (up he (Nat.le_add_left e d))⟩

theorem pipe (h : PolyCan m B S s t x y) (g : PolyCan m B S t u y z) :
    PolyCan m B S s u x z :=
  let ⟨d, hd⟩ := h
  let ⟨e, he⟩ := g
  ⟨d+e, (up hd (Nat.le_add_right d e)).then_do (up he (Nat.le_add_left e d))⟩

theorem pair (h : PolyCan m B S s t x y) (g : PolyCan m B S s u x z) :
    PolyCan m B S s (p t u) x (fun i => (y i,z i)) := lift2 (fun a b => a.pair b) h g

theorem bind (h : PolyCan m B S s t x y)
    (g : PolyCan m B S (p s t) u (fun i => (x i,y i)) z) :
    PolyCan m B S s u x z :=
  let ⟨d, hd⟩ := h
  let ⟨e, he⟩ := g
  ⟨d+e, (up hd (Nat.le_add_right d e)).bind (up he (Nat.le_add_left e d))⟩

theorem id : PolyCan m B S s s x x := ⟨0, Can.id⟩

theorem fst {v : ι → T (p t u)} (h : PolyCan m B S s (p t u) x v) :
    PolyCan m B S s t x (fun i => (v i).1) := lift1 (fun a => a.fst) h

theorem snd {v : ι → T (p t u)} (h : PolyCan m B S s (p t u) x v) :
    PolyCan m B S s u x (fun i => (v i).2) := lift1 (fun a => a.snd) h

theorem first {x : ι → T (p t u)} : PolyCan m B S (p t u) t x (fun i => (x i).1) := ⟨0, Can.first⟩

theorem second {x : ι → T (p t u)} : PolyCan m B S (p t u) u x (fun i => (x i).2) := ⟨0, Can.second⟩

theorem wc (n : ℕ) : PolyCan m B S s w x (fun _ => n) := ⟨0, Can.wc n⟩

theorem zero {cl} : PolyCan m B S s (c cl) x (fun _ => 0) := ⟨0, Can.zero⟩

theorem one : PolyCan m B S s sc x (fun _ => 1) := ⟨0, Can.one⟩

section
variable {cl : Paint} {f g : ι → ℂ}

theorem add (h : PolyCan m B S s (c cl) x f)
    (k : PolyCan m B S s (c cl) x g) :
    PolyCan m B S s (c cl) x (fun i => f i + g i) := lift2 (fun a b => a.add b) h k

theorem sub (h : PolyCan m B S s (c cl) x f)
    (k : PolyCan m B S s (c cl) x g) :
    PolyCan m B S s (c cl) x (fun i => f i - g i) := lift2 (fun a b => a.sub b) h k

theorem mul (h : PolyCan m B S s sc x f)
    (k : PolyCan m B S s (c cl) x g) :
    PolyCan m B S s (c cl) x (fun i => f i * g i) := lift2 (fun a b => a.mul b) h k

theorem inv (h : PolyCan m B S s sc x f) (hk : ∀ i, f i ≠ 0) :
    PolyCan m B S s sc x (fun i => (f i)⁻¹) := lift1 (fun a => a.inv hk) h

variable {n q : ι → ℕ} {v : ι → Tape (T t)}

theorem look (h : PolyCan m B S s (a t) x v) (k : PolyCan m B S s w x n) :
    PolyCan m B S s t x (fun i => (v i).look (n i) t.blank) := lift2 (fun a b => a.look b) h k

theorem wadd (h : PolyCan m B S s w x n) (k : PolyCan m B S s w x q)
    (hb : Small B (fun i => n i + q i)) :
    PolyCan m B S s w x (fun i => n i + q i) := lift2 (fun a b => a.wadd b hb) h k

theorem wsub (h : PolyCan m B S s w x n) (k : PolyCan m B S s w x q)
    (hb : Small B (fun i => n i - q i)) :
    PolyCan m B S s w x (fun i => n i - q i) := lift2 (fun a b => a.wsub b hb) h k

theorem wmul (h : PolyCan m B S s w x n) (k : PolyCan m B S s w x q)
    (hb : Small B (fun i => n i * q i)) :
    PolyCan m B S s w x (fun i => n i * q i) := lift2 (fun a b => a.wmul b hb) h k

theorem wdiv (h : PolyCan m B S s w x n) (k : PolyCan m B S s w x q)
    (hb : Small B (fun i => n i / q i)) :
    PolyCan m B S s w x (fun i => n i / q i) := lift2 (fun a b => a.wdiv b hb) h k

theorem wmod (h : PolyCan m B S s w x n) (k : PolyCan m B S s w x q)
    (hb : Small B (fun i => n i % q i)) :
    PolyCan m B S s w x (fun i => n i % q i) := lift2 (fun a b => a.wmod b hb) h k

theorem wlt (h : PolyCan m B S s w x n) (k : PolyCan m B S s w x q) :
    PolyCan m B S s w x (fun i => if n i < q i then 1 else 0) := lift2 (fun a b => a.wlt b) h k

theorem loop {v : ι → ℕ → T t}
    (h : PolyCan m B S s w x n)
    (hi : PolyCan m B S s t x (fun i => v i 0))
    (hs : PolyCan m (fun d : During n => B d.i) (fun d => S d.i)
      (p s (p w t)) t
      (fun d => (x d.i,d.j,v d.i d.j)) (fun d => v d.i (d.j+1)))
    (hc : Small B n) (hd : Small S n) :
    PolyCan m B S s t x (fun i => v i (n i)) := by
  obtain ⟨d1, h1⟩ := h
  obtain ⟨d2, h2⟩ := hi
  obtain ⟨d3, h3⟩ := hs
  obtain ⟨e, he⟩ := hd
  refine ⟨d1+d2+d3+e+2, (Can.loop (uB := fun i _ => (S i+2)^d3) h1 h2 h3 hc).mono fun i => ?_⟩
  have q1 := Small.pow_mono_degree (S i) (show d1 ≤ d1+d2+d3+e by omega)
  have q2 := Small.pow_mono_degree (S i) (show d2 ≤ d1+d2+d3+e by omega)
  have q3 := Small.pow_mono_degree (S i) (show e+d3 ≤ d1+d2+d3+e by omega)
  have q4 := Small.pow_mono_degree (S i) (show e ≤ d1+d2+d3+e by omega)
  have q5 := four_le (S i) (d1+d2+d3+e)
  have hs' := sum_const' (n i) ((S i+2)^d3)
  have hm : n i * (S i+2)^d3 ≤ (S i+2)^(e+d3) := by
    rw [Nat.pow_add]; exact Nat.mul_le_mul (he i) (Nat.le_refl _)
  have := he i
  ce_omega

theorem tab {v : ι → ℕ → T t}
    (h : PolyCan m B S s w x n)
    (hs : PolyCan m (fun d : During n => B d.i) (fun d => S d.i)
      (p s w) t (fun d => (x d.i,d.j)) (fun d => v d.i d.j))
    (hc : Small B n) (hd : Small S n) :
    PolyCan m B S s (a t) x (fun i => Tape.tab (n i) (v i)) := by
  obtain ⟨d1, h1⟩ := h
  obtain ⟨d3, h3⟩ := hs
  obtain ⟨e, he⟩ := hd
  refine ⟨d1+d3+e+2, (Can.tab (uB := fun i _ => (S i+2)^d3) h1 h3 hc).mono fun i => ?_⟩
  have q1 := Small.pow_mono_degree (S i) (show d1 ≤ d1+d3+e by omega)
  have q3 := Small.pow_mono_degree (S i) (show e+d3 ≤ d1+d3+e by omega)
  have q4 := Small.pow_mono_degree (S i) (show e ≤ d1+d3+e by omega)
  have q5 := four_le (S i) (d1+d3+e)
  have hs' := sum_const' (n i) ((S i+2)^d3)
  have hm : n i * (S i+2)^d3 ≤ (S i+2)^(e+d3) := by
    rw [Nat.pow_add]; exact Nat.mul_le_mul (he i) (Nat.le_refl _)
  have := he i
  ce_omega

theorem testz (h : PolyCan m B S s w x n)
    (g : PolyCan m (fun i : {i // n i = 0} => B i.val) (fun i => S i.val) s t
      (fun i => x i.val) (fun i => y i.val))
    (j : PolyCan m (fun i : {i // n i ≠ 0} => B i.val) (fun i => S i.val) s t
      (fun i => x i.val) (fun i => y i.val)) :
    PolyCan m B S s t x y :=
  let ⟨d1, h1⟩ := h
  let ⟨d2, h2⟩ := g
  let ⟨d3, h3⟩ := j
  ⟨d1+d2+d3, Can.testz (up (e := d1+d2+d3) h1 (by omega)) (up (e := d1+d2+d3) h2 (by omega))
    (up (e := d1+d2+d3) h3 (by omega))⟩

end
end PolyCan

structure Bench (m : Bool) (ι : Type U) where
  size : ι→ℕ
  tray : Ty
  env : ι → T tray

namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V}

def Makes (b : Bench m ι) (t : Ty) (f : ι → T t) : Prop :=
  PolyCan m b.size b.size b.tray t b.env f

structure Digit (b : Bench m ι) (f : ι→ℕ) : Prop where
  run : b.Makes w f
  small : Small b.size f

def along (b : Bench m ι) (f : κ → ι) : Bench m κ :=
  ⟨fun i => b.size (f i), b.tray, fun i => b.env (f i)⟩

def extend (b : Bench m ι) (t : Ty) (x : ι→T t) : Bench m ι :=
  ⟨b.size,p b.tray t,fun i => (b.env i,x i)⟩

def scrutin (b : Bench m ι) (P : ι→Prop) : Bench m {i // P i} :=
  b.along Subtype.val

def scan (b : Bench m ι) (n : ι→ℕ) : Bench m (During n) :=
  (b.along During.i).extend w During.j

def climbs (b : Bench m ι) (n : ι→ℕ) (t : Ty) (x : ι → ℕ → T t) :
    Bench m (During n) :=
  (b.along During.i).extend (p w t) fun d => (d.j,x d.i d.j)

structure Feeds (b : Bench m ι) (q : Bench m κ) (f : ι→κ) : Prop where
  inputs : b.Makes q.tray (fun i => q.env (f i))
  size : Small b.size (fun i => q.size (f i))

variable {b : Bench m ι} {q : Bench m κ} {s t : Ty}

namespace Makes

lemma congr {x y : ι→T t} (h : b.Makes t x) (H : ∀ i, x i=y i) :
    b.Makes t y := PolyCan.cong h (fun _ => rfl) H

lemma pair {x : ι→T s} {y : ι→T t} (h : b.Makes s x) (g : b.Makes t y) :
    b.Makes (p s t) (fun i => (x i,y i)) := PolyCan.pair h g

lemma fst {x : ι→T (p s t)} (h : b.Makes (p s t) x) :
    b.Makes s (fun i => (x i).1) := PolyCan.fst h

lemma snd {x : ι→T (p s t)} (h : b.Makes (p s t) x) :
    b.Makes t (fun i => (x i).2) := PolyCan.snd h

lemma wc (n : ℕ) : b.Makes w (fun _ => n) := PolyCan.wc n

lemma zero {cl} : b.Makes (c cl) (fun _ => 0) := PolyCan.zero

lemma one : b.Makes sc (fun _ => 1) := PolyCan.one

lemma add {cl} {x y : ι→ℂ} (h : b.Makes (c cl) x) (g : b.Makes (c cl) y) :
    b.Makes (c cl) (fun i => x i+y i) := PolyCan.add h g

lemma sub {cl} {x y : ι→ℂ} (h : b.Makes (c cl) x) (g : b.Makes (c cl) y) :
    b.Makes (c cl) (fun i => x i-y i) := PolyCan.sub h g

lemma neg {cl} {x : ι→ℂ} (h : b.Makes (c cl) x) :
    b.Makes (c cl) (fun i => -x i) :=
  (PolyCan.sub PolyCan.zero h).cong (fun _ => rfl) (fun _ => zero_sub _)

lemma mul {cl} {x y : ι→ℂ} (h : b.Makes sc x) (g : b.Makes (c cl) y) :
    b.Makes (c cl) (fun i => x i*y i) := PolyCan.mul h g

lemma inv {x : ι→ℂ} (h : b.Makes sc x) (g : ∀ i, x i ≠ 0) :
    b.Makes sc (fun i => (x i)⁻¹) := PolyCan.inv h g

lemma look {x : ι→Tape (T t)} {n} (h : b.Makes (a t) x) (g : b.Makes w n) :
    b.Makes t (fun i => (x i).look (n i) t.blank) := PolyCan.look h g

end Makes

lemma prepares (b : Bench m ι) : b.Makes b.tray b.env := PolyCan.id

lemma pull {f : ι→κ} (h : b.Feeds q f) {x : κ→T t} (g : q.Makes t x) :
    b.Makes t (fun i => x (f i)) :=
  PolyCan.pipe h.inputs (PolyCan.weaken (PolyCan.reindex g f) h.size h.size)

lemma draw {f : ι→κ} (h : b.Feeds q f) {x} (g : q.Digit x) :
    b.Digit (fun i => x (f i)) :=
  ⟨pull h g.run, (g.small.reindex f).trans h.size⟩

lemma Feeds.along (b : Bench m ι) (f : κ→ι) :
    (b.along f).Feeds b f := ⟨PolyCan.id, Small.self _⟩

lemma toppings (b : Bench m ι) (f : ι→T t) :
    (b.extend t f).Makes t f := PolyCan.second

lemma Feeds.extend (b : Bench m ι) (t : Ty) (f : ι→T t) :
    (b.extend t f).Feeds b id := ⟨PolyCan.first, Small.self _⟩

lemma Feeds.next {μ : Type Z} {a : Bench m μ} {f : ι→κ} {g : κ→μ}
    (h : b.Feeds q f) (j : q.Feeds a g) :
    b.Feeds a (fun i => g (f i)) :=
  ⟨pull h j.inputs, (j.size.reindex f).trans h.size⟩

namespace Digit
variable {x y : ι→ℕ}

lemma wc (n : ℕ) : b.Digit (fun _ => n) := ⟨Makes.wc n, Small.const _ n⟩

lemma congr (h : b.Digit x) (g : ∀ i, x i=y i) : b.Digit y :=
  ⟨h.run.congr g, h.small.mono fun i => Nat.le_of_eq (g i).symm⟩

lemma add (h : b.Digit x) (g : b.Digit y) :
    b.Digit (fun i => x i + y i) :=
  ⟨PolyCan.wadd h.run g.run (h.small.add g.small), h.small.add g.small⟩

lemma sub (h : b.Digit x) (g : b.Digit y) :
    b.Digit (fun i => x i-y i) :=
  ⟨PolyCan.wsub h.run g.run (h.small.mono fun _ => Nat.sub_le _ _),
    h.small.mono fun _ => Nat.sub_le _ _⟩

lemma mul (h : b.Digit x) (g : b.Digit y) :
    b.Digit (fun i => x i * y i) :=
  ⟨PolyCan.wmul h.run g.run (h.small.mul g.small), h.small.mul g.small⟩

lemma minimum (h : b.Digit x) (g : b.Digit y) :
    b.Digit (fun i => min (x i) (y i)) :=
  (h.sub (h.sub g)).congr fun i => by
    show x i - (x i - y i) = min (x i) (y i)
    rcases Nat.le_total (x i) (y i) with hh | hh
    · rw [Nat.min_eq_left hh]; omega
    · rw [Nat.min_eq_right hh]; omega

lemma isLess (h : b.Digit x) (g : b.Digit y) :
    b.Digit (fun i => if x i<y i then 1 else 0) :=
  ⟨PolyCan.wlt h.run g.run,
    (Small.const _ 1).mono fun i => by show (if x i < y i then 1 else 0) ≤ 1; split <;> omega⟩

end Digit

variable {n : ι→ℕ}

lemma Feeds.scan (b : Bench m ι) (n : ι→ℕ) : (b.scan n).Feeds b During.i :=
  ⟨PolyCan.first, Small.self _⟩

lemma Feeds.climbs (b : Bench m ι) (n : ι→ℕ) (x : ι → ℕ → T t) :
    (b.climbs n t x).Feeds b During.i :=
  ⟨PolyCan.first, Small.self _⟩

lemma slot (h : b.Digit n) :
    (b.scan n).Digit During.j :=
  ⟨PolyCan.second, (h.small.reindex During.i).mono fun d => Nat.le_of_lt d.hj⟩

lemma tab (h : b.Digit n) (x : ι→ℕ→T t) (g : (b.scan n).Makes t (fun d => x d.i d.j)) :
    b.Makes (a t) (fun i => Tape.tab (n i) (x i)) :=
  PolyCan.tab h.run g h.small h.small

lemma stepi (h : b.Digit n) (x : ι → ℕ → T t) :
    (b.climbs n t x).Digit During.j :=
  ⟨PolyCan.fst (PolyCan.second (x := (b.climbs n t x).env)), (h.small.reindex During.i).mono fun d => Nat.le_of_lt d.hj⟩

lemma stepsum (b : Bench m ι) (n : ι→ℕ) (x : ι → ℕ → T t) :
    (b.climbs n t x).Makes t (fun d => x d.i d.j) :=
  PolyCan.snd (PolyCan.second (x := (b.climbs n t x).env))

lemma loop (h : b.Digit n) (x : ι → ℕ → T t) (g : b.Makes t (fun i => x i 0))
    (k : (b.climbs n t x).Makes t (fun d => x d.i (d.j+1))) :
    b.Makes t (fun i => x i (n i)) :=
  PolyCan.loop h.run g k h.small h.small

lemma Feeds.select {n : κ→ℕ} {f : ι → During n}
    (h : b.Feeds q (fun i => (f i).i)) (g : b.Makes w (fun i => (f i).j)) :
    b.Feeds (q.scan n) f :=
  ⟨PolyCan.pair h.inputs g, h.size⟩

end Bench

end RAM
end PowerSaving
end OAI
