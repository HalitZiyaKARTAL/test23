import Submission.OAI.Computability.FourierTransform.CompilerEnvironment
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Data.Nat.SuccPred
import Mathlib.Algebra.CharP.Defs
import Mathlib.Data.Nat.Log

namespace OAI
namespace PowerSaving
open Finset

structure Layout (α : Type*) where
  n : ℕ
  loc : α → ℕ
  bd : ∀ i, loc i < n
  inj : Function.Injective loc
  onto : ∀ j : Fin n, ∃ i, loc i = j.val

namespace Layout

variable {α β μ : Type*}

noncomputable def atFin (L : Layout α) (j : Fin L.n) : α := Classical.choose (L.onto j)
@[simp] theorem loc_atFin (L : Layout α) (j : Fin L.n) :
    L.loc (L.atFin j) = j.val := Classical.choose_spec (L.onto j)

def toIx (L : Layout α) (i : α) : Fin L.n := ⟨L.loc i,L.bd i⟩

noncomputable def index (L : Layout α) : α ≃ Fin L.n :=
  ⟨L.toIx,L.atFin,fun _ => L.inj (loc_atFin _ _), fun _ => Fin.ext (loc_atFin _ _)⟩

noncomputable def tape (L : Layout α) (x : α → μ) : Tape μ :=
  ⟨L.n, fun j => x (L.atFin j)⟩

@[simp] theorem read (L : Layout α) (x : α → μ) (i : α) (z : μ) :
    (L.tape x).look (L.loc i) z = x i := by
  rw [Tape.look_of_lt _ _ (L.bd i)]
  exact congr_arg x (L.index.left_inv _)

theorem verify (L : Layout α) (v : Tape μ) (z : μ) (x : α → μ)
    (h : v.len = L.n) (hx : ∀ i, v.look (L.loc i) z = x i) :
    v = L.tape x := by
  refine Tape.ext_look h z ?_
  intro j hj
  have hl : j<L.n := h ▸ hj
  obtain ⟨i,hi⟩ := L.onto ⟨j,hl⟩
  change L.loc i = j at hi
  subst j
  rw [hx,L.read]

def std (n : ℕ) : Layout (Fin n) :=
  ⟨n,Fin.val, Fin.is_lt, Fin.val_injective, fun j => ⟨j,rfl⟩⟩

theorem card [Fintype α] (X : Layout α) : Fintype.card α = X.n := by
  simpa using Fintype.card_congr X.index

def comap (L : Layout α) (f : β ≃ α) : Layout β where
  n := L.n
  loc := fun j => L.loc (f j)
  bd := fun j => L.bd (f j)
  inj := L.inj.comp f.injective
  onto := fun j => by
    obtain ⟨i,h⟩ := L.onto j
    exact ⟨f.symm i, by simpa using h⟩

noncomputable def someLayout (α : Type*) [Fintype α] : Layout α :=
  (std _).comap (Fintype.equivFin α)

lemma div_join {a b n : ℕ} (hb : b < n) : (a*n+b)/n = a := by
  have hn : n>0 := by omega
  rw [add_comm, Nat.add_mul_div_right b a hn, Nat.div_eq_of_lt hb, zero_add]
lemma mod_join {a b n : ℕ} (hb : b < n) : (a*n+b)%n = b := by
  simp [Nat.mod_eq_of_lt hb]
lemma lt_join {a b m n : ℕ} (h : a < m) (g : b < n) : a*n+b  <  m*n := by
  calc
    _ < a*n+n := Nat.add_lt_add_left g _
    _ ≤ _ := by simpa [add_mul] using Nat.mul_le_mul_right n h

def pair (X : Layout α) (Y : Layout β) : Layout (α × β) where
  n := X.n * Y.n
  loc := fun i => X.loc i.1*Y.n + Y.loc i.2
  bd := fun i => lt_join (X.bd _) (Y.bd _)
  inj := fun {a b} h => by
    change X.loc a.1*Y.n+Y.loc a.2=X.loc b.1*Y.n+Y.loc b.2 at h
    apply Prod.ext
    · apply X.inj
      exact (div_join (Y.bd a.2)).symm.trans ((congr_arg (· / Y.n) h).trans (div_join (Y.bd b.2)))
    · apply Y.inj
      exact (mod_join (Y.bd a.2)).symm.trans ((congr_arg (· % Y.n) h).trans (mod_join (Y.bd b.2)))
  onto := fun j => by
    have hj := j.isLt
    have hy : 0 < Y.n := Nat.pos_of_ne_zero (fun g => by simp [g] at hj)
    obtain ⟨i,hi⟩ := X.onto ⟨j.val/Y.n, (Nat.div_lt_iff_lt_mul hy).mpr hj⟩
    obtain ⟨k,hk⟩ := Y.onto ⟨j.val%Y.n,Nat.mod_lt _ hy⟩
    exact ⟨(i,k),by
      dsimp
      rw [hi,hk,Nat.mul_comm]
      exact Nat.div_add_mod _ _⟩

@[simp] lemma pair_len (X : Layout α) (Y : Layout β) :
    (X.pair Y).n = X.n*Y.n := rfl

@[simp] lemma pair_loc (X : Layout α) (Y : Layout β) (i) :
    (X.pair Y).loc i = X.loc i.1*Y.n+Y.loc i.2 := rfl

lemma pair_div (X : Layout α) (Y : Layout β) (i) :
    (X.pair Y).loc i / Y.n = X.loc i.1 := div_join (Y.bd _)
lemma pair_mod (X : Layout α) (Y : Layout β) (i) :
    (X.pair Y).loc i % Y.n = Y.loc i.2 := mod_join (Y.bd _)

def cat (X : Layout α) (Y : Layout β) : Layout (α ⊕ β) where
  n := X.n+Y.n
  loc := Sum.elim X.loc (fun i => X.n+Y.loc i)
  bd := by
    rintro (i|i)
    · exact lt_of_lt_of_le (X.bd i) (Nat.le_add_right ..)
    · exact Nat.add_lt_add_left (Y.bd i) _
  inj := by
    rintro (i|i) (j|j) h
    · exact congr_arg Sum.inl (X.inj h)
    · have := X.bd i; simp only [Sum.elim_inl,Sum.elim_inr] at h; omega
    · have := X.bd j; simp only [Sum.elim_inl,Sum.elim_inr] at h; omega
    · exact congr_arg Sum.inr (Y.inj (Nat.add_left_cancel h))
  onto := by
    intro j
    by_cases h : j.val < X.n
    · obtain ⟨i,hi⟩ := X.onto ⟨j.val,h⟩
      exact ⟨.inl i,hi⟩
    · have := j.isLt
      obtain ⟨i,hi⟩ := Y.onto ⟨j.val-X.n,by omega⟩
      refine ⟨.inr i,?_⟩
      change X.n + Y.loc i = _
      dsimp at hi
      omega

private def expand (X : Layout α) {k} (x : Fin k→α) :=
  ∑ i, X.loc (x i)*X.n^i.val

private lemma expand_zero (X : Layout α) (x : Fin 0→α) : expand X x=0 := by simp [expand]

private lemma expand_succ (X : Layout α) {k} (x : Fin (k+1)→α) :
    expand X x=expand X (fun i : Fin k => x i.succ)*X.n + X.loc (x 0) := by
  unfold expand
  rw [Fin.sum_univ_succ]
  simp [pow_succ, sum_mul, mul_assoc, Nat.add_comm]

private lemma expand_lt (X : Layout α) {k} (x : Fin k→α) : expand X x < X.n^k := by
  induction k with
  | zero => simp [expand_zero]
  | succ k ih => rw [expand_succ,pow_succ]; exact lt_join (ih _) (X.bd _)

private lemma expand_entry (X : Layout α) {k} (x : Fin k→α) (i : Fin k) :
    expand X x / X.n^i.val % X.n = X.loc (x i) := by
  induction k with
  | zero => exact i.elim0
  | succ k ih =>
    refine Fin.cases ?_ (fun j => ?_) i
    · rw [expand_succ]
      simpa using mod_join (a:=expand X (fun i : Fin k => x i.succ)) (X.bd (x 0))
    · rw [expand_succ,Fin.val_succ, pow_succ', ← Nat.div_div_eq_div_mul, div_join (X.bd _)]
      exact ih _ j

private lemma expand_onto (X : Layout α) (k) (i : ℕ) (hi : i<X.n^k) :
    ∃ x : Fin k → α, expand X x=i := by
  induction k generalizing i with
  | zero => exact ⟨Fin.elim0, by simp at hi; simp [expand_zero,hi]⟩
  | succ k ih =>
    rw [pow_succ] at hi
    have h : 0<X.n := Nat.pos_of_ne_zero fun a => by simp [a] at hi
    obtain ⟨y,hy⟩ := ih (i/X.n) ((Nat.div_lt_iff_lt_mul h).mpr hi)
    obtain ⟨z,hz⟩ := X.onto ⟨i%X.n,Nat.mod_lt _ h⟩
    refine ⟨Fin.cons z y,?_⟩
    rw [expand_succ]
    simp [hy,hz,Nat.div_add_mod, Nat.mul_comm]

def vecFin (X : Layout α) (k : ℕ) : Layout (Fin k → α) where
  n := X.n^k
  loc := expand X
  bd := expand_lt X
  inj := by
    intro a b h
    funext i
    apply X.inj
    rw [← expand_entry X a i, ← expand_entry X b i, h]
  onto := fun j => expand_onto X k j j.isLt

def permFn (e : α ≃ β) (μ : Type*) : (α → μ) ≃ (β → μ) where
  toFun f := f ∘ e.symm
  invFun f := f ∘ e
  left_inv f := by ext; simp
  right_inv f := by ext; simp

noncomputable def digits (J : Layout β) (X : Layout α) : Layout (β → α) :=
  (vecFin X J.n).comap (permFn J.index α)

@[simp] theorem digits_len (J : Layout β) (X : Layout α) :
    (digits J X).n=X.n^J.n := rfl

theorem digits_code [Fintype β] (J : Layout β) (X : Layout α) (x : β→α) :
    (digits J X).loc x = ∑ j, X.loc (x j)*X.n^(J.loc j) := by
  change ∑ i : Fin J.n, X.loc ((x ∘ J.index.symm) i)*X.n^i.val=_
  rw [← Equiv.sum_comp J.index]
  apply sum_congr rfl
  intro j hj
  simp [show J.loc j = (J.index j).val from rfl]

theorem digits_entry (J : Layout β) (X : Layout α) (x : β→α) (j : β) :
    (digits J X).loc x / X.n^(J.loc j) % X.n=X.loc (x j) := by
  change expand X (x∘J.index.symm) / X.n^(J.index j).val % X.n = _
  simp [expand_entry]

end Layout
end PowerSaving

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Finset
noncomputable section

universe U V
variable {ι : Type U} {α : ι → Type V}

private lemma as_tab {μ η : Type*} (L : Layout μ) (x : μ → η) (z : η) :
    Tape.tab L.n (fun j => if h : j < L.n then x (L.atFin ⟨j,h⟩) else z)
    = L.tape x := by
  unfold Tape.tab Layout.tape; congr 1
  funext i; simp [i.isLt]

namespace Able
variable {m : Bool} {r : Port} {b : Bank r ι} {s t : Ty}
  {x : ι → T s} {W Z P H : ι → ℕ}

theorem layout {L : ∀ i, Layout (α i)} {v : ∀ i, α i → T t}
    (h : Able m b s w x (fun i => (L i).n) W Z)
    (hs : Able m (b.comap (Sigma.fst (β:=α))) (p s w) t
      (fun d => (x d.1,(L d.1).loc d.2)) (fun d => v d.1 d.2)
      (fun d => P d.1) (fun d => H d.1))
    (hc : Small b.B fun i => (L i).n) :
    Able m b s (a t) x (fun i => (L i).tape (v i))
      (fun i => W i+(L i).n+(L i).n*P i) (fun i => Z i+(L i).n*H i) := by
  let n i := (L i).n
  let vals (i : ι) (j : ℕ) : T t :=
    if hg : j < n i then v i ((L i).atFin ⟨j,hg⟩) else t.blank
  let k (q : During n) : Σ i, α i :=
    ⟨q.i, (L q.i).atFin ⟨q.j,q.hj⟩⟩
  have hx := hs.reindex k
  have hh : Able m (b.comap (During.i (n:=n))) (p s w) t
      (fun d => (x d.i,d.j)) (fun d => vals d.i d.j)
      (fun d => P d.i) (fun d => H d.i) := by
    refine hx.cong ?_ ?_
    · rintro ⟨i,j,hj⟩; simp [k]
    · rintro ⟨i,j,hj⟩; simp [vals,k,hj]
  have ht := Able.tab (n:=n) (v:=vals) (Wb:=fun i _ => P i) (Zb:=fun i _ => H i) h hh hc
  have he (i) : Tape.tab (n i) (vals i) = (L i).tape (v i) :=
    as_tab _ _ _
  simpa only [he,sum_const,card_range,nsmul_eq_mul,Nat.cast_id] using ht

end Able

namespace Small

lemma loc {B : ι → ℕ} {x : ∀ i, α i} {L : ∀ i, Layout (α i)}
    (h : Small B fun i => (L i).n) :
    Small B fun i => (L i).loc (x i) :=
  h.mono fun i => ((L i).bd _).le

end Small

namespace Can
variable {m : Bool} {s t : Ty} {x : ι → T s}
  {B W P : ι → ℕ} {L : ∀ i, Layout (α i)} {v : ∀ i, α i → T t}

theorem layout (h : Can m B s w x (fun i => (L i).n) W)
    (g : Can m (fun d : Σ i, α i => B d.1) (p s w) t
      (fun d => (x d.1,(L d.1).loc d.2)) (fun d => v d.1 d.2) (fun d => P d.1))
    (hn : Small B fun i => (L i).n) :
    Can m B s (a t) x (fun i => (L i).tape (v i))
      (fun i => W i+(L i).n+(L i).n*P i) := by
  have ht := Able.layout (b:=Bank.closed B) (L:=L) (v:=v)
    (P:=P) (H:=fun _ => 0) h g hn
  simpa [Can] using ht

theorem fetch {i : ∀ d, α d}
    (h : Can m B s (a t) x (fun i => (L i).tape (v i)) W)
    (g : Can m B s w x (fun d => (L d).loc (i d)) W) :
    Can m B s t x (fun d => v d (i d)) W :=
  (h.look g).cong (fun _ => rfl) (fun _ => Layout.read ..)

variable {μ : Type V}

theorem eqbit {n q : ι → ℕ} (h : Can m B s w x n W) (k : Can m B s w x q W) :
    Can m B s w x (fun i => if n i = q i then 0 else 1) W := by
  let f i := if n i < q i then 1 else 0
  let g i := if q i < n i then 1 else 0
  have a : Small B f := by
    apply (Small.const B 1).mono; intro; unfold f; split <;> omega
  have b : Small B g := by
    apply (Small.const B 1).mono; intro; unfold g; split <;> omega
  refine ((h.wlt k).wadd (k.wlt h) (a.add b)).cong (fun _ => rfl) ?_
  intro i
  rcases lt_trichotomy (n i) (q i) with h|h|h
  · simp [h, not_lt.mpr h.le, ne_of_lt h]
  · simp [h]
  · simp [h, not_lt.mpr h.le, ne_of_gt h]

private def blankProg (m : Bool) (s : Ty) : (t : Ty) → Prog m s t
  | .w => .atom (.lit 0)
  | .c e => .atom (.cz e)
  | .p q u => .fork (blankProg m s q) (blankProg m s u)
  | .a q => .tab (.atom (.lit 0)) (.comp (.atom .fst) (blankProg m s q))

theorem cases_code [DecidableEq μ] [Fintype μ] {y : ι → T t} {q : ι→μ}
    (D : Layout μ) (h : Can m B s w x (fun i => D.loc (q i)) W)
    (g : ∀ f : μ, Can m (fun i : {i // q i=f} => B i.1) s t
      (fun i => x i.1) (fun i => y i.1) (fun i => W i.1)) :
    Can m B s t x y W := by
  have hg (l : Finset μ) : Can m (fun i : {i // q i∈l} => B i.1) s t
      (fun i => x i.1) (fun i => y i.1) (fun i => W i.1) := by
    induction l using Finset.induction with
    | empty =>
      refine ⟨blankProg m s t,0,0,?_⟩
      rintro ⟨i,hi⟩; simp at hi
    | insert i l hi ih =>
      let K := {j // q j∈insert i l}
      let n (a : K) := if D.loc (q a.1)=D.loc i then 0 else 1
      apply Can.testz (n:=n) ((h.reindex (fun j : K => j.1)).eqbit (Can.wc _))
      · let p (f : {j : K // n j=0}) : {j // q j=i} := ⟨f.1.1, by
          have hh := f.2
          apply D.inj
          unfold n at hh
          split at hh
          next h => exact h
          next h => simp at hh⟩
        exact (g i).reindex p
      · let p (f : {j : K // n j ≠ 0}) : {j // q j∈l} :=
          ⟨f.1.1,by
            have hh := f.2
            have hg := f.1.2
            rw [mem_insert] at hg
            rcases hg with g|g
            · simp [n,g] at hh
            · exact g⟩
        exact ih.reindex p
  exact (hg univ).reindex (fun i => ⟨i, mem_univ _⟩)

theorem sum_wconst [Fintype μ] {v : μ → ι → ℕ}
    (h : ∀ i : μ, Can m B s w x (v i) W)
    (g : ∀ i : μ, Small B (v i)) :
    Can m B s w x (fun j => ∑ i, v i j) W := by
  classical
  have hh (l : Finset μ) :
      Can m B s w x (fun j => ∑ i ∈ l, v i j) W ∧ Small B (fun j => ∑ i ∈ l, v i j) := by
    induction l using Finset.induction with
    | empty =>
      simpa using And.intro (Can.wc (B:=B) (m:=m) (x:=x) (W:=W) 0)
        (Small.const B 0)
    | insert i l hi ih =>
      have ht := (g i).add ih.2
      simpa [hi] using And.intro ((h i).wadd ih.1 ht) ht
  exact (hh _).1

theorem sum_cconst [Fintype μ] {cl} {v : μ → ι → ℂ}
    (h : ∀ i : μ, Can m B s (c cl) x (v i) W) :
    Can m B s (c cl) x (fun j => ∑ i, v i j) W := by
  classical
  have hh (l : Finset μ) :
      Can m B s (c cl) x (fun j => ∑ i ∈ l, v i j) W := by
    induction l using Finset.induction with
    | empty => simpa using (Can.zero (cl:=cl) (m:=m) (B:=B) (x:=x) (W:=W))
    | insert i l hi ih =>
      simpa [hi] using (h i).add ih
  exact hh _

end Can
end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Finset
noncomputable section

universe U
variable {ι : Type U} {m : Bool}

namespace Small
variable {B P Q : ι → ℕ}

theorem sub (h : Small B P) : Small B (fun i => P i-Q i) :=
  h.mono fun _ => Nat.sub_le _ _

theorem div (h : Small B P) : Small B (fun i => P i/Q i) :=
  h.mono fun _ => Nat.div_le_self _ _

theorem mod (h : Small B P) : Small B (fun i => P i%Q i) :=
  h.mono fun _ => Nat.mod_le _ _
end Small

namespace Can
variable {s t : Ty} {x : ι → T s} {B W A Q : ι → ℕ}

lemma minus (h : Can m B s w x A W) (k : Can m B s w x Q W)
    (hh : Small B A) : Can m B s w x (fun i => A i - Q i) W :=
  h.wsub k hh.sub

lemma times (h : Can m B s w x A W) (k : Can m B s w x Q W)
    (hh : Small B A) (gg : Small B Q) : Can m B s w x (fun i => A i * Q i) W :=
  h.wmul k (hh.mul gg)

lemma plus (h : Can m B s w x A W) (k : Can m B s w x Q W)
    (hh : Small B A) (gg : Small B Q) : Can m B s w x (fun i => A i + Q i) W :=
  h.wadd k (hh.add gg)

lemma dvdW (h : Can m B s w x A W) (k : Can m B s w x Q W) (hh : Small B A) :
    Can m B s w x (fun i => A i / Q i) W :=
  h.wdiv k hh.div

lemma modW (h : Can m B s w x A W) (k : Can m B s w x Q W) (hh : Small B A) :
    Can m B s w x (fun i => A i % Q i) W :=
  h.wmod k hh.mod

lemma wpow_fixed (n : ℕ) (h : Can m B s w x A W) (hh : Small B A) :
    Can m B s w x (fun i => (A i)^n) W := by
  induction n with
  | zero => simpa using wc (s:=s) (m:=m) (B:=B) (x:=x) (W:=W) 1
  | succ n ih => simpa [pow_succ] using ih.times h (hh.pow n) hh

lemma wTwo (h : Can m B s w x A W) (hh : Small B A)
    (hq : Small B fun i => 2^A i) (ha : Dom W A) :
    Can m B s w x (fun i => 2^A i) W := by
  let v (_ : ι) (n : ℕ) := 2^n
  have hs : Can m (fun d : During A => B d.i) (p s (p w w)) w
      (fun d => (x d.i, d.j, v d.i d.j)) (fun d => v d.i (d.j+1)) (fun _ => 0) := by
    have hp : Small (fun d : During A => B d.i) fun d => v d.i d.j :=
      (hq.reindex During.i).mono (fun d => Nat.pow_le_pow_right (by omega) d.hj.le)
    unfold v at *
    simp only [pow_succ]
    exact (Can.snd Can.second).times (Can.wc _) hp (Small.const ..)
  have ht := Can.loop (t:=w) (v:=v) (W':=fun _ => 0) (uB:=fun _ _ => 0) h
    (by simpa only [v,pow_zero] using (Can.wc (m:=m) (W:=fun _ => 0)
      (B:=B) (s:=s) (x:=x) 1)) hs hh
  simp only [Finset.sum_const_zero,Nat.add_zero] at ht
  exact ht.weaken ((Dom.self W).add ha)

end Can

namespace Can
variable {s t : Ty} {x : ι → T s} {B W A Q : ι → ℕ}

lemma neg {cl} {z : ι→ℂ} (h : Can m B s (c cl) x z W) :
    Can m B s (c cl) x (fun i => -(z i)) W := by
  simpa using (Can.sub Can.zero h)

lemma cNat (n : ℕ) : Can m B s sc x (fun _ => (n:ℂ)) W := by
  induction n with
  | zero =>
    simp only [Nat.cast_zero]
    exact Can.zero
  | succ n ih => simpa using ih.add Can.one

lemma cInt (n : ℤ) : Can m B s sc x (fun _ => (n:ℂ)) W := by
  cases n with
  | ofNat n =>
    simpa using (cNat (s:=s) (m:=m) (B:=B) (W:=W) (x:=x) n)
  | negSucc n =>
    simpa using (cNat (s:=s) (m:=m) (B:=B) (W:=W) (x:=x) (n+1)).neg

lemma rat (z : ℚ) : Can m B s sc x (fun _ => (z:ℂ)) W := by
  rw [Rat.cast_def]
  simp only [div_eq_mul_inv]
  exact (Can.cInt _).mul ((Can.cNat _).inv (by intro i; exact_mod_cast z.den_nz))

lemma prod_cconst {μ : Type*} [Fintype μ] {v : μ→ι→ℂ}
    (h : ∀ i : μ, Can m B s sc x (v i) W) :
    Can m B s sc x (fun j => ∏ i, v i j) W := by
  classical
  have hh (l : Finset μ) : Can m B s sc x (fun j => ∏ i∈l,v i j) W := by
    induction l using Finset.induction with
    | empty =>
      simp only [prod_empty]
      exact Can.one
    | insert i l hi ih =>
      simp only [prod_insert hi]
      exact (h i).mul ih
  exact hh _

end Can

namespace Can
-- product addressing at arbitrary parameter types
variable {s t : Ty} {x : ι → T s} {B W : ι → ℕ}
variable {α β : ι → Type*} {L : ∀ i, Layout (α i)} {R : ∀ i, Layout (β i)}
  {u : ∀ i, α i × β i}

lemma addr_join (h : Can m B s w x (fun i => (L i).loc (u i).1) W)
    (k : Can m B s w x (fun i => (R i).loc (u i).2) W)
    (d : Can m B s w x (fun i => (R i).n) W)
    (hl : Small B fun i => (L i).n) (hr : Small B fun i => (R i).n) :
    Can m B s w x (fun i => ((L i).pair (R i)).loc (u i)) W :=
  (h.times d (Small.loc (x:=fun i => (u i).1) (L:=L) hl) hr).plus k
    ((Small.loc (x:=fun i => (u i).1) (L:=L) hl).mul hr)
    (Small.loc (x:=fun i => (u i).2) (L:=R) hr)

lemma addr_high (h : Can m B s w x (fun i => ((L i).pair (R i)).loc (u i)) W)
    (k : Can m B s w x (fun i => (R i).n) W)
    (hs : Small B fun i => (L i).n*(R i).n) :
    Can m B s w x (fun i => (L i).loc (u i).1) W :=
  (h.dvdW k (Small.loc (L:=fun i => (L i).pair (R i)) (x:=u) hs)).cong
    (fun _ => rfl) (fun _ => Layout.pair_div ..)

lemma addr_low (h : Can m B s w x (fun i => ((L i).pair (R i)).loc (u i)) W)
    (k : Can m B s w x (fun i => (R i).n) W)
    (hs : Small B fun i => (L i).n*(R i).n) :
    Can m B s w x (fun i => (R i).loc (u i).2) W :=
  (h.modW k (Small.loc (L:=fun i => (L i).pair (R i)) (x:=u) hs)).cong
    (fun _ => rfl) (fun _ => Layout.pair_mod ..)

end Can
end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Finset
noncomputable section

universe U V Z

namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V} {μ : Type Z}

def Moves (b : Bench m ι) (W : ι→ℕ) (t : Ty) (f : ι→T t) : Prop :=
  Can m b.size b.tray t b.env f W

structure Nick (b : Bench m ι) (f : ι→ℕ) : Prop where
  close : b.Moves (fun _ => 0) w f
  small : Small b.size f

structure Instant (b : Bench m ι) (q : Bench m κ) (f : ι→κ) : Prop where
  prep : b.Moves (fun _ => 0) q.tray fun i => q.env (f i)
  covers : Small b.size fun i => q.size (f i)

variable {b : Bench m ι} {q : Bench m κ} {z : Bench m μ} {s t : Ty} {W : ι → ℕ}
  {x y : ι → T t}

namespace Moves

lemma congr (h : b.Moves W t x) (g : ∀ i, x i=y i) :
    b.Moves W t y := by rwa [← funext g]

lemma weaken {P} (h : b.Moves W t x) (g : Dom P W) :
    b.Moves P t x := Can.weaken h g

lemma ease (h : b.Moves (fun _ => 0) t x) (V : ι → ℕ) :
    b.Moves V t x := h.weaken (Dom.const V 0)

lemma wc (n : ℕ) : b.Moves W w fun _ => n := Can.wc n

lemma pair {u : ι → T s} (h : b.Moves W s u) (g : b.Moves W t x) :
    b.Moves W (p s t) fun i => (u i,x i) := Can.pair h g
lemma fst {v : ι → T (p s t)} (h : b.Moves W (p s t) v) :
    b.Moves W s fun i => (v i).1 := Can.fst h
lemma snd {v : ι → T (p s t)} (h : b.Moves W (p s t) v) :
    b.Moves W t fun i => (v i).2 := Can.snd h

lemma len {v : ι→Tape (T t)} (h : b.Moves W (a t) v) (g : Small b.size fun i => (v i).len) :
    b.Moves W w fun i => (v i).len := Can.len h g

lemma pick {n k : ι → ℕ} (x : ι → ℕ → T t)
    (h : b.Moves W (a t) fun i => Tape.tab (n i) (x i)) (g : b.Moves W w k)
    (hh : ∀ i, k i<n i) :
    b.Moves W t fun i => x i (k i) :=
  (Can.look h g).cong (fun _ => rfl) (fun i => by rw [Tape.look_tab,ite_eq_left (hh i)])

lemma transfer {P : κ→ℕ} {x : κ→T t} (h : q.Moves P t x) {f} (g : b.Instant q f) :
    b.Moves (fun i => P (f i)) t fun i => x (f i) :=
  Can.then_do (g.prep.ease _) ((Can.reindex h f).ambient g.covers)

variable {cl : Paint}
lemma zero : b.Moves W (c cl) (fun _ => 0) := Can.zero
lemma one : b.Moves W sc (fun _ => 1) := Can.one
variable {X Y : ι→ℂ}
lemma add (h : b.Moves W (c cl) X) (g : b.Moves W (c cl) Y) :
    b.Moves W (c cl) fun i => X i+Y i := Can.add h g
lemma sub (h : b.Moves W (c cl) X) (g : b.Moves W (c cl) Y) :
    b.Moves W (c cl) fun i => X i-Y i := Can.sub h g
lemma mul (h : b.Moves W sc X) (g : b.Moves W (c cl) Y) :
    b.Moves W (c cl) fun i => X i*Y i := Can.mul h g
lemma inv (h : b.Moves W sc X) (k : ∀ i, X i≠0) :
    b.Moves W sc fun i => (X i)⁻¹ := Can.inv h k

end Moves

namespace Nick
variable {x y : ι→ℕ}
lemma wc (n : ℕ) : b.Nick fun _ => n := ⟨Moves.wc n,Small.const _ n⟩

lemma mov (h : b.Nick x) (W : ι→ℕ) : b.Moves W w x := h.close.ease W

lemma congr (h : b.Nick x) (g : ∀ i, x i=y i) :
    b.Nick y := by rwa [← funext g]

lemma transfer {f} {x : κ→ℕ} (h : q.Nick x) (g : b.Instant q f) :
    b.Nick fun i => x (f i) :=
  ⟨h.close.transfer g,(h.small.reindex _).trans g.covers⟩

lemma add (h : b.Nick x) (g : b.Nick y) : b.Nick fun i => x i+y i :=
  ⟨Can.plus h.close g.close h.small g.small,h.small.add g.small⟩
lemma sub (h : b.Nick x) (g : b.Nick y) : b.Nick fun i => x i-y i :=
  ⟨Can.minus h.close g.close h.small,h.small.sub⟩
lemma mul (h : b.Nick x) (g : b.Nick y) : b.Nick fun i => x i*y i :=
  ⟨Can.times h.close g.close h.small g.small,h.small.mul g.small⟩
lemma div (h : b.Nick x) (g : b.Nick y) : b.Nick fun i => x i/y i :=
  ⟨Can.dvdW h.close g.close h.small,h.small.div⟩
lemma residue (h : b.Nick x) (g : b.Nick y) : b.Nick fun i => x i%y i :=
  ⟨Can.modW h.close g.close h.small,h.small.mod⟩
lemma digit (h : b.Nick x) : b.Digit x :=
  ⟨PolyCan.of_can h.close (Small.const _ _),h.small⟩
end Nick

lemma envNow (b : Bench m ι) : b.Moves W b.tray b.env := Can.id
lemma cherry (b : Bench m ι) (x : ι→T t) : (b.extend t x).Moves W t x := Can.second
lemma pie (b : Bench m ι) (x : ι→T t) : (b.extend t x).Moves W b.tray b.env :=
  Can.first
lemma caseM {v : ι→T s} (h : b.Moves W t x) (g : (b.extend t x).Moves W s v) :
    b.Moves W s v := Can.bind h g

namespace Instant
variable {f : ι→κ}

lemma next (h : b.Instant q f) {p : κ→μ} (g : q.Instant z p) :
    b.Instant z fun i => p (f i) :=
  ⟨g.prep.transfer h,(g.covers.reindex _).trans h.covers⟩
lemma extend (b : Bench m ι) (x : ι→T t) : (b.extend t x).Instant b id :=
  ⟨pie b x,Small.self _⟩
lemma along (b : Bench m ι) (f : κ→ι) : (b.along f).Instant b f :=
  ⟨envNow (b.along f),Small.self _⟩
lemma scan (b : Bench m ι) (n : ι→ℕ) : (b.scan n).Instant b During.i :=
  (Instant.extend _ (t:=w) (During.j (n:=n))).next (Instant.along b During.i)
lemma climbs (b : Bench m ι) (n : ι→ℕ) (x : ι → ℕ → T t) :
    (b.climbs n t x).Instant b During.i :=
  (Instant.extend _ (t:=p w t) (fun i : During n => (i.j,x i.i i.j))).next (Instant.along b During.i)
lemma supply (h : b.Instant q f) (x : κ→T t)
    (hx : b.Moves (fun _ => 0) t (fun i => x (f i))) :
    b.Instant (q.extend t x) f := ⟨h.prep.pair hx,h.covers⟩
lemma select {n : κ→ℕ} {f : ι→During n} (h : b.Instant q (fun i => (f i).i))
    (g : b.Moves (fun _ => 0) w (fun i => (f i).j)) :
    b.Instant (q.scan n) f := ⟨h.prep.pair g,h.covers⟩
end Instant

lemma chop {n : ι→ℕ} (h : b.Nick n) :
    (b.scan n).Nick During.j :=
  ⟨cherry (t:=w) _ During.j,
    (h.small.reindex During.i).mono (fun d : During n => d.hj.le)⟩

lemma stride {n : ι→ℕ} (h : b.Nick n) (x : ι → ℕ → T t) :
    (b.climbs n t x).Nick During.j :=
  ⟨(cherry (W:=fun _ => 0) _ (t:=p w t) (fun d : During n => (d.j,x d.i d.j))).fst,
    (chop h).small⟩
lemma tokenNow (b : Bench m ι) (n : ι→ℕ) (x : ι → ℕ → T t) :
    (b.climbs n t x).Moves (fun _ => 0) t (fun i => x i.i i.j) :=
  (cherry (t:=p w t) (W:=fun _ => 0) _ (fun d : During n => (d.j,x d.i d.j))).snd

variable {n : ι→ℕ} {u : ι → ℕ → ℕ}

theorem arrayM (h : b.Nick n) (f : ι→ℕ→T t)
    (hs : (b.scan n).Moves (fun d => u d.i d.j) t (fun d => f d.i d.j)) :
    b.Moves (fun i => n i + ∑ j ∈ range (n i), u i j) (a t)
      (fun i => Tape.tab (n i) (f i)) := by
  have hh := Can.tab (v:=f) (uB:=u) h.close hs h.small
  simpa only [Nat.zero_add,Moves] using hh

theorem arrayNow (h : b.Nick n) (f : ι→ℕ→T t)
    (hs : (b.scan n).Moves (fun _ => 0) t (fun d => f d.i d.j)) :
    b.Moves n (a t) (fun i => Tape.tab (n i) (f i)) := by
  simpa only [Nat.add_zero,sum_const_zero] using arrayM (u:=fun _ _ => 0) h f hs

theorem scatterNow (h : b.Nick n) (f : ι → ℕ → ℕ × T t)
    (hs : (b.scan n).Moves (fun _ => 0) (p w t) (fun d => f d.i d.j)) :
    b.Moves n (a t) (fun i => Tape.sow (n i) (n i) t.blank (f i)) := by
  have H := Can.sow (v:=f) (uB:=fun _ _ => 0) h.close h.close hs h.small h.small
  simp only [Nat.add_zero,Nat.zero_add,sum_const_zero] at H
  exact H.weaken ((Dom.self n).add (Dom.self n))

theorem repeatM (h : b.Nick n) (f : ι → ℕ → T t)
    (hb : b.Moves (fun _ => 0) t fun i => f i 0)
    (hh : (b.climbs n t f).Moves (fun d => u d.i d.j) t fun d => f d.i (d.j+1)) :
    b.Moves (fun i => n i+∑ j ∈ range (n i), u i j) t fun i => f i (n i) := by
  have H := Can.loop (v:=f) (uB:=u) h.close hb hh h.small
  simpa only [Nat.add_zero,Nat.zero_add,Moves] using H

theorem inspectz (h : b.Nick n)
    (hg : (b.along (Subtype.val (p:=fun i => n i = 0))).Moves
      (fun i => W i.val) t (fun i => x i.val))
    (hj : (b.along (Subtype.val (p:=fun i => n i ≠ 0))).Moves
      (fun i => W i.val) t (fun i => x i.val)) :
    b.Moves W t x := Can.testz (h.mov W) hg hj

end Bench

end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Finset
noncomputable section

-- halving and log. All-natural iterations.
def tallyH (n : ℕ) : ℕ → ℕ×ℕ
  | 0 => (n,0)
  | k+1 => let p := tallyH n k
           (p.1 / 2,p.2+(if 1<p.1 then 1 else 0))

namespace tallyH

lemma small (n k : ℕ) : (tallyH n k).1 ≤ n ∧ (tallyH n k).2 ≤ k := by
  induction k with
  | zero => exact ⟨le_rfl,le_rfl⟩
  | succ k ih => simp only [tallyH]; split <;> omega

lemma tally (n k : ℕ) :
    Nat.log 2 n = Nat.log 2 (tallyH n k).1 + (tallyH n k).2 := by
  induction k with
  | zero => rfl
  | succ k ih =>
    simp only [tallyH]; split
    · rename_i H
      conv_lhs => rw [ih,Nat.log_of_one_lt_of_le Nat.one_lt_two H]
      omega
    · rename_i H
      rw [Nat.log_of_lt (show (tallyH n k).1/2<2 by omega)]
      have hx := Nat.log_of_lt (b:=2) (show (tallyH n k).1<2 by omega)
      rw [hx] at ih; omega

lemma quota (n k : ℕ) :
    (tallyH n k).1 ≤ n-k := by
  induction k with
  | zero => rfl
  | succ k ih => simp only [tallyH]; omega

lemma end_eq (n : ℕ) : (tallyH n n).2 = Nat.log 2 n := by
  have H := tally n n
  rw [Nat.log_of_lt (show (tallyH n n).1<2 by have := quota n n; omega)] at H
  omega
end tallyH

universe U V
namespace Bench
variable {m : Bool} {ι : Type U} {b : Bench m ι} {n k : ι→ℕ}

lemma Nick.cmp (h : b.Nick n) (g : b.Nick k) :
    b.Nick fun i => if n i < k i then 1 else 0 :=
  ⟨Can.wlt h.close g.close,(Small.const _ 1).mono fun i => by split <;> omega⟩

lemma Nick.logM (h : b.Nick n) :
    b.Moves n w fun i => Nat.log 2 (n i) := by
  let V (i : ι) j : T (p w w) := tallyH (n i) j
  have F := Instant.climbs b n V (t:=p w w)
  have hk := tokenNow b n V
  have hb := (h.transfer F).small
  let D := b.climbs n (p w w) V
  have hx : D.Nick fun i => (V i.i i.j).1 :=
    ⟨hk.fst,hb.mono fun i => (tallyH.small _ _).1⟩
  have hy : D.Nick fun i => (V i.i i.j).2 :=
    ⟨hk.snd,hb.mono fun i => ((tallyH.small _ _).2).trans i.hj.le⟩
  have hh := repeatM h V (h.close.pair (Moves.wc 0)) (u:=fun _ _ => 0)
    ((hx.div (Nick.wc 2)).close.pair (hy.add ((Nick.wc 1).cmp hx)).close)
  simp only [sum_const_zero,Nat.add_zero] at hh
  exact hh.snd.congr fun i => tallyH.end_eq _

lemma Nick.numeralM (h : b.Nick n) :
    b.Moves n sc fun i => (n i:ℂ) := by
  let V (i : ι) (j : ℕ) : T sc := (j:ℂ)
  have H := repeatM h V (u:=fun _ _ => 0)
    (Moves.zero.congr (fun _ => by simp [V])) (((tokenNow b n V).add Moves.one).congr
      (fun _ => by simp [V]))
  simpa only [sum_const_zero,Nat.add_zero] using H
end Bench
end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty
noncomputable section

universe U V

namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι} {q : Bench m κ} {s t : Ty}

def Dry (b : Bench m ι) (S : ι→ℕ) (t : Ty) (f : ι→T t) : Prop :=
  PolyCan m b.size S b.tray t b.env f

structure Grain (b : Bench m ι) (S f : ι→ℕ) : Prop where
  dry : b.Dry S w f
  small : Small b.size f

variable {S : ι→ℕ}

lemma Moves.dry {W x} (h : b.Moves W t x) (g : Small S W) :
    b.Dry S t x := PolyCan.of_can h g
lemma Moves.dunes {x} (h : b.Moves (fun _ => 0) t x) (S : ι→ℕ) :
    b.Dry S t x := h.dry (Small.const _ 0)
lemma Nick.grain {x} (h : b.Nick x) (S : ι→ℕ) :
    b.Grain S x := ⟨h.close.dunes S,h.small⟩

namespace Dry
variable {x y : ι→T t}

lemma congr (h : b.Dry S t x) (g : ∀ i, x i=y i) :
    b.Dry S t y := by rwa [← funext g]
lemma pair {v : ι→T s} (h : b.Dry S t x) (g : b.Dry S s v) :
    b.Dry S (p t s) fun i => (x i,v i) := PolyCan.pair h g
lemma fst {v : ι→T (p s t)} (h : b.Dry S (p s t) v) :
    b.Dry S s fun i => (v i).1 := PolyCan.fst h
lemma snd {v : ι→T (p s t)} (h : b.Dry S (p s t) v) :
    b.Dry S t fun i => (v i).2 := PolyCan.snd h
lemma wc (n : ℕ) : b.Dry S w fun _ => n := PolyCan.wc n
lemma one : b.Dry S sc fun _ => 1 := PolyCan.one
lemma mul {cl} {x y : ι→ℂ} (h : b.Dry S sc x) (g : b.Dry S (c cl) y) :
    b.Dry S (c cl) fun i => x i*y i := PolyCan.mul h g
lemma inv {x : ι→ℂ} (h : b.Dry S sc x) (g : ∀ i, x i≠0) :
    b.Dry S sc fun i => (x i)⁻¹ := PolyCan.inv h g
lemma transfer {f : ι→κ} {S : κ→ℕ} {x : κ→T t} (h : q.Dry S t x) (g : b.Instant q f) :
    b.Dry (fun i => S (f i)) t fun i => x (f i) :=
  PolyCan.pipe (g.prep.dunes _) (PolyCan.weaken (PolyCan.reindex h f) g.covers (Small.self _))
lemma together {v : ι→T s} (h : b.Dry S t x) (g : (b.extend t x).Dry S s v) :
    b.Dry S s v := PolyCan.bind h g
lemma look {x : ι→Tape (T t)} {n} (h : b.Dry S (a t) x) (g : b.Dry S w n) :
    b.Dry S t fun i => (x i).look (n i) t.blank := PolyCan.look h g
lemma pick {x : ι→ℕ→T t} {n k : ι→ℕ} (h : b.Dry S (a t) fun i => Tape.tab (n i) (x i))
    (g : b.Dry S w k) (hk : ∀ i,k i<n i) :
    b.Dry S t fun i => x i (k i) :=
  (h.look g).congr fun i => by rw [Tape.look_tab, ite_eq_left (hk i)]
lemma testz {f} (h : b.Dry S w f)
    (g : (b.along (Subtype.val (p:=fun i => f i = 0))).Dry (fun i => S i.val) t fun i => x i.val)
    (j : (b.along (Subtype.val (p:=fun i => f i ≠ 0))).Dry (fun i => S i.val) t fun i => x i.val) :
    b.Dry S t x := PolyCan.testz h g j
lemma branch {f} (h : b.Dry S w f) (g : b.Dry S t x) (j : b.Dry S t y) :
    b.Dry S t fun i => if f i = 0 then x i else y i := by
  refine testz h ?_ ?_
  · exact (g.transfer (Instant.along b (Subtype.val (p:=fun i => f i = 0)))).congr
      fun i => (ite_eq_left i.property).symm
  · exact (j.transfer (Instant.along b (Subtype.val (p:=fun i => f i ≠ 0)))).congr
      fun i => (ite_eq_right i.property).symm
end Dry
namespace Grain
variable {x y : ι→ℕ}

lemma wc (n : ℕ) : b.Grain S fun _ => n := (Nick.wc n).grain _
lemma add (h : b.Grain S x) (g : b.Grain S y) :
    b.Grain S fun i => x i+y i :=
  ⟨PolyCan.wadd h.dry g.dry (h.small.add g.small),h.small.add g.small⟩
lemma mul (h : b.Grain S x) (g : b.Grain S y) :
    b.Grain S fun i => x i*y i :=
  ⟨PolyCan.wmul h.dry g.dry (h.small.mul g.small),h.small.mul g.small⟩
lemma div (h : b.Grain S x) (g : b.Grain S y) :
    b.Grain S fun i => x i/y i :=
  ⟨PolyCan.wdiv h.dry g.dry h.small.div,h.small.div⟩
lemma residue (h : b.Grain S x) (g : b.Grain S y) :
    b.Grain S fun i => x i%y i :=
  ⟨PolyCan.wmod h.dry g.dry h.small.mod,h.small.mod⟩
lemma cmp (h : b.Grain S x) (g : b.Grain S y) :
    b.Grain S fun i => if x i<y i then 1 else 0 :=
  ⟨PolyCan.wlt h.dry g.dry,(Small.const _ 1).mono fun i => by split <;> omega⟩
lemma congr (h : b.Grain S x) (g : ∀ i,x i=y i) :
    b.Grain S y := by rwa [← funext g]
lemma transfer {f : ι→κ} {S x : κ→ℕ} (h : q.Grain S x) (g : b.Instant q f) :
    b.Grain (fun i => S (f i)) fun i => x (f i) :=
  ⟨h.dry.transfer g,(h.small.reindex _).trans g.covers⟩
lemma logtwo (h : b.Grain S x) (g : Small S x) :
    b.Grain S fun i => Nat.log 2 (x i) := by
  have hh : (b.extend w x).Nick x := ⟨cherry (t:=w) b x,h.small⟩
  exact ⟨h.dry.together (hh.logM.dry g),h.small.mono fun i => Nat.log_le_self 2 _⟩
end Grain

variable {n : ι→ℕ}
lemma strideG (h : b.Grain S n) (x : ι → ℕ → T t) :
    (b.climbs n t x).Grain (fun i => S i.i) During.j :=
  ⟨PolyCan.fst PolyCan.second,
    (h.small.reindex During.i).mono (fun i : During n => i.hj.le)⟩
lemma chopG (h : b.Grain S n) :
    (b.scan n).Grain (fun i => S i.i) During.j :=
  ⟨PolyCan.second,(h.small.reindex During.i).mono (fun i : During n => i.hj.le)⟩

lemma Dry.token (b : Bench m ι) (n S : ι→ℕ) (x : ι → ℕ → T t) :
    (b.climbs n t x).Dry (fun i => S i.i) t fun i => x i.i i.j :=
  (tokenNow b n x).dunes _

lemma cycleG (h : b.Grain S n) (k : Small S n) (x : ι → ℕ → T t)
    (g : b.Dry S t fun i => x i 0)
    (j : (b.climbs n t x).Dry (fun i => S i.i) t fun i => x i.i (i.j+1)) :
    b.Dry S t fun i => x i (n i) :=
  PolyCan.loop h.dry g j h.small k

lemma arrayG (h : b.Grain S n) (k : Small S n) (x : ι→ℕ→T t)
    (g : (b.scan n).Dry (fun i => S i.i) t fun i => x i.i i.j) :
    b.Dry S (a t) fun i => Tape.tab (n i) (x i) := PolyCan.tab h.dry g h.small k

lemma Grain.twoPow (h : b.Grain S n) (k : Small S n)
    (j : Small b.size fun i => 2^n i) :
    b.Grain S fun i => 2^n i := by
  let v (i : ι) (a : ℕ) : T w := 2^a
  let D := b.climbs n w v
  have hh : D.Grain (fun i => S i.i) fun i => v i.i i.j :=
    ⟨Dry.token b n S v,
      (j.reindex During.i).mono fun i => Nat.pow_le_pow_right (by omega) i.hj.le⟩
  refine ⟨cycleG h k v ?_ ((hh.mul (wc 2)).dry.congr fun i => (pow_succ _ _).symm),j⟩
  simpa only [v,pow_zero] using Dry.wc (b:=b) (S:=S) 1

end Bench
end
end PowerSaving.RAM

end OAI
