import Submission.OAI.Computability.FourierTransform.RootPreparation

namespace OAI
namespace PowerSaving.Binary
open Matrix Finset

abbrev Sky (α : Type*) (f : ℕ) := (Fin f → Space α)
abbrev Data (α : Type*) (ρ : Type*) (f : ℕ) := ρ → Sky α f → ℂ

section
variable {α ρ : Type*} [Fintype α] [DecidableEq α]

def matAct (f : ℕ) (M : CMat α) (x : Sky α f → ℂ) : Sky α f → ℂ :=
  (digitProd (fun _ : Fin f => M)) *ᵥ x

@[simp] theorem matAct_mul (f : ℕ) (M N : CMat α) (x : Sky α f → ℂ) :
    matAct f M (matAct f N x) = matAct f (M*N) x := by
  unfold matAct; rw [Matrix.mulVec_mulVec, digitProd_mul]

@[simp] theorem matAct_one (f : ℕ) (x : Sky α f → ℂ) :
    matAct f (1 : CMat α) x=x := by
  unfold matAct; rw [digitProd_one, Matrix.one_mulVec]

def multiAct (f : ℕ) (M : ρ → CMat α) (x : Data α ρ f) : Data α ρ f :=
  fun r => matAct f (M r) (x r)

def roleAct (f : ℕ) [DecidableEq ρ] (r : ρ) (M : CMat α) (x : Data α ρ f) : Data α ρ f :=
  fun j => if j=r then matAct f M (x j) else x j

@[simp] lemma roleAct_mul (f : ℕ) [DecidableEq ρ] (r : ρ) (M N : CMat α)
    (x : Data α ρ f) :
    roleAct f r M (roleAct f r N x) = roleAct f r (M*N) x := by
  funext j; by_cases h : j = r <;> simp [roleAct, h]

def point (f : ℕ) (g : (ρ→ℂ)→(ρ→ℂ)) (x : Data α ρ f) : Data α ρ f :=
  fun r i => g (fun r => x r i) r

theorem matAct_shift (f : ℕ) (z : Space α) (y : Sky α f → ℂ) (j : Sky α f) :
    matAct f (shift z) y j = y (fun l => j l + z) := by
  simp only [matAct, Matrix.mulVec, dotProduct]
  rw [Finset.sum_eq_single (fun l => j l + z)]
  · simp [digitProd_apply, shift]
  · intro b _ hb
    obtain ⟨l, hl⟩ : ∃ l, j l + z ≠ b l := by
      by_contra hc
      exact hb (funext fun l => by_contra fun e => hc ⟨l, fun h' => e h'.symm⟩)
    rw [digitProd_apply, Finset.prod_eq_zero (Finset.mem_univ l) (by simp [shift, hl]), zero_mul]
  · intro h; exact absurd (Finset.mem_univ _) h

end

section
variable {α ρ : Type*}

inductive Move (α ρ : Type*)
  | localM (g : Matrix ρ ρ ℚ)
  | dir (r : ρ) (z : Space α) (nz : z≠0)
  | shift (r : ρ) (z : Space α)

def toll : Move α ρ → ℕ
  | .dir _ _ _ => 1
  | _ => 0

abbrev PWord (α ρ : Type*) := List (Move α ρ)

def tally (s : PWord α ρ) : ℕ := (s.map toll).sum

theorem tally_append (p q : PWord α ρ) : tally (p++q) = tally p + tally q := by
  simp [tally]

end

section
variable {α ρ : Type*}
variable [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

def actPoint (g : Matrix ρ ρ ℚ) (x : ρ→ℂ) (r : ρ) := ∑ j, (g r j:ℂ)*x j

noncomputable def Move.go (f : ℕ) : Move α ρ → Data α ρ f → Data α ρ f
  | .localM M => point f (actPoint M)
  | .dir r z _ => roleAct f r (Binary.dir z)
  | .shift r z => roleAct f r (Binary.shift z)

noncomputable def walk (f : ℕ) (p : PWord α ρ) (x : Data α ρ f) : Data α ρ f :=
  p.foldl (fun y s => s.go f y) x

theorem walk_append (f : ℕ) (p q : PWord α ρ) (x : Data α ρ f) :
    walk f (p++q) x = walk f q (walk f p x) := by
  simp [walk, List.foldl_append]

def mass (s : ρ → Finset α) := ∑ r, (s r).card
def loss (s t : ρ → Finset α) := ∑ r, (s r \ t r).card

noncomputable def withFrame (A : ρ → OBase α) (s : ρ → Finset α) (f : ℕ) : Data α ρ f → Data α ρ f :=
  multiAct f fun r => frame (A r) (s r)

def Path (A : ρ → OBase α) (s t : ρ → Finset α)
    (g : (ρ→ℂ) → (ρ→ℂ)) (losses : ℕ) : Prop :=
  ∃ p : PWord α ρ,
    tally p + mass s = mass t + 2 * losses ∧
    ∀ (f : ℕ) (x : Data α ρ f),
      walk f p (withFrame A s f x) = withFrame A t f (point f g x)

namespace Path
variable {A : ρ → OBase α} {s t u : ρ → Finset α}

theorem refl : Path A s s id 0 := ⟨[], by simp [tally], fun _ _ => rfl⟩

theorem trans {g h i j} (a : Path A s t g i) (b : Path A t u h j) :
    Path A s u (h ∘ g) (i+j) := by
  obtain ⟨p, hp, wp⟩ := a
  obtain ⟨q, hq, wq⟩ := b
  refine ⟨p ++ q, by rw [tally_append]; omega, fun f x => ?_⟩
  rw [walk_append, wp, wq]; rfl

theorem sum_update (G : ρ → ℕ) (r : ρ) (c : ℕ) :
    ∑ r', Function.update G r c r' + G r = ∑ r', G r' + c := by
  have h1 : Function.update G r c r + ∑ x ∈ Finset.univ.erase r, Function.update G r c x =
      ∑ x, Function.update G r c x := Finset.add_sum_erase _ _ (Finset.mem_univ r)
  have h2 : G r + ∑ x ∈ Finset.univ.erase r, G x = ∑ x, G x :=
    Finset.add_sum_erase _ _ (Finset.mem_univ r)
  have h3 : ∑ x ∈ Finset.univ.erase r, Function.update G r c x = ∑ x ∈ Finset.univ.erase r, G x :=
    Finset.sum_congr rfl (fun x hx => Function.update_of_ne (Finset.ne_of_mem_erase hx) c G)
  rw [Function.update_self] at h1
  omega

theorem delta_word (r : ρ) (z : Space α) (hz : dot z z = 1) (nz : z ≠ 0) :
    ∃ p : PWord α ρ, tally p = 1 ∧ ∀ f y, walk f p y = roleAct f r (delta z) y := by
  rcases lum_of_unit z hz with h | h
  · exact ⟨[.dir r z nz], rfl, fun f y => by simp [walk, Move.go, delta_pos z h]⟩
  · exact ⟨[.dir r z nz, .shift r z], rfl, fun f y => by
      simp [walk, Move.go, delta_neg z h]⟩

theorem change_add (s : ρ → Finset α) (r : ρ) (i : α) (hi : i ∉ s r) :
    Path A s (Function.update s r (insert i (s r))) id 0 := by
  obtain ⟨p, hp, hw⟩ := delta_word (ρ := ρ) r ((A r).v i) ((A r).self i) ((A r).nz i)
  refine ⟨p, ?_, fun f x => ?_⟩
  · have := sum_update (fun r' => (s r').card) r (insert i (s r)).card
    try simp only at this
    have c := Finset.card_insert_of_notMem hi
    have e : (fun r' => (Function.update s r (insert i (s r)) r').card) =
        Function.update (fun r' => (s r').card) r (insert i (s r)).card := by
      funext r'; exact Function.apply_update (fun _ => Finset.card) s r _ r'
    unfold mass; rw [e]; linarith
  · rw [hw]
    funext r' y
    by_cases e : r' = r
    · rw [e]
      simp [roleAct, withFrame, multiAct, frame_ins (A r) (s r) i hi]
      try rfl
    · simp [roleAct, withFrame, multiAct, e, Function.update_apply]
      try rfl

theorem inc (A : ρ → OBase α) {s t : ρ → Finset α} (h : ∀ r, s r ⊆ t r) :
    Path A s t id 0 := by
  suffices H : ∀ n (s : ρ → Finset α), (∀ r, s r ⊆ t r) → loss t s = n → Path A s t id 0 from
    H _ s h rfl
  intro n
  induction n with
  | zero =>
    intro s hs h0
    have : s = t := funext fun r => Finset.Subset.antisymm (hs r) (Finset.sdiff_eq_empty_iff_subset.mp
      (Finset.card_eq_zero.mp ((Finset.sum_eq_zero_iff.mp h0) r (Finset.mem_univ r))))
    subst this; exact refl
  | succ n ih =>
    intro s hs hn
    obtain ⟨r, -, hr⟩ := Finset.exists_ne_zero_of_sum_ne_zero (by rw [loss] at hn; omega :
      ∑ r, (t r \ s r).card ≠ 0)
    obtain ⟨i, hi⟩ := Finset.card_ne_zero.mp hr
    rw [Finset.mem_sdiff] at hi
    let s' := Function.update s r (insert i (s r))
    have hs' : ∀ r', s' r' ⊆ t r' := by
      intro r'
      by_cases e : r' = r
      · rw [e]; simp only [s', Function.update_self]; exact Finset.insert_subset hi.1 (hs r)
      · simp only [s', Function.update_of_ne e]; exact hs r'
    have hl : loss t s' = n := by
      have := sum_update (fun r' => (t r' \ s r').card) r (t r \ insert i (s r)).card
      have e : (fun r' => (t r' \ s' r').card) =
          Function.update (fun r' => (t r' \ s r').card) r (t r \ insert i (s r)).card := by
        funext r'; exact Function.apply_update (fun r' x => (t r' \ x).card) s r _ r'
      have c : (t r \ insert i (s r)).card + 1 = (t r \ s r).card := by
        rw [Finset.sdiff_insert, Finset.card_erase_of_mem (Finset.mem_sdiff.mpr hi)]
        have := Finset.card_pos.mpr ⟨i, Finset.mem_sdiff.mpr hi⟩; omega
      try simp only at this
      unfold loss at hn ⊢; rw [e]; linarith
    exact (change_add s r i hi.2).trans (ih s' hs' hl)

end Path
end

section
variable {α : Type*}

abbrev Bits (k : ℕ) := Space (Fin k)

def lbit : Layout F where
  n := 2
  loc := fun i => i.val
  bd := fun i => (show Fin 2 from i).isLt
  inj := fun _ _ h => Fin.ext h
  onto := fun j => ⟨Fin.mk j.val j.isLt, rfl⟩

noncomputable def shape (X : Layout α) : Layout (Space α) := X.digits lbit

noncomputable def bits (k : ℕ) : Layout (Bits k) := shape (Layout.std k)

@[simp] theorem bits_len (k : ℕ) : (bits k).n=2^k := rfl

theorem bits_loc (k : ℕ) (x : Bits k) :
    (bits k).loc x = ∑ i : Fin k, (x i).val*2^i.val :=
  Layout.digits_code (Layout.std k) lbit x

theorem bits_div (k : ℕ) (x : Bits k) (i : Fin k) :
    ((bits k).loc x / 2^i.val)%2 = (x i).val :=
  Layout.digits_entry (Layout.std k) lbit x i

theorem bits_lit (k : ℕ) : (bits k).loc (fun _ => 1)+1=2^k := by
  rw [bits_loc]
  simp only [show (1 : F).val = 1 from rfl, Nat.one_mul]
  rw [Fin.sum_univ_eq_sum_range (fun i => 2^i) k]
  induction k with
  | zero => rfl
  | succ k ih => rw [Finset.sum_range_succ, Nat.pow_succ]; omega

abbrev Grid (α : Type*) (r f : ℕ) := Bits r × Sky α f

def rows (α : Type*) (f : ℕ) : Sky α f ≃ (α → Bits f) where
  toFun x i j := x j i
  invFun x i j := x j i
  left_inv _ := rfl
  right_inv _ := rfl

noncomputable def bodyOrder (X : Layout α) (f : ℕ) : Layout (Sky α f) :=
  (X.digits (bits f)).comap (rows α f)

noncomputable def book (X : Layout α) (r f : ℕ) : Layout (Grid α r f) :=
  (bits r).pair (bodyOrder X f)

@[simp] theorem book_len (X : Layout α) (r f) :
    (book X r f).n = 2^(X.n*f+r) := by
  show 2^r * (2^f)^X.n = _
  rw [Nat.pow_add, Nat.pow_mul', Nat.mul_comm]

abbrev Layers (α : Type*) (r f : ℕ) := (α × Fin f) ⊕ Fin r

def build (α : Type*) (r f : ℕ) : Grid α r f ≃ Space (Layers α r f) where
  toFun x
    | .inl (i,j) => x.2 j i
    | .inr i => x.1 i
  invFun x := (fun i => x (.inr i), fun j i => x (.inl (i,j)))
  left_inv _ := rfl
  right_inv x := by ext (⟨i,j⟩|i) <;> rfl

def stick (X : Layout α) (r f : ℕ) : Layout (Layers α r f) :=
  (X.pair (Layout.std f)).cat (Layout.std r)

noncomputable def normIndex {β : Type*} (L : Layout β) {k : ℕ} (h : L.n = k) : β ≃ Fin k :=
  L.index.trans (finCongr h)

noncomputable def serial (X : Layout α) (r f : ℕ) {k} (h : X.n*f+r=k) :
    Grid α r f ≃ Bits k :=
  (build α r f).trans (Layout.permFn (normIndex (stick X r f) h) F)

theorem serial_at (X : Layout α) (r f : ℕ) {k} (h : X.n*f+r=k) (x : Grid α r f)
    (q : Layers α r f) : serial X r f h x (normIndex (stick X r f) h q) = build α r f x q := by
  show build α r f x ((normIndex (stick X r f) h).symm (normIndex (stick X r f) h q)) = _
  rw [Equiv.symm_apply_apply]

lemma serial_code {α : Type*} [Fintype α] (X : Layout α) (r f) {k}
    (h : X.n*f+r=k) (x : Grid α r f) :
    (bits k).loc (serial X r f h x) = (book X r f).loc x := by
  rw [bits_loc, ← Equiv.sum_comp (normIndex (stick X r f) h)]
  simp only [serial_at]
  -- CHECK: the normal form below; `(normIndex L h q).val = L.loc q` is `rfl`
  show ∑ q : Layers α r f, (build α r f x q).val * 2^((stick X r f).loc q) =
    (bits r).loc x.1 * (2^f)^X.n + (Layout.digits X (bits f)).loc ((rows α f) x.2)
  rw [Fintype.sum_sum_type, Fintype.sum_prod_type, Layout.digits_code, bits_loc, Finset.sum_mul]
  refine Eq.trans (add_comm _ _) ?_
  congr 1
  · refine Finset.sum_congr rfl (fun i _ => ?_)
    show (x.1 i).val * 2^(X.n * f + i.val) = (x.1 i).val * 2^i.val * (2^f)^X.n
    rw [Nat.pow_add, Nat.mul_comm X.n f, Nat.pow_mul]; ring
  · refine Finset.sum_congr rfl (fun a _ => ?_)
    rw [bits_loc, Finset.sum_mul]
    refine Finset.sum_congr rfl (fun l _ => ?_)
    show (x.2 l a).val * 2^(X.loc a * f + l.val) = (x.2 l a).val * 2^l.val * (2^f)^(X.loc a)
    rw [Nat.pow_add, Nat.mul_comm (X.loc a) f, Nat.pow_mul]; ring

lemma kernel_serial {α : Type*} [Fintype α] (X : Layout α) (r f) {k}
    (h : X.n*f+r=k) (x y : Grid α r f) :
    kernel (Fin k) (serial X r f h x) (serial X r f h y) =
    kernel (Fin r) x.1 y.1 * digitProd (fun _ : Fin f => kernel α) x.2 y.2 := by
  simp only [kernel, digitProd_apply]
  rw [← Equiv.prod_comp (normIndex (stick X r f) h)]
  simp only [serial_at]
  rw [Fintype.prod_sum_type, Fintype.prod_prod_type, Finset.prod_comm, mul_comm]
  rfl

noncomputable def ripple (k : ℕ) (x : Bits k → ℂ) := kernel (Fin k) *ᵥ x

end

section
variable {α : Type*} [Fintype α] [DecidableEq α]

abbrev Minus (i : α) := {j : α // j ≠ i}

omit [Fintype α] [DecidableEq α] in
def peel (i : α) (z : Space α) : Space α ≃ Space (Minus i) × F where
  toFun x := (fun j => x j.1 + z j.1*x i, x i)
  invFun q j := if h : j=i then q.2 else q.1 ⟨j,h⟩ + z j*q.2
  left_inv x := by ext j; by_cases j=i <;> simp [*,add_assoc]
  right_inv q := by
    apply Prod.ext
    · funext j; simp [j.property,add_assoc]
    · simp

end
end PowerSaving.Binary

namespace PowerSaving.RAM
open Binary Matrix Ty Finset
noncomputable section
universe U V

section
variable {ι : Type U}

abbrev Has (m : Bool) (B : ι → ℕ) (s t : Ty) (x : ι → T s) (y : ι → T t) : Prop :=
  Can m B s t x y (fun _ => 0)

abbrev Knows (m : Bool) (B : ι → ℕ) (s : Ty) (x : ι → T s) (y : ι → ℕ) : Prop :=
  Has m B s w x y

end

theorem lt_two_pow' (n : ℕ) : n < 2^n := by
  induction n with
  | zero => simp
  | succ n ih => rw [Nat.pow_succ]; omega

def xorOrd (k : ℕ) : Layout (Bits k × Bits k) := (bits k).pair (bits k)

def xorTab (k : ℕ) : Tape ℕ := (xorOrd k).tape (fun i => (bits k).loc (i.1+i.2))

private lemma val_add2 (a b : F) : (a+b).val = (a.val+b.val)%2 := by revert a b; decide

theorem xor_value (k : ℕ) (a b : Bits k) : (bits k).loc (a+b) =
    ∑ l ∈ range k, ((bits k).loc a / 2^l + (bits k).loc b / 2^l) % 2 * 2^l := by
  rw [bits_loc, ← Fin.sum_univ_eq_sum_range
    (fun l => ((bits k).loc a / 2^l + (bits k).loc b / 2^l) % 2 * 2^l)]
  refine Finset.sum_congr rfl (fun l _ => ?_)
  rw [Pi.add_apply, val_add2, Nat.add_mod ((bits k).loc a / 2^l.val), bits_div, bits_div]

def accXor (A C j : ℕ) : ℕ := ∑ l ∈ range j, (A / 2^l + C / 2^l) % 2 * 2^l

theorem accXor_lt (A C j : ℕ) : accXor A C j < 2^j := by
  induction j with
  | zero => simp [accXor]
  | succ j ih =>
    unfold accXor at *
    rw [Finset.sum_range_succ, Nat.pow_succ]
    have : (A / 2^j + C / 2^j) % 2 ≤ 1 := by omega
    have := Nat.mul_le_mul_right (2^j) this
    omega

section
variable {ι : Type U} {m : Bool} {s : Ty} {x : ι→T s} {B f : ι→ℕ}

theorem Can.xor_prepare (hf : Can m B s w x f (fun _ => 0))
    (hg : Can m B s w x (fun i => 2^f i) (fun _ => 0))
    (hB : Small B f) (hd : Small B fun i => 2^f i) :
    Can m B s (a w) x (fun i => xorTab (f i)) (fun i => (2^f i)^3) := by
  let Q := Σ i, Bits (f i) × Bits (f i)
  let ℓ (d : Q) : ℕ := (xorOrd (f d.1)).loc d.2
  let A (d : Q) : ℕ := (bits (f d.1)).loc d.2.1
  let C (d : Q) : ℕ := (bits (f d.1)).loc d.2.2
  let y (d : Q) : T (p s w) := (x d.1, ℓ d)
  let vv (d : Q) (j : ℕ) : T (p w w) := (2^j, accXor (A d) (C d) j)
  let BQ (d : Q) := B d.1
  -- bounds over the loop instances
  let K (dd : During (fun d : Q => f d.1)) : ℕ := (2^f dd.i.1)^2*2
  have hK : Small (fun dd : During (fun d : Q => f d.1) => B dd.i.1) K :=
    (((hd.reindex Sigma.fst).reindex During.i).pow 2).mul (Small.const _ 2)
  have hP (dd : During (fun d : Q => f d.1)) : 2^(dd.j+1) ≤ K dd := by
    have h1 : 2^(dd.j+1) ≤ 2^f dd.i.1 := Nat.pow_le_pow_right (by omega) dd.hj
    have h2 : 1 ≤ 2^f dd.i.1 := Nat.one_le_two_pow
    show _ ≤ (2^f dd.i.1)^2*2
    rw [Nat.pow_two]; have := Nat.mul_le_mul h2 (Nat.le_refl (2^f dd.i.1)); omega
  have hℓ (d : Q) : ℓ d < 2^f d.1 * 2^f d.1 := (xorOrd (f d.1)).bd d.2
  have hA (d : Q) : A d = ℓ d / 2^f d.1 := (Layout.pair_div (bits (f d.1)) (bits (f d.1)) d.2).symm
  have hC (d : Q) : C d = ℓ d % 2^f d.1 := (Layout.pair_mod (bits (f d.1)) (bits (f d.1)) d.2).symm
  have hlK (dd : During (fun d : Q => f d.1)) : ℓ dd.i ≤ K dd := by
    have := hℓ dd.i; show _ ≤ (2^f dd.i.1)^2*2; rw [Nat.pow_two]; omega
  -- the loop body: (P,S) ↦ (2P, S + P*((A/P + C/P) % 2))
  let IN := p (p s w) (p w (p w w))
  have F0 : ∀ {u : Ty} {z : During (fun d : Q => f d.1) → T u},
      Has m (fun dd => B dd.i.1) (p s w) u (fun dd => y dd.i) z →
      Has m (fun dd => B dd.i.1) IN u (fun dd => (y dd.i, dd.j, vv dd.i dd.j)) z :=
    fun g => Can.first.then_do g
  have hl : Knows m (fun dd : During (fun d : Q => f d.1) => B dd.i.1) IN
      (fun dd => (y dd.i, dd.j, vv dd.i dd.j)) (fun dd => ℓ dd.i) := F0 Can.second
  have hpf : Knows m (fun dd : During (fun d : Q => f d.1) => B dd.i.1) IN
      (fun dd => (y dd.i, dd.j, vv dd.i dd.j)) (fun dd => 2^f dd.i.1) :=
    F0 (Can.first.then_do ((hg.reindex Sigma.fst).reindex During.i))
  have hPw : Knows m (fun dd : During (fun d : Q => f d.1) => B dd.i.1) IN
      (fun dd => (y dd.i, dd.j, vv dd.i dd.j)) (fun dd => 2^dd.j) := Can.second.snd.fst
  have hSw : Knows m (fun dd : During (fun d : Q => f d.1) => B dd.i.1) IN
      (fun dd => (y dd.i, dd.j, vv dd.i dd.j)) (fun dd => accXor (A dd.i) (C dd.i) dd.j) :=
    Can.second.snd.snd
  have sl : Small (fun dd : During (fun d : Q => f d.1) => B dd.i.1) (fun dd => ℓ dd.i) := hK.mono hlK
  have hAw := (hl.dvdW hpf sl).cong (fun _ => rfl) (fun dd => (hA dd.i).symm)
  have hCw := (hl.modW hpf sl).cong (fun _ => rfl) (fun dd => (hC dd.i).symm)
  have sA : Small (fun dd : During (fun d : Q => f d.1) => B dd.i.1) (fun dd => A dd.i) :=
    sl.mono fun dd => by show A dd.i ≤ ℓ dd.i; rw [hA]; exact Nat.div_le_self _ _
  have sC : Small (fun dd : During (fun d : Q => f d.1) => B dd.i.1) (fun dd => C dd.i) :=
    sl.mono fun dd => by show C dd.i ≤ ℓ dd.i; rw [hC]; exact Nat.mod_le _ _
  have hbit := ((hAw.dvdW hPw sA).plus (hCw.dvdW hPw sC) sA.div sC.div).modW (Can.wc 2)
    (sA.div.add sC.div)
  have sP : Small (fun dd : During (fun d : Q => f d.1) => B dd.i.1) (fun dd => 2^dd.j) :=
    hK.mono fun dd => Nat.le_trans (Nat.pow_le_pow_right (by omega) (Nat.le_succ _)) (hP dd)
  have sb : Small (fun dd : During (fun d : Q => f d.1) => B dd.i.1)
      (fun dd => (A dd.i / 2^dd.j + C dd.i / 2^dd.j) % 2) :=
    (Small.const _ 1).mono fun dd => by show (A dd.i / 2^dd.j + C dd.i / 2^dd.j) % 2 ≤ 1; omega
  have sS : Small (fun dd : During (fun d : Q => f d.1) => B dd.i.1)
      (fun dd => accXor (A dd.i) (C dd.i) dd.j) := sP.mono fun dd => (accXor_lt _ _ _).le
  have hstep : Has m (fun dd : During (fun d : Q => f d.1) => B dd.i.1) IN (p w w)
      (fun dd => (y dd.i, dd.j, vv dd.i dd.j)) (fun dd => vv dd.i (dd.j+1)) := by
    refine ((hPw.times (Can.wc 2) sP (Small.const _ 2)).pair
      (hSw.plus (hPw.times hbit sP sb) sS (sP.mul sb))).cong (fun _ => rfl) (fun dd => ?_)
    show (2^dd.j*2, accXor (A dd.i) (C dd.i) dd.j + 2^dd.j * ((A dd.i / 2^dd.j + C dd.i / 2^dd.j) % 2))
      = (2^(dd.j+1), accXor (A dd.i) (C dd.i) (dd.j+1))
    refine Prod.ext ?_ ?_
    · show 2^dd.j*2 = 2^(dd.j+1); rw [Nat.pow_succ]
    · show _ = accXor (A dd.i) (C dd.i) (dd.j+1)
      unfold accXor; rw [Finset.sum_range_succ]; ring
  have hn : Knows m BQ (p s w) y (fun d => f d.1) := Can.first.then_do (hf.reindex Sigma.fst)
  have hloop := Can.loop (v := vv) (uB := fun _ _ => 0) hn
    ((Can.wc (W := fun _ => 0) 1).pair (Can.wc 0)) hstep
    (hB.reindex Sigma.fst)
  have hent : Can m BQ (p s w) w y (fun d => (bits (f d.1)).loc (d.2.1 + d.2.2)) (fun d => f d.1) :=
    (hloop.snd.cong (fun _ => rfl) (fun d => (xor_value _ _ _).symm)).mono (fun d => by simp)
  have H := Can.layout (t := w) (L := fun i => xorOrd (f i)) (P := f)
    (v := fun i q => (bits (f i)).loc (q.1+q.2)) (hg.times hg hd hd) hent (hd.mul hd)
  refine H.mono fun i => ?_
  show 0 + 2^f i * 2^f i + 2^f i * 2^f i * f i ≤ (2^f i)^3
  have e1 : f i + 1 ≤ 2^f i := lt_two_pow' (f i)
  have := Nat.mul_le_mul (Nat.le_refl (2^f i * 2^f i)) e1
  rw [Nat.mul_add, Nat.mul_one] at this
  rw [Nat.pow_succ, Nat.pow_two]
  omega

end

variable {ι : Type U}

structure Gear (m : Bool) (B f : ι → ℕ) (s : Ty) (x : ι → T s) : Prop where
  power : Knows m B s x (fun i => 2^f i)
  given : Knows m B s x f
  table : Has m B s (a w) x (fun i => xorTab (f i))
  bound : Small B fun i => 2^f i

namespace Gear
variable {m : Bool} {B f : ι → ℕ} {s t : Ty} {x : ι → T s}
variable (g : Gear m B f s x)
include g

lemma descend {κ : Type V} (j : κ → ι) (y : κ → T t)
    (h : Has m (fun k => B (j k)) t s y (fun k => x (j k))) :
    Gear m (fun k => B (j k)) (fun k => f (j k)) t y :=
  ⟨h.then_do (g.power.reindex j), h.then_do (g.given.reindex j), h.then_do (g.table.reindex j),
    g.bound.reindex j⟩

variable {α : Type*} [Fintype α] [DecidableEq α]

omit [Fintype α] [DecidableEq α] in
lemma body_size (X : Layout α) : Knows m B s x (fun i => (bodyOrder X (f i)).n) :=
  Can.wpow_fixed X.n g.power g.bound

omit [Fintype α] [DecidableEq α] in
lemma grid_size (X : Layout α) (r : ℕ) :
    Knows m B s x (fun i => (book X r (f i)).n) :=
  ((g.body_size X).times (Can.wc (2^r)) (g.bound.pow X.n) (Small.const _ _)).cong (fun _ => rfl)
    (fun i => Nat.mul_comm _ _)

omit [Fintype α] [DecidableEq α] in
lemma grid_small (X : Layout α) (r : ℕ) :
    Small B fun i => (book X r (f i)).n :=
  ((g.bound.pow X.n).mul (Small.const B (2^r))).mono fun i => Nat.le_of_eq (Nat.mul_comm _ _)

omit [Fintype α] [DecidableEq α] in
lemma body_get (X : Layout α) (v : ∀ i, Sky α (f i)) (j : α)
    (h : Knows m B s x fun i => (bodyOrder X (f i)).loc (v i)) :
    Knows m B s x (fun i => (bits (f i)).loc (fun l => v i l j)) := by
  have hs : Small B fun i => (bodyOrder X (f i)).loc (v i) :=
    Small.loc (L := fun i => bodyOrder X (f i)) (x := v) (g.bound.pow X.n)
  exact ((h.dvdW (Can.wpow_fixed (X.loc j) g.power g.bound) hs).modW g.power hs.div).cong
    (fun _ => rfl) (fun i => Layout.digits_entry X (bits (f i)) ((rows α (f i)) (v i)) j)

omit [DecidableEq α] in
lemma body_set (X : Layout α) (v : ∀ i, Sky α (f i))
    (h : ∀ j : α, Knows m B s x fun i => (bits (f i)).loc (fun l => v i l j)) :
    Knows m B s x (fun i => (bodyOrder X (f i)).loc (v i)) := by
  have sj : ∀ j : α, Small B fun i => (bits (f i)).loc (fun l => v i l j) * (2^f i)^(X.loc j) :=
    fun j => (Small.loc (L := fun i => bits (f i)) (x := fun i l => v i l j) g.bound).mul
      (g.bound.pow _)
  have hj : ∀ j : α, Knows m B s x fun i => (bits (f i)).loc (fun l => v i l j) * (2^f i)^(X.loc j) :=
    fun j => (h j).times (Can.wpow_fixed (X.loc j) g.power g.bound)
      (Small.loc (L := fun i => bits (f i)) (x := fun i l => v i l j) g.bound) (g.bound.pow _)
  exact (Can.sum_wconst hj sj).cong (fun _ => rfl)
    (fun i => (Layout.digits_code X (bits (f i)) ((rows α (f i)) (v i))).symm)

variable (X : Layout α) (r : ℕ)

omit [Fintype α] [DecidableEq α] in
lemma grid_fetch {v : ∀ i, Grid α r (f i)}
    (h : Knows m B s x fun i => (book X r (f i)).loc (v i)) :
    Knows m B s x (fun i => (bits r).loc (v i).1) ∧
    Knows m B s x (fun i => (bodyOrder X (f i)).loc (v i).2) :=
  ⟨Can.addr_high (L := fun _ => bits r) (R := fun i => bodyOrder X (f i)) (u := v) h
      (g.body_size X) (g.grid_small X r),
    Can.addr_low (L := fun _ => bits r) (R := fun i => bodyOrder X (f i)) (u := v) h
      (g.body_size X) (g.grid_small X r)⟩

omit [Fintype α] [DecidableEq α] in
lemma grid_combine {v : ∀ i, Grid α r (f i)}
    (a : Knows m B s x (fun i => (bits r).loc (v i).1))
    (b : Knows m B s x (fun i => (bodyOrder X (f i)).loc (v i).2)) :
    Knows m B s x (fun i => (book X r (f i)).loc (v i)) :=
  Can.addr_join (L := fun _ => bits r) (R := fun i => bodyOrder X (f i)) (u := v) a b
    (g.body_size X) (Small.const B (2^r)) (g.bound.pow X.n)

omit [Fintype α] [DecidableEq α] in
lemma addr_xor (v : ∀ i, Bits (f i) × Bits (f i))
    (h : Knows m B s x (fun i => (bits (f i)).loc (v i).1))
    (k : Knows m B s x (fun i => (bits (f i)).loc (v i).2)) :
    Knows m B s x (fun i => (bits (f i)).loc ((v i).1+(v i).2)) :=
  Can.fetch (t := w) (L := fun i => xorOrd (f i)) (v := fun i q => (bits (f i)).loc (q.1+q.2)) (i := v)
    (show Has m B s (a w) x fun i => (xorOrd (f i)).tape (fun q => (bits (f i)).loc (q.1+q.2))
      from g.table) (Can.addr_join (L := fun i => bits (f i)) (R := fun i => bits (f i)) (u := v) h k
      g.power g.bound g.bound)

omit [DecidableEq α] in
lemma shifted (z : Space α) (v : ∀ i, Grid α r (f i))
    (h : Knows m B s x (fun i => (book X r (f i)).loc (v i))) :
    Knows m B s x (fun i => (book X r (f i)).loc ((v i).1,
      fun j => (v i).2 j + z)) := by
  obtain ⟨h1, h2⟩ := g.grid_fetch X r h
  refine g.grid_combine X r (v := fun i => ((v i).1, fun j => (v i).2 j + z)) h1
    (g.body_set X _ fun a => ?_)
  have hr := g.body_get X (fun i => (v i).2) a h2
  have hc : Knows m B s x fun i => (bits (f i)).loc (fun _ => z a) := by
    rcases bit_cases (z a) with e | e
    · exact (Can.wc 0).cong (fun _ => rfl) (fun i => by
        show 0 = (bits (f i)).loc (fun _ => z a)
        rw [e, bits_loc]; simp)
    · exact (g.power.minus (Can.wc 1) g.bound).cong (fun _ => rfl) (fun i => by
        show 2^f i - 1 = (bits (f i)).loc (fun _ => z a)
        rw [e]; have := bits_lit (f i); omega)
  exact g.addr_xor (fun i => ((fun l => (v i).2 l a), fun _ => z a)) hr hc

end Gear

abbrev Beach (α ρ : Type*) (r f : ℕ) := ρ × Grid α r f
abbrev Grain (α ρ : Type*) (r f : ℕ) := Beach α ρ r f → ℂ

def fleet {α ρ : Type*} (X : Layout α) (R : Layout ρ) (r f : ℕ) :=
  R.pair (book X r f)

section
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

def ferry (r f : ℕ) (u : Move α ρ) (v : Grain α ρ r f) : Grain α ρ r f :=
  fun x => u.go f (fun i j => v (i,x.2.1,j)) x.1 x.2.2

end

structure Rig {α ρ : Type*} (m : Bool) (B f : ι → ℕ) (s : Ty) (x : ι → T s)
    (cl : Paint) (X : Layout α) (R : Layout ρ) (r : ℕ) (v : ∀ i, Grain α ρ r (f i)) : Prop where
  gear : Gear m B f s x
  imag : Has m B s sc x fun _ => Complex.I
  items : Has m B s (a (c cl)) x fun i => (fleet X R r (f i)).tape (v i)

namespace Rig
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
variable {m : Bool} {B f : ι → ℕ} {s t : Ty} {x : ι → T s}
    {cl : Paint} {X : Layout α} {R : Layout ρ} {r : ℕ} {v : ∀ i, Grain α ρ r (f i)}
variable (h : Rig m B f s x cl X R r v)
include h

omit [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ] in
lemma gather {κ : Type V} (j : κ → ι) (y : κ → T t)
    (g : Has m (fun k => B (j k)) t s y (fun k => x (j k))) :
    Rig m (fun k => B (j k)) (fun k => f (j k)) t y cl X R r (fun k => v (j k)) :=
  ⟨h.gear.descend j y g, g.then_do (h.imag.reindex j), g.then_do (h.items.reindex j)⟩

omit [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ] in
lemma large : Small B fun i => (fleet X R r (f i)).n :=
  (Small.const B R.n).mul (h.gear.grid_small X r)

omit [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ] in
lemma size : Knows m B s x fun i => (fleet X R r (f i)).n :=
  (Can.wc R.n).times (h.gear.grid_size X r) (Small.const _ _) (h.gear.grid_small X r)

omit [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ] in
lemma addrs (u : ∀ i, Beach α ρ r (f i))
    (hg : Knows m B s x fun i => (fleet X R r (f i)).loc (u i)) :
    Knows m B s x (fun i => R.loc (u i).1) ∧
      Knows m B s x (fun i => (book X r (f i)).loc (u i).2) :=
  ⟨Can.addr_high (L := fun _ => R) (R := fun i => book X r (f i)) (u := u) hg
      (h.gear.grid_size X r) h.large,
    Can.addr_low (L := fun _ => R) (R := fun i => book X r (f i)) (u := u) hg
      (h.gear.grid_size X r) h.large⟩

omit [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ] in
lemma read (u : ∀ i, Beach α ρ r (f i)) (ha : Knows m B s x fun i => R.loc (u i).1)
    (hb : Knows m B s x fun i => (book X r (f i)).loc (u i).2) :
    Has m B s (c cl) x (fun i => v i (u i)) :=
  Can.fetch (t := c cl) (L := fun i => fleet X R r (f i)) (v := v) (i := u) h.items
    (Can.addr_join (L := fun _ => R) (R := fun i => book X r (f i)) (u := u) ha hb
      (h.gear.grid_size X r) (Small.const _ _) (h.gear.grid_small X r))

omit [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ] in
lemma chart (v : ∀ i, Grain α ρ r (f i))
    (g : Has m (fun i : Σ i, Beach α ρ r (f i) => B i.1) (p s w) (c cl)
      (fun d => (x d.1,(fleet X R r (f d.1)).loc d.2)) (fun d => v d.1 d.2)) :
    Can m B s (a (c cl)) x (fun i => (fleet X R r (f i)).tape (v i))
      (fun i => (fleet X R r (f i)).n) :=
  (Can.layout (t := c cl) (L := fun i => fleet X R r (f i)) (P := fun _ => 0) (v := v) h.size g h.large).mono
    (W' := fun i => (fleet X R r (f i)).n)
    (fun i => by simp)

lemma ferry_point (M : Matrix ρ ρ ℚ) (q : ∀ i, Beach α ρ r (f i))
    (g : Knows m B s x fun i => (fleet X R r (f i)).loc (q i)) :
    Has m B s (c cl) x fun i => ferry r (f i) (.localM M) (v i) (q i) := by
  obtain ⟨ha, hb⟩ := h.addrs q g
  refine Can.cases_code R ha (fun e => ?_)
  have h' := h.gather (fun i : {i // (q i).1 = e} => i.1) (fun i => x i.1) Can.id
  refine (Can.sum_cconst (fun j : ρ => (Can.rat (M e j)).mul
    (h'.read (fun i => (j, (q i.1).2)) (Can.wc (R.loc j)) (hb.reindex _)))).cong
    (fun _ => rfl) (fun i => ?_)
  -- CHECK: unfolding `ferry`/`Move.go`/`point`/`actPoint` to the role sum
  simp only [ferry, Move.go, point, actPoint]
  rw [i.2]

lemma ferry_shift (l : ρ) (z : Space α) (q : ∀ i, Beach α ρ r (f i))
    (g : Knows m B s x fun i => (fleet X R r (f i)).loc (q i)) :
    Has m B s (c cl) x fun i => ferry r (f i) (.shift l z) (v i) (q i) := by
  obtain ⟨ha, hb⟩ := h.addrs q g
  refine Can.cases_code R ha (fun e => ?_)
  have h' := h.gather (fun i : {i // (q i).1 = e} => i.1) (fun i => x i.1) Can.id
  have hb' := hb.reindex (fun i : {i // (q i).1 = e} => i.1)
  by_cases he : e = l
  · refine (h'.read (fun i => (e, (q i.1).2.1, fun j => (q i.1).2.2 j + z)) (Can.wc (R.loc e))
      (h'.gear.shifted X r z (fun i => (q i.1).2) hb')).cong (fun _ => rfl) (fun i => ?_)
    simp only [ferry, Move.go, roleAct, i.2, he, eq_self_iff_true, if_true, matAct_shift]
    try rfl
  · refine (h'.read (fun i => (e, (q i.1).2)) (Can.wc (R.loc e)) hb').cong (fun _ => rfl)
      (fun i => ?_)
    simp only [ferry, Move.go, roleAct, i.2, if_neg he]
    try rfl

lemma point_cost (M : Matrix ρ ρ ℚ) :
    Can m B s (a (c cl)) x
      (fun i => (fleet X R r (f i)).tape (ferry r (f i) (.localM M) (v i)))
      (fun i => (fleet X R r (f i)).n) :=
  h.chart _ ((h.gather (t := p s w) Sigma.fst (fun d : Σ i, Beach α ρ r (f i) => (x d.1,(fleet X R r (f d.1)).loc d.2))
    Can.first).ferry_point M (fun d => d.2) Can.second)

lemma shift_cost (l : ρ) (z : Space α) :
    Can m B s (a (c cl)) x
      (fun i => (fleet X R r (f i)).tape (ferry r (f i) (.shift l z) (v i)))
      (fun i => (fleet X R r (f i)).n) :=
  h.chart _ ((h.gather (t := p s w) Sigma.fst (fun d : Σ i, Beach α ρ r (f i) => (x d.1,(fleet X R r (f d.1)).loc d.2))
    Can.first).ferry_shift l z (fun d => d.2) Can.second)

omit [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ] in
lemma little (i j : F) :
    Has m B s sc x fun _ => littleC i j := by
  have hh : Has m B s sc x fun _ => ((1/2 : ℚ) : ℂ) := Can.rat _
  by_cases e : i = j
  · refine (hh.mul (Can.one.add h.imag)).cong (fun _ => rfl) (fun _ => ?_)
    try dsimp only
    rw [show littleC i j = ca from if_pos e, ca]; push_cast; ring
  · refine (hh.mul (Can.one.sub h.imag)).cong (fun _ => rfl) (fun _ => ?_)
    try dsimp only
    rw [show littleC i j = cb from if_neg e, cb]; push_cast; ring

end Rig

abbrev Sim (ρ : Type*) (k : ℕ) := ρ × Bits k
def sim {ρ : Type*} (R : Layout ρ) (k : ℕ) := R.pair (bits k)

abbrev bundle := fun cl => a (c cl)
abbrev simIn := fun cl => p w (p sc (bundle cl))
abbrev hatch := fun cl => some (simIn cl,bundle cl)

def whole {ρ : Type*} (k : ℕ) (v : Sim ρ k → ℂ) : Sim ρ k → ℂ :=
  fun (l,i) => ripple k (fun j => v (l,j)) i

def loaded {ρ : Type*} (cl : Paint) (R : Layout ρ) (k : ℕ) (v : Sim ρ k → ℂ) :
    T (simIn cl) :=
  (k,Complex.I,(sim R k).tape v)

def cut {β ρ} (r f t : ℕ) (X : Layout β) (R : Layout ρ)
    (h : t*R.n = (book X r f).n) :
    (Fin t × ρ) ≃ Grid β r f :=
  let L := (Layout.std t).pair R
  (L.index.trans (finCongr h)).trans (book X r f).index.symm

section
variable {m : Bool}
variable {r : Port} {b : Bank r ι} {s t : Ty} {x : ι → T s} {y : ι → T t} {n W Z : ι → ℕ}

lemma Able.branch (h : Can m b.B s w x n W) (P : ι → Prop) (hp : ∀ i, n i=0 ↔ P i)
    (g : Able m (b.comap (fun i : {i // P i} => i.1)) s t
      (fun i => x i.1) (fun i => y i.1) (fun i => W i.1) (fun i => Z i.1))
    (k : Able m (b.comap (fun i : {i // ¬P i} => i.1)) s t
      (fun i => x i.1) (fun i => y i.1) (fun i => W i.1) (fun i => Z i.1)) :
    Able m b s t x y W Z :=
  (Able.ifz (W := W) (Z := Z) (Able.of_can h)
    (g.reindex (fun i : {i // n i = 0} => (⟨i.1, (hp i.1).1 i.2⟩ : {i // P i})))
    (k.reindex (fun i : {i // n i ≠ 0} => (⟨i.1, fun hP => i.2 ((hp i.1).2 hP)⟩ : {i // ¬P i})))).weaken
    (Dom.add (Dom.self W) (Dom.self W)) (fun _ => by simp)

end

def threshold (u a : ℕ) := u*(a+1)
def batches (u a k : ℕ) := 2^(k-k/u-a)

def allot (u a D : ℕ) (k : ℕ) : ℕ :=
  if h : k/u<k ∧ threshold u a ≤ k then
    2^k + D*batches u a k*allot u a D (k/u)
  else 2^k
termination_by k

section Direct
open Complex

def partK (k b : ℕ) : CMat (Fin k) :=
  wrap fun x => ∏ l : Fin k, if l.val < b then tint (x l) else 1

theorem partK_zero (k : ℕ) : partK k 0 = 1 := by
  simp [partK, wrap_one]

theorem partK_full (k : ℕ) : partK k k = kernel (Fin k) := by
  simp only [partK, Fin.is_lt, if_true]; exact wrap_lum

theorem partK_succ (k b : ℕ) (hb : b < k) :
    dir (eu (⟨b, hb⟩ : Fin k)) * partK k b = partK k (b+1) := by
  rw [dir_phase, partK, partK, wrap_mul]
  congr 1; funext x
  rw [dot_eu_left]
  have e : ∀ l : Fin k, (if l.val < b+1 then tint (x l) else 1) =
      (if l = ⟨b, hb⟩ then tint (x l) else 1) * (if l.val < b then tint (x l) else 1) := by
    intro l
    by_cases h1 : l = ⟨b, hb⟩
    · subst h1; simp
    · have : l.val ≠ b := fun h' => h1 (Fin.ext h')
      by_cases h2 : l.val < b
      · simp [h1, h2, show l.val < b+1 by omega]
      · simp [h1, h2, show ¬ l.val < b+1 by omega]
  rw [Finset.prod_congr rfl (fun l _ => e l), Finset.prod_mul_distrib, Finset.prod_ite_eq']
  simp

theorem dirK_apply {α : Type*} [Fintype α] [DecidableEq α] (z : Space α) (u : Space α → ℂ)
    (y : Space α) : (dir z *ᵥ u) y = ca * u y + cb * u (y + z) := by
  have e : ∀ x, dir z y x * u x =
      ca * ((if y = x then 1 else 0) * u x) + cb * ((if y + z = x then 1 else 0) * u x) := by
    intro x
    simp only [dir, Matrix.add_apply, Matrix.smul_apply, smul_eq_mul, Matrix.one_apply, shift]
    ring
  simp only [Matrix.mulVec, dotProduct, e, Finset.sum_add_distrib, ← Finset.mul_sum, ite_mul,
    one_mul, zero_mul, Finset.sum_ite_eq, Finset.mem_univ, ite_true]

theorem flip_loc (k b : ℕ) (hb : b < k) (y : Bits k) :
    (bits k).loc (y + eu (⟨b, hb⟩ : Fin k)) =
      (bits k).loc y + 2^b - 2 * ((bits k).loc y / 2^b % 2) * 2^b := by
  have hd := bits_div k y ⟨b, hb⟩
  have key : (bits k).loc (y + eu (⟨b, hb⟩ : Fin k)) + 2 * (y ⟨b, hb⟩).val * 2^b =
      (bits k).loc y + 2^b := by
    rw [bits_loc, bits_loc, ← Finset.add_sum_erase _ _ (Finset.mem_univ (⟨b, hb⟩ : Fin k)),
      ← Finset.add_sum_erase _ _ (Finset.mem_univ (⟨b, hb⟩ : Fin k)),
      Finset.sum_congr rfl (fun l hl => show ((y + eu (⟨b, hb⟩ : Fin k)) l).val * 2^l.val =
        (y l).val * 2^l.val by
          simp [eu, Ne.symm (Finset.ne_of_mem_erase hl)])]
    simp only [Pi.add_apply, eu, eq_self_iff_true, if_true, Fin.val_mk]
    rcases bit_cases (y ⟨b, hb⟩) with e | e <;> rw [e]
    · simp only [zero_add, show (1 : F).val = 1 from rfl, show (0 : F).val = 0 from rfl]; omega
    · simp only [cancel, show (1 : F).val = 1 from rfl, show (0 : F).val = 0 from rfl]; omega
  have hv : (y ⟨b, hb⟩).val ≤ 1 := by have := (show Fin 2 from y ⟨b, hb⟩).isLt; omega
  simp only [Fin.val_mk] at hd
  rw [hd]; omega

variable {ι : Type U}

theorem naive_kernel_direct (cl : Paint) (m : Bool) (k : ι→ℕ)
    (v : ∀ i, Bits (k i) → ℂ) :
    Can m (fun i => 2^k i) (simIn cl) (bundle cl)
      (fun i => ((k i, Complex.I, (bits (k i)).tape (v i)) : T (simIn cl)))
      (fun i => (bits (k i)).tape (ripple (k i) (v i)))
      (fun i => 2^k i * (2 * k i + 1)) := by
  let B : ι → ℕ := fun i => 2^k i
  let x : ι → T (simIn cl) := fun i => (k i, Complex.I, (bits (k i)).tape (v i))
  let U (i : ι) (b : ℕ) : Bits (k i) → ℂ := partK (k i) b *ᵥ v i
  let st (i : ι) (b : ℕ) : T (p w (bundle cl)) := (2^b, (bits (k i)).tape (U i b))
  let D := During k
  let IN := p (simIn cl) (p w (p w (bundle cl)))
  let xin (d : D) : T IN := (x d.i, d.j, st d.i d.j)
  let BD (d : D) := B d.i
  -- one pass, at every position `e` of the tape
  let E := During (fun d : D => 2^k d.i)
  let JN := p IN w
  let ex (e : E) : T JN := (xin e.i, e.j)
  let BE (e : E) := B e.i.i
  have sBE : Small BE (fun e => 2^k e.i.i * 2) := ((Small.self B).reindex _).mul (Small.const _ 2)
  have hj : Knows m BE JN ex (fun e => e.j) := Can.second
  have hP : Knows m BE JN ex (fun e => 2^e.i.j) := Can.first.snd.snd.fst
  have hT : Has m BE JN (bundle cl) ex (fun e => (bits (k e.i.i)).tape (U e.i.i e.i.j)) :=
    Can.first.snd.snd.snd
  have hPle (e : E) : 2^e.i.j ≤ 2^k e.i.i := Nat.pow_le_pow_right (by omega) (Nat.le_of_lt e.i.hj)
  have hjle (e : E) : e.j < 2^k e.i.i := e.hj
  have sj : Small BE (fun e => e.j) :=
    sBE.mono fun e => by show e.j ≤ 2^k e.i.i * 2; have := hjle e; omega
  have sP : Small BE (fun e => 2^e.i.j) :=
    sBE.mono fun e => by show 2^e.i.j ≤ 2^k e.i.i * 2; have := hPle e; omega
  have hbit := (hj.dvdW hP sj).modW (Can.wc 2) sj.div
  have sbit : Small BE (fun e => e.j / 2^e.i.j % 2) :=
    (Small.const _ 1).mono fun e => by show e.j / 2^e.i.j % 2 ≤ 1; omega
  have hpart : Knows m BE JN ex (fun e => e.j + 2^e.i.j - 2 * (e.j / 2^e.i.j % 2) * 2^e.i.j) :=
    (hj.plus hP sj sP).minus (((Can.wc 2).times hbit (Small.const _ 2) sbit).times hP
      ((Small.const _ 2).mul sbit) sP) (sj.add sP)
  have hca : Has m BE JN sc ex (fun _ => ca) :=
    ((Can.rat (1/2 : ℚ)).mul (Can.one.add (Can.first.fst.snd.fst))).cong (fun _ => rfl)
      (fun _ => by (try dsimp only); rw [ca]; push_cast; ring)
  have hcb : Has m BE JN sc ex (fun _ => cb) :=
    ((Can.rat (1/2 : ℚ)).mul (Can.one.sub (Can.first.fst.snd.fst))).cong (fun _ => rfl)
      (fun _ => by (try dsimp only); rw [cb]; push_cast; ring)
  let g' (d : D) (j : ℕ) : ℂ := ca * ((bits (k d.i)).tape (U d.i d.j)).look j (c cl).blank +
    cb * ((bits (k d.i)).tape (U d.i d.j)).look
      (j + 2^d.j - 2 * (j / 2^d.j % 2) * 2^d.j) (c cl).blank
  have hent : Has m BE JN (c cl) ex (fun e => g' e.i e.j) :=
    (hca.mul (hT.look hj)).add (hcb.mul (hT.look hpart))
  have hlen : Knows m BD IN xin (fun d => 2^k d.i) :=
    Can.first.snd.snd.len ((Small.self B).reindex During.i)
  have htab := Can.tab (t := c cl) (uB := fun _ _ => 0) (v := g') hlen hent ((Small.self B).reindex During.i)
  have hnext (d : D) : Tape.tab (2^k d.i) (g' d) = (bits (k d.i)).tape (U d.i (d.j+1)) := by
    refine Layout.verify (bits (k d.i)) _ (c cl).blank _ rfl (fun y => ?_)
    have hy : (bits (k d.i)).loc y < 2^k d.i := (bits (k d.i)).bd y
    rw [Tape.look_tab, if_pos hy]
    show ca * _ + cb * _ = _
    rw [← flip_loc (k d.i) d.j d.hj y, Layout.read, Layout.read]
    show _ = (partK (k d.i) (d.j+1) *ᵥ v d.i) y
    rw [← partK_succ (k d.i) d.j d.hj, ← Matrix.mulVec_mulVec, dirK_apply]
  have hP0 : Knows m BD IN xin (fun d => 2^d.j) := Can.second.snd.fst
  have sP0 : Small BD (fun d => 2^d.j) :=
    ((Small.self B).reindex During.i).mono fun d => Nat.pow_le_pow_right (by omega) d.hj.le
  have hstep : Can m BD IN (p w (bundle cl)) xin (fun d => st d.i (d.j+1)) (fun d => 2^k d.i) := by
    refine (((hP0.times (Can.wc 2) sP0 (Small.const _ 2)).mono (W' := fun d => 2^k d.i)
      (fun _ => Nat.zero_le _)).pair
      (htab.mono (W' := fun d => 2^k d.i) (fun d => by simp))).cong (fun _ => rfl) (fun d => ?_)
    show (2^d.j * 2, Tape.tab (2^k d.i) (g' d)) = (2^(d.j+1), (bits (k d.i)).tape (U d.i (d.j+1)))
    rw [hnext, Nat.pow_succ]
  have hk0 : Knows m B (simIn cl) x k := Can.first
  have hinit : Has m B (simIn cl) (p w (bundle cl)) x (fun i => st i 0) :=
    ((Can.wc 1).pair Can.second.snd).cong (fun _ => rfl) (fun i => by
      show (1, (bits (k i)).tape (v i)) = (2^0, (bits (k i)).tape (partK (k i) 0 *ᵥ v i))
      rw [partK_zero, Matrix.one_mulVec, Nat.pow_zero])
  have hloop := Can.loop (v := st) (uB := fun i _ => 2^k i) hk0 hinit hstep
    ((Small.self B).mono fun i => (lt_two_pow' (k i)).le)
  refine (hloop.snd.cong (fun _ => rfl) (fun i => ?_)).mono (fun i => ?_)
  · show (bits (k i)).tape (partK (k i) (k i) *ᵥ v i) = (bits (k i)).tape (ripple (k i) (v i))
    rw [partK_full]; try rfl
  · show 0 + 0 + k i + ∑ j ∈ range (k i), 2^k i ≤ 2^k i * (2 * k i + 1)
    rw [sum_const', Nat.mul_add, Nat.mul_one]
    have := (lt_two_pow' (k i)).le
    have e : 2^k i * (2 * k i) = k i * 2^k i + k i * 2^k i := by ring
    omega

end Direct

end
end PowerSaving.RAM

end OAI
