import Submission.Work.XHostD.FramesK
import Submission.Work.Mixed.HeadM1


namespace OAI
namespace PowerSaving
namespace FH
open Binary Matrix Finset GF CB B401 XHost

noncomputable section

section Target
variable {α : Type} [Fintype α] [DecidableEq α]

def targ (D : Finset α) : Fin D.card → Space α := (OBase.canonical α).fam D

lemma targ_indep (D : Finset α) : LinearIndependent F (targ D) := OBase.fam_indep _ D

lemma pk_eq_targ (D : Finset α) : pk D = blockMat (targ D) := pk_eq_blockMat D


end Target

end
end FH
end PowerSaving
end OAI
