import Submission.Work.GCert.Chain.Win


namespace OAI
namespace PowerSaving.GF
def SLbl.top {H : Type} [Fintype H] (U : SLbl H) : SLbl H := ⟨U.G, Finset.univ⟩
lemma SLbl.top_dim {H : Type} [Fintype H] (U : SLbl H) : U.top.dim = Fintype.card H := Finset.card_univ
end PowerSaving.GF
end OAI
