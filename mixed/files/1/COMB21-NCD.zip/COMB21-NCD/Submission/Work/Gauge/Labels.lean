import Submission.Work.GCert.Labels.RouteRun
import Submission.Work.GCert.Labels.EndSound
import Submission.Work.Gauge.Defs


namespace GLab
open SSC GXD OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.GF OAI.PowerSaving.RAM
  OAI.PowerSaving.CB Finset Matrix

theorem memK_sound (r : Nat) : ∀ gl : List Nat, memK r gl = true → r ∈ gl := by
  intro gl
  induction gl with
  | nil => intro h; exact absurd h Bool.false_ne_true
  | cons x gl ih =>
    intro h
    have h' : Bool.rec (motive := fun _ => Bool) (memK r gl) true (Nat.beq x r) = true := h
    cases e : Nat.beq x r with
    | true => rw [← beq_true e]; exact List.mem_cons_self
    | false => rw [e] at h'; exact List.mem_cons_of_mem _ (ih h')

end GLab

