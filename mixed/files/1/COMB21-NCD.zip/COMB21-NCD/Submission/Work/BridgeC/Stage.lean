import Submission.Work.BridgeC.Blocks
import Submission.Work.GFrame.Top.Api


namespace OAI
namespace PowerSaving
namespace BC
open Binary Matrix Finset RAM SS CB RF
noncomputable section

section Q
variable {B H : Type} [Fintype B] [DecidableEq B] [Fintype H] [DecidableEq H] {l : H}

instance instFintypeOrthLC : Fintype (Orth (LC B H l)) := inferInstance

instance instDecEqOrthLC : DecidableEq (Orth (LC B H l)) := inferInstance

lemma card_lt_LC (hB : 1 ≤ Fintype.card B) (hH : 2 ≤ Fintype.card H) (s : Finset H) :
    s.card < Fintype.card (LC B H l) := by
  have h1 : 1 * 1 ≤ Fintype.card B * (Fintype.card H - 1) := Nat.mul_le_mul hB (by omega)
  have h2 := Finset.card_le_univ s
  rw [card_LC]
  omega

def qC (bs : Finset B) : Finset (B × Hp H l) := bs ×ˢ univ

lemma mem_qC (bs : Finset B) (b : B) (j : Hp H l) : (b, j) ∈ qC bs ↔ b ∈ bs := by
  unfold qC
  rw [Finset.mem_product]
  exact ⟨fun h => h.1, fun h => ⟨h, Finset.mem_univ j⟩⟩

lemma qC_empty : qC (l := l) (∅ : Finset B) = ∅ := by
  unfold qC
  exact Finset.empty_product _

lemma card_qC (bs : Finset B) : (qC (l := l) bs).card = bs.card * (Fintype.card H - 1) := by
  unfold qC
  rw [Finset.card_product, Finset.card_univ, card_Hp]

lemma blockOf_qC (bs : Finset B) (c : B) (hc : c ∈ bs) : BlockOfC (l := l) c (qC bs) :=
  fun j => (mem_qC bs c j).mpr hc

lemma rest_qC (bs : Finset B) (c : B) (hc : c ∉ bs) :
    RestC (l := l) c (qC (insert c bs)) (qC bs) := by
  intro b j
  rw [mem_qC, mem_qC, Finset.mem_insert]
  constructor
  · intro hb
    exact ⟨fun e => hc (by rw [← e]; exact hb), Or.inr hb⟩
  · rintro ⟨hne, hb⟩
    rcases hb with hb | hb
    · exact absurd hb hne
    · exact hb

def fmapC (hB : 1 ≤ Fintype.card B) (hH : 2 ≤ Fintype.card H) (d : Orth (LC B H l))
    (q : Finset (B × Hp H l)) : XMap H (LC B H l) where
  Φ := PhiC d q

end Q

section Banks
variable {B H : Type} [Fintype B] [DecidableEq B] [Fintype H] [DecidableEq H]
variable (base : OBase H) (l : H)

def RrC (c : B) : Orth (LC B H l) ≃ Orth (LC B H l) :=
  Orth.conjPerm (blkC B l base) (blkC_orth base) (piC l c)

def BBC (g : Orth (LC B H l)) : OBase (LC B H l) :=
  ofCols (g.1 * blkC B l base) (mul_orth g.2 (blkC_orth base))

lemma PhiC_BBC (g : Orth (LC B H l)) (q : Finset (B × Hp H l)) (s : Finset H) :
    PhiC g q (base.mat s) = frame (BBC base l g) (JC s q) := PhiC_eq g q base s

lemma PhiC_step (c : B) (g : Orth (LC B H l)) (s s' : Finset H) (q q' : Finset (B × Hp H l))
    (hmap : (JC s q).map (piC l c).toEmbedding = JC s' q') :
    PhiC (RrC base l c g) q (base.mat s) = PhiC g q' (base.mat s') :=
  PhiC_perm (RrC base l c g) g base (piC l c)
    (Orth.conjPerm_mul (blkC B l base) (blkC_orth base) (piC l c) g) s s' q q' hmap

lemma bank_inX (bs : Finset B) (c : B) (hc : c ∉ bs) (g : Orth (LC B H l)) :
    PhiC (RrC base l c g) (qC (insert c bs)) (base.mat {l})
      = frame (BBC base l g) (JC univ (qC bs)) :=
  (PhiC_step base l c g {l} univ (qC (insert c bs)) (qC bs)
    (map_piC_single l c (qC (insert c bs)) (qC bs)
      (blockOf_qC (insert c bs) c (Finset.mem_insert_self c bs)) (rest_qC bs c hc))).trans
  (PhiC_BBC base l g (qC bs) univ)

lemma bank_inY (bs : Finset B) (c : B) (hc : c ∉ bs) (g : Orth (LC B H l)) :
    PhiC (RrC base l c g) (qC (insert c bs)) (base.mat ∅)
      = frame (BBC base l g) (JC (univ \ {l}) (qC bs)) :=
  (PhiC_step base l c g ∅ (univ \ {l}) (qC (insert c bs)) (qC bs)
    (map_piC_empty l c (qC (insert c bs)) (qC bs)
      (blockOf_qC (insert c bs) c (Finset.mem_insert_self c bs)) (rest_qC bs c hc))).trans
  (PhiC_BBC base l g (qC bs) (univ \ {l}))

lemma bank_outX (bs : Finset B) (c : B) (hc : c ∈ bs) (g : Orth (LC B H l)) :
    PhiC (RrC base l c g) (qC bs) (base.mat univ) = frame (BBC base l g) (JC univ (qC bs)) :=
  (PhiC_step base l c g univ univ (qC bs) (qC bs)
    (map_piC_univ l c (qC bs) (blockOf_qC bs c hc))).trans (PhiC_BBC base l g (qC bs) univ)

lemma bank_outY (bs : Finset B) (c : B) (hc : c ∈ bs) (g : Orth (LC B H l)) :
    PhiC (RrC base l c g) (qC bs) (base.mat (univ \ {l}))
      = frame (BBC base l g) (JC (univ \ {l}) (qC bs)) :=
  (PhiC_step base l c g (univ \ {l}) (univ \ {l}) (qC bs) (qC bs)
    (map_piC_compl l c (qC bs) (blockOf_qC bs c hc))).trans
  (PhiC_BBC base l g (qC bs) (univ \ {l}))

end Banks

section Reach
variable {n : Type} [Fintype n] [DecidableEq n]

lemma reach_of_pos (hm : 2 ≤ Fintype.card n) (A : OBase n) {s t : Finset n} (h : s ⊆ t)
    (k : ℕ) (hk : k + s.card = t.card) (hs : 1 ≤ s.card) :
    GF.GReach (frame A s) (frame A t) (fun φ => bcost φ k) := by
  refine (GF.GReach.of_subset hm A h).cast (fun φ => ?_)
  have h1 := Finset.card_sdiff_add_card_eq_card h
  have h2 := Finset.card_le_univ t
  have e : (t \ s).card = k := by omega
  rw [e]
  exact split_bcost φ (by omega)

end Reach

section Climbs
variable {B H : Type} [Fintype B] [DecidableEq B] [Fintype H] [DecidableEq H]

lemma card_JC {l : H} (s : Finset H) (q : Finset (B × Hp H l)) : (JC s q).card = s.card + q.card :=
  Finset.card_disjSum s q

lemma card_compl_single (l : H) : ((univ : Finset H) \ {l}).card = Fintype.card H - 1 := by
  rw [Finset.card_sdiff_of_subset (Finset.subset_univ _), Finset.card_univ, Finset.card_singleton]

variable (hB : 1 ≤ Fintype.card B) (hH : 2 ≤ Fintype.card H) (l : H) (A : OBase (LC B H l))
include hB hH

end Climbs


section ClassT
variable {B H : Type} [Fintype B] [DecidableEq B] [Fintype H] [DecidableEq H]
variable (base : OBase H) (l : H)

lemma classT_X0 (g : Orth (LC B H l)) :
    PhiC g ∅ (tt (base.v l)) = frame (BBC base l g) (JC {l} ∅) := by
  have e := PhiC_BBC base l g ∅ {l}
  rw [mat_single] at e
  exact e

lemma classT_Y0 (g : Orth (LC B H l)) : PhiC g ∅ 0 = frame (BBC base l g) (JC ∅ ∅) := by
  have e := PhiC_BBC base l g ∅ ∅
  rw [mat_empty] at e
  exact e

lemma classT_X (bs : Finset B) (c : B) (hc : c ∈ bs) (g : Orth (LC B H l)) :
    PhiC (RrC base l c g) (qC bs) 1 = frame (BBC base l g) (JC univ (qC bs)) := by
  have e := bank_outX base l bs c hc g
  rw [OBase.mat_univ] at e
  exact e

lemma classT_Y (bs : Finset B) (c : B) (hc : c ∈ bs) (g : Orth (LC B H l)) :
    PhiC (RrC base l c g) (qC bs) (1 + tt (base.v l))
      = frame (BBC base l g) (JC (univ \ {l}) (qC bs)) := by
  have e := bank_outY base l bs c hc g
  rw [mat_compl_single] at e
  exact e

variable (hB : 1 ≤ Fintype.card B) (hH : 2 ≤ Fintype.card H)
include hB hH

end ClassT
end
end BC
end PowerSaving
end OAI
