import Submission.Work.SharedSumChecker.PCert

namespace SSC

noncomputable def Trie.beqK : Trie → Trie → Bool :=
  Trie.rec (motive := fun _ => Trie → Bool)
    (fun v t' => Trie.rec (motive := fun _ => Bool) (fun v' => Nat.beq v v') (fun _ _ _ _ => false) t')
    (fun _ _ el er t' => Trie.rec (motive := fun _ => Bool) (fun _ => false)
      (fun l' r' _ _ => guard (el l') (er r')) t')

end SSC
