import Submission.Work.Combine.XG
import Submission.Work.Combine.Ranks

namespace SSC
open OAI.PowerSaving.CB Finset

def wsum (wt : Nat → Nat) (l : List Nat) : Nat := (l.map wt).sum

theorem wsum_cons (wt : Nat → Nat) (a : Nat) (l : List Nat) : wsum wt (a :: l) = wt a + wsum wt l := by
  simp [wsum]
theorem wEq_apply (r n : Nat) : wEq r n = if n = r then 1 else 0 := by
  show Bool.rec (motive := fun _ => Nat) 0 1 (Nat.beq n r) = _
  by_cases h : n = r
  · subst h; rw [if_pos rfl, Nat.beq_refl]
  · rw [if_neg h]
    have hb : Nat.beq n r = false := by
      cases hb : Nat.beq n r with
      | false => rfl
      | true => exact absurd (Nat.eq_of_beq_eq_true hb) h
    rw [hb]

theorem wGt_apply (B n : Nat) : wGt B n = if n ≤ B then 0 else 1 := by
  show Bool.rec (motive := fun _ => Nat) 1 0 (Nat.ble n B) = _
  by_cases h : n ≤ B
  · rw [if_pos h, Nat.ble_eq_true_of_le h]
  · rw [if_neg h]
    have hb : Nat.ble n B = false := by
      cases hb : Nat.ble n B with
      | false => rfl
      | true => exact absurd (Nat.le_of_ble_eq_true hb) h
    rw [hb]

theorem wsum_wEq (r : Nat) (l : List Nat) : wsum (wEq r) l = l.count r := by
  induction l with
  | nil => rfl
  | cons a l ih =>
    rw [wsum_cons, ih, wEq_apply, List.count_cons]
    by_cases h : a = r
    · simp [h]; omega
    · simp [h]

theorem wsum_wGt (B : Nat) (l : List Nat) (h : wsum (wGt B) l = 0) : ∀ x ∈ l, x ≤ B := by
  induction l with
  | nil => intro x hx; simp at hx
  | cons a l ih =>
    rw [wsum_cons, wGt_apply] at h
    intro x hx
    rcases List.mem_cons.mp hx with e | e
    · rw [e]
      by_contra hc
      rw [if_neg hc] at h
      omega
    · exact ih (by omega) x e

theorem rcost_count (φ : ℕ → ℝ) (l : List ℕ) (B : ℕ) (hB : ∀ x ∈ l, x ≤ B) :
    rcost φ l = ∑ r ∈ range (B+1), (l.count r : ℝ) * bcost φ r := by
  induction l with
  | nil => simp [rcost_nil]
  | cons a l ih =>
    have ha : a ≤ B := hB a (List.mem_cons_self ..)
    rw [rcost_cons, ih (fun x hx => hB x (List.mem_cons_of_mem _ hx))]
    have e : ∀ r, ((List.count r (a :: l) : ℕ) : ℝ) * bcost φ r
        = (l.count r : ℝ) * bcost φ r + (if a = r then bcost φ r else 0) := by
      intro r
      rw [List.count_cons]
      by_cases h : a = r
      · simp [h]; ring
      · simp [h]
    simp_rw [e]
    rw [sum_add_distrib, sum_ite_eq (range (B+1)) a (fun r => bcost φ r)]
    simp only [mem_range.mpr (Nat.lt_succ_of_le ha), if_true]
    ring

end SSC

