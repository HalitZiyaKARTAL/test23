import Submission.Work.SharedSumChecker.PCert

namespace SSC

noncomputable def wEq (r : Nat) : Nat → Nat :=
  fun n => Bool.rec (motive := fun _ => Nat) 0 1 (Nat.beq n r)

noncomputable def wGt (B : Nat) : Nat → Nat :=
  fun n => Bool.rec (motive := fun _ => Nat) 1 0 (Nat.ble n B)

end SSC
