import Submission.Work.BlockApply.Exact
import Submission.Work.SharedSumStructured.Labels


namespace OAI
namespace PowerSaving
namespace CB
open Binary Matrix Finset RAM SS
noncomputable section

def bcost (φ : ℕ → ℝ) (q : ℕ) : ℝ := if q = 0 then 0 else φ q

def rcost (φ : ℕ → ℝ) (l : List ℕ) : ℝ := (l.map (bcost φ)).sum

lemma bcost_zero (φ : ℕ → ℝ) : bcost φ 0 = 0 := by simp [bcost]
lemma bcost_pos (φ : ℕ → ℝ) {q : ℕ} (h : q ≠ 0) : bcost φ q = φ q := by simp [bcost, h]
lemma rcost_nil (φ : ℕ → ℝ) : rcost φ [] = 0 := rfl
lemma rcost_cons (φ : ℕ → ℝ) (a : ℕ) (l : List ℕ) : rcost φ (a :: l) = bcost φ a + rcost φ l := by
  simp [rcost]
lemma rcost_append (φ : ℕ → ℝ) (l l' : List ℕ) : rcost φ (l ++ l') = rcost φ l + rcost φ l' := by
  simp [rcost]
lemma rcost_single (φ : ℕ → ℝ) (a : ℕ) : rcost φ [a] = bcost φ a := by simp [rcost]

lemma split_bcost (φ : ℕ → ℝ) {m q : ℕ} (h : q < m) : splitCost φ m q = bcost φ q := by
  unfold splitCost bcost
  by_cases h0 : q = 0
  · simp [h0]
  · simp [h0, h]

structure XMap (H α : Type) [Fintype H] [DecidableEq H] [Fintype α] [DecidableEq α] where
  Φ : Matrix H H F → CMat α

section Two
variable {H : Type} [Fintype H] [DecidableEq H]

variable (hH : 2 ≤ Fintype.card H) (A B : OBase H) (ka kb : H)
include hH

end Two
end
end CB
end PowerSaving
end OAI

