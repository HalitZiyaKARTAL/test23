import Mathlib.Logic.Equiv.Fintype
import Submission.Work.Bank401.Adapt
import Submission.Work.GFrame.Top.Api


namespace OAI
namespace PowerSaving
namespace XHost
open Binary Matrix Finset GF CB B401
noncomputable section

section Adapt
variable {α : Type} [Fintype α] [DecidableEq α]

theorem host_adapt {A B C C' : CMat α} (hA : Free A) (hC : Free C) (hC' : Free C')
    (D U R : Finset α) (hUD : U ⊆ D) (hc : U.card + R.card ≤ D.card) :
    ∃ P, Free P ∧ ∃ (A2 : CMat α) (U2 : Finset α), Free A2 ∧ U2 ⊆ D ∧ U2.card = U.card + R.card ∧
      C * pk R * C' * (P * (A * pk U * B)) = A2 * pk U2 * B := by
  obtain ⟨Ai, hAi, hAiA, -⟩ := free_inv hA
  obtain ⟨Ci, hCi, -, hC'Ci⟩ := free_inv hC'
  have hUc : R.card ≤ (D \ U).card := by
    rw [Finset.card_sdiff_of_subset hUD]
    omega
  obtain ⟨T, hTU, hTc⟩ := Finset.exists_subset_card_eq hUc
  obtain ⟨σ, hσ⟩ := Equiv.Perm.exists_map_finset_eq T R (hTc.trans rfl)
  have hPi : pk R * permMat (cperm σ) = permMat (cperm σ) * pk T := by
    rw [pk_cperm, hσ]
  have hdisj : Disjoint T U := by
    rw [Finset.disjoint_left]
    intro a ha hu
    exact (Finset.mem_sdiff.mp (hTU ha)).2 hu
  refine ⟨Ci * permMat (cperm σ) * Ai, Free.mul (Free.mul hCi (free_cperm σ)) hAi,
    C * permMat (cperm σ), T ∪ U, Free.mul hC (free_cperm σ), ?_, ?_, ?_⟩
  · intro a ha
    rcases Finset.mem_union.mp ha with ht | hu
    · exact (Finset.mem_sdiff.mp (hTU ht)).1
    · exact hUD hu
  · rw [Finset.card_union_of_disjoint hdisj, hTc, Nat.add_comm]
  · have e : C * pk R * C' * (Ci * permMat (cperm σ) * Ai * (A * pk U * B))
        = C * (pk R * permMat (cperm σ)) * (Ai * A) * pk U * B := by
      simp only [Matrix.mul_assoc]
      rw [← Matrix.mul_assoc C' Ci, hC'Ci, Matrix.one_mul]
    rw [e, hAiA, Matrix.mul_one, hPi, pk_union T U hdisj]
    simp only [Matrix.mul_assoc]

theorem host_pad {A Q : CMat α} (hA : Free A) (hQ : Free Q) (B : CMat α) (D U : Finset α) (hUD : U ⊆ D)
    (hD : D.card - U.card < Fintype.card α) :
    GReach (A * pk U * B) (Q * pk D * B) (fun φ => bcost φ (D.card - U.card)) := by
  intro ρ _ _ l
  obtain ⟨Ai, hAi, hAiA, -⟩ := free_inv hA
  obtain ⟨Qi, hQi, hQiQ, -⟩ := free_inv hQ
  have h1 := gstep_free (Free.mul hQ hAi) l (A * pk U * B)
  have e1 : Q * Ai * (A * pk U * B) = Q * pk U * B := by
    simp only [Matrix.mul_assoc]
    rw [← Matrix.mul_assoc Ai A, hAiA, Matrix.one_mul]
  rw [e1] at h1
  have hk : (D \ U).card = D.card - U.card := Finset.card_sdiff_of_subset hUD
  by_cases h0 : D.card - U.card = 0
  · have hUeq : U = D := Finset.eq_of_subset_of_card_le hUD (by omega)
    subst hUeq
    refine h1.cast (fun φ => ?_)
    simp [bcost]
  · have h2 := gstep_of_factor l (Q * pk U * B) ((OBase.canonical α).fam (D \ U))
      ((OBase.canonical α).fam_indep _) hQ hQi (by omega) (by omega)
    have e2 : Q * blockMat ((OBase.canonical α).fam (D \ U)) * Qi * (Q * pk U * B) = Q * pk D * B := by
      rw [← pk_eq_blockMat, pk_sdiff hUD]
      simp only [Matrix.mul_assoc]
      rw [← Matrix.mul_assoc Qi Q, hQiQ, Matrix.one_mul]
    rw [e2, hk] at h2
    refine (h1.trans h2).cast (fun φ => ?_)
    rw [bcost_pos φ h0]
    ring

end Adapt


end
end XHost
end PowerSaving
end OAI
