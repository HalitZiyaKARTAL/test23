import Submission.Work.GFrame.Engine.Letters


namespace OAI
namespace PowerSaving.MX
open Binary GF Matrix Finset
noncomputable section

section Mats
variable {α : Type*} [Fintype α] [DecidableEq α]

def bph {r : ℕ} (z : Fin r → Space α) (x : Space α) : ℂ := ∏ i, tint (dot (z i) x)

lemma blockMat_eq_wrap {r : ℕ} (z : Fin r → Space α) : blockMat z = wrap (bph z) := by
  rw [blockMat_wrap]
  congr 1
  funext x
  rw [List.map_ofFn, List.prod_ofFn]
  rfl

lemma blockMat_congr {r r' : ℕ} (z : Fin r → Space α) (z' : Fin r' → Space α)
    (h : ∀ x, bph z x = bph z' x) : blockMat z = blockMat z' := by
  rw [blockMat_eq_wrap, blockMat_eq_wrap]
  congr 1
  funext x
  exact h x

lemma blockMat_comm {r r' : ℕ} (z : Fin r → Space α) (z' : Fin r' → Space α) :
    blockMat z * blockMat z' = blockMat z' * blockMat z := by
  rw [blockMat_eq_wrap, blockMat_eq_wrap]
  exact wrap_comm _ _

lemma bph_add {a b : ℕ} (z : Fin (a+b) → Space α) (x : Space α) :
    bph z x = bph (fun i : Fin a => z (Fin.castAdd b i)) x * bph (fun j : Fin b => z (Fin.natAdd a j)) x := by
  unfold bph
  exact Fin.prod_univ_add (fun i => tint (dot (z i) x))

theorem split_block {a b : ℕ} (z : Fin (a+b) → Space α) :
    blockMat z = blockMat (fun i : Fin a => z (Fin.castAdd b i))
      * blockMat (fun j : Fin b => z (Fin.natAdd a j)) := by
  rw [blockMat_eq_wrap, blockMat_eq_wrap, blockMat_eq_wrap, wrap_mul]
  congr 1
  funext x
  exact bph_add z x

lemma shift_mul_shift (c d : Space α) : Binary.shift c * Binary.shift d = Binary.shift (c + d) := by
  rw [shift_phase, shift_phase, shift_phase, wrap_mul]
  congr 1
  funext x
  rw [dot_add_left, sign_add]

lemma shift_mul_shift_self (c : Space α) (M : CMat α) :
    Binary.shift c * (Binary.shift c * M) = M := by
  rw [← Matrix.mul_assoc, shift_sq, Matrix.one_mul]

end Mats

section Words
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

def GLiveKernelM (e : σ → ρ) (T : σ → CMat α) (w : GWord α ρ) : Prop :=
  ∀ (f : ℕ) (v : Data α ρ f), (∀ s, (∀ l, e l ≠ s) → v s = 0) →
    ∀ l, gwalk f w v (e l) = matAct f (T l) (v (e l))

theorem GLiveKernelM.congr {e : σ → ρ} {T T' : σ → CMat α} {w : GWord α ρ}
    (h : GLiveKernelM e T w) (hT : ∀ l, T l = T' l) : GLiveKernelM e T' w := by
  intro f v hv l
  rw [h f v hv l, hT l]

theorem GLiveKernelM.of_gwalk {e : σ → ρ} {T : σ → CMat α} {w w' : GWord α ρ}
    (h : GLiveKernelM e T w) (hw : ∀ f (x : Data α ρ f), gwalk f w x = gwalk f w' x) :
    GLiveKernelM e T w' := by
  intro f v hv l
  rw [← hw f v]
  exact h f v hv l

def rmat : GMove α ρ → ρ → CMat α
  | .old (.localM _), _ => 1
  | .old (.shift l z), j => if j = l then Binary.shift z else 1
  | .old (.block l _ z _), j => if j = l then blockMat z else 1
  | .perm l G, j => if j = l then permMat G else 1
  | .phase l z c, j => if j = l then phaseMat z c else 1
  | .localG _ _, _ => 1

def IsLocal : GMove α ρ → Prop
  | .old (.localM _) => False
  | .localG _ _ => False
  | _ => True

def RoleLocal (w : GWord α ρ) : Prop := ∀ mv ∈ w, IsLocal mv

def roleProd : GWord α ρ → ρ → CMat α
  | [], _ => 1
  | mv :: w, j => roleProd w j * rmat mv j

@[simp] lemma roleProd_nil (j : ρ) : roleProd ([] : GWord α ρ) j = 1 := rfl
lemma roleProd_cons (mv : GMove α ρ) (w : GWord α ρ) (j : ρ) :
    roleProd (mv :: w) j = roleProd w j * rmat mv j := rfl

lemma act_local (f : ℕ) (mv : GMove α ρ) (h : IsLocal mv) (x : Data α ρ f) (j : ρ) :
    mv.act f x j = matAct f (rmat mv j) (x j) := by
  cases mv with
  | old mv =>
    cases mv with
    | localM g => exact h.elim
    | shift l z =>
      change roleAct f l (Binary.shift z) x j = _
      simp only [roleAct, rmat]
      split_ifs <;> simp
    | block l rk z ind =>
      change roleAct f l (blockMat z) x j = _
      simp only [roleAct, rmat]
      split_ifs <;> simp
  | perm l G =>
    change roleAct f l (permMat G) x j = _
    simp only [roleAct, rmat]
    split_ifs <;> simp
  | phase l z c =>
    change roleAct f l (phaseMat z c) x j = _
    simp only [roleAct, rmat]
    split_ifs <;> simp
  | localG gr gi => exact h.elim

theorem gwalk_local (f : ℕ) (w : GWord α ρ) (hw : RoleLocal w) (x : Data α ρ f) (j : ρ) :
    gwalk f w x j = matAct f (roleProd w j) (x j) := by
  induction w generalizing x with
  | nil => simp
  | cons mv w ih =>
    rw [gwalk_cons, ih (fun m hm => hw m (List.mem_cons_of_mem _ hm)),
      act_local f mv (hw mv List.mem_cons_self), matAct_mul, roleProd_cons]

theorem GLiveKernelM.append_local {e : σ → ρ} {T : σ → CMat α} {w : GWord α ρ}
    (h : GLiveKernelM e T w) (t : GWord α ρ) (ht : RoleLocal t) :
    GLiveKernelM e (fun l => roleProd t (e l) * T l) (w ++ t) := by
  intro f v hv l
  rw [gwalk_append, gwalk_local f t ht, h f v hv l, matAct_mul]

def OnRole (e : σ → ρ) (mk : σ → GMove α ρ) (M : σ → CMat α) : Prop :=
  ∀ l, IsLocal (mk l) ∧ ∀ j, rmat (mk l) j = if j = e l then M l else 1

lemma roleProd_map_e [DecidableEq σ] {e : σ → ρ} (he : Function.Injective e) {mk : σ → GMove α ρ} {M : σ → CMat α}
    (hm : OnRole e mk M) (L : List σ) (hL : L.Nodup) (l : σ) :
    roleProd (L.map mk) (e l) = if l ∈ L then M l else 1 := by
  induction L with
  | nil => simp
  | cons l0 L ih =>
    rw [List.nodup_cons] at hL
    rw [List.map_cons, roleProd_cons, ih hL.2, (hm l0).2 (e l)]
    by_cases h : l = l0
    · subst h
      simp [hL.1]
    · have h' : e l ≠ e l0 := fun h'' => h (he h'')
      simp [h, h']

end Words
end
end PowerSaving.MX
end OAI
