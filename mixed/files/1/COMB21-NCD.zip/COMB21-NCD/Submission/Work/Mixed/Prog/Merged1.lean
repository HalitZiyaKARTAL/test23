import Submission.Work.Kit.RAMEnv
import Submission.Work.GFrame.Engine.Sweep
import Submission.WHTCheck.Solution
import Submission.Work.Mixed.Prog.Sem
import Submission.Work.Mixed.Prog.Seq
import Submission.Work.Mixed.Prog.EngArith

namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

universe U

abbrev UnitF {ι : Type U} (NU : ι → ℕ) := Σ i, Fin (NU i)

section CTab
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

def ctab (X : Layout α) (R : Layout ρ) (NU : ℕ) (c ib : ℕ → ℕ)
    (V : ∀ p : Fin NU, Bits (ib p) → Grain α ρ 0 (c p)) : Tape (Tape (Tape ℂ)) :=
  (Layout.std NU).tape (fun p => (bits (ib p)).tape (fun q => (fleet X R 0 (c p)).tape (V p q)))

end CTab

structure CCtx {ι : Type U} (m : Bool) (B : ι → ℕ) (s : Ty) (x : ι → T s) (mx : ℕ)
    (n NU : ι → ℕ) (col ib : ι → ℕ → ℕ) : Prop where
  nK : Knows m B s x n
  p2n : Knows m B s x (fun i => 2^(n i))
  nuK : Knows m B s x NU
  imag : Has m B s sc x (fun _ => Complex.I)
  tc : Has m B s (a w) x (fun i => (Layout.std (NU i)).tape (fun p => col i p))
  tpc : Has m B s (a w) x (fun i => (Layout.std (NU i)).tape (fun p => 2^(col i p)))
  tib : Has m B s (a w) x (fun i => (Layout.std (NU i)).tape (fun p => ib i p))
  tpib : Has m B s (a w) x (fun i => (Layout.std (NU i)).tape (fun p => 2^(ib i p)))
  txr : Has m B s (a (a w)) x (fun i => (Layout.std (NU i)).tape (fun p => xorTab (col i p)))
  tlum : Has m B s (a (a sc)) x
    (fun i => (Layout.std (NU i)).tape (fun p => (bits (col i p)).tape (fun y : Bits (col i p) => lum y)))
  big : Small B (fun i => 2^(n i))
  nuS : Small B NU
  fit : ∀ i (p : Fin (NU i)), mx * col i p + ib i p = n i
  mx1 : 1 ≤ mx

namespace CCtx
variable {ι : Type U} {m : Bool} {B : ι → ℕ} {s : Ty} {x : ι → T s} {mx : ℕ}
  {n NU : ι → ℕ} {col ib : ι → ℕ → ℕ}
variable (c : CCtx m B s x mx n NU col ib)
include c

lemma ext {t : Ty} (y : ι → T t) :
    CCtx m B (p s t) (fun i => (x i, y i)) mx n NU col ib :=
  ⟨Can.first.then_do c.nK, Can.first.then_do c.p2n, Can.first.then_do c.nuK,
    Can.first.then_do c.imag, Can.first.then_do c.tc, Can.first.then_do c.tpc,
    Can.first.then_do c.tib, Can.first.then_do c.tpib, Can.first.then_do c.txr,
    Can.first.then_do c.tlum, c.big, c.nuS, c.fit, c.mx1⟩

lemma reindex {κ : Type U} (j : κ → ι) {t : Ty} (y : κ → T t)
    (g : Has m (fun k => B (j k)) t s y (fun k => x (j k))) :
    CCtx m (fun k => B (j k)) t y mx (fun k => n (j k)) (fun k => NU (j k))
      (fun k => col (j k)) (fun k => ib (j k)) :=
  ⟨g.then_do (c.nK.reindex j), g.then_do (c.p2n.reindex j), g.then_do (c.nuK.reindex j),
    g.then_do (c.imag.reindex j), g.then_do (c.tc.reindex j), g.then_do (c.tpc.reindex j),
    g.then_do (c.tib.reindex j), g.then_do (c.tpib.reindex j), g.then_do (c.txr.reindex j),
    g.then_do (c.tlum.reindex j), c.big.reindex j, c.nuS.reindex j, fun k => c.fit (j k), c.mx1⟩

lemma col_le (i : ι) (p : Fin (NU i)) : col i p ≤ n i := by
  have h1 := c.fit i p
  have h2 : col i p ≤ mx * col i p := Nat.le_mul_of_pos_left _ c.mx1
  omega

lemma ib_le (i : ι) (p : Fin (NU i)) : ib i p ≤ n i := by
  have h1 := c.fit i p
  omega

end CCtx

lemma _root_.OAI.PowerSaving.RAM.unit_fetch {ι : Type U} {m : Bool} {B : ι → ℕ} {s : Ty}
    {x : ι → T s} {NU : ι → ℕ} {t : Ty} (g : ∀ i, Fin (NU i) → T t)
    (ht : Has m B s (a t) x (fun i => (Layout.std (NU i)).tape (g i))) :
    Has m (fun u : UnitF NU => B u.1) (p s w) t (fun u => (x u.1, u.2.val)) (fun u => g u.1 u.2) :=
  Can.fetch (t := t) (L := fun u : UnitF NU => Layout.std (NU u.1)) (v := fun u => g u.1)
    (i := fun u => u.2) (Can.first.then_do (ht.reindex (fun u : UnitF NU => u.1))) Can.second

section Route
variable {α β ρ : Type*} [Fintype α] [DecidableEq α] [Fintype β] [DecidableEq β]
  [Fintype ρ] [DecidableEq ρ] {k : ℕ}

def blockJob (S : Split α β (Fin k)) (X' : Layout β) (f r n : ℕ)
    (h : k*f + X'.n*f + r = n) (l : ρ) (v : Bits r → Grain α ρ 0 f) : Bits n → ℂ :=
  fun e => v ((placeS S X' f r n h).symm e).1 (l, (0, ((placeS S X' f r n h).symm e).2))

lemma blockJob_placeS (S : Split α β (Fin k)) (X' : Layout β) (f r n : ℕ)
    (h : k*f + X'.n*f + r = n) (l : ρ) (v : Bits r → Grain α ρ 0 f) (q : Bits r) (y : Sky α f) :
    blockJob S X' f r n h l v (placeS S X' f r n h (q, y)) = v q (l, (0, y)) := by
  unfold blockJob
  rw [Equiv.symm_apply_apply]

omit [Fintype β] [DecidableEq β] in
lemma fitk {X : Layout α} (X' : Layout β) (hX' : X'.n + k = X.n) {f r n : ℕ}
    (hf : X.n * f + r = n) : k*f + X'.n*f + r = n := by
  subst hf
  rw [← hX', Nat.add_mul]
  omega

def cjob (X : Layout α) (S : Split α β (Fin k)) (X' : Layout β) (hX' : X'.n + k = X.n) (l : ρ)
    {NU n : ℕ} {col ib : ℕ → ℕ} (hfit : ∀ p : Fin NU, X.n * col p + ib p = n)
    (V : ∀ p : Fin NU, Bits (ib p) → Grain α ρ 0 (col p))
    (fl pp si : ℕ → ℕ) (hpp : ∀ t, fl t ≠ 0 → pp t < NU) (sup : ℕ → Bits n → ℂ) (t : ℕ) :
    Bits n → ℂ :=
  if hf : fl t ≠ 0 then
    blockJob S X' (col (pp t)) (ib (pp t)) n (fitk X' hX' (hfit ⟨pp t, hpp t hf⟩)) l (V ⟨pp t, hpp t hf⟩)
  else sup (si t)

end Route

abbrev jobsT (cl : Paint) : Ty := a (a (c cl))
abbrev portIn (cl : Paint) : Ty := p w (p sc (p w (p w (p w (p (jobsT cl) (jobsT cl))))))
abbrev portOut (cl : Paint) : Ty := p (jobsT cl) (p (jobsT cl) (a w))
abbrev portM (cl : Paint) : Port := some (portIn cl, portOut cl)

def mkIn (cl : Paint) (n kind μ o : ℕ) (own sup : Tape (Tape ℂ)) : T (portIn cl) :=
  (n, Complex.I, kind, μ, o, own, sup)

def jobsTape (n N : ℕ) (J : ℕ → Bits n → ℂ) : Tape (Tape ℂ) :=
  (Layout.std N).tape (fun t => (bits n).tape (J t))

lemma jobsTape_zero (n n' : ℕ) (f : ℕ → Bits n → ℂ) (g : ℕ → Bits n' → ℂ) :
    jobsTape n 0 f = jobsTape n' 0 g := by
  unfold jobsTape Layout.tape
  congr 1
  funext j
  exact absurd j.2 (Nat.not_lt_zero _)

lemma jobsTape_congr {n N : ℕ} {J J' : ℕ → Bits n → ℂ} (h : ∀ t, t < N → J t = J' t) :
    jobsTape n N J = jobsTape n N J' := by
  unfold jobsTape Layout.tape
  congr 1
  funext j
  show (bits n).tape (J ((Layout.std N).atFin j).val) = (bits n).tape (J' ((Layout.std N).atFin j).val)
  rw [h _ ((Layout.std N).atFin j).2]

def bitsOf (b j : ℕ) : Bits b := (bits b).atFin ⟨j % 2^b, Nat.mod_lt _ (Nat.two_pow_pos b)⟩

lemma bitsOf_loc (b j : ℕ) : (bits b).loc (bitsOf b j) = j % 2^b :=
  Layout.loc_atFin _ _

lemma bitsOf_of_loc (b : ℕ) (y : Bits b) : bitsOf b ((bits b).loc y) = y := by
  apply (bits b).inj
  rw [bitsOf_loc]
  exact Nat.mod_eq_of_lt (by have := (bits b).bd y; rwa [bits_len] at this)

def toVec (n k : ℕ) (hk : k ≤ n) (J : ℕ → Bits n → ℂ) (t : ℕ) : Bits k → ℂ :=
  fun x => J (t / 2^(n-k)) (castB (Nat.add_sub_cancel' hk) (catB k (n-k) (x, bitsOf (n-k) t)))

lemma loc_castB_catB (n k : ℕ) (hk : k ≤ n) (x : Bits k) (y : Bits (n-k)) :
    (bits n).loc (castB (Nat.add_sub_cancel' hk) (catB k (n-k) (x, y))) =
      (bits k).loc x + 2^k * (bits (n-k)).loc y := by
  rw [castB_loc, catB_loc]

def fromVec (n k : ℕ) (hk : k ≤ n) (Y : ℕ → Bits k → ℂ) (j : ℕ) : Bits n → ℂ :=
  fun e => Y (j * 2^(n-k) + (bits (n-k)).loc ((catB k (n-k)).symm ((castB (Nat.add_sub_cancel' hk)).symm e)).2)
    ((catB k (n-k)).symm ((castB (Nat.add_sub_cancel' hk)).symm e)).1

lemma fromVec_ripple (n k : ℕ) (hk : k ≤ n) (J : ℕ → Bits n → ℂ) (j : ℕ) :
    fromVec n k hk (fun t => ripple k (toVec n k hk J t)) j = hlow n k (J j) := by
  funext e
  obtain ⟨⟨x, y⟩, rfl⟩ : ∃ z : Bits k × Bits (n - k),
      castB (Nat.add_sub_cancel' hk) (catB k (n - k) z) = e :=
    ⟨(catB k (n - k)).symm ((castB (Nat.add_sub_cancel' hk)).symm e), by simp⟩
  unfold fromVec
  simp only [Equiv.symm_apply_apply]
  have hy : (bits (n-k)).loc y < 2^(n-k) := by have := (bits (n-k)).bd y; rwa [bits_len] at this
  have h2 : 0 < 2^(n-k) := Nat.two_pow_pos _
  have e1 : (j * 2^(n-k) + (bits (n-k)).loc y) / 2^(n-k) = j := by
    rw [Nat.add_comm, Nat.add_mul_div_right _ _ h2, Nat.div_eq_of_lt hy, Nat.zero_add]
  have e2 : bitsOf (n-k) (j * 2^(n-k) + (bits (n-k)).loc y) = y := by
    apply (bits (n-k)).inj
    rw [bitsOf_loc, Nat.add_comm, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt hy]
  have e3 : toVec n k hk J (j * 2^(n-k) + (bits (n-k)).loc y) =
      fun x' => J j (castB (Nat.add_sub_cancel' hk) (catB k (n-k) (x', y))) := by
    funext x'
    unfold toVec
    rw [e1, e2]
  rw [e3]
  -- CHECK: `hlow_catB` (Sem) reads `hlow (a+b) a w (catB a b (x, q)) = ripple a (fun x' => w (catB a b (x', q))) x`
  have hc : ∀ (a b : ℕ) (hab : a + b = n) (x : Bits a) (q : Bits b),
      hlow n a (J j) (castB hab (catB a b (x, q))) =
        ripple a (fun x' => J j (castB hab (catB a b (x', q)))) x := by
    intro a b hab x q
    subst hab
    exact hlow_catB a b (J j) x q
  exact (hc k (n-k) (Nat.add_sub_cancel' hk) x y).symm

def exFl (N t : ℕ) : ℕ := if t < N then 1 else 0

lemma exFl_pp (N t : ℕ) (h : exFl N t ≠ 0) : t < N := by
  unfold exFl at h
  by_contra hn
  exact h (if_neg hn)

section ExitJobs
variable {α β ρ : Type*} [Fintype α] [DecidableEq α] [Fintype β] [DecidableEq β]
  [Fintype ρ] [DecidableEq ρ] {k : ℕ}

def exJobs (X : Layout α) (S : Split α β (Fin k)) (X' : Layout β) (hX' : X'.n + k = X.n) (l : ρ)
    {NU n : ℕ} {col ib : ℕ → ℕ} (hfit : ∀ p : Fin NU, X.n * col p + ib p = n)
    (V : ∀ p : Fin NU, Bits (ib p) → Grain α ρ 0 (col p)) : ℕ → Bits n → ℂ :=
  cjob X S X' hX' l hfit V (exFl NU) id (fun _ => 0) (exFl_pp NU) (fun _ _ => 0)

end ExitJobs

inductive MDesc
  | top (n B : ℕ) (v : ℕ → Bits n → ℂ)
  | cls (n h μ o BS : ℕ) (J sup : ℕ → Bits n → ℂ)

structure Eng (α ρ σ : Type*) [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
    [Fintype σ] [DecidableEq σ] where
  X : Layout α
  R : Layout ρ
  Q : Layout σ
  e : σ → ρ
  he : Function.Injective e
  tr : σ → ℕ
  tz : ∀ l, Fin (tr l) → Space α
  tind : ∀ l, LinearIndependent F (tz l)
  tr_le : ∀ l, tr l ≤ X.n
  tr_pos : ∀ l, 1 ≤ tr l
  wd : GWord α ρ
  hP : wd.Proper X.n
  sep : ∀ mv ∈ wd, ∀ r, mv.rk? = some r → ∀ l, r < tr l
  W_pos : 0 < Q.n
  three : 3 ≤ X.n
  hw : ∀ (f : ℕ) (v : Data α ρ f), (∀ s, (∀ l, e l ≠ s) → v s = 0) →
    ∀ l, gwalk f wd v (e l) = matAct f (blockMat (tz l)) (v (e l))

lemma dom_mul {ι : Type*} {W F : ι → ℕ} (K : ℕ) (h : ∀ i, F i ≤ K * W i) : Dom W F :=
  ⟨K + 1, fun i => by
    have := h i
    rw [Nat.add_mul, Nat.one_mul, Nat.mul_add, Nat.mul_one]
    omega⟩

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ] (E : Eng α ρ σ)

abbrev W : ℕ := E.Q.n
def tq (a : ℕ) : ℕ := if h : a < E.Q.n then E.tr (E.Q.atFin ⟨a, h⟩) else 0
abbrev mx : ℕ := E.X.n

abbrev NUc (n h μ : ℕ) : ℕ := MXR.NU E.W E.tq E.mx n h μ
abbrev Uc (n h μ p : ℕ) : ℕ := MXR.U E.W E.tq E.mx n h μ p
abbrev PCc (n h μ t : ℕ) : ℕ := MXR.PC E.W E.tq E.mx n h μ t
abbrev cUc (n h μ p : ℕ) : ℕ := MXR.cU E.W E.tq E.mx n h μ p
abbrev iUc (n h μ p : ℕ) : ℕ := MXR.iU E.W E.tq E.mx n h μ p

lemma fitc (n h μ : ℕ) (p : Fin (E.NUc n h μ)) : E.X.n * E.cUc n h μ p + E.iUc n h μ p = n :=
  MXR.iU_add p.2

lemma tq_loc (l : σ) : E.tq (E.Q.loc l) = E.tr l := by
  unfold tq
  rw [dif_pos (E.Q.bd l)]
  congr 1
  apply E.Q.inj
  simp

def slotSize (n h μ t : ℕ) : ℕ := E.tq (t % E.W) * E.cUc n h μ (t / E.W)

abbrev CState (n h μ : ℕ) := ∀ p : Fin (E.NUc n h μ), Bits (E.iUc n h μ p) → Grain α ρ 0 (E.cUc n h μ p)

def St (l : σ) : Split α (Fin (Fintype.card α - E.tr l)) (Fin (E.tr l)) :=
  Classical.choose (exists_split (E.tz l) (E.tind l))

lemma St_spec (l : σ) (i : Fin (E.tr l)) : (E.St l).e.symm (0, eu i) = E.tz l i :=
  Classical.choose_spec (exists_split (E.tz l) (E.tind l)) i

def Xt (l : σ) : Layout (Fin (Fintype.card α - E.tr l)) := Layout.someLayout _
lemma Xt_n (l : σ) : (E.Xt l).n + E.tr l = E.X.n := by
  show Fintype.card (Fin (Fintype.card α - E.tr l)) + E.tr l = E.X.n
  rw [Fintype.card_fin, Layout.card E.X]
  exact Nat.sub_add_cancel (E.tr_le l)

def liveOf (l' : ρ) : Option σ := if h : ∃ s0, E.e s0 = l' then some (Classical.choose h) else none

lemma liveOf_e (l : σ) : E.liveOf (E.e l) = some l := by
  unfold liveOf
  have h : ∃ s0, E.e s0 = E.e l := ⟨l, rfl⟩
  rw [dif_pos h]
  exact congrArg some (E.he (Classical.choose_spec h))

lemma liveOf_none (l' : ρ) (h : ∀ l, E.e l ≠ l') : E.liveOf l' = none := by
  unfold liveOf
  rw [dif_neg (fun ⟨s0, hs⟩ => h s0 hs)]

def placeT (n h μ : ℕ) (p : Fin (E.NUc n h μ)) (l : σ) :
    Bits (E.iUc n h μ p) × Sky α (E.cUc n h μ p) ≃ Bits n :=
  placeS (E.St l) (E.Xt l) (E.cUc n h μ p) (E.iUc n h μ p) n (fitk (E.Xt l) (E.Xt_n l) (E.fitc n h μ p))

def V0 (n h μ : ℕ) (J : ℕ → Bits n → ℂ) : E.CState n h μ :=
  fun p q x => match E.liveOf x.1 with
    | some l => J (p.val * E.W + E.Q.loc l) (E.placeT n h μ p l (q, x.2.2))
    | none => 0

def stepV {n h μ : ℕ} (V : E.CState n h μ) (mv : GMove α ρ) : E.CState n h μ :=
  fun p q => gferry 0 (E.cUc n h μ p) mv (V p q)

def runV {n h μ : ℕ} (V : E.CState n h μ) (w : GWord α ρ) : E.CState n h μ :=
  fun p q => gcoast 0 (E.cUc n h μ p) w (V p q)

def parCode (n h μ r t : ℕ) : ℕ := t % E.W + E.W * E.Uc n h (μ * r) (t / E.W)

def fedP (n h μ r t : ℕ) : Prop :=
  t < E.NUc n h (μ * r) * E.W ∧ inRS E.W E.tq E.mx n (h+1) μ (E.parCode n h μ r t)
instance (n h μ r : ℕ) : DecidablePred (E.fedP n h μ r) := fun t => by unfold fedP; infer_instance

def srcP (n h μ r t : ℕ) : Prop := t < E.NUc n h (μ * r) * E.W ∧ ¬ inRS E.W E.tq E.mx n (h+1) μ (E.parCode n h μ r t)
instance (n h μ r : ℕ) : DecidablePred (E.srcP n h μ r) := fun t => by unfold srcP; infer_instance

def flR (n h μ r t : ℕ) : ℕ := if E.fedP n h μ r t then 1 else 0
def ppR (n h μ r t : ℕ) : ℕ := E.PCc n (h+1) μ (E.parCode n h μ r t)
def siR (n h μ r o t : ℕ) : ℕ := o + Nat.count (E.srcP n h μ r) t

def slotR (n h μ r p : ℕ) : ℕ :=
  E.PCc n h (μ * r) (E.Uc n (h+1) μ p / E.W) * E.W + E.Uc n (h+1) μ p % E.W

lemma ppR_lt (n h μ r t : ℕ) (hf : E.flR n h μ r t ≠ 0) : E.ppR n h μ r t < E.NUc n (h+1) μ := by
  unfold flR at hf
  by_cases hfed : E.fedP n h μ r t
  · unfold ppR
    exact MXR.PC_lt hfed.2
  · exact absurd (if_neg hfed) hf

def blockRanks (w : GWord α ρ) : List ℕ := w.filterMap GMove.rk?

def ownSrc (n h μ r : ℕ) : List ℕ :=
  (List.range (E.NUc n h (μ * r) * E.W)).filterMap
    (fun t => if E.srcP n h μ r t then some (E.slotSize n h (μ * r) t) else none)

def srcSizes (n : ℕ) : ℕ → ℕ → List ℕ
  | 0, _ => []
  | h+1, μ => (blockRanks E.wd).flatMap (fun r => E.ownSrc n h μ r ++ srcSizes n h (μ * r))

def cons (n h μ : ℕ) : ℕ := (E.srcSizes n h μ).length
def csz (n h μ k : ℕ) : ℕ := (E.srcSizes n h μ).getD k 0

def bS {r : ℕ} (z : Fin r → Space α) (ind : LinearIndependent F z) :
    Split α (Fin (Fintype.card α - r)) (Fin r) := Classical.choose (exists_split z ind)

lemma bS_spec {r : ℕ} (z : Fin r → Space α) (ind : LinearIndependent F z) (i : Fin r) :
    (bS z ind).e.symm (0, eu i) = z i :=
  Classical.choose_spec (exists_split z ind) i

def bX (r : ℕ) : Layout (Fin (Fintype.card α - r)) := Layout.someLayout _
lemma bX_n {r : ℕ} (hr : r ≤ E.X.n) : (bX (α:=α) r).n + r = E.X.n := by
  show Fintype.card (Fin (Fintype.card α - r)) + r = E.X.n
  rw [Fintype.card_fin, Layout.card E.X]
  exact Nat.sub_add_cancel hr

def childC (n h μ BS : ℕ) (sup : ℕ → Bits n → ℂ) (V : E.CState n (h+1) μ) (o : ℕ)
    (l : ρ) (r : ℕ) (z : Fin r → Space α) (ind : LinearIndependent F z) (hr : r ≤ E.X.n) : MDesc :=
  MDesc.cls n h (μ * r) (o + (E.ownSrc n h μ r).length) BS
    (cjob E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc n (h+1) μ) V (E.flR n h μ r) (E.ppR n h μ r)
      (E.siR n h μ r o) (E.ppR_lt n h μ r) sup) sup

def exitC (n μ : ℕ) (V : E.CState n 0 μ) (l : ρ) (r : ℕ) (z : Fin r → Space α)
    (ind : LinearIndependent F z) (hr : r ≤ E.X.n) : MDesc :=
  if hk : r * μ ≤ n then
    MDesc.top (r * μ) (E.NUc n 0 μ * 2^(n - r * μ))
      (toVec n (r * μ) hk (exJobs E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc n 0 μ) V))
  else MDesc.top 0 0 (fun _ _ => 0)

def kidsUp (n h μ BS : ℕ) (sup : ℕ → Bits n → ℂ) : E.CState n (h+1) μ → ℕ → GWord α ρ → List MDesc
  | _, _, [] => []
  | V, o, mv :: ws => match mv with
    | .old (.block l r z ind) =>
      (if hr : r ≤ E.X.n then [E.childC n h μ BS sup V o l r z ind hr] else []) ++
        kidsUp n h μ BS sup (E.stepV V mv) (o + (E.ownSrc n h μ r).length + E.cons n h (μ * r)) ws
    | _ => kidsUp n h μ BS sup (E.stepV V mv) o ws

def kidsLeaf (n μ : ℕ) : E.CState n 0 μ → GWord α ρ → List MDesc
  | _, [] => []
  | V, mv :: ws => match mv with
    | .old (.block l r z ind) =>
      (if hr : r ≤ E.X.n then [E.exitC n μ V l r z ind hr] else []) ++ kidsLeaf n μ (E.stepV V mv) ws
    | _ => kidsLeaf n μ (E.stepV V mv) ws

def kidsC : MDesc → List MDesc
  | MDesc.top _ _ _ => []
  | MDesc.cls n 0 μ _ _ J _ => E.kidsLeaf n μ (E.V0 n 0 μ J) E.wd
  | MDesc.cls n (h+1) μ o BS J sup => E.kidsUp n h μ BS sup (E.V0 n (h+1) μ J) o E.wd

def enc (cl : Paint) : MDesc → T (portIn cl)
  | MDesc.top n B v => mkIn cl n 0 0 0 (jobsTape n B v) (jobsTape n 0 (fun _ _ => 0))
  | MDesc.cls n h μ o BS J sup => mkIn cl n (h+1) μ o (jobsTape n (E.NUc n h μ * E.W) J) (jobsTape n BS sup)

def out (cl : Paint) : MDesc → T (portOut cl)
  | MDesc.top n B v => (jobsTape n B (fun t => ripple n (v t)), jobsTape n 0 (fun _ _ => 0),
      (Layout.std 0).tape (fun _ => 0))
  | MDesc.cls n h μ o BS J sup =>
      (jobsTape n (E.NUc n h μ * E.W) (fun t => hlow n (E.slotSize n h μ t) (J t)),
       jobsTape n (E.cons n h μ) (fun k => hlow n (E.csz n h μ k) (sup (o + k))),
       (Layout.std (E.cons n h μ)).tape (fun k => E.csz n h μ k))

end Eng

section Kit
universe V
variable {ι : Type U} {m : Bool}

def blankCodeE (m : Bool) (r : Port) (s : Ty) : (t : Ty) → Code m r s t
  | .w => .atom (.lit 0)
  | .c e => .atom (.cz e)
  | .p q u => .fork (blankCodeE m r s q) (blankCodeE m r s u)
  | .a q => .tab (.atom (.lit 0)) (.comp (.atom .fst) (blankCodeE m r s q))

lemma able_empty {κ : Type V} (he : κ → False) {r : Port} {b : Bank r κ} {s t : Ty}
    {x : κ → T s} {y : κ → T t} {W Z : κ → ℕ} : Able m b s t x y W Z :=
  ⟨blankCodeE m r s t, 0, 0, fun k => (he k).elim⟩

lemma has_tape0 {B : ι → ℕ} {s t : Ty} {x : ι → T s} (f : ι → Fin 0 → T t) :
    Has m B s (a t) x (fun i => (Layout.std 0).tape (f i)) := by
  have H := Can.layout (m := m) (t := t) (L := fun _ : ι => Layout.std 0) (v := f) (P := fun _ => 0)
    (W := fun _ => 0) (B := B) (x := x) (Can.wc 0) (able_empty (fun d => d.2.elim0)) (Small.const _ 0)
  exact H.mono (fun _ => Nat.le_of_eq rfl)

lemma has_jobs0 {B : ι → ℕ} {s : Ty} {x : ι → T s} {cl : Paint} (n : ι → ℕ)
    (J : ∀ i, ℕ → Bits (n i) → ℂ) :
    Has m B s (jobsT cl) x (fun i => jobsTape (n i) 0 (J i)) :=
  has_tape0 (t := a (c cl)) (fun i (t : Fin 0) => (bits (n i)).tape (J i t))

lemma can_jobsTape {B : ι → ℕ} {s : Ty} {x : ι → T s} {cl : Paint}
    {n N : ι → ℕ} {J : ∀ i, ℕ → Bits (n i) → ℂ}
    (hN : Knows m B s x N) (h2 : Knows m B s x (fun i => 2^(n i)))
    (hNs : Small B N) (h2s : Small B (fun i => 2^(n i)))
    (hel : Has m (fun d : Σ u : UnitF N, Bits (n u.1) => B d.1.1) (p (p s w) w) (c cl)
      (fun d => ((x d.1.1, d.1.2.val), (bits (n d.1.1)).loc d.2)) (fun d => J d.1.1 d.1.2.val d.2)) :
    Can m B s (jobsT cl) x (fun i => jobsTape (n i) (N i) (J i)) (fun i => N i * (2^(n i) + 1)) := by
  have hlen : Knows m (fun u : UnitF N => B u.1) (p s w) (fun u => (x u.1, u.2.val))
      (fun u => (bits (n u.1)).n) :=
    (Can.first.then_do (h2.reindex (fun u : UnitF N => u.1))).cong (fun _ => rfl) (fun _ => rfl)
  have HI := Can.layout (m := m) (t := c cl) (L := fun u : UnitF N => bits (n u.1))
    (v := fun u y => J u.1 u.2.val y) (P := fun _ => 0) (W := fun _ => 0) hlen
    (hel.mono (fun _ => Nat.zero_le _)) ((h2s.reindex (fun u : UnitF N => u.1)).mono (fun _ => le_rfl))
  have HO := Can.layout (m := m) (t := a (c cl)) (L := fun i => Layout.std (N i))
    (v := fun i t => (bits (n i)).tape (J i t.val)) (P := fun i => 2^(n i)) (W := fun _ => 0) hN
    (HI.mono (fun u => by simp)) hNs
  refine HO.mono (fun i => ?_)
  show 0 + N i + N i * 2^(n i) ≤ N i * (2^(n i) + 1)
  rw [Nat.mul_add, Nat.mul_one]
  omega

lemma has_jobsRead {B : ι → ℕ} {s : Ty} {x : ι → T s} {cl : Paint} {n N : ι → ℕ}
    {J : ∀ i, ℕ → Bits (n i) → ℂ} {tt : ι → ℕ} {e : ∀ i, Bits (n i)}
    (ht : Has m B s (jobsT cl) x (fun i => jobsTape (n i) (N i) (J i)))
    (hix : Knows m B s x tt) (hlt : ∀ i, tt i < N i)
    (he : Knows m B s x (fun i => (bits (n i)).loc (e i))) :
    Has m B s (c cl) x (fun i => J i (tt i) (e i)) := by
  have h1 : Has m B s (a (c cl)) x (fun i => (bits (n i)).tape (J i (tt i))) :=
    Can.fetch (t := a (c cl)) (L := fun i => Layout.std (N i))
      (v := fun i t => (bits (n i)).tape (J i t.val)) (i := fun i => ⟨tt i, hlt i⟩) ht hix
  exact Can.fetch (t := c cl) (L := fun i => bits (n i)) (v := fun i => J i (tt i)) (i := e) h1 he

lemma has_jobsAt {B : ι → ℕ} {s : Ty} {x : ι → T s} {cl : Paint} {n N : ι → ℕ}
    {J : ∀ i, ℕ → Bits (n i) → ℂ} {tt : ι → ℕ}
    (ht : Has m B s (jobsT cl) x (fun i => jobsTape (n i) (N i) (J i)))
    (hix : Knows m B s x tt) (hlt : ∀ i, tt i < N i) :
    Has m B s (a (c cl)) x (fun i => (bits (n i)).tape (J i (tt i))) :=
  Can.fetch (t := a (c cl)) (L := fun i => Layout.std (N i))
    (v := fun i t => (bits (n i)).tape (J i t.val)) (i := fun i => ⟨tt i, hlt i⟩) ht hix

lemma can_ptrTape {B : ι → ℕ} {s t : Ty} {x : ι → T s} {N : ι → ℕ} {v : ∀ i, ℕ → T t}
    (hN : Knows m B s x N) (hNs : Small B N)
    (hel : Has m (fun u : UnitF N => B u.1) (p s w) t (fun u => (x u.1, u.2.val)) (fun u => v u.1 u.2.val)) :
    Can m B s (a t) x (fun i => (Layout.std (N i)).tape (fun j => v i j.val)) (fun i => N i + 1) := by
  have H := Can.layout (m := m) (t := t) (L := fun i => Layout.std (N i)) (v := fun i j => v i j.val)
    (P := fun _ => 0) (W := fun _ => 0) hN hel hNs
  refine H.mono (fun i => ?_)
  show 0 + N i + N i * 0 ≤ N i + 1
  omega

end Kit

section KitCtab
universe V
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
variable {ι : Type U} {m : Bool} {cl : Paint}

lemma fleet_n (X : Layout α) (R : Layout ρ) (f : ℕ) : (fleet X R 0 f).n = R.n * 2^(X.n * f) := by
  show R.n * (book X 0 f).n = _
  rw [book_len, Nat.add_zero]

abbrev InstF {ι : Type U} (NU : ι → ℕ) (ib : ι → ℕ → ℕ) := Σ u : UnitF NU, Bits (ib u.1 u.2)

lemma can_ctab (X : Layout α) (R : Layout ρ) {B : ι → ℕ} {s : Ty} {x : ι → T s}
    {NU : ι → ℕ} {col ib : ι → ℕ → ℕ}
    {V' : ∀ i, ∀ p : Fin (NU i), Bits (ib i p) → Grain α ρ 0 (col i p)}
    (hNU : Knows m B s x NU) (hNUs : Small B NU)
    (hib : Knows m (fun u : UnitF NU => B u.1) (p s w) (fun u => (x u.1, u.2.val))
      (fun u => 2^(ib u.1 u.2)))
    (hibs : Small (fun u : UnitF NU => B u.1) (fun u => 2^(ib u.1 u.2)))
    {P : ι → ℕ} (hP : ∀ u : UnitF NU, 2^(ib u.1 u.2) + 2^(ib u.1 u.2) * (R.n * 2^(X.n * col u.1 u.2)) ≤ P u.1)
    (hin : Can m (fun v : InstF NU ib => B v.1.1) (p (p s w) w) (a (c cl))
      (fun v => ((x v.1.1, v.1.2.val), (bits (ib v.1.1 v.1.2)).loc v.2))
      (fun v => (fleet X R 0 (col v.1.1 v.1.2)).tape (V' v.1.1 v.1.2 v.2))
      (fun v => R.n * 2^(X.n * col v.1.1 v.1.2))) :
    Can m B s (a (a (a (c cl)))) x (fun i => ctab X R (NU i) (col i) (ib i) (V' i))
      (fun i => NU i + NU i * P i) := by
  -- same shape as ckpt3's ctab_build: the costs never mention `fleet .. |>.n` or `(bits ..).n`
  have HI := Can.layout (m := m) (t := a (c cl)) (L := fun u : UnitF NU => bits (ib u.1 u.2))
    (v := fun u q => (fleet X R 0 (col u.1 u.2)).tape (V' u.1 u.2 q))
    (P := fun u => R.n * 2^(X.n * col u.1 u.2)) (W := fun _ => 0) hib hin hibs
  have HI' : Can m (fun u : UnitF NU => B u.1) (p s w) (a (a (c cl))) (fun u => (x u.1, u.2.val))
      (fun u => (bits (ib u.1 u.2)).tape (fun q => (fleet X R 0 (col u.1 u.2)).tape (V' u.1 u.2 q)))
      (fun u => P u.1) := by
    refine HI.mono (fun u => ?_)
    have := hP u
    change 0 + 2^(ib u.1 u.2) + 2^(ib u.1 u.2) * (R.n * 2^(X.n * col u.1 u.2)) ≤ _
    omega
  have HO := Can.layout (m := m) (t := a (a (c cl))) (L := fun i => Layout.std (NU i))
    (v := fun i p => (bits (ib i p)).tape (fun q => (fleet X R 0 (col i p)).tape (V' i p q)))
    (P := P) (W := fun _ => 0) hNU HI' hNUs
  refine HO.mono (fun i => ?_)
  change 0 + NU i + NU i * P i ≤ NU i + NU i * P i
  omega

abbrev ctabT (cl : Paint) : Ty := a (a (a (c cl)))

lemma has_ctabInst (X : Layout α) (R : Layout ρ) {κ : Type V} {Bk : κ → ℕ} {sk : Ty} {y : κ → T sk}
    {NU : κ → ℕ} {col ib : κ → ℕ → ℕ}
    {V' : ∀ k, ∀ p : Fin (NU k), Bits (ib k p) → Grain α ρ 0 (col k p)}
    (pu : ∀ k, Fin (NU k)) (qu : ∀ k, Bits (ib k (pu k)))
    (ht : Has m Bk sk (a (a (a (c cl)))) y (fun k => ctab X R (NU k) (col k) (ib k) (V' k)))
    (hp : Knows m Bk sk y (fun k => (pu k).val))
    (hq : Knows m Bk sk y (fun k => (bits (ib k (pu k))).loc (qu k))) :
    Has m Bk sk (a (c cl)) y (fun k => (fleet X R 0 (col k (pu k))).tape (V' k (pu k) (qu k))) := by
  have h1 : Has m Bk sk (a (a (c cl))) y
      (fun k => (bits (ib k (pu k))).tape (fun q => (fleet X R 0 (col k (pu k))).tape (V' k (pu k) q))) :=
    Can.fetch (t := a (a (c cl))) (L := fun k => Layout.std (NU k))
      (v := fun k p => (bits (ib k p)).tape (fun q => (fleet X R 0 (col k p)).tape (V' k p q)))
      (i := pu) ht hp
  exact Can.fetch (t := a (c cl)) (L := fun k => bits (ib k (pu k)))
    (v := fun k q => (fleet X R 0 (col k (pu k))).tape (V' k (pu k) q)) (i := qu) h1 hq

lemma has_ctabRead (X : Layout α) (R : Layout ρ) {κ : Type V} {Bk : κ → ℕ} {sk : Ty} {y : κ → T sk}
    {NU : κ → ℕ} {col ib : κ → ℕ → ℕ}
    {V' : ∀ k, ∀ p : Fin (NU k), Bits (ib k p) → Grain α ρ 0 (col k p)}
    (pu : ∀ k, Fin (NU k)) (qu : ∀ k, Bits (ib k (pu k))) (bu : ∀ k, Beach α ρ 0 (col k (pu k)))
    (ht : Has m Bk sk (a (a (a (c cl)))) y (fun k => ctab X R (NU k) (col k) (ib k) (V' k)))
    (hp : Knows m Bk sk y (fun k => (pu k).val))
    (hq : Knows m Bk sk y (fun k => (bits (ib k (pu k))).loc (qu k)))
    (hb : Knows m Bk sk y (fun k => (fleet X R 0 (col k (pu k))).loc (bu k))) :
    Has m Bk sk (c cl) y (fun k => V' k (pu k) (qu k) (bu k)) := by
  have h1 : Has m Bk sk (a (a (c cl))) y
      (fun k => (bits (ib k (pu k))).tape (fun q => (fleet X R 0 (col k (pu k))).tape (V' k (pu k) q))) :=
    Can.fetch (t := a (a (c cl))) (L := fun k => Layout.std (NU k))
      (v := fun k p => (bits (ib k p)).tape (fun q => (fleet X R 0 (col k p)).tape (V' k p q)))
      (i := pu) ht hp
  have h2 : Has m Bk sk (a (c cl)) y (fun k => (fleet X R 0 (col k (pu k))).tape (V' k (pu k) (qu k))) :=
    Can.fetch (t := a (c cl)) (L := fun k => bits (ib k (pu k)))
      (v := fun k q => (fleet X R 0 (col k (pu k))).tape (V' k (pu k) q)) (i := qu) h1 hq
  exact Can.fetch (t := c cl) (L := fun k => fleet X R 0 (col k (pu k))) (v := fun k => V' k (pu k) (qu k))
    (i := bu) h2 hb

end KitCtab

namespace CCtx
universe V
variable {ι : Type U} {m : Bool} {B : ι → ℕ} {s : Ty} {x : ι → T s} {mx : ℕ}
  {n NU : ι → ℕ} {col ib : ι → ℕ → ℕ}
variable (c : CCtx m B s x mx n NU col ib)
include c

lemma pow_col_le (i : ι) (p : Fin (NU i)) : 2^(col i p) ≤ 2^(n i) :=
  Nat.pow_le_pow_right (by omega) (c.col_le i p)

lemma pow_ib_le (i : ι) (p : Fin (NU i)) : 2^(ib i p) ≤ 2^(n i) :=
  Nat.pow_le_pow_right (by omega) (c.ib_le i p)

lemma gearU : Gear m (fun u : UnitF NU => B u.1) (fun u => col u.1 u.2) (p s w) (fun u => (x u.1, u.2.val)) :=
  ⟨unit_fetch (m := m) (B := B) (s := s) (x := x) (t := w) (fun i (p : Fin (NU i)) => 2^(col i p)) c.tpc,
   unit_fetch (m := m) (B := B) (s := s) (x := x) (t := w) (fun i (p : Fin (NU i)) => col i p) c.tc,
   unit_fetch (m := m) (B := B) (s := s) (x := x) (t := a w) (fun i (p : Fin (NU i)) => xorTab (col i p)) c.txr,
   (c.big.reindex (fun u : UnitF NU => u.1)).mono (fun u => c.pow_col_le u.1 u.2)⟩

lemma lumU : Has m (fun u : UnitF NU => B u.1) (p s w) (a sc) (fun u => (x u.1, u.2.val))
    (fun u => (bits (col u.1 u.2)).tape (fun y : Bits (col u.1 u.2) => lum y)) :=
  unit_fetch (m := m) (B := B) (s := s) (x := x) (t := a sc) (fun i (p : Fin (NU i)) => (bits (col i p)).tape (fun y : Bits (col i p) => lum y)) c.tlum

lemma p2ibU : Knows m (fun u : UnitF NU => B u.1) (p s w) (fun u => (x u.1, u.2.val))
    (fun u => 2^(ib u.1 u.2)) :=
  unit_fetch (m := m) (B := B) (s := s) (x := x) (t := w) (fun i (p : Fin (NU i)) => 2^(ib i p)) c.tpib

lemma p2ibS : Small (fun u : UnitF NU => B u.1) (fun u => 2^(ib u.1 u.2)) :=
  (c.big.reindex (fun u : UnitF NU => u.1)).mono (fun u => c.pow_ib_le u.1 u.2)

lemma unit_size {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
    (X : Layout α) (R : Layout ρ) (hX : X.n = mx) (i : ι) (p : Fin (NU i)) :
    2^(ib i p) * (fleet X R 0 (col i p)).n = R.n * 2^(n i) := by
  rw [fleet_n, hX, ← c.fit i p, Nat.pow_add]
  ac_rfl

end CCtx

namespace GMove
variable {α ρ : Type*}

lemma rk_cases (mv : GMove α ρ) :
    mv.rk? = none ∨ ∃ l r z ind, mv = GMove.old (BMove.block l r z ind) := by
  cases mv with
  | old b =>
    cases b with
    | localM g => exact Or.inl rfl
    | shift l z => exact Or.inl rfl
    | block l r z ind => exact Or.inr ⟨l, r, z, ind, rfl⟩
  | perm l G => exact Or.inl rfl
  | phase l z c => exact Or.inl rfl
  | localG gr gi => exact Or.inl rfl

lemma rk_block (l : ρ) (r : ℕ) (z : Fin r → Space α) (ind : LinearIndependent F z) :
    (GMove.old (BMove.block l r z ind)).rk? = some r := rfl

end GMove

end
end PowerSaving.RAM
end OAI
