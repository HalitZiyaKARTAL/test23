import Submission.Work.MixedCost.EngineFinal
import Submission.Work.BlockApply.Exact


namespace OAI
namespace PowerSaving.PB
open Binary Matrix Finset GF MX RAM

noncomputable section

universe U

section Words
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

lemma rk_bounds {u r : ℕ} {mv : GMove α ρ} (hp : mv.Proper u) (hr : mv.rk? = some r) : 1 ≤ r ∧ r < u := by
  cases mv with
  | old mv =>
    cases mv with
    | localM g => exact absurd hr (by simp [GMove.rk?, GMove.shadow, BMove.rk?])
    | shift l z => exact absurd hr (by simp [GMove.rk?, GMove.shadow, BMove.rk?])
    | block l rk z ind =>
      have hr' : rk = r := by simpa [GMove.rk?, GMove.shadow, BMove.rk?] using hr
      subst hr'
      exact hp
  | perm l G => exact absurd hr (by simp [GMove.rk?, GMove.shadow, BMove.rk?])
  | phase l z c => exact absurd hr (by simp [GMove.rk?, GMove.shadow, BMove.rk?])
  | localG gr gi => exact absurd hr (by simp [GMove.rk?, GMove.shadow, BMove.rk?])

lemma mem_blockRanks {w : GWord α ρ} {r : ℕ} : r ∈ Eng.blockRanks w ↔ ∃ mv ∈ w, mv.rk? = some r := by
  unfold Eng.blockRanks
  exact List.mem_filterMap

end Words

section EngFacts
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]

lemma rkI_mem (E : Eng α ρ σ) (j : Fin E.nB) : ∃ mv ∈ E.wd, mv.rk? = some (E.rkI j) := by
  have hj : (j : ℕ) < (Eng.blockRanks E.wd).length := j.2
  have : E.rkI j = (Eng.blockRanks E.wd)[(j : ℕ)] := by
    unfold Eng.rkI
    exact List.getD_eq_getElem _ _ hj
  rw [this]
  exact mem_blockRanks.mp (List.getElem_mem hj)

lemma rkI_pos (E : Eng α ρ σ) (j : Fin E.nB) : 1 ≤ E.rkI j := by
  obtain ⟨mv, hmv, hr⟩ := rkI_mem E j
  exact (rk_bounds (E.hP mv hmv) hr).1

lemma rkI_le (E : Eng α ρ σ) {rmax : ℕ} (hwr : ∀ mv ∈ E.wd, ∀ r, mv.rk? = some r → r ≤ rmax)
    (j : Fin E.nB) : E.rkI j ≤ rmax := by
  obtain ⟨mv, hmv, hr⟩ := rkI_mem E j
  exact hwr mv hmv _ hr

lemma tq_of_lt (E : Eng α ρ σ) (i : Fin E.W) : E.tq i = E.tr (E.Q.atFin i) := by
  unfold Eng.tq
  rw [dif_pos i.2]

end EngFacts

end
end PowerSaving.PB
end OAI

