
namespace OAI.PowerSaving.EngArith

theorem div_join {a b n : Nat} (hb : b < n) : (a * n + b) / n = a := by
  have hn : 0 < n := Nat.lt_of_le_of_lt (Nat.zero_le _) hb
  rw [Nat.add_comm, Nat.add_mul_div_right _ _ hn, Nat.div_eq_of_lt hb, Nat.zero_add]

theorem mod_join {a b n : Nat} (hb : b < n) : (a * n + b) % n = b := by
  rw [Nat.add_comm, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt hb]

theorem lt_join {a b m n : Nat} (h : a < m) (g : b < n) : a * n + b < m * n := by
  have : (a + 1) * n ≤ m * n := Nat.mul_le_mul_right _ h
  rw [Nat.succ_mul] at this
  omega

theorem div_join' {a b n : Nat} (hb : b < n) : (b + n * a) / n = a := by
  rw [Nat.mul_comm, Nat.add_comm]; exact div_join hb

theorem mod_join' {a b n : Nat} (hb : b < n) : (b + n * a) % n = b := by
  rw [Nat.mul_comm, Nat.add_comm]; exact mod_join hb

theorem split_join (t n : Nat) : t / n * n + t % n = t := by
  have := Nat.div_add_mod t n
  rw [Nat.mul_comm] at this
  exact this

theorem succ_mul_le_of_lt_div {c B N : Nat} (h : c < B / N) : (c + 1) * N ≤ B := by
  have h1 : (c + 1) * N ≤ B / N * N := Nat.mul_le_mul_right _ h
  exact Nat.le_trans h1 (Nat.div_mul_le_self B N)

theorem sub_div_mul (B N : Nat) : B - B / N * N = B % N := by
  have := split_join B N
  omega

theorem grp_lt {c j B N : Nat} (hc : c < B / N) (hj : j < N) : c * N + j < B := by
  have := succ_mul_le_of_lt_div hc
  rw [Nat.succ_mul] at this
  omega

theorem getD_append_left {β : Type _} (L M : List β) (z : β) {k : Nat} (hk : k < L.length) :
    (L ++ M).getD k z = L.getD k z := by
  simp [List.getD_eq_getElem?_getD, List.getElem?_append_left hk]

theorem getD_append_right {β : Type _} (L M : List β) (z : β) (k : Nat) :
    (L ++ M).getD (L.length + k) z = M.getD k z := by
  simp [List.getD_eq_getElem?_getD, List.getElem?_append_right (Nat.le_add_right _ _)]

theorem split3_eq (a b c P Q : Nat) : a + P * b + P * Q * c = a + P * (b + Q * c) := by
  rw [Nat.mul_add, Nat.mul_assoc, Nat.add_assoc]

theorem split3_mod {a b c P Q : Nat} (ha : a < P) : (a + P * b + P * Q * c) % P = a := by
  rw [split3_eq, Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt ha]

theorem split3_mid {a b c P Q : Nat} (ha : a < P) (hb : b < Q) :
    (a + P * b + P * Q * c) / P % Q = b := by
  have hP : 0 < P := Nat.lt_of_le_of_lt (Nat.zero_le _) ha
  rw [split3_eq, Nat.add_mul_div_left _ _ hP, Nat.div_eq_of_lt ha, Nat.zero_add,
    Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hb]

theorem split3_low {a b P Q : Nat} (ha : a < P) (hb : b < Q) : a + P * b < P * Q := by
  have h1 : P * (b + 1) ≤ P * Q := Nat.mul_le_mul_left P hb
  rw [Nat.mul_succ] at h1
  omega

theorem split3_div {a b c P Q : Nat} (ha : a < P) (hb : b < Q) :
    (a + P * b + P * Q * c) / (P * Q) = c := by
  have hl := split3_low ha hb
  have hPQ : 0 < P * Q := Nat.lt_of_le_of_lt (Nat.zero_le _) hl
  rw [Nat.add_mul_div_left _ _ hPQ, Nat.div_eq_of_lt hl, Nat.zero_add]

theorem split3_parts {a b c P Q T : Nat} (h : a + P * b + P * Q * c = T) :
    a ≤ T ∧ P * b ≤ T ∧ P * Q * c ≤ T ∧ a + P * b ≤ T := by
  omega

theorem le_mul_of_one_le {b P : Nat} (hP : 1 ≤ P) : b ≤ P * b := by
  have := Nat.mul_le_mul_right b hP
  rw [Nat.one_mul] at this
  exact this

end OAI.PowerSaving.EngArith
