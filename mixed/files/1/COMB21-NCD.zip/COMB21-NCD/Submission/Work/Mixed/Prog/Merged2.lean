import Submission.Work.Mixed.Prog.ClassTabs

namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

universe U

lemma CIn.child {ι : Type U} {m : Bool} {B : ι → ℕ} {s : Ty} {x : ι → T s} {n h μ : ι → ℕ}
    (c : CIn m B s x n (fun i => h i + 1) μ) (r : ℕ) :
    CIn m B s x n h (fun i => μ i * r) :=
  ⟨c.nK, (c.hK.minus (Can.wc 1) c.hS).cong (fun _ => rfl) (fun i => Nat.add_sub_cancel _ _),
    c.μK.times (Can.wc r) c.μS (Small.const _ r), c.p2n, c.imag, c.big,
    fun i => Nat.le_of_succ_le (c.hle i), c.μS.mul (Small.const _ r)⟩

namespace Gear
universe V
variable {ι : Type V} {m : Bool} {B : ι → ℕ} {s : Ty} {x : ι → T s} {f : ι → ℕ}
variable (g : Gear m B f s x)
include g
variable {α β : Type*} [Fintype α] [DecidableEq α] [Fintype β] [DecidableEq β] {k : ℕ}

omit g in
lemma grid0 (y : Grid α 0 k) : ((0 : Bits 0), y.2) = y :=
  Prod.ext (Subsingleton.elim _ _) rfl

omit g in
lemma place_split (X : Layout α) (S : Split α β (Fin k)) (X' : Layout β) (f0 r0 n0 : ℕ)
    (hh : k*f0 + X'.n*f0 + r0 = n0) (q : Bits r0) (y : Sky α f0) :
    (bits (k*f0)).loc (S.peel 0 f0 ((0 : Bits 0), y)).2 +
      2^(k*f0) * (book X' 0 f0).loc (S.peel 0 f0 ((0 : Bits 0), y)).1 +
      2^(k*f0) * 2^(X'.n*f0) * (bits r0).loc q =
    (bits n0).loc (placeS S X' f0 r0 n0 hh (q, y)) := by
  rw [placeS_loc, Nat.pow_add]

omit g in
lemma place_lt (S : Split α β (Fin k)) (X' : Layout β) (f0 : ℕ) (y : Sky α f0) :
    (bits (k*f0)).loc (S.peel 0 f0 ((0 : Bits 0), y)).2 < 2^(k*f0) ∧
      (book X' 0 f0).loc (S.peel 0 f0 ((0 : Bits 0), y)).1 < 2^(X'.n*f0) := by
  constructor
  · have := (bits (k*f0)).bd (S.peel 0 f0 ((0 : Bits 0), y)).2
    rwa [bits_len] at this
  · have := (book X' 0 f0).bd (S.peel 0 f0 ((0 : Bits 0), y)).1
    rwa [book_len, Nat.add_zero] at this

lemma place_enc (X : Layout α) (S : Split α β (Fin k)) (X' : Layout β) (hX' : X'.n + k = X.n)
    {r n : ι → ℕ} (hfit : ∀ i, X.n * f i + r i = n i) (hbig : Small B (fun i => 2^(n i)))
    (q : ∀ i, Bits (r i)) (y : ∀ i, Sky α (f i))
    (hq : Knows m B s x (fun i => (bits (r i)).loc (q i)))
    (hy : Knows m B s x (fun i => (book X 0 (f i)).loc ((0 : Bits 0), y i))) :
    Knows m B s x (fun i => (bits (n i)).loc
      (placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i)) (q i, y i))) := by
  obtain ⟨hb, ha⟩ := g.from_gridB X 0 S X' (fun i => ((0 : Bits 0), y i)) hy
  have hT := fun i => place_split X S X' (f i) (r i) (n i) (fitk X' hX' (hfit i)) (q i) (y i)
  have hlt : ∀ i, (bits (n i)).loc (placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i)) (q i, y i))
      ≤ 2^(n i) := fun i => ((bits (n i)).bd _).le
  have hP1 : ∀ i, 1 ≤ 2^(k * f i) := fun i => Nat.one_le_two_pow
  have hQ1 : ∀ i, 1 ≤ 2^(k * f i) * 2^(X'.n * f i) := fun i => Nat.mul_pos (Nat.two_pow_pos _) (Nat.two_pow_pos _)
  have hkn : ∀ i, k * f i ≤ n i := fun i => by have := fitk X' hX' (hfit i); omega
  have hkq : ∀ i, k * f i + X'.n * f i ≤ n i := fun i => by have := fitk X' hX' (hfit i); omega
  have sA : Small B (fun i => (bits (k * f i)).loc (S.peel 0 (f i) ((0 : Bits 0), y i)).2) :=
    hbig.mono (fun i => le_trans (EngArith.split3_parts (hT i)).1 (hlt i))
  have sPB : Small B (fun i => 2^(k * f i) * (book X' 0 (f i)).loc (S.peel 0 (f i) ((0 : Bits 0), y i)).1) :=
    hbig.mono (fun i => le_trans (EngArith.split3_parts (hT i)).2.1 (hlt i))
  have sB : Small B (fun i => (book X' 0 (f i)).loc (S.peel 0 (f i) ((0 : Bits 0), y i)).1) :=
    sPB.mono (fun i => EngArith.le_mul_of_one_le (hP1 i))
  have sPQC : Small B (fun i => 2^(k * f i) * 2^(X'.n * f i) * (bits (r i)).loc (q i)) :=
    hbig.mono (fun i => le_trans (EngArith.split3_parts (hT i)).2.2.1 (hlt i))
  have sC : Small B (fun i => (bits (r i)).loc (q i)) :=
    sPQC.mono (fun i => EngArith.le_mul_of_one_le (hQ1 i))
  have sAPB : Small B (fun i => (bits (k * f i)).loc (S.peel 0 (f i) ((0 : Bits 0), y i)).2 +
      2^(k * f i) * (book X' 0 (f i)).loc (S.peel 0 (f i) ((0 : Bits 0), y i)).1) :=
    hbig.mono (fun i => le_trans (EngArith.split3_parts (hT i)).2.2.2 (hlt i))
  have sP : Small B (fun i => 2^(k * f i)) :=
    hbig.mono (fun i => Nat.pow_le_pow_right (by omega) (hkn i))
  have sQ : Small B (fun i => 2^(X'.n * f i)) :=
    hbig.mono (fun i => Nat.pow_le_pow_right (by omega) (by have := hkq i; omega))
  have sPQ : Small B (fun i => 2^(k * f i) * 2^(X'.n * f i)) :=
    hbig.mono (fun i => by rw [← Nat.pow_add]; exact Nat.pow_le_pow_right (by omega) (hkq i))
  have hP := g.powerB k
  have hQ := g.powerB X'.n
  have hPB := hP.times hb sP sB
  have hPQC := (hP.times hQ sP sQ).times hq sPQ sC
  exact ((ha.plus hPB sA sPB).plus hPQC sAPB sPQC).cong (fun _ => rfl) (fun i => hT i)

lemma place_dec (X : Layout α) (S : Split α β (Fin k)) (X' : Layout β) (hX' : X'.n + k = X.n)
    {r n : ι → ℕ} (hfit : ∀ i, X.n * f i + r i = n i) (hbig : Small B (fun i => 2^(n i)))
    (e : ∀ i, Bits (n i)) (he : Knows m B s x (fun i => (bits (n i)).loc (e i))) :
    Knows m B s x (fun i => (bits (r i)).loc
      ((placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i))).symm (e i)).1) ∧
    Knows m B s x (fun i => (book X 0 (f i)).loc ((0 : Bits 0),
      ((placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i))).symm (e i)).2)) := by
  have hT : ∀ i, (bits (k * f i)).loc (S.peel 0 (f i) ((0 : Bits 0),
        ((placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i))).symm (e i)).2)).2 +
      2^(k * f i) * (book X' 0 (f i)).loc (S.peel 0 (f i) ((0 : Bits 0),
        ((placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i))).symm (e i)).2)).1 +
      2^(k * f i) * 2^(X'.n * f i) *
        (bits (r i)).loc ((placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i))).symm (e i)).1 =
      (bits (n i)).loc (e i) := by
    intro i
    rw [place_split X S X' (f i) (r i) (n i) (fitk X' hX' (hfit i)), Prod.mk.eta, Equiv.apply_symm_apply]
  have hlt := fun i => place_lt S X' (f i)
    ((placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i))).symm (e i)).2
  have hkq : ∀ i, k * f i + X'.n * f i ≤ n i := fun i => by have := fitk X' hX' (hfit i); omega
  have sT : Small B (fun i => (bits (n i)).loc (e i)) := hbig.mono (fun i => ((bits (n i)).bd _).le)
  have hP := g.powerB k
  have hQ := g.powerB X'.n
  have sP : Small B (fun i => 2^(k * f i)) :=
    hbig.mono (fun i => Nat.pow_le_pow_right (by omega) (by have := hkq i; omega))
  have sQ : Small B (fun i => 2^(X'.n * f i)) :=
    hbig.mono (fun i => Nat.pow_le_pow_right (by omega) (by have := hkq i; omega))
  have hPQ := hP.times hQ sP sQ
  have hC : Knows m B s x (fun i => (bits (r i)).loc
      ((placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i))).symm (e i)).1) :=
    (he.dvdW hPQ sT).cong (fun _ => rfl)
      (fun i => by rw [← hT i]; exact EngArith.split3_div (hlt i).1 (hlt i).2)
  have hA : Knows m B s x (fun i => (bits (k * f i)).loc (S.peel 0 (f i) ((0 : Bits 0),
      ((placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i))).symm (e i)).2)).2) :=
    (he.modW hP sT).cong (fun _ => rfl)
      (fun i => by rw [← hT i]; exact EngArith.split3_mod (hlt i).1)
  have hB : Knows m B s x (fun i => (book X' 0 (f i)).loc (S.peel 0 (f i) ((0 : Bits 0),
      ((placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i))).symm (e i)).2)).1) :=
    ((he.dvdW hP sT).modW hQ sT.div).cong (fun _ => rfl)
      (fun i => by rw [← hT i]; exact EngArith.split3_mid (hlt i).1 (hlt i).2)
  refine ⟨hC, ?_⟩
  have hg := g.to_gridB X 0 S X'
    (fun i => S.peel 0 (f i) ((0 : Bits 0),
      ((placeS S X' (f i) (r i) (n i) (fitk X' hX' (hfit i))).symm (e i)).2)) hB hA
  exact hg.cong (fun _ => rfl) (fun i => by rw [Equiv.symm_apply_apply])

lemma fleet_join {ρ : Type*} (X : Layout α) (R : Layout ρ) (l : ι → ρ) (gr : ∀ i, Grid α 0 (f i))
    (hl : Knows m B s x (fun i => R.loc (l i)))
    (hg : Knows m B s x (fun i => (book X 0 (f i)).loc (gr i))) :
    Knows m B s x (fun i => (fleet X R 0 (f i)).loc (l i, gr i)) :=
  Can.addr_join (L := fun _ => R) (R := fun i => book X 0 (f i)) (u := fun i => (l i, gr i)) hl hg
    (g.grid_size X 0) (Small.const _ R.n) (g.grid_small X 0)

lemma fleet_split {ρ : Type*} (X : Layout α) (R : Layout ρ) (u : ∀ i, Beach α ρ 0 (f i))
    (h : Knows m B s x (fun i => (fleet X R 0 (f i)).loc (u i))) :
    Knows m B s x (fun i => R.loc (u i).1) ∧ Knows m B s x (fun i => (book X 0 (f i)).loc (u i).2) :=
  ⟨Can.addr_high (L := fun _ => R) (R := fun i => book X 0 (f i)) (u := u) h (g.grid_size X 0)
      ((Small.const _ R.n).mul (g.grid_small X 0)),
   Can.addr_low (L := fun _ => R) (R := fun i => book X 0 (f i)) (u := u) h (g.grid_size X 0)
      ((Small.const _ R.n).mul (g.grid_small X 0))⟩

lemma fleet_size {ρ : Type*} (X : Layout α) (R : Layout ρ) :
    Knows m B s x (fun i => (fleet X R 0 (f i)).n) :=
  (Can.wc R.n).times (g.grid_size X 0) (Small.const _ R.n) (g.grid_small X 0)

lemma fleet_small {ρ : Type*} (X : Layout α) (R : Layout ρ) :
    Small B (fun i => (fleet X R 0 (f i)).n) :=
  (Small.const _ R.n).mul (g.grid_small X 0)

end Gear

section Free
universe V
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
variable {m : Bool} {cl : Paint}

lemma free_inst {κ : Type V} {Bk : κ → ℕ} {f : κ → ℕ} {sk : Ty} {y : κ → T sk}
    {X : Layout α} {R : Layout ρ} {v : ∀ k, Grain α ρ 0 (f k)}
    (hR : GRig m Bk f sk y cl X R 0 v) (mv : GMove α ρ) (hmv : mv.rk? = none) :
    Can m Bk sk (a (Ty.c cl)) y (fun k => (fleet X R 0 (f k)).tape (gferry 0 (f k) mv (v k)))
      (fun k => (fleet X R 0 (f k)).n) := by
  cases mv with
  | old b =>
    cases b with
    | localM g => exact hR.rig.point_cost g
    | shift l z => exact hR.rig.shift_cost l z
    | block l r z ind => exact absurd hmv (by simp [GMove.rk?, GMove.shadow, BMove.rk?])
  | perm l G => exact hR.rig.perm_cost l G
  | phase l z c' => exact hR.phase_cost l z c'
  | localG gr gi => exact hR.rig.pointG_cost gr gi

end Free

lemma len_fm_count {β : Type*} (P : ℕ → Prop) [DecidablePred P] (g : ℕ → β) (N : ℕ) :
    ((List.range N).filterMap (fun t => if P t then some (g t) else none)).length = Nat.count P N := by
  induction N with
  | zero => simp
  | succ N ih =>
    rw [List.range_succ, List.filterMap_append, List.length_append, ih, Nat.count_succ]
    by_cases hp : P N <;> simp [hp]

lemma getD_fm_nth (P : ℕ → Prop) [DecidablePred P] (g : ℕ → ℕ) (N j : ℕ) (hj : j < Nat.count P N) :
    ((List.range N).filterMap (fun t => if P t then some (g t) else none)).getD j 0 = g (Nat.nth P j) := by
  induction N with
  | zero => simp at hj
  | succ N ih =>
    rw [List.range_succ, List.filterMap_append]
    rw [Nat.count_succ] at hj
    by_cases hjN : j < Nat.count P N
    · rw [EngArith.getD_append_left _ _ _ (by rw [len_fm_count]; exact hjN)]
      exact ih hjN
    · have hPN : P N := by
        by_contra hn
        simp only [hn, if_false, Nat.add_zero] at hj
        exact hjN hj
      have hj' : j = Nat.count P N := by
        simp only [hPN, if_true] at hj
        omega
      have hl := len_fm_count P g N
      subst hj'
      have e1 : ((List.range N).filterMap (fun t => if P t then some (g t) else none) ++
          [N].filterMap (fun t => if P t then some (g t) else none)).getD (Nat.count P N) 0 =
          ([N].filterMap (fun t => if P t then some (g t) else none)).getD 0 0 := by
        have := EngArith.getD_append_right ((List.range N).filterMap (fun t => if P t then some (g t) else none))
          ([N].filterMap (fun t => if P t then some (g t) else none)) 0 0
        rwa [Nat.add_zero, hl] at this
      rw [e1, Nat.nth_count hPN]
      simp [hPN]

def accA (n : ℕ) (L : List ℕ) (o : ℕ) (sup : ℕ → Bits n → ℂ) : Tape (Tape ℂ) :=
  jobsTape n L.length (fun k => hlow n (L.getD k 0) (sup (o + k)))

def accZ (L : List ℕ) : Tape ℕ := (Layout.std L.length).tape (fun k => L.getD k 0)

abbrev SwT (s : Ty) (cl : Paint) : Ty := p s (p (ctabT cl) (p (jobsT cl) (a w)))

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable (E : Eng α ρ σ)

def rtCost (n h μ r : ℕ) : ℕ :=
  E.idxCost n h (μ * r) + 8 * (E.W^(h+1) + 1) * (E.W^(h+1) + 1) * (h + 3) + 8

def roleAt (t : ℕ) : σ := E.Q.atFin ⟨t % E.W, Nat.mod_lt _ E.W_pos⟩

lemma roleAt_loc (t : ℕ) : E.Q.loc (E.roleAt t) = t % E.W := by
  unfold roleAt
  simp

lemma tq_mod (t : ℕ) : E.tq (t % E.W) = E.tr (E.roleAt t) := by
  rw [← E.roleAt_loc, E.tq_loc]

def unl (n h μ : ℕ) (V : E.CState n h μ) (t : ℕ) : Bits n → ℂ :=
  if hp : t / E.W < E.NUc n h μ then
    fun e => V ⟨t / E.W, hp⟩ ((E.placeT n h μ ⟨t / E.W, hp⟩ (E.roleAt t)).symm e).1
      (E.e (E.roleAt t), (0, ((E.placeT n h μ ⟨t / E.W, hp⟩ (E.roleAt t)).symm e).2))
  else fun _ => 0

lemma unl_eq (n h μ : ℕ) (V : E.CState n h μ) (t : ℕ) (hp : t / E.W < E.NUc n h μ) (l : σ)
    (hl : E.roleAt t = l) (e : Bits n) :
    E.unl n h μ V t e = V ⟨t / E.W, hp⟩ ((E.placeT n h μ ⟨t / E.W, hp⟩ l).symm e).1
      (E.e l, (0, ((E.placeT n h μ ⟨t / E.W, hp⟩ l).symm e).2)) := by
  subst hl
  unfold unl
  rw [dif_pos hp]

lemma V0_live (n h μ : ℕ) (J : ℕ → Bits n → ℂ) (p : Fin (E.NUc n h μ)) (q : Bits (E.iUc n h μ p))
    (l : σ) (g : Grid α 0 (E.cUc n h μ p)) :
    E.V0 n h μ J p q (E.e l, g) = J (p.val * E.W + E.Q.loc l) (E.placeT n h μ p l (q, g.2)) := by
  unfold V0
  simp only [E.liveOf_e]

lemma V0_dead (n h μ : ℕ) (J : ℕ → Bits n → ℂ) (p : Fin (E.NUc n h μ)) (q : Bits (E.iUc n h μ p))
    (l' : ρ) (hl : ∀ l, E.e l ≠ l') (g : Grid α 0 (E.cUc n h μ p)) :
    E.V0 n h μ J p q (l', g) = 0 := by
  unfold V0
  simp only [E.liveOf_none l' hl]

theorem unl_run (n h μ : ℕ) (J : ℕ → Bits n → ℂ) (t : ℕ) (ht : t < E.NUc n h μ * E.W) :
    E.unl n h μ (E.runV (E.V0 n h μ J) E.wd) t = hlow n (E.slotSize n h μ t) (J t) := by
  have hp : t / E.W < E.NUc n h μ := (Nat.div_lt_iff_lt_mul E.W_pos).2 ht
  have hsz : E.slotSize n h μ t = E.tr (E.roleAt t) * E.cUc n h μ (⟨t / E.W, hp⟩ : Fin _) := by
    unfold slotSize
    rw [E.tq_mod]
  funext e
  obtain ⟨⟨q, y⟩, rfl⟩ := (E.placeT n h μ ⟨t / E.W, hp⟩ (E.roleAt t)).surjective e
  rw [E.unl_eq n h μ _ t hp (E.roleAt t) rfl, Equiv.symm_apply_apply, hsz]
  have hv : ∀ s', (∀ l', E.e l' ≠ s') →
      (fun i j => E.V0 n h μ J ⟨t / E.W, hp⟩ q (i, ((0 : Bits 0), j))) s' = 0 := by
    intro s' hs'
    funext j
    simp only [Pi.zero_apply]
    exact E.V0_dead n h μ J _ q s' hs' _
  show gwalk (E.cUc n h μ (t / E.W)) E.wd
      (fun i j => E.V0 n h μ J ⟨t / E.W, hp⟩ q (i, ((0 : Bits 0), j))) (E.e (E.roleAt t)) y = _
  rw [E.hw _ _ hv (E.roleAt t),
    blockMat_eq_lift (E.St (E.roleAt t)) (E.tz (E.roleAt t)) (E.St_spec (E.roleAt t))]
  -- CHECK: `placeT` is `placeS (St l) (Xt l) …` by definition (rfl).
  show _ = hlow n (E.tr (E.roleAt t) * E.cUc n h μ (t / E.W)) (J t)
    (placeS (E.St (E.roleAt t)) (E.Xt (E.roleAt t)) _ _ n _ (q, y))
  rw [hlow_placeS]
  congr 2
  funext y'
  show E.V0 n h μ J ⟨t / E.W, hp⟩ q (E.e (E.roleAt t), ((0 : Bits 0), y')) = _
  rw [E.V0_live]
  have ht' : (⟨t / E.W, hp⟩ : Fin (E.NUc n h μ)).val * E.W + E.Q.loc (E.roleAt t) = t := by
    rw [E.roleAt_loc]; exact EngArith.split_join t E.W
  exact congrArg (fun k => J k (E.placeT n h μ ⟨t / E.W, hp⟩ (E.roleAt t) (q, y'))) ht'

lemma ownSrc_len (n h μ r : ℕ) :
    (E.ownSrc n h μ r).length = Nat.count (E.srcP n h μ r) (E.NUc n h (μ * r) * E.W) := by
  unfold ownSrc
  generalize E.NUc n h (μ * r) * E.W = N
  induction N with
  | zero => simp
  | succ N ih =>
    rw [List.range_succ, List.filterMap_append, List.length_append, ih, Nat.count_succ]
    by_cases hp : E.srcP n h μ r N <;> simp [hp]

def accR (n h μ r : ℕ) : List ℕ := E.ownSrc n h μ r ++ E.srcSizes n h (μ * r)

lemma accR_len (n h μ r : ℕ) :
    (E.accR n h μ r).length = (E.ownSrc n h μ r).length + E.cons n h (μ * r) := by
  unfold accR cons
  rw [List.length_append]

def blkCost (n h μ r L : ℕ) : ℕ :=
  E.rtCost n h μ r + (E.NUc n h (μ * r) * E.W + E.NUc n (h+1) μ) * 2^n + 2 * (L + (E.accR n h μ r).length) + 20

def accW (n h μ : ℕ) (ws : GWord α ρ) : List ℕ := (blockRanks ws).flatMap (fun r => E.accR n h μ r)

lemma accW_cons (n h μ : ℕ) (mv : GMove α ρ) (ws : GWord α ρ) :
    E.accW n h μ (mv :: ws) = (match mv.rk? with | some r => E.accR n h μ r | none => []) ++ E.accW n h μ ws := by
  unfold accW blockRanks
  cases hr : mv.rk? with
  | none => simp [List.filterMap_cons, hr]
  | some r => simp [List.filterMap_cons, hr, List.flatMap_cons]

lemma accW_wd (n h μ : ℕ) : E.accW n h μ E.wd = E.srcSizes n (h+1) μ := rfl

def swCost (n h μ : ℕ) : ℕ → GWord α ρ → ℕ
  | _, [] => 0
  | L, mv :: ws => (match mv.rk? with
      | some r => E.blkCost n h μ r L
      | none => E.NUc n (h+1) μ * 2^n) +
      swCost n h μ (L + (match mv.rk? with | some r => (E.accR n h μ r).length | none => 0)) ws

def lfCost (n μ : ℕ) : GWord α ρ → ℕ
  | [] => 0
  | mv :: ws => (match mv.rk? with
      | some _ => E.NUc n 0 μ * 2^n + 2 * n + 2
      | none => E.NUc n 0 μ * 2^n) + lfCost n μ ws

def locUp (n h μ : ℕ) : ℕ :=
  (n + 1) + E.idxCost n (h+1) μ + E.NUc n (h+1) μ * (4 * n + 4 * (h + 1) + 8) +
    E.NUc n (h+1) μ * (2 * 2^n + 2) + E.NUc n (h+1) μ * 2^n + E.swCost n h μ 0 E.wd +
    E.NUc n (h+1) μ * E.W * 2^n

def locLeaf (n μ : ℕ) : ℕ :=
  (n + 1) + E.idxCost n 0 μ + E.NUc n 0 μ * (4 * n + 4 * 0 + 8) +
    E.NUc n 0 μ * (2 * 2^n + 2) + E.NUc n 0 μ * 2^n + E.lfCost n μ E.wd + E.NUc n 0 μ * E.W * 2^n

def clsLoc (n h μ : ℕ) : ℕ := if h = 0 then E.locLeaf n μ else E.locUp n (h - 1) μ

def Valid (kmin : ℕ) : MDesc → Prop
  | .top _ _ _ => True
  | .cls n h μ o BS _ _ => 1 ≤ μ ∧ E.mx * μ * kmin ^ h ≤ n ∧ o + E.cons n h μ ≤ BS

structure KMin (kmin : ℕ) : Prop where
  two : 2 ≤ kmin
  att : ∃ l, E.tr l = kmin

lemma kidsUp_free (n h μ BS : ℕ) (sup : ℕ → Bits n → ℂ) (V : E.CState n (h+1) μ) (o : ℕ)
    (mv : GMove α ρ) (ws : GWord α ρ) (hmv : mv.rk? = none) :
    E.kidsUp n h μ BS sup V o (mv :: ws) = E.kidsUp n h μ BS sup (E.stepV V mv) o ws := by
  rcases mv with ⟨_ | _ | _⟩ | _ | _ | _ <;> first | rfl | exact absurd hmv (by simp [GMove.rk?, GMove.shadow, BMove.rk?])

lemma kidsUp_block (n h μ BS : ℕ) (sup : ℕ → Bits n → ℂ) (V : E.CState n (h+1) μ) (o : ℕ)
    (l : ρ) (r : ℕ) (z : Fin r → Space α) (ind : LinearIndependent F z) (ws : GWord α ρ)
    (hr : r ≤ E.X.n) :
    E.kidsUp n h μ BS sup V o (GMove.old (BMove.block l r z ind) :: ws) =
      E.childC n h μ BS sup V o l r z ind hr ::
        E.kidsUp n h μ BS sup (E.stepV V (GMove.old (BMove.block l r z ind)))
          (o + (E.ownSrc n h μ r).length + E.cons n h (μ * r)) ws := by
  show (if hr : r ≤ E.X.n then [E.childC n h μ BS sup V o l r z ind hr] else []) ++ _ = _
  rw [dif_pos hr]
  rfl

lemma kidsLeaf_free (n μ : ℕ) (V : E.CState n 0 μ) (mv : GMove α ρ) (ws : GWord α ρ)
    (hmv : mv.rk? = none) :
    E.kidsLeaf n μ V (mv :: ws) = E.kidsLeaf n μ (E.stepV V mv) ws := by
  rcases mv with ⟨_ | _ | _⟩ | _ | _ | _ <;> first | rfl | exact absurd hmv (by simp [GMove.rk?, GMove.shadow, BMove.rk?])

lemma kidsLeaf_block (n μ : ℕ) (V : E.CState n 0 μ)
    (l : ρ) (r : ℕ) (z : Fin r → Space α) (ind : LinearIndependent F z) (ws : GWord α ρ)
    (hr : r ≤ E.X.n) :
    E.kidsLeaf n μ V (GMove.old (BMove.block l r z ind) :: ws) =
      E.exitC n μ V l r z ind hr :: E.kidsLeaf n μ (E.stepV V (GMove.old (BMove.block l r z ind))) ws := by
  show (if hr : r ≤ E.X.n then [E.exitC n μ V l r z ind hr] else []) ++ _ = _
  rw [dif_pos hr]
  rfl

lemma wd_block {l : ρ} {r : ℕ} {z : Fin r → Space α} {ind : LinearIndependent F z}
    (hm : GMove.old (BMove.block l r z ind) ∈ E.wd) : 1 ≤ r ∧ r < E.X.n :=
  E.hP _ hm

lemma kidsLeaf_valid {kmin : ℕ} (n μ : ℕ) :
    ∀ (ws : GWord α ρ) (V : E.CState n 0 μ), ∀ c ∈ E.kidsLeaf n μ V ws, E.Valid kmin c := by
  intro ws
  induction ws with
  | nil => intro V c hc; simp [kidsLeaf] at hc
  | cons mv ws ih =>
    intro V c hc
    rcases GMove.rk_cases mv with hmv | ⟨l, r, z, ind, rfl⟩
    · rw [E.kidsLeaf_free n μ V mv ws hmv] at hc
      exact ih _ c hc
    · change c ∈ (if hr : r ≤ E.X.n then [E.exitC n μ V l r z ind hr] else []) ++ _ at hc
      rcases List.mem_append.1 hc with hc | hc
      · split_ifs at hc with hr
        · rw [List.mem_singleton] at hc
          subst hc
          unfold exitC
          split_ifs <;> trivial
        · simp at hc
      · exact ih _ c hc

lemma kidsUp_valid {kmin : ℕ} (hk : E.KMin kmin) (n h μ BS : ℕ) (sup : ℕ → Bits n → ℂ)
    (hμ : 1 ≤ μ) (hreg : E.mx * μ * kmin ^ (h+1) ≤ n) :
    ∀ (ws : GWord α ρ), (∀ mv ∈ ws, mv ∈ E.wd) → ∀ (V : E.CState n (h+1) μ) (o : ℕ),
      o + (E.accW n h μ ws).length ≤ BS → ∀ c ∈ E.kidsUp n h μ BS sup V o ws, E.Valid kmin c := by
  intro ws
  induction ws with
  | nil => intro _ V o _ c hc; simp [kidsUp] at hc
  | cons mv ws ih =>
    intro hws V o ho c hc
    have hws' : ∀ mv ∈ ws, mv ∈ E.wd := fun mv' h' => hws mv' (List.mem_cons_of_mem _ h')
    rcases GMove.rk_cases mv with hmv | ⟨l, r, z, ind, rfl⟩
    · rw [E.kidsUp_free n h μ BS sup V o mv ws hmv] at hc
      rw [E.accW_cons, hmv] at ho
      exact ih hws' _ o (by simpa using ho) c hc
    · have hmem := hws _ List.mem_cons_self
      obtain ⟨hr1, hr2⟩ := E.wd_block hmem
      rw [E.kidsUp_block n h μ BS sup V o l r z ind ws hr2.le] at hc
      rw [E.accW_cons, GMove.rk_block] at ho
      simp only [List.length_append, E.accR_len] at ho
      rcases List.mem_cons.1 hc with hc | hc
      · subst hc
        obtain ⟨l0, hl0⟩ := hk.att
        have hrk : r < kmin := by have := E.sep _ hmem r rfl l0; omega
        show 1 ≤ μ * r ∧ E.mx * (μ * r) * kmin ^ h ≤ n ∧
          o + (E.ownSrc n h μ r).length + E.cons n h (μ * r) ≤ BS
        refine ⟨by have := Nat.mul_le_mul hμ hr1; simpa using this, ?_, ?_⟩
        · have h1 : E.mx * (μ * r) * kmin ^ h ≤ E.mx * μ * kmin ^ (h+1) := by
            rw [Nat.pow_succ, ← Nat.mul_assoc E.mx μ r, Nat.mul_assoc (E.mx * μ) r]
            apply Nat.mul_le_mul_left
            rw [Nat.mul_comm r]
            exact Nat.mul_le_mul_left _ hrk.le
          exact le_trans h1 hreg
        · omega
      · exact ih hws' _ _ (by omega) c hc

theorem kidsC_valid {kmin : ℕ} (hk : E.KMin kmin) (d : MDesc) (hd : E.Valid kmin d) :
    ∀ c ∈ E.kidsC d, E.Valid kmin c := by
  cases d with
  | top n B v => intro c hc; simp [kidsC] at hc
  | cls n h μ o BS J sup =>
    cases h with
    | zero => exact E.kidsLeaf_valid n μ E.wd _
    | succ h =>
      obtain ⟨hμ, hreg, hfit⟩ := hd
      exact E.kidsUp_valid hk n h μ BS sup hμ hreg E.wd (fun _ h' => h') _ o
        (by rw [E.accW_wd]; exact hfit)

lemma valid_facts {kmin : ℕ} (hk : E.KMin kmin) {n h μ o BS : ℕ} {J sup : ℕ → Bits n → ℂ}
    (hd : E.Valid kmin (MDesc.cls n h μ o BS J sup)) :
    (h = 0 → E.X.n * μ ≤ n) ∧ h ≤ n ∧ μ ≤ n ∧ o + E.cons n h μ ≤ BS := by
  obtain ⟨hμ, hreg, hfit⟩ := hd
  have hk1 : 1 ≤ kmin ^ h := Nat.one_le_pow _ _ (by have := hk.two; omega)
  have hmx : 1 ≤ E.mx := Nat.le_trans (by decide) E.three
  have h1 : μ * kmin ^ h ≤ E.mx * μ * kmin ^ h := by
    rw [Nat.mul_assoc]; exact Nat.le_mul_of_pos_left _ hmx
  have h2 : kmin ^ h ≤ μ * kmin ^ h := Nat.le_mul_of_pos_left _ hμ
  have h3 : μ ≤ μ * kmin ^ h := Nat.le_mul_of_pos_right _ hk1
  have h4 : h < 2 ^ h := Nat.lt_two_pow_self
  have h5 : 2 ^ h ≤ kmin ^ h := Nat.pow_le_pow_left hk.two h
  refine ⟨fun h0 => ?_, by omega, by omega, hfit⟩
  subst h0
  have h6 := hreg
  rw [Nat.pow_zero, Nat.mul_one] at h6
  exact h6

section ClassTable
universe V
variable {ι : Type V} {m : Bool} {B : ι → ℕ} {s : Ty} {x : ι → T s} {cl : Paint} {n H μ : ι → ℕ}

abbrev Ctx (m : Bool) (B : ι → ℕ) (s : Ty) (x : ι → T s) (n H μ : ι → ℕ) : Prop :=
  CCtx m B s x E.X.n n (fun i => E.NUc (n i) (H i) (μ i)) (fun i p => E.cUc (n i) (H i) (μ i) p)
    (fun i p => E.iUc (n i) (H i) (μ i) p)

abbrev tabV (n H μ : ι → ℕ) (V : ∀ i, E.CState (n i) (H i) (μ i)) (i : ι) : Tape (Tape (Tape ℂ)) :=
  ctab E.X E.R (E.NUc (n i) (H i) (μ i)) (fun p => E.cUc (n i) (H i) (μ i) p)
    (fun p => E.iUc (n i) (H i) (μ i) p) (V i)

def passCost (n NU : ℕ) : ℕ := NU + NU * ((E.R.n + 1) * 2^n)

lemma pass_bound (c : E.Ctx m B s x n H μ) (u : UnitF (fun i => E.NUc (n i) (H i) (μ i))) :
    2^(E.iUc (n u.1) (H u.1) (μ u.1) u.2) +
      2^(E.iUc (n u.1) (H u.1) (μ u.1) u.2) * (E.R.n * 2^(E.X.n * E.cUc (n u.1) (H u.1) (μ u.1) u.2))
      ≤ (E.R.n + 1) * 2^(n u.1) := by
  have h1 := c.unit_size E.X E.R rfl u.1 u.2
  have h2 := c.pow_ib_le u.1 u.2
  simp only at h1 h2
  rw [fleet_n] at h1
  rw [h1, Nat.add_mul _ 1, Nat.one_mul]
  omega

abbrev IEnv (s : Ty) : Ty := p (p s w) w

lemma gearI (c : E.Ctx m B s x n H μ) :
    Gear m (fun v : InstF (fun i => E.NUc (n i) (H i) (μ i)) (fun i p => E.iUc (n i) (H i) (μ i) p) => B v.1.1)
      (fun v => E.cUc (n v.1.1) (H v.1.1) (μ v.1.1) v.1.2) (IEnv s)
      (fun v => ((x v.1.1, v.1.2.val), (bits (E.iUc (n v.1.1) (H v.1.1) (μ v.1.1) v.1.2)).loc v.2)) :=
  c.gearU.descend (fun v : InstF (fun i => E.NUc (n i) (H i) (μ i)) (fun i p => E.iUc (n i) (H i) (μ i) p) => v.1)
    _ Can.first

lemma has_placeRead (c : E.Ctx m B s x n H μ) {V : ∀ i, E.CState (n i) (H i) (μ i)} {κ : Type*} {sk : Ty}
    {yk : κ → T sk} (j : κ → UnitF (fun i => E.NUc (n i) (H i) (μ i)))
    (hj : Has m (fun k => B (j k).1) sk (p s w) yk (fun k => (x (j k).1, (j k).2.val)))
    (hV : Has m (fun k => B (j k).1) sk (ctabT cl) yk (fun k => E.tabV n H μ V (j k).1))
    {β : Type*} [Fintype β] [DecidableEq β] {kk : ℕ} (S : Split α β (Fin kk)) (X' : Layout β)
    (hX' : X'.n + kk = E.X.n) (l : ρ) (e : ∀ k, Bits (n (j k).1))
    (he : Knows m (fun k => B (j k).1) sk yk (fun k => (bits (n (j k).1)).loc (e k))) :
    Has m (fun k => B (j k).1) sk (Ty.c cl) yk (fun k => V (j k).1 (j k).2
      ((placeS S X' (E.cUc (n (j k).1) (H (j k).1) (μ (j k).1) (j k).2)
        (E.iUc (n (j k).1) (H (j k).1) (μ (j k).1) (j k).2) (n (j k).1)
        (fitk X' hX' (E.fitc _ _ _ (j k).2))).symm (e k)).1
      (l, ((0 : Bits 0), ((placeS S X' (E.cUc (n (j k).1) (H (j k).1) (μ (j k).1) (j k).2)
        (E.iUc (n (j k).1) (H (j k).1) (μ (j k).1) (j k).2) (n (j k).1)
        (fitk X' hX' (E.fitc _ _ _ (j k).2))).symm (e k)).2))) := by
  have gK := c.gearU.descend j yk hj
  have hdec := gK.place_dec E.X S X' hX' (r := fun k => E.iUc (n (j k).1) (H (j k).1) (μ (j k).1) (j k).2)
    (n := fun k => n (j k).1) (fun k => E.fitc _ _ _ (j k).2) (c.big.reindex _) e he
  exact has_ctabRead E.X E.R (NU := fun k => E.NUc (n (j k).1) (H (j k).1) (μ (j k).1))
    (col := fun k p => E.cUc (n (j k).1) (H (j k).1) (μ (j k).1) p)
    (ib := fun k p => E.iUc (n (j k).1) (H (j k).1) (μ (j k).1) p) (V' := fun k => V (j k).1)
    (fun k => (j k).2) _ _ hV (Can.snd hj) hdec.1 (gK.fleet_join E.X E.R (fun _ => l) _ (Can.wc _) hdec.2)

lemma can_free (c : E.Ctx m B s x n H μ) {V : ∀ i, E.CState (n i) (H i) (μ i)}
    (hV : Has m B s (ctabT cl) x (E.tabV n H μ V)) (mv : GMove α ρ) (hmv : mv.rk? = none) :
    Can m B s (ctabT cl) x (E.tabV n H μ (fun i => E.stepV (V i) mv))
      (fun i => E.passCost (n i) (E.NUc (n i) (H i) (μ i))) := by
  let IF := InstF (fun i => E.NUc (n i) (H i) (μ i)) (fun i p => E.iUc (n i) (H i) (μ i) p)
  have gI := E.gearI c
  have hitems : Has m (fun v : IF => B v.1.1) (IEnv s) (a (Ty.c cl))
      (fun v => ((x v.1.1, v.1.2.val), (bits (E.iUc (n v.1.1) (H v.1.1) (μ v.1.1) v.1.2)).loc v.2))
      (fun v => (fleet E.X E.R 0 (E.cUc (n v.1.1) (H v.1.1) (μ v.1.1) v.1.2)).tape (V v.1.1 v.1.2 v.2)) :=
    has_ctabInst E.X E.R (NU := fun v : IF => E.NUc (n v.1.1) (H v.1.1) (μ v.1.1))
      (col := fun v p => E.cUc (n v.1.1) (H v.1.1) (μ v.1.1) p)
      (ib := fun v p => E.iUc (n v.1.1) (H v.1.1) (μ v.1.1) p) (V' := fun v => V v.1.1)
      (fun v => v.1.2) (fun v => v.2)
      (Can.first.then_do (Can.first.then_do (hV.reindex (fun v : IF => v.1.1))))
      (Can.first.then_do Can.second) Can.second
  have hR : GRig m (fun v : IF => B v.1.1) (fun v => E.cUc (n v.1.1) (H v.1.1) (μ v.1.1) v.1.2) (IEnv s)
      (fun v => ((x v.1.1, v.1.2.val), (bits (E.iUc (n v.1.1) (H v.1.1) (μ v.1.1) v.1.2)).loc v.2))
      cl E.X E.R 0 (fun v => V v.1.1 v.1.2 v.2) :=
    ⟨⟨gI, Can.first.then_do (Can.first.then_do (c.imag.reindex (fun v : IF => v.1.1))), hitems⟩,
      Can.first.then_do (c.lumU.reindex (fun v : IF => v.1))⟩
  have H1 := can_ctab E.X E.R (V' := fun i => E.stepV (V i) mv) c.nuK c.nuS c.p2ibU c.p2ibS
    (P := fun i => (E.R.n + 1) * 2^(n i)) (fun u => E.pass_bound c u) ((free_inst hR mv hmv).mono (fun v => (fleet_n _ _ _).le))
  exact H1

abbrev ElemF {ι : Type*} (n H μ : ι → ℕ) :=
  Σ v : InstF (fun i => E.NUc (n i) (H i) (μ i)) (fun i p => E.iUc (n i) (H i) (μ i) p),
    Beach α ρ 0 (E.cUc (n v.1.1) (H v.1.1) (μ v.1.1) v.1.2)

abbrev elemEnv {ι : Type*} {s : Ty} (x : ι → T s) (n H μ : ι → ℕ) (d : E.ElemF n H μ) : T (p (IEnv s) w) :=
  (((x d.1.1.1, d.1.1.2.val), (bits (E.iUc (n d.1.1.1) (H d.1.1.1) (μ d.1.1.1) d.1.1.2)).loc d.1.2),
    (fleet E.X E.R 0 (E.cUc (n d.1.1.1) (H d.1.1.1) (μ d.1.1.1) d.1.1.2)).loc d.2)

lemma knows_hitAddr (c : E.Ctx m B s x n H μ) (l : ρ) {β : Type*} [Fintype β] [DecidableEq β] {kk : ℕ}
    (S : Split α β (Fin kk)) (X' : Layout β) (hX' : X'.n + kk = E.X.n) :
    Knows m (fun d : {d : E.ElemF n H μ // d.2.1 = l} => B d.1.1.1.1) (p (IEnv s) w)
      (fun d => E.elemEnv x n H μ d.1)
      (fun d => (bits (n d.1.1.1.1)).loc (placeS S X' (E.cUc (n d.1.1.1.1) (H d.1.1.1.1) (μ d.1.1.1.1) d.1.1.1.2)
        (E.iUc (n d.1.1.1.1) (H d.1.1.1.1) (μ d.1.1.1.1) d.1.1.1.2) (n d.1.1.1.1)
        (fitk X' hX' (E.fitc _ _ _ d.1.1.1.2)) (d.1.1.2, d.1.2.2.2))) := by
  have gK := ((E.gearI c).descend (fun d : E.ElemF n H μ => d.1) (E.elemEnv x n H μ) Can.first).descend
    (fun d : {d : E.ElemF n H μ // d.2.1 = l} => d.1) (fun d => E.elemEnv x n H μ d.1) Can.id
  obtain ⟨_, hgrid⟩ := gK.fleet_split E.X E.R (fun d => d.1.2) Can.second
  exact gK.place_enc E.X S X' hX'
    (r := fun d : {d : E.ElemF n H μ // d.2.1 = l} => E.iUc (n d.1.1.1.1) (H d.1.1.1.1) (μ d.1.1.1.1) d.1.1.1.2)
    (n := fun d => n d.1.1.1.1) (fun d => E.fitc _ _ _ d.1.1.1.2) (c.big.reindex _)
    (fun d => d.1.1.2) (fun d => d.1.2.2.2) (Can.first.then_do Can.second)
    (hgrid.cong (fun _ => rfl) (fun d => by rw [Gear.grid0]))

lemma can_tabEl (c : E.Ctx m B s x n H μ) {V' : ∀ i, E.CState (n i) (H i) (μ i)}
    (hel : ∀ l' : ρ, Has m (fun d : {d : E.ElemF n H μ // d.2.1 = l'} => B d.1.1.1.1) (p (IEnv s) w) (Ty.c cl)
      (fun d => E.elemEnv x n H μ d.1) (fun d => V' d.1.1.1.1 d.1.1.1.2 d.1.1.2 d.1.2)) :
    Can m B s (ctabT cl) x (E.tabV n H μ V') (fun i => E.passCost (n i) (E.NUc (n i) (H i) (μ i))) := by
  let IF := InstF (fun i => E.NUc (n i) (H i) (μ i)) (fun i p => E.iUc (n i) (H i) (μ i) p)
  have gI := E.gearI c
  have gE : Gear m (fun d : E.ElemF n H μ => B d.1.1.1) (fun d => E.cUc (n d.1.1.1) (H d.1.1.1) (μ d.1.1.1) d.1.1.2)
      (p (IEnv s) w) (E.elemEnv x n H μ) := gI.descend (fun d : E.ElemF n H μ => d.1) _ Can.first
  obtain ⟨hrole, _⟩ := gE.fleet_split E.X E.R (fun d => d.2) Can.second
  have HL := Can.layout (m := m) (t := Ty.c cl)
    (L := fun v : IF => fleet E.X E.R 0 (E.cUc (n v.1.1) (H v.1.1) (μ v.1.1) v.1.2))
    (v := fun v b => V' v.1.1 v.1.2 v.2 b) (P := fun _ => 0) (W := fun _ => 0)
    (gI.fleet_size E.X E.R) (Can.cases_code (q := fun d : E.ElemF n H μ => d.2.1) E.R hrole hel)
    (gI.fleet_small E.X E.R)
  exact can_ctab E.X E.R (V' := V') c.nuK c.nuS c.p2ibU c.p2ibS (P := fun i => (E.R.n + 1) * 2^(n i))
    (fun u => E.pass_bound c u)
    (HL.mono (fun v => by have := fleet_n E.X E.R (E.cUc (n v.1.1) (H v.1.1) (μ v.1.1) v.1.2); omega))

lemma can_load (c : E.Ctx m B s x n H μ) {J : ∀ i, ℕ → Bits (n i) → ℂ}
    (hJ : Has m B s (jobsT cl) x (fun i => jobsTape (n i) (E.NUc (n i) (H i) (μ i) * E.W) (J i))) :
    Can m B s (ctabT cl) x (E.tabV n H μ (fun i => E.V0 (n i) (H i) (μ i) (J i)))
      (fun i => E.passCost (n i) (E.NUc (n i) (H i) (μ i))) := by
  refine E.can_tabEl c (fun l' => ?_)
  by_cases hlive : ∃ l, E.e l = l'
  · obtain ⟨l, rfl⟩ := hlive
    let K := {d : E.ElemF n H μ // d.2.1 = E.e l}
    let yK (d : K) := E.elemEnv x n H μ d.1
    have hp : Knows m (fun d : K => B d.1.1.1.1) (p (IEnv s) w) yK (fun d => d.1.1.1.2.val) :=
      Can.first.then_do (Can.first.then_do Can.second)
    have sp : Small (fun d : K => B d.1.1.1.1) (fun d => d.1.1.1.2.val) :=
      (c.nuS.reindex (fun d : K => d.1.1.1.1)).mono (fun d => d.1.1.1.2.2.le)
    have hix : Knows m (fun d : K => B d.1.1.1.1) (p (IEnv s) w) yK
        (fun d => d.1.1.1.2.val * E.W + E.Q.loc l) :=
      (hp.times (Can.wc E.W) sp (Small.const _ _)).plus (Can.wc _) (sp.mul (Small.const _ _)) (Small.const _ _)
    have hJK : Has m (fun d : K => B d.1.1.1.1) (p (IEnv s) w) (jobsT cl) yK
        (fun d => jobsTape (n d.1.1.1.1) (E.NUc (n d.1.1.1.1) (H d.1.1.1.1) (μ d.1.1.1.1) * E.W) (J d.1.1.1.1)) :=
      (Can.first.then_do (Can.first.then_do Can.first)).then_do (hJ.reindex (fun d : K => d.1.1.1.1))
    refine (has_jobsRead hJK hix (fun d => EngArith.lt_join d.1.1.1.2.2 (E.Q.bd l))
      (E.knows_hitAddr c (E.e l) (E.St l) (E.Xt l) (E.Xt_n l))).cong (fun _ => rfl) (fun d => ?_)
    have hd : d.1.2 = (E.e l, ((0 : Bits 0), d.1.2.2.2)) := by
      rw [Gear.grid0]; exact Prod.ext d.2 rfl
    show _ = E.V0 _ _ _ _ _ _ d.1.2
    rw [hd, E.V0_live]
    rfl
  · refine (Can.zero (cl := cl)).cong (fun _ => rfl) (fun d => ?_)
    have hd : d.1.2 = (l', d.1.2.2) := Prod.ext d.2 rfl
    show (0 : ℂ) = E.V0 _ _ _ _ _ _ d.1.2
    rw [hd, E.V0_dead _ _ _ _ _ _ l' (fun l hl => hlive ⟨l, hl⟩)]

lemma can_unload (c : E.Ctx m B s x n H μ) {V : ∀ i, E.CState (n i) (H i) (μ i)}
    (hV : Has m B s (ctabT cl) x (E.tabV n H μ V)) :
    Can m B s (jobsT cl) x
      (fun i => jobsTape (n i) (E.NUc (n i) (H i) (μ i) * E.W) (E.unl (n i) (H i) (μ i) (V i)))
      (fun i => E.NUc (n i) (H i) (μ i) * E.W * (2^(n i) + 1)) := by
  let EL := Σ u : UnitF (fun i => E.NUc (n i) (H i) (μ i) * E.W), Bits (n u.1)
  let yE (d : EL) : T (p (p s w) w) := ((x d.1.1, d.1.2.val), (bits (n d.1.1)).loc d.2)
  have hNs : Small B (fun i => E.NUc (n i) (H i) (μ i) * E.W) := c.nuS.mul (Small.const _ _)
  have htS : Small (fun d : EL => B d.1.1) (fun d => d.1.2.val) :=
    (hNs.reindex (fun d : EL => d.1.1)).mono (fun d => d.1.2.2.le)
  have ht : Knows m (fun d : EL => B d.1.1) (p (p s w) w) yE (fun d => d.1.2.val) :=
    Can.first.then_do Can.second
  have hdiv : Knows m (fun d : EL => B d.1.1) (p (p s w) w) yE (fun d => d.1.2.val / E.W) :=
    ht.dvdW (Can.wc _) htS
  have hmod : Knows m (fun d : EL => B d.1.1) (p (p s w) w) yE (fun d => d.1.2.val % E.W) :=
    ht.modW (Can.wc _) htS
  have hp : ∀ d : EL, d.1.2.val / E.W < E.NUc (n d.1.1) (H d.1.1) (μ d.1.1) := fun d =>
    (Nat.div_lt_iff_lt_mul E.W_pos).2 d.1.2.2
  have hel : Has m (fun d : EL => B d.1.1) (p (p s w) w) (Ty.c cl) yE
      (fun d => E.unl (n d.1.1) (H d.1.1) (μ d.1.1) (V d.1.1) d.1.2.val d.2) := by
    apply Can.cases_code (q := fun d : EL => E.roleAt d.1.2.val) E.Q
      (hmod.cong (fun _ => rfl) (fun d => (E.roleAt_loc _).symm))
    intro l
    let K := {d : EL // E.roleAt d.1.2.val = l}
    let jU (d : K) : UnitF (fun i => E.NUc (n i) (H i) (μ i)) := ⟨d.1.1.1, ⟨d.1.1.2.val / E.W, hp d.1⟩⟩
    have hread := E.has_placeRead c (V := V) jU
      ((Can.first.then_do Can.first).pair (hdiv.reindex (fun d : K => d.1)))
      ((Can.first.then_do Can.first).then_do (hV.reindex (fun d : K => d.1.1.1)))
      (E.St l) (E.Xt l) (E.Xt_n l) (E.e l) (fun d => d.1.2) Can.second
    exact hread.cong (fun _ => rfl) (fun d => (E.unl_eq _ _ _ _ _ (hp d.1) l d.2 _).symm)
  exact can_jobsTape (N := fun i => E.NUc (n i) (H i) (μ i) * E.W) (c.nuK.times (Can.wc _) c.nuS (Small.const _ _)) c.p2n hNs c.big hel

end ClassTable

lemma can_scatterG {ι : Type*} {m : Bool} {B : ι → ℕ} {s : Ty} {x : ι → T s} {cl : Paint} {n H μ : ι → ℕ}
    (c : E.Ctx m B s x n H μ) {V V' : ∀ i, E.CState (n i) (H i) (μ i)}
    (hV : Has m B s (ctabT cl) x (E.tabV n H μ V)) (l : ρ)
    (hmiss : ∀ i (p : Fin (E.NUc (n i) (H i) (μ i))) (q : Bits (E.iUc (n i) (H i) (μ i) p))
      (b : Beach α ρ 0 (E.cUc (n i) (H i) (μ i) p)), b.1 ≠ l → V i p q b = V' i p q b)
    (hhit : Has m (fun d : {d : E.ElemF n H μ // d.2.1 = l} => B d.1.1.1.1) (p (IEnv s) w) (Ty.c cl)
      (fun d => E.elemEnv x n H μ d.1) (fun d => V' d.1.1.1.1 d.1.1.1.2 d.1.1.2 d.1.2)) :
    Can m B s (ctabT cl) x (E.tabV n H μ V') (fun i => E.passCost (n i) (E.NUc (n i) (H i) (μ i))) := by
  refine E.can_tabEl c (fun l' => ?_)
  by_cases hl : l' = l
  · subst hl; exact hhit
  · let K := {d : E.ElemF n H μ // d.2.1 = l'}
    exact (has_ctabRead E.X E.R (NU := fun d : K => E.NUc (n d.1.1.1.1) (H d.1.1.1.1) (μ d.1.1.1.1))
      (col := fun d p => E.cUc (n d.1.1.1.1) (H d.1.1.1.1) (μ d.1.1.1.1) p)
      (ib := fun d p => E.iUc (n d.1.1.1.1) (H d.1.1.1.1) (μ d.1.1.1.1) p) (V' := fun d => V d.1.1.1.1)
      (fun d => d.1.1.1.2) (fun d => d.1.1.2) (fun d => d.1.2)
      ((Can.first.then_do (Can.first.then_do Can.first)).then_do (hV.reindex (fun d : K => d.1.1.1.1)))
      (Can.first.then_do (Can.first.then_do Can.second) : Knows m (fun d : K => B d.1.1.1.1) (p (IEnv s) w)
        (fun d => E.elemEnv x n H μ d.1) (fun d => d.1.1.1.2.val))
      (Can.first.then_do Can.second : Knows m (fun d : K => B d.1.1.1.1) (p (IEnv s) w)
        (fun d => E.elemEnv x n H μ d.1)
        (fun d => (bits (E.iUc (n d.1.1.1.1) (H d.1.1.1.1) (μ d.1.1.1.1) d.1.1.1.2)).loc d.1.1.2))
      (Can.second : Knows m (fun d : K => B d.1.1.1.1) (p (IEnv s) w) (fun d => E.elemEnv x n H μ d.1)
        (fun d => (fleet E.X E.R 0 (E.cUc (n d.1.1.1.1) (H d.1.1.1.1) (μ d.1.1.1.1) d.1.1.1.2)).loc d.1.2))).cong
      (fun _ => rfl) (fun d => hmiss _ _ _ _ (by rw [d.2]; exact hl))


lemma tq_lt_W (a : ℕ) (ha : a < E.W) : E.tq a = E.tr (E.Q.atFin ⟨a, ha⟩) := by
  unfold tq; rw [dif_pos ha]

lemma rk_le_tq {l : ρ} {r : ℕ} {z : Fin r → Space α} {ind : LinearIndependent F z}
    (hm : GMove.old (BMove.block l r z ind) ∈ E.wd) (a : ℕ) (ha : a < E.W) : r ≤ E.tq a := by
  rw [E.tq_lt_W a ha]
  exact (E.sep _ hm r rfl _).le

lemma flR_eq (n h μ r t : ℕ) (ht : t < E.NUc n h (μ * r) * E.W) :
    E.flR n h μ r t = 1 - (if E.srcP n h μ r t then 1 else 0) := by
  unfold flR fedP srcP
  by_cases hin : inRS E.W E.tq E.mx n (h+1) μ (E.parCode n h μ r t) <;> simp [hin, ht]

lemma parCode_lt (n h μ r t : ℕ) (ht : t < E.NUc n h (μ * r) * E.W) :
    E.parCode n h μ r t < E.W^(h+1) := by
  have hp : t / E.W < E.NUc n h (μ * r) := (Nat.div_lt_iff_lt_mul E.W_pos).2 ht
  exact MXR.lt_of_cons E.W h _ _ (Nat.mod_lt _ E.W_pos) (MXR.U_lt hp)

lemma slotR_spec (n h μ r : ℕ) (hrs : ∀ a, a < E.W → r ≤ E.tq a) (p : Fin (E.NUc n (h+1) μ)) :
    E.slotR n h μ r p < E.NUc n h (μ * r) * E.W ∧ E.flR n h μ r (E.slotR n h μ r p) ≠ 0 ∧
      E.ppR n h μ r (E.slotR n h μ r p) = p ∧
      E.slotSize n h (μ * r) (E.slotR n h μ r p) = r * E.cUc n (h+1) μ p := by
  have hW := E.W_pos
  obtain ⟨hin, hlt, hpc⟩ := MXR.U_spec p.2 (W := E.W) (tq := E.tq) (mx := E.mx)
  set u := E.Uc n (h+1) μ p with hu
  have hmod : u % E.W < E.W := Nat.mod_lt _ hW
  have hsplit : u % E.W + E.W * (u / E.W) = u := Nat.mod_add_div u E.W
  have hcol : colS E.W E.tq (h+1) u = E.tq (u % E.W) * colS E.W E.tq h (u / E.W) := by
    conv_lhs => rw [← hsplit]
    exact MXR.colS_cons E.W E.tq h _ _ hmod
  have hchild : inRS E.W E.tq E.mx n h (μ * r) (u / E.W) := by
    refine ⟨?_, ?_⟩
    · have h1 : u < E.W^h * E.W := by rw [← Nat.pow_succ]; exact hin.1
      exact (Nat.div_lt_iff_lt_mul hW).2 h1
    · have h2 := hin.2
      rw [hcol] at h2
      have h3 : μ * r * colS E.W E.tq h (u / E.W) ≤ μ * (E.tq (u % E.W) * colS E.W E.tq h (u / E.W)) := by
        rw [Nat.mul_assoc]
        exact Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ (hrs _ hmod))
      exact le_trans (Nat.mul_le_mul_left _ h3) h2
  have hpcl := MXR.PC_lt hchild
  have hUP := MXR.U_PC hchild
  have hsl : E.slotR n h μ r p = E.PCc n h (μ * r) (u / E.W) * E.W + u % E.W := rfl
  have hdiv : E.slotR n h μ r p / E.W = E.PCc n h (μ * r) (u / E.W) := by
    rw [hsl]; exact EngArith.div_join hmod
  have hmd : E.slotR n h μ r p % E.W = u % E.W := by
    rw [hsl]; exact EngArith.mod_join hmod
  have hslt : E.slotR n h μ r p < E.NUc n h (μ * r) * E.W := by
    rw [hsl]; exact EngArith.lt_join hpcl hmod
  have hpar : E.parCode n h μ r (E.slotR n h μ r p) = u := by
    unfold parCode
    rw [hmd, hdiv]
    show u % E.W + E.W * MXR.U E.W E.tq E.mx n h (μ * r) (MXR.PC E.W E.tq E.mx n h (μ * r) (u / E.W)) = u
    rw [hUP, hsplit]
  have hfed : E.fedP n h μ r (E.slotR n h μ r p) := ⟨hslt, by rw [hpar]; exact hin⟩
  refine ⟨hslt, ?_, ?_, ?_⟩
  · unfold flR; rw [if_pos hfed]; omega
  · unfold ppR; rw [hpar]; exact hpc
  · unfold slotSize
    rw [hmd, hdiv]
    show E.tq (u % E.W) * ((μ * r) * colS E.W E.tq h
      (MXR.U E.W E.tq E.mx n h (μ * r) (MXR.PC E.W E.tq E.mx n h (μ * r) (u / E.W)))) =
      r * (μ * colS E.W E.tq (h+1) u)
    rw [hUP, hcol]
    ac_rfl

lemma stepV_block {n h μ : ℕ} (V : E.CState n h μ) (l : ρ) (r : ℕ) (z : Fin r → Space α)
    (ind : LinearIndependent F z) (hr : r ≤ E.X.n) (p : Fin (E.NUc n h μ)) (q : Bits (E.iUc n h μ p))
    (gr : Grid α 0 (E.cUc n h μ p)) :
    E.stepV V (GMove.old (BMove.block l r z ind)) p q (l, gr) =
      hlow n (r * E.cUc n h μ p)
        (blockJob (bS z ind) (bX (α:=α) r) (E.cUc n h μ p) (E.iUc n h μ p) n
          (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc n h μ p)) l (V p))
        (placeS (bS z ind) (bX (α:=α) r) (E.cUc n h μ p) (E.iUc n h μ p) n
          (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc n h μ p)) (q, gr.2)) := by
  rw [hlow_placeS]
  show (if l = l then matAct (E.cUc n h μ p) (blockMat z) (fun j => V p q (l, gr.1, j))
    else (fun j => V p q (l, gr.1, j))) gr.2 = _
  rw [if_pos rfl, blockMat_eq_lift (bS z ind) z (bS_spec z ind)]
  congr 2
  funext y'
  rw [blockJob_placeS]
  rw [show gr.1 = (0 : Bits 0) from Subsingleton.elim _ _]

lemma stepV_other {n h μ : ℕ} (V : E.CState n h μ) (l : ρ) (r : ℕ) (z : Fin r → Space α)
    (ind : LinearIndependent F z) (p : Fin (E.NUc n h μ)) (q : Bits (E.iUc n h μ p))
    (l' : ρ) (hl : l' ≠ l) (gr : Grid α 0 (E.cUc n h μ p)) :
    E.stepV V (GMove.old (BMove.block l r z ind)) p q (l', gr) = V p q (l', gr) := by
  show (if l' = l then matAct (E.cUc n h μ p) (blockMat z) (fun j => V p q (l', gr.1, j))
    else (fun j => V p q (l', gr.1, j))) gr.2 = _
  rw [if_neg hl]

lemma cjob_src (n h μ : ℕ) (sup : ℕ → Bits n → ℂ) (V : E.CState n (h+1) μ) (o : ℕ)
    (l : ρ) (r : ℕ) (z : Fin r → Space α) (ind : LinearIndependent F z) (hr : r ≤ E.X.n)
    (t : ℕ) (hs : E.srcP n h μ r t) :
    cjob E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc n (h+1) μ) V (E.flR n h μ r) (E.ppR n h μ r)
      (E.siR n h μ r o) (E.ppR_lt n h μ r) sup t = sup (o + Nat.count (E.srcP n h μ r) t) := by
  have hfl : ¬ E.flR n h μ r t ≠ 0 := by
    unfold flR
    rw [if_neg (fun hf => hs.2 hf.2)]
    exact fun h0 => h0 rfl
  unfold cjob
  rw [dif_neg hfl]
  rfl

lemma cjob_fed (n h μ : ℕ) (sup : ℕ → Bits n → ℂ) (V : E.CState n (h+1) μ) (o : ℕ)
    (l : ρ) (r : ℕ) (z : Fin r → Space α) (ind : LinearIndependent F z) (hr : r ≤ E.X.n)
    (t : ℕ) (hf : E.flR n h μ r t ≠ 0) :
    cjob E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc n (h+1) μ) V (E.flR n h μ r) (E.ppR n h μ r)
      (E.siR n h μ r o) (E.ppR_lt n h μ r) sup t =
    blockJob (bS z ind) (bX (α:=α) r) (E.cUc n (h+1) μ (E.ppR n h μ r t))
      (E.iUc n (h+1) μ (E.ppR n h μ r t)) n
      (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc n (h+1) μ ⟨E.ppR n h μ r t, E.ppR_lt n h μ r t hf⟩)) l (V ⟨E.ppR n h μ r t, E.ppR_lt n h μ r t hf⟩) := by
  unfold cjob
  rw [dif_pos hf]

section Block
universe V
variable {ι : Type V} {m : Bool} {B : ι → ℕ} {s : Ty} {x : ι → T s} {cl : Paint} {n h μ : ι → ℕ}

abbrev Nc (n h μ : ι → ℕ) (r : ℕ) (i : ι) : ℕ := E.NUc (n i) (h i) (μ i * r) * E.W

abbrev ITt (n h μ : ι → ℕ) (r : ℕ) (i : ι) : Tape ℕ :=
  (Layout.std (E.Nc n h μ r i)).tape (fun t => if E.srcP (n i) (h i) (μ i) r t then 1 else 0)

abbrev CTt (n h μ : ι → ℕ) (r : ℕ) (i : ι) : Tape ℕ :=
  (Layout.std (E.Nc n h μ r i)).tape (fun t => Nat.count (E.srcP (n i) (h i) (μ i) r) t)

abbrev UTc (n h μ : ι → ℕ) (r : ℕ) (i : ι) : Tape ℕ :=
  (Layout.std (E.NUc (n i) (h i) (μ i * r))).tape (fun p => E.Uc (n i) (h i) (μ i * r) p)

lemma Nc_le (r : ℕ) (i : ι) : E.Nc n h μ r i ≤ E.W^(h i + 1) := by
  rw [Nat.pow_succ]
  exact Nat.mul_le_mul_right _ (E.NU_le' _ _ _)

lemma knows_parCode {κ : Type V} {Bk : κ → ℕ} {sk : Ty} {y : κ → T sk} {nk hk μk : κ → ℕ} (r : ℕ)
    {tk : κ → ℕ} (ht : Knows m Bk sk y tk) (hlt : ∀ k, tk k < E.Nc nk hk μk r k)
    (hU : Has m Bk sk (a w) y (E.UTc nk hk μk r)) (hs : Small Bk (fun k => E.W^(hk k + 1))) :
    Knows m Bk sk y (fun k => E.parCode (nk k) (hk k) (μk k) r (tk k)) ∧
      Small Bk (fun k => E.parCode (nk k) (hk k) (μk k) r (tk k)) := by
  have htS : Small Bk tk := hs.mono (fun k => ((hlt k).trans_le (E.Nc_le r k)).le)
  have hp : ∀ k, tk k / E.W < E.NUc (nk k) (hk k) (μk k * r) := fun k =>
    (Nat.div_lt_iff_lt_mul E.W_pos).2 (hlt k)
  have hdiv := ht.dvdW (Can.wc E.W) htS
  have hmod := ht.modW (Can.wc E.W) htS
  have hUu : Knows m Bk sk y (fun k => E.Uc (nk k) (hk k) (μk k * r) (tk k / E.W)) :=
    Can.fetch (t := w) (L := fun k => Layout.std (E.NUc (nk k) (hk k) (μk k * r)))
      (v := fun k p => E.Uc (nk k) (hk k) (μk k * r) p.val) (i := fun k => ⟨tk k / E.W, hp k⟩) hU hdiv
  have sU : Small Bk (fun k => E.Uc (nk k) (hk k) (μk k * r) (tk k / E.W)) :=
    hs.mono (fun k => by
      have h1 := MXR.U_lt (hp k) (W := E.W) (tq := E.tq) (mx := E.mx)
      have h2 : E.W^(hk k) ≤ E.W^(hk k + 1) := Nat.pow_le_pow_right E.W_pos (Nat.le_succ _)
      exact (h1.trans_le h2).le)
  have sPC : Small Bk (fun k => E.parCode (nk k) (hk k) (μk k) r (tk k)) :=
    hs.mono (fun k => (E.parCode_lt _ _ _ _ _ (hlt k)).le)
  refine ⟨?_, sPC⟩
  have sM : Small Bk (fun k => tk k % E.W) := (Small.const _ E.W).mono (fun k => (Nat.mod_lt _ E.W_pos).le)
  exact (hmod.plus ((Can.wc E.W).times hUu (Small.const _ _) sU) sM ((Small.const _ _).mul sU)).cong
    (fun _ => rfl) (fun _ => rfl)

lemma can_IT (ci : CIn m B s x n (fun i => h i + 1) μ) (r : ℕ)
    (hN : Knows m B s x (E.Nc n h μ r)) (hU : Has m B s (a w) x (E.UTc n h μ r))
    (hWh : Knows m B s x (fun i => E.W^(h i + 1))) :
    Can m B s (a w) x (E.ITt n h μ r) (fun i => 0 + E.Nc n h μ r i + E.Nc n h μ r i * (h i + 2)) := by
  let SL := UnitF (E.Nc n h μ r)
  let yS (u : SL) : T (p s w) := (x u.1, u.2.val)
  have ciS : CIn m (fun u : SL => B u.1) (p s w) yS (fun u => n u.1) (fun u => h u.1 + 1) (fun u => μ u.1) :=
    ci.reindex (fun u : SL => u.1) yS Can.first
  have hs : Small (fun u : SL => B u.1) (fun u => E.W^(h u.1 + 1)) := ciS.powS E.W
  obtain ⟨hpc, spc⟩ := E.knows_parCode (y := yS) (nk := fun u => n u.1) (hk := fun u => h u.1)
    (μk := fun u => μ u.1) r (tk := fun u => u.2.val) Can.second (fun u => u.2.2)
    (Can.first.then_do (hU.reindex (fun u : SL => u.1))) hs
  have hin := E.knows_inR ciS hpc spc (Can.first.then_do (hWh.reindex (fun u : SL => u.1)))
  have hind : Can m (fun u : SL => B u.1) (p s w) w yS
      (fun u => if E.srcP (n u.1) (h u.1) (μ u.1) r u.2.val then 1 else 0) (fun u => h u.1 + 2) := by
    refine ((Can.wc 1).wsub hin ((Small.const _ 1).mono (fun _ => Nat.sub_le _ _))).cong (fun _ => rfl)
      (fun u => ?_)
    by_cases hr : inRS E.W E.tq E.mx (n u.1) (h u.1 + 1) (μ u.1) (E.parCode (n u.1) (h u.1) (μ u.1) r u.2.val)
    · have hs : ¬ E.srcP (n u.1) (h u.1) (μ u.1) r u.2.val := fun hs => hs.2 hr
      simp [hr, hs]
    · have hs : E.srcP (n u.1) (h u.1) (μ u.1) r u.2.val := ⟨u.2.2, hr⟩
      simp [hr, hs]
  exact Can.layout (m := m) (t := w) (L := fun i => Layout.std (E.Nc n h μ r i))
    (v := fun i t => if E.srcP (n i) (h i) (μ i) r t.val then 1 else 0) (P := fun i => h i + 2)
    (W := fun _ => 0) hN hind ((ci.powS E.W).mono (fun i => E.Nc_le r i))

lemma has_ITat {κ : Type V} {Bk : κ → ℕ} {sk : Ty} {y : κ → T sk} {nk hk μk : κ → ℕ} (r : ℕ)
    {jk : κ → ℕ} (hIT : Has m Bk sk (a w) y (E.ITt nk hk μk r)) (hj : Knows m Bk sk y jk)
    (hlt : ∀ k, jk k < E.Nc nk hk μk r k) :
    Knows m Bk sk y (fun k => if E.srcP (nk k) (hk k) (μk k) r (jk k) then 1 else 0) :=
  Can.fetch (t := w) (L := fun k => Layout.std (E.Nc nk hk μk r k))
    (v := fun k t => if E.srcP (nk k) (hk k) (μk k) r t.val then 1 else 0) (i := fun k => ⟨jk k, hlt k⟩) hIT hj

lemma hindN (r : ℕ) (hIT : Has m B s (a w) x (E.ITt n h μ r)) :
    Can m (fun d : During (E.Nc n h μ r) => B d.i) (p s w) w (fun d => (x d.i, d.j))
      (fun d => if E.srcP (n d.i) (h d.i) (μ d.i) r d.j then 1 else 0) (fun _ => 0) :=
  E.has_ITat (nk := fun d : During (E.Nc n h μ r) => n d.i) (hk := fun d => h d.i) (μk := fun d => μ d.i) r
    (Can.first.then_do (hIT.reindex During.i)) Can.second (fun d => d.hj)

lemma can_CT (r : ℕ) (hN : Knows m B s x (E.Nc n h μ r)) (hNs : Small B (E.Nc n h μ r))
    (hIT : Has m B s (a w) x (E.ITt n h μ r)) :
    Can m B s (a w) x (E.CTt n h μ r)
      (fun i => 0 + E.Nc n h μ r i + E.Nc n h μ r i * (E.Nc n h μ r i + 1)) := by
  let SL := UnitF (E.Nc n h μ r)
  have hbody : Can m (fun u : SL => B u.1) (p s w) w (fun u => (x u.1, u.2.val))
      (fun u => Nat.count (E.srcP (n u.1) (h u.1) (μ u.1) r) u.2.val) (fun u => E.Nc n h μ r u.1 + 1) := by
    have hind : Can m (fun d : During (fun u : SL => u.2.val) => B d.i.1) (p (p s w) w) w
        (fun d => ((x d.i.1, d.i.2.val), d.j))
        (fun d => if E.srcP (n d.i.1) (h d.i.1) (μ d.i.1) r d.j then 1 else 0) (fun _ => 0) :=
      E.has_ITat (nk := fun d : During (fun u : SL => u.2.val) => n d.i.1) (hk := fun d => h d.i.1)
        (μk := fun d => μ d.i.1) r
        ((Can.first.then_do Can.first).then_do (hIT.reindex (fun d : During (fun u : SL => u.2.val) => d.i.1)))
        Can.second (fun d => d.hj.trans d.i.2.2)
    have hT : Knows m (fun u : SL => B u.1) (p s w) (fun u : SL => (x u.1, u.2.val)) (fun u => u.2.val) :=
      Can.second
    have H := can_count (P := fun u : SL => E.srcP (n u.1) (h u.1) (μ u.1) r) (T := fun u => u.2.val)
      (Wt := fun _ => 0) hT
      ((hNs.reindex (fun u : SL => u.1)).mono (fun u => u.2.2.le)) hind
    exact H.mono (fun u => by have := u.2.2; simp only [Nat.zero_add, Nat.mul_one]; omega)
  exact Can.layout (m := m) (t := w) (L := fun i => Layout.std (E.Nc n h μ r i))
    (v := fun i t => Nat.count (E.srcP (n i) (h i) (μ i) r) t.val) (P := fun i => E.Nc n h μ r i + 1)
    (W := fun _ => 0) hN hbody hNs

lemma can_own (r : ℕ) (hN : Knows m B s x (E.Nc n h μ r)) (hNs : Small B (E.Nc n h μ r))
    (hIT : Has m B s (a w) x (E.ITt n h μ r)) :
    Can m B s w x (fun i => Nat.count (E.srcP (n i) (h i) (μ i) r) (E.Nc n h μ r i))
      (fun i => E.Nc n h μ r i * (0 + 1) + 1) :=
  can_count (P := fun i => E.srcP (n i) (h i) (μ i) r) (T := E.Nc n h μ r) (Wt := fun _ => 0) hN hNs
    (E.hindN r hIT)

abbrev UTp (n h μ : ι → ℕ) (i : ι) : Tape ℕ :=
  (Layout.std (E.NUc (n i) (h i + 1) (μ i))).tape (fun p => E.Uc (n i) (h i + 1) (μ i) p)

abbrev PCTp (n h μ : ι → ℕ) (i : ι) : Tape ℕ :=
  (Layout.std (E.W^(h i + 1))).tape (fun t => E.PCc (n i) (h i + 1) (μ i) t)

abbrev PCTc (n h μ : ι → ℕ) (r : ℕ) (i : ι) : Tape ℕ :=
  (Layout.std (E.W^(h i))).tape (fun t => E.PCc (n i) (h i) (μ i * r) t)

abbrev cjobF (n h μ : ι → ℕ) (l : ρ) (r : ℕ) (z : Fin r → Space α) (ind : LinearIndependent F z)
    (hr : r ≤ E.X.n) (V : ∀ i, E.CState (n i) (h i + 1) (μ i)) (oc : ι → ℕ)
    (sup : ∀ i, ℕ → Bits (n i) → ℂ) (i : ι) : ℕ → Bits (n i) → ℂ :=
  cjob E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc (n i) (h i + 1) (μ i)) (V i)
    (E.flR (n i) (h i) (μ i) r) (E.ppR (n i) (h i) (μ i) r) (E.siR (n i) (h i) (μ i) r (oc i))
    (E.ppR_lt (n i) (h i) (μ i) r) (sup i)

lemma can_OJ (c : E.Ctx m B s x n (fun i => h i + 1) μ) {l : ρ} {r : ℕ} {z : Fin r → Space α}
    {ind : LinearIndependent F z} (hr : r ≤ E.X.n) {V : ∀ i, E.CState (n i) (h i + 1) (μ i)}
    (hV : Has m B s (ctabT cl) x (E.tabV n (fun i => h i + 1) μ V))
    (hPC : Has m B s (a w) x (E.PCTp n h μ)) (hU : Has m B s (a w) x (E.UTc n h μ r))
    (hIT : Has m B s (a w) x (E.ITt n h μ r)) (hCT : Has m B s (a w) x (E.CTt n h μ r))
    {oc BS : ι → ℕ} (hoc : Knows m B s x oc) {sup : ∀ i, ℕ → Bits (n i) → ℂ}
    (hsup : Has m B s (jobsT cl) x (fun i => jobsTape (n i) (BS i) (sup i)))
    (hown : ∀ i, oc i + Nat.count (E.srcP (n i) (h i) (μ i) r) (E.Nc n h μ r i) ≤ BS i)
    (hN : Knows m B s x (E.Nc n h μ r)) (hNs : Small B (E.Nc n h μ r))
    (hs : Small B (fun i => E.W^(h i + 1))) (hBSs : Small B BS) :
    Can m B s (jobsT cl) x (fun i => jobsTape (n i) (E.Nc n h μ r i) (E.cjobF n h μ l r z ind hr V oc sup i))
      (fun i => E.Nc n h μ r i * (2^(n i) + 1)) := by
  let EL := Σ u : UnitF (E.Nc n h μ r), Bits (n u.1)
  let yE (d : EL) : T (p (p s w) w) := ((x d.1.1, d.1.2.val), (bits (n d.1.1)).loc d.2)
  have lift : ∀ {t : Ty} {v : ι → T t}, Has m B s t x v →
      Has m (fun d : EL => B d.1.1) (p (p s w) w) t yE (fun d => v d.1.1) :=
    fun hv => (Can.first.then_do Can.first).then_do (hv.reindex (fun d : EL => d.1.1))
  have ht : Knows m (fun d : EL => B d.1.1) (p (p s w) w) yE (fun d => d.1.2.val) :=
    Can.first.then_do Can.second
  have hsE : Small (fun d : EL => B d.1.1) (fun d => E.W^(h d.1.1 + 1)) := hs.reindex _
  have heE : Knows m (fun d : EL => B d.1.1) (p (p s w) w) yE (fun d => (bits (n d.1.1)).loc d.2) := Can.second
  have hxE : Has m (fun d : EL => B d.1.1) (p (p s w) w) s yE (fun d => x d.1.1) := lift Can.id
  have hitv := E.has_ITat (nk := fun d : EL => n d.1.1) (hk := fun d => h d.1.1) (μk := fun d => μ d.1.1) r
    (lift hIT) ht (fun d => d.1.2.2)
  have hel : Has m (fun d : EL => B d.1.1) (p (p s w) w) (Ty.c cl) yE
      (fun d => E.cjobF n h μ l r z ind hr V oc sup d.1.1 d.1.2.val d.2) := by
    refine Can.testz hitv ?_ ?_
    · -- a fed slot: the job of parent unit `ppR t`
      let K := {d : EL // (if E.srcP (n d.1.1) (h d.1.1) (μ d.1.1) r d.1.2.val then 1 else 0) = 0}
      have hns : ∀ d : K, ¬ E.srcP (n d.1.1.1) (h d.1.1.1) (μ d.1.1.1) r d.1.1.2.val := fun d hs' => by
        have := d.2; rw [if_pos hs'] at this; exact absurd this (by omega)
      have hf : ∀ d : K, E.flR (n d.1.1.1) (h d.1.1.1) (μ d.1.1.1) r d.1.1.2.val ≠ 0 := fun d => by
        rw [E.flR_eq _ _ _ _ _ d.1.1.2.2, if_neg (hns d)]; omega
      obtain ⟨hpc, spc⟩ := E.knows_parCode (y := fun d : K => yE d.1) (nk := fun d => n d.1.1.1)
        (hk := fun d => h d.1.1.1) (μk := fun d => μ d.1.1.1) r (tk := fun d => d.1.1.2.val)
        (ht.reindex (fun d : K => d.1)) (fun d => d.1.1.2.2) ((lift hU).reindex (fun d : K => d.1))
        (hsE.reindex _)
      have hpp : Knows m (fun d : K => B d.1.1.1) (p (p s w) w) (fun d => yE d.1)
          (fun d => E.ppR (n d.1.1.1) (h d.1.1.1) (μ d.1.1.1) r d.1.1.2.val) :=
        Can.fetch (t := w) (L := fun d : K => Layout.std (E.W^(h d.1.1.1 + 1)))
          (v := fun d t => E.PCc (n d.1.1.1) (h d.1.1.1 + 1) (μ d.1.1.1) t.val)
          (i := fun d => ⟨_, E.parCode_lt _ _ _ _ _ d.1.1.2.2⟩) ((lift hPC).reindex (fun d : K => d.1)) hpc
      let jU (d : K) : UnitF (fun i => E.NUc (n i) (h i + 1) (μ i)) :=
        ⟨d.1.1.1, ⟨E.ppR (n d.1.1.1) (h d.1.1.1) (μ d.1.1.1) r d.1.1.2.val, E.ppR_lt _ _ _ _ _ (hf d)⟩⟩
      have hread := E.has_placeRead c (V := V) jU ((hxE.reindex (fun d : K => d.1)).pair hpp)
        ((lift hV).reindex (fun d : K => d.1)) (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (fun d => d.1.2)
        (heE.reindex (fun d : K => d.1))
      refine hread.cong (fun _ => rfl) (fun d => ?_)
      dsimp only [Eng.cjobF]
      rw [E.cjob_fed _ _ _ _ _ _ l r z ind hr _ (hf d)]
      rfl
    · -- a source slot: the supply at `oc + count`
      let K := {d : EL // (if E.srcP (n d.1.1) (h d.1.1) (μ d.1.1) r d.1.2.val then 1 else 0) ≠ 0}
      have hsrc : ∀ d : K, E.srcP (n d.1.1.1) (h d.1.1.1) (μ d.1.1.1) r d.1.1.2.val := fun d => by
        by_contra hn; exact d.2 (if_neg hn)
      have hcnt : Knows m (fun d : K => B d.1.1.1) (p (p s w) w) (fun d => yE d.1)
          (fun d => Nat.count (E.srcP (n d.1.1.1) (h d.1.1.1) (μ d.1.1.1) r) d.1.1.2.val) :=
        Can.fetch (t := w) (L := fun d : K => Layout.std (E.Nc n h μ r d.1.1.1))
          (v := fun d t => Nat.count (E.srcP (n d.1.1.1) (h d.1.1.1) (μ d.1.1.1) r) t.val)
          (i := fun d => d.1.1.2) ((lift hCT).reindex (fun d : K => d.1)) (ht.reindex (fun d : K => d.1))
      have hlt : ∀ d : K, oc d.1.1.1 + Nat.count (E.srcP (n d.1.1.1) (h d.1.1.1) (μ d.1.1.1) r) d.1.1.2.val
          < BS d.1.1.1 := fun d => by
        have h1 := MXR.count_lt_of_mem (hsrc d) d.1.1.2.2
        have h2 := hown d.1.1.1
        omega
      have hBSK : Small (fun d : K => B d.1.1.1) (fun d => BS d.1.1.1) := hBSs.reindex _
      have hocK : Knows m (fun d : K => B d.1.1.1) (p (p s w) w) (fun d => yE d.1) (fun d => oc d.1.1.1) :=
        (lift hoc).reindex (fun d : K => d.1)
      have hsi := hocK.plus hcnt (hBSK.mono (fun d => by have := hlt d; omega))
        (hBSK.mono (fun d => by have := hlt d; omega))
      have hrd := has_jobsRead (n := fun d : K => n d.1.1.1) (N := fun d => BS d.1.1.1)
        (J := fun d => sup d.1.1.1) ((lift hsup).reindex (fun d : K => d.1)) hsi hlt
        (heE.reindex (fun d : K => d.1))
      refine hrd.cong (fun _ => rfl) (fun d => ?_)
      dsimp only [Eng.cjobF]
      rw [E.cjob_src _ _ _ _ _ _ l r z ind hr _ (hsrc d)]
  exact can_jobsTape (N := E.Nc n h μ r) hN c.p2n hNs c.big hel

end Block

section Block2
universe V
variable {ι : Type V} {m : Bool} {B : ι → ℕ} {s : Ty} {x : ι → T s} {cl : Paint} {n h μ : ι → ℕ}

lemma scatter_hit {n0 h0 μ0 : ℕ} (V0' : E.CState n0 (h0 + 1) μ0) {l : ρ} {r : ℕ} {z : Fin r → Space α}
    {ind : LinearIndependent F z} (hr : r ≤ E.X.n) (J' : ℕ → Bits n0 → ℂ)
    (hJ' : ∀ (p : Fin (E.NUc n0 (h0 + 1) μ0)) (e : Bits n0), J' (E.slotR n0 h0 μ0 r p) e =
      hlow n0 (r * E.cUc n0 (h0 + 1) μ0 p) (blockJob (bS z ind) (bX (α:=α) r) _ _ n0
        (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc n0 (h0 + 1) μ0 p)) l (V0' p)) e)
    (p : Fin (E.NUc n0 (h0 + 1) μ0)) (q : Bits (E.iUc n0 (h0 + 1) μ0 p))
    (b : Beach α ρ 0 (E.cUc n0 (h0 + 1) μ0 p)) (hb : b.1 = l) :
    J' (E.slotR n0 h0 μ0 r p) (placeS (bS z ind) (bX (α:=α) r) _ _ n0
        (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc n0 (h0 + 1) μ0 p)) (q, b.2.2)) =
      E.stepV V0' (GMove.old (BMove.block l r z ind)) p q b := by
  obtain ⟨l1, g1⟩ := b
  simp only at hb
  subst hb
  rw [hJ', E.stepV_block _ _ _ _ _ hr]

lemma scatter_miss {n0 h0 μ0 : ℕ} (V0' : E.CState n0 h0 μ0) {l : ρ} {r : ℕ} {z : Fin r → Space α}
    {ind : LinearIndependent F z} (p : Fin (E.NUc n0 h0 μ0)) (q : Bits (E.iUc n0 h0 μ0 p))
    (b : Beach α ρ 0 (E.cUc n0 h0 μ0 p)) (hb : b.1 ≠ l) :
    V0' p q b = E.stepV V0' (GMove.old (BMove.block l r z ind)) p q b := by
  obtain ⟨l1, g1⟩ := b
  exact (E.stepV_other V0' l r z ind p q l1 hb g1).symm

lemma can_scatter (c : E.Ctx m B s x n (fun i => h i + 1) μ) {l : ρ} {r : ℕ} {z : Fin r → Space α}
    {ind : LinearIndependent F z} (hr : r ≤ E.X.n) (hrs : ∀ a, a < E.W → r ≤ E.tq a)
    {V : ∀ i, E.CState (n i) (h i + 1) (μ i)}
    (hV : Has m B s (ctabT cl) x (E.tabV n (fun i => h i + 1) μ V))
    (hUp : Has m B s (a w) x (E.UTp n h μ)) (hPCc : Has m B s (a w) x (E.PCTc n h μ r))
    {J' : ∀ i, ℕ → Bits (n i) → ℂ}
    (hout : Has m B s (jobsT cl) x (fun i => jobsTape (n i) (E.Nc n h μ r i) (J' i)))
    (hJ' : ∀ i (p : Fin (E.NUc (n i) (h i + 1) (μ i))) (e : Bits (n i)),
      J' i (E.slotR (n i) (h i) (μ i) r p) e =
      hlow (n i) (r * E.cUc (n i) (h i + 1) (μ i) p) (blockJob (bS z ind) (bX (α:=α) r) _ _ (n i)
        (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc (n i) (h i + 1) (μ i) p)) l (V i p)) e)
    (hs : Small B (fun i => E.W^(h i + 1))) :
    Can m B s (ctabT cl) x
      (E.tabV n (fun i => h i + 1) μ (fun i => E.stepV (V i) (GMove.old (BMove.block l r z ind))))
      (fun i => E.passCost (n i) (E.NUc (n i) (h i + 1) (μ i))) := by
  refine E.can_scatterG c hV l (fun i p q b hb => E.scatter_miss (V i) p q b hb) ?_
  let K := {d : E.ElemF n (fun i => h i + 1) μ // d.2.1 = l}
  let yK (d : K) := E.elemEnv x n (fun i => h i + 1) μ d.1
  have lift : ∀ {t : Ty} {v : ι → T t}, Has m B s t x v → Has m (fun d : K => B d.1.1.1.1) (p (IEnv s) w) t yK
      (fun d => v d.1.1.1.1) :=
    fun hv => (Can.first.then_do (Can.first.then_do Can.first)).then_do (hv.reindex (fun d : K => d.1.1.1.1))
  have hp : Knows m (fun d : K => B d.1.1.1.1) _ yK (fun d => d.1.1.1.2.val) :=
    Can.first.then_do (Can.first.then_do Can.second)
  have hsK : Small (fun d : K => B d.1.1.1.1) (fun d => E.W^(h d.1.1.1.1 + 1)) := hs.reindex _
  have hUu : Knows m (fun d : K => B d.1.1.1.1) _ yK
      (fun d => E.Uc (n d.1.1.1.1) (h d.1.1.1.1 + 1) (μ d.1.1.1.1) d.1.1.1.2) :=
    Can.fetch (t := w) (L := fun d : K => Layout.std (E.NUc (n d.1.1.1.1) (h d.1.1.1.1 + 1) (μ d.1.1.1.1)))
      (v := fun d p => E.Uc (n d.1.1.1.1) (h d.1.1.1.1 + 1) (μ d.1.1.1.1) p.val) (i := fun d => d.1.1.1.2)
      (lift hUp) hp
  have hUlt : ∀ d : K, E.Uc (n d.1.1.1.1) (h d.1.1.1.1 + 1) (μ d.1.1.1.1) d.1.1.1.2 < E.W^(h d.1.1.1.1 + 1) :=
    fun d => MXR.U_lt d.1.1.1.2.2
  have sU := hsK.mono (fun d => (hUlt d).le)
  have hdl : ∀ d : K, E.Uc (n d.1.1.1.1) (h d.1.1.1.1 + 1) (μ d.1.1.1.1) d.1.1.1.2 / E.W < E.W^(h d.1.1.1.1) :=
    fun d => (Nat.div_lt_iff_lt_mul E.W_pos).2 (by rw [← Nat.pow_succ]; exact hUlt d)
  have hPC : Knows m (fun d : K => B d.1.1.1.1) _ yK
      (fun d => E.PCc (n d.1.1.1.1) (h d.1.1.1.1) (μ d.1.1.1.1 * r)
        (E.Uc (n d.1.1.1.1) (h d.1.1.1.1 + 1) (μ d.1.1.1.1) d.1.1.1.2 / E.W)) :=
    Can.fetch (t := w) (L := fun d : K => Layout.std (E.W^(h d.1.1.1.1)))
      (v := fun d t => E.PCc (n d.1.1.1.1) (h d.1.1.1.1) (μ d.1.1.1.1 * r) t.val)
      (i := fun d => ⟨_, hdl d⟩) (lift hPCc) (hUu.dvdW (Can.wc E.W) sU)
  have sPC : Small (fun d : K => B d.1.1.1.1) (fun d => E.PCc (n d.1.1.1.1) (h d.1.1.1.1) (μ d.1.1.1.1 * r)
      (E.Uc (n d.1.1.1.1) (h d.1.1.1.1 + 1) (μ d.1.1.1.1) d.1.1.1.2 / E.W)) := hsK.mono (fun d => (MXR.count_le_self (p := inRS E.W E.tq E.mx (n d.1.1.1.1) (h d.1.1.1.1) (μ d.1.1.1.1 * r)) _).trans
    ((Nat.div_le_self _ _).trans (hUlt d).le))
  have hslot : Knows m (fun d : K => B d.1.1.1.1) _ yK
      (fun d => E.slotR (n d.1.1.1.1) (h d.1.1.1.1) (μ d.1.1.1.1) r d.1.1.1.2) :=
    (hPC.times (Can.wc E.W) sPC (Small.const _ _)).plus (hUu.modW (Can.wc E.W) sU)
      (sPC.mul (Small.const _ _)) ((Small.const _ E.W).mono (fun _ => (Nat.mod_lt _ E.W_pos).le))
  have haddr := E.knows_hitAddr c l (bS z ind) (bX (α:=α) r) (E.bX_n hr)
  exact (has_jobsRead (n := fun d : K => n d.1.1.1.1) (N := fun d => E.Nc n h μ r d.1.1.1.1)
    (J := fun d => J' d.1.1.1.1) (lift hout) hslot (fun d => (E.slotR_spec _ _ _ r hrs d.1.1.1.2).1) haddr).cong
    (fun _ => rfl) (fun d => E.scatter_hit (V d.1.1.1.1) hr (J' d.1.1.1.1) (hJ' d.1.1.1.1) d.1.1.1.2 d.1.1.2 d.1.2 d.2)

abbrev own (n h μ : ι → ℕ) (r : ℕ) (i : ι) : ℕ := (E.ownSrc (n i) (h i) (μ i) r).length

lemma own_eq (r : ℕ) (i : ι) :
    E.own n h μ r i = Nat.count (E.srcP (n i) (h i) (μ i) r) (E.Nc n h μ r i) :=
  E.ownSrc_len _ _ _ _

lemma can_nthSrc (r : ℕ) (hN : Knows m B s x (E.Nc n h μ r)) (hNs : Small B (E.Nc n h μ r))
    (hIT : Has m B s (a w) x (E.ITt n h μ r)) {j : ι → ℕ} (hj : Knows m B s x j)
    (hjl : ∀ i, j i < E.own n h μ r i) :
    Can m B s w x (fun i => Nat.nth (E.srcP (n i) (h i) (μ i) r) (j i)) (fun i => E.Nc n h μ r i * (0 + 1) + 1) := by
  have H := can_nthc (P := fun i => E.srcP (n i) (h i) (μ i) r) (T := E.Nc n h μ r) (Wt := fun _ => 0)
    (q := j) hN hNs hj
    (E.hindN r hIT)
  refine H.cong (fun _ => rfl) (fun i => ?_)
  have := hjl i
  rw [E.own_eq] at this
  rw [if_pos this]

lemma nth_lt (r : ℕ) (i : ι) {j : ℕ} (hj : j < E.own n h μ r i) :
    Nat.nth (E.srcP (n i) (h i) (μ i) r) j < E.Nc n h μ r i ∧
      E.srcP (n i) (h i) (μ i) r (Nat.nth (E.srcP (n i) (h i) (μ i) r) j) ∧
      Nat.count (E.srcP (n i) (h i) (μ i) r) (Nat.nth (E.srcP (n i) (h i) (μ i) r) j) = j := by
  rw [E.own_eq] at hj
  obtain ⟨h1, h2, h3⟩ := MXR.nth_spec hj
  exact ⟨h2, h1, h3⟩

lemma can_OA (r : ℕ) (hN : Knows m B s x (E.Nc n h μ r)) (hNs : Small B (E.Nc n h μ r))
    (hIT : Has m B s (a w) x (E.ITt n h μ r)) (hown : Knows m B s x (E.own n h μ r))
    (hownS : Small B (E.own n h μ r)) {J' : ∀ i, ℕ → Bits (n i) → ℂ}
    (hout : Has m B s (jobsT cl) x (fun i => jobsTape (n i) (E.Nc n h μ r i) (J' i))) :
    Can m B s (jobsT cl) x
      (fun i => jobsTape (n i) (E.own n h μ r i) (fun j => J' i (Nat.nth (E.srcP (n i) (h i) (μ i) r) j)))
      (fun i => 0 + E.own n h μ r i + E.own n h μ r i * (E.Nc n h μ r i * (0 + 1) + 1 + 0)) := by
  let UO := UnitF (E.own n h μ r)
  have hnth := E.can_nthSrc (x := fun u : UO => (x u.1, u.2.val)) (n := fun u => n u.1) (h := fun u => h u.1)
    (μ := fun u => μ u.1) r (Can.first.then_do (hN.reindex (fun u : UO => u.1))) (hNs.reindex _)
    (Can.first.then_do (hIT.reindex (fun u : UO => u.1))) Can.second (fun u => u.2.2)
  have hget : Has m (fun u : UO => B u.1) (p (p s w) w) (a (Ty.c cl))
      (fun u => ((x u.1, u.2.val), Nat.nth (E.srcP (n u.1) (h u.1) (μ u.1) r) u.2.val))
      (fun u => (bits (n u.1)).tape (J' u.1 (Nat.nth (E.srcP (n u.1) (h u.1) (μ u.1) r) u.2.val))) :=
    has_jobsAt ((Can.first.then_do Can.first).then_do (hout.reindex (fun u : UO => u.1))) Can.second
      (fun u => (E.nth_lt r u.1 u.2.2).1)
  exact Can.layout (m := m) (t := a (Ty.c cl)) (L := fun i => Layout.std (E.own n h μ r i))
    (v := fun i j => (bits (n i)).tape (J' i (Nat.nth (E.srcP (n i) (h i) (μ i) r) j.val)))
    (P := fun i => E.Nc n h μ r i * (0 + 1) + 1 + 0) (W := fun _ => 0) hown (hnth.save hget) hownS

lemma can_OS (r : ℕ) (ci : CIn m B s x n h (fun i => μ i * r)) (hN : Knows m B s x (E.Nc n h μ r))
    (hNs : Small B (E.Nc n h μ r)) (hIT : Has m B s (a w) x (E.ITt n h μ r))
    (hU : Has m B s (a w) x (E.UTc n h μ r))
    (hown : Knows m B s x (E.own n h μ r)) (hownS : Small B (E.own n h μ r)) :
    Can m B s (a w) x
      (fun i => (Layout.std (E.own n h μ r i)).tape
        (fun j => E.slotSize (n i) (h i) (μ i * r) (Nat.nth (E.srcP (n i) (h i) (μ i) r) j)))
      (fun i => 0 + E.own n h μ r i + E.own n h μ r i * (E.Nc n h μ r i * (0 + 1) + 1 + (h i + 1))) := by
  let UO := UnitF (E.own n h μ r)
  have hnth := E.can_nthSrc (x := fun u : UO => (x u.1, u.2.val)) (n := fun u => n u.1) (h := fun u => h u.1)
    (μ := fun u => μ u.1) r (Can.first.then_do (hN.reindex (fun u : UO => u.1))) (hNs.reindex _)
    (Can.first.then_do (hIT.reindex (fun u : UO => u.1))) Can.second (fun u => u.2.2)
  let tt (u : UO) : ℕ := Nat.nth (E.srcP (n u.1) (h u.1) (μ u.1) r) u.2.val
  let y2 (u : UO) : T (p (p s w) w) := ((x u.1, u.2.val), tt u)
  have htl : ∀ u : UO, tt u < E.Nc n h μ r u.1 := fun u => (E.nth_lt r u.1 u.2.2).1
  have cu : CIn m (fun u : UO => B u.1) (p (p s w) w) y2 (fun u => n u.1) (fun u => h u.1) (fun u => μ u.1 * r) :=
    ci.reindex (fun u : UO => u.1) y2 (Can.first.then_do Can.first)
  have hs := cu.powS E.W
  have htS : Small (fun u : UO => B u.1) tt := (hNs.reindex (fun u : UO => u.1)).mono (fun u => (htl u).le)
  have htK : Knows m (fun u : UO => B u.1) (p (p s w) w) y2 tt := Can.second
  have hmod := htK.modW (Can.wc E.W) htS
  have hdiv := htK.dvdW (Can.wc E.W) htS
  have hp : ∀ u : UO, tt u / E.W < E.NUc (n u.1) (h u.1) (μ u.1 * r) := fun u =>
    (Nat.div_lt_iff_lt_mul E.W_pos).2 (htl u)
  have hUu : Knows m (fun u : UO => B u.1) (p (p s w) w) y2
      (fun u => E.Uc (n u.1) (h u.1) (μ u.1 * r) (tt u / E.W)) :=
    Can.fetch (t := w) (L := fun u : UO => Layout.std (E.NUc (n u.1) (h u.1) (μ u.1 * r)))
      (v := fun u p => E.Uc (n u.1) (h u.1) (μ u.1 * r) p.val) (i := fun u => ⟨tt u / E.W, hp u⟩)
      ((Can.first.then_do Can.first).then_do (hU.reindex (fun u : UO => u.1))) hdiv
  have sU : Small (fun u : UO => B u.1) (fun u => E.Uc (n u.1) (h u.1) (μ u.1 * r) (tt u / E.W)) :=
    hs.mono (fun u => (MXR.U_lt (hp u)).le)
  have hcol := E.can_colS cu.hK cu.hS hUu sU (cu.powS E.mx)
  have hcs : Small (fun u : UO => B u.1) (fun u => colS E.W E.tq (h u.1) (E.Uc (n u.1) (h u.1) (μ u.1 * r) (tt u / E.W))) :=
    (cu.powS E.mx).mono (fun u => (E.stepC_iter_le _ _).1)
  have hcU := (cu.μK.mono (fun _ => Nat.zero_le _)).times hcol cu.μS hcs
  have htq : Knows m (fun u : UO => B u.1) (p (p s w) w) y2 (fun u => E.tq (tt u % E.W)) :=
    E.knows_tq hmod (fun u => Nat.mod_lt _ E.W_pos)
  have hsz : Can m (fun u : UO => B u.1) (p (p s w) w) w y2
      (fun u => E.slotSize (n u.1) (h u.1) (μ u.1 * r) (tt u)) (fun u => h u.1 + 1) :=
    ((htq.mono (fun _ => Nat.zero_le _)).times hcU ((Small.const _ E.mx).mono (fun u => E.tq_le _))
      (cu.μS.mul hcs)).cong (fun _ => rfl) (fun _ => rfl)
  exact Can.layout (m := m) (t := w) (L := fun i => Layout.std (E.own n h μ r i))
    (v := fun i j => E.slotSize (n i) (h i) (μ i * r) (Nat.nth (E.srcP (n i) (h i) (μ i) r) j.val))
    (P := fun i => E.Nc n h μ r i * (0 + 1) + 1 + (h i + 1)) (W := fun _ => 0) hown (hnth.save hsz) hownS

lemma acc_getD (n0 h0 μ0 r : ℕ) (acc : List ℕ) (k : ℕ) :
    (acc ++ E.accR n0 h0 μ0 r).getD k 0 =
      if k < acc.length then acc.getD k 0
      else if k < acc.length + (E.ownSrc n0 h0 μ0 r).length then
        E.slotSize n0 h0 (μ0 * r) (Nat.nth (E.srcP n0 h0 μ0 r) (k - acc.length))
      else E.csz n0 h0 (μ0 * r) (k - acc.length - (E.ownSrc n0 h0 μ0 r).length) := by
  by_cases h1 : k < acc.length
  · rw [if_pos h1, EngArith.getD_append_left _ _ _ h1]
  · rw [if_neg h1]
    have e1 : (acc ++ E.accR n0 h0 μ0 r).getD k 0 = (E.accR n0 h0 μ0 r).getD (k - acc.length) 0 := by
      have := EngArith.getD_append_right acc (E.accR n0 h0 μ0 r) 0 (k - acc.length)
      rwa [show acc.length + (k - acc.length) = k by omega] at this
    rw [e1]
    unfold accR
    by_cases h2 : k < acc.length + (E.ownSrc n0 h0 μ0 r).length
    · rw [if_pos h2, EngArith.getD_append_left _ _ _ (by omega)]
      unfold ownSrc
      apply getD_fm_nth
      rw [← E.ownSrc_len]
      omega
    · rw [if_neg h2]
      have := EngArith.getD_append_right (E.ownSrc n0 h0 μ0 r) (E.srcSizes n0 h0 (μ0 * r)) 0
        (k - acc.length - (E.ownSrc n0 h0 μ0 r).length)
      rw [show (E.ownSrc n0 h0 μ0 r).length + (k - acc.length - (E.ownSrc n0 h0 μ0 r).length) =
        k - acc.length by omega] at this
      rw [this]
      rfl

end Block2

section Block3
universe V
variable {ι : Type V} {m : Bool} {B : ι → ℕ} {s : Ty} {x : ι → T s} {cl : Paint} {n h μ : ι → ℕ}

lemma can_cat3 {t : Ty} {L O C : ι → ℕ} {f1 f2 f3 g : ∀ _ : ι, ℕ → T t}
    (hT1 : Has m B s (a t) x (fun i => (Layout.std (L i)).tape (fun k => f1 i k)))
    (hT2 : Has m B s (a t) x (fun i => (Layout.std (O i)).tape (fun k => f2 i k)))
    (hT3 : Has m B s (a t) x (fun i => (Layout.std (C i)).tape (fun k => f3 i k)))
    (hL : Knows m B s x L) (hO : Knows m B s x O) (hC : Knows m B s x C)
    (hsm : Small B (fun i => L i + (O i + C i)))
    (hg : ∀ i k, k < L i + (O i + C i) → g i k = if k < L i then f1 i k
      else if k < L i + O i then f2 i (k - L i) else f3 i (k - L i - O i)) :
    Can m B s (a t) x (fun i => (Layout.std (L i + (O i + C i))).tape (fun k => g i k))
      (fun i => L i + (O i + C i) + 1) := by
  have sL : Small B L := hsm.mono (fun i => by omega)
  have sO : Small B O := hsm.mono (fun i => by omega)
  let U := UnitF (fun i => L i + (O i + C i))
  have lift : ∀ {t' : Ty} {v : ι → T t'}, Has m B s t' x v →
      Has m (fun u : U => B u.1) (p s w) t' (fun u => (x u.1, u.2.val)) (fun u => v u.1) :=
    fun hv => Can.first.then_do (hv.reindex (fun u : U => u.1))
  have hk : Knows m (fun u : U => B u.1) (p s w) (fun u => (x u.1, u.2.val)) (fun u => u.2.val) := Can.second
  have sk : Small (fun u : U => B u.1) (fun u => u.2.val) := (hsm.reindex (fun u : U => u.1)).mono (fun u => u.2.2.le)
  have hel : Has m (fun u : U => B u.1) (p s w) t (fun u => (x u.1, u.2.val)) (fun u => g u.1 u.2.val) := by
    refine Can.testz (hk.wlt (lift hL)) ?_ ?_
    · refine Can.testz ((hk.wlt ((lift hL).plus (lift hO) (sL.reindex _) (sO.reindex _))).reindex
        (fun u : {u : U // (if u.2.val < L u.1 then 1 else 0) = 0} => u.1)) ?_ ?_
      · let K := {u : {u : U // (if u.2.val < L u.1 then 1 else 0) = 0} //
          (if u.1.2.val < L u.1.1 + O u.1.1 then 1 else 0) = 0}
        have h1 : ∀ u : K, ¬ u.1.1.2.val < L u.1.1.1 := fun u hh => by
          have := u.1.2; rw [if_pos hh] at this; exact absurd this one_ne_zero
        have h2 : ∀ u : K, ¬ u.1.1.2.val < L u.1.1.1 + O u.1.1.1 := fun u hh => by
          have := u.2; rw [if_pos hh] at this; exact absurd this one_ne_zero
        have hq3 : ∀ u : K, u.1.1.2.val - L u.1.1.1 - O u.1.1.1 < C u.1.1.1 := fun u => by
          have h0 : u.1.1.2.val < L u.1.1.1 + (O u.1.1.1 + C u.1.1.1) := u.1.1.2.2
          have := h2 u
          omega
        refine (Can.fetch (t := t) (L := fun u : K => Layout.std (C u.1.1.1)) (v := fun u k => f3 u.1.1.1 k.val)
          (i := fun u => ⟨_, hq3 u⟩) ((lift hT3).reindex (fun u : K => u.1.1))
          (((hk.minus (lift hL) sk).minus (lift hO) (sk.mono (fun _ => Nat.sub_le _ _))).reindex
            (fun u : K => u.1.1))).cong (fun _ => rfl) (fun u => ?_)
        rw [hg _ _ u.1.1.2.2, if_neg (h1 u), if_neg (h2 u)]
      · let K := {u : {u : U // (if u.2.val < L u.1 then 1 else 0) = 0} //
          (if u.1.2.val < L u.1.1 + O u.1.1 then 1 else 0) ≠ 0}
        have h1 : ∀ u : K, ¬ u.1.1.2.val < L u.1.1.1 := fun u hh => by
          have := u.1.2; rw [if_pos hh] at this; exact absurd this one_ne_zero
        have h2 : ∀ u : K, u.1.1.2.val < L u.1.1.1 + O u.1.1.1 := fun u => by
          by_contra hn; exact u.2 (if_neg hn)
        have hq2 : ∀ u : K, u.1.1.2.val - L u.1.1.1 < O u.1.1.1 := fun u => by
          have := h1 u
          have := h2 u
          omega
        have hq2 : ∀ u : K, u.1.1.2.val - L u.1.1.1 < O u.1.1.1 := fun u => by
          have := h1 u
          have := h2 u
          omega
        refine (Can.fetch (t := t) (L := fun u : K => Layout.std (O u.1.1.1)) (v := fun u k => f2 u.1.1.1 k.val)
          (i := fun u => ⟨_, hq2 u⟩)
          ((lift hT2).reindex (fun u : K => u.1.1)) ((hk.minus (lift hL) sk).reindex (fun u : K => u.1.1))).cong
          (fun _ => rfl) (fun u => ?_)
        rw [hg _ _ u.1.1.2.2, if_neg (h1 u), if_pos (h2 u)]
    · let K := {u : U // (if u.2.val < L u.1 then 1 else 0) ≠ 0}
      have h1 : ∀ u : K, u.1.2.val < L u.1.1 := fun u => by by_contra hn; exact u.2 (if_neg hn)
      refine (Can.fetch (t := t) (L := fun u : K => Layout.std (L u.1.1)) (v := fun u k => f1 u.1.1 k.val)
        (i := fun u => ⟨u.1.2.val, h1 u⟩) ((lift hT1).reindex (fun u : K => u.1)) (hk.reindex (fun u : K => u.1))).cong
        (fun _ => rfl) (fun u => ?_)
      rw [hg _ _ u.1.2.2, if_pos (h1 u)]
  exact can_ptrTape (t := t) (N := fun i => L i + (O i + C i)) ((hL.plus (hO.plus hC sO (hsm.mono
    (fun i => by omega))) sL (hsm.mono (fun i => by omega)))) hsm hel

lemma can_accA (r : ℕ) {acc : ι → List ℕ} {o : ι → ℕ} {sup : ∀ i, ℕ → Bits (n i) → ℂ}
    {J' : ∀ i, ℕ → Bits (n i) → ℂ}
    (hA : Has m B s (jobsT cl) x (fun i => accA (n i) (acc i) (o i) (sup i)))
    (hOA : Has m B s (jobsT cl) x
      (fun i => jobsTape (n i) (E.own n h μ r i) (fun j => J' i (Nat.nth (E.srcP (n i) (h i) (μ i) r) j))))
    (hC2 : Has m B s (jobsT cl) x (fun i => jobsTape (n i) (E.cons (n i) (h i) (μ i * r))
      (fun k => hlow (n i) (E.csz (n i) (h i) (μ i * r) k)
        (sup i (o i + (acc i).length + E.own n h μ r i + k)))))
    (hJ' : ∀ i j, j < E.own n h μ r i → J' i (Nat.nth (E.srcP (n i) (h i) (μ i) r) j) =
      hlow (n i) (E.slotSize (n i) (h i) (μ i * r) (Nat.nth (E.srcP (n i) (h i) (μ i) r) j))
        (sup i (o i + (acc i).length + j)))
    (hL : Knows m B s x (fun i => (acc i).length)) (hown : Knows m B s x (E.own n h μ r))
    (hcons : Knows m B s x (fun i => E.cons (n i) (h i) (μ i * r)))
    (hsm : Small B (fun i => (acc i ++ E.accR (n i) (h i) (μ i) r).length)) :
    Can m B s (jobsT cl) x (fun i => accA (n i) (acc i ++ E.accR (n i) (h i) (μ i) r) (o i) (sup i))
      (fun i => (acc i ++ E.accR (n i) (h i) (μ i) r).length + 1) := by
  have hlen : ∀ i, (acc i ++ E.accR (n i) (h i) (μ i) r).length =
      (acc i).length + (E.own n h μ r i + E.cons (n i) (h i) (μ i * r)) := fun i => by
    rw [List.length_append, E.accR_len]
  refine ((can_cat3 (f1 := fun i k => (bits (n i)).tape (hlow (n i) ((acc i).getD k 0) (sup i (o i + k))))
    (f2 := fun i j => (bits (n i)).tape (J' i (Nat.nth (E.srcP (n i) (h i) (μ i) r) j)))
    (f3 := fun i k => (bits (n i)).tape (hlow (n i) (E.csz (n i) (h i) (μ i * r) k)
      (sup i (o i + (acc i).length + E.own n h μ r i + k))))
    (g := fun i k => (bits (n i)).tape (hlow (n i) ((acc i ++ E.accR (n i) (h i) (μ i) r).getD k 0) (sup i (o i + k))))
    hA hOA hC2 hL hown hcons (hsm.mono (fun i => (hlen i).ge)) (fun i k hk => ?_)).cong (fun _ => rfl)
    (fun i => by unfold accA jobsTape; rw [hlen i])).mono (fun i => by rw [hlen i])
  rw [E.acc_getD]
  dsimp only [Eng.own] at *
  split_ifs with h1 h2
  · rfl
  · rw [hJ' i _ (by omega)]; congr 3; omega
  · congr 3; omega

lemma can_accZ (r : ℕ) {acc : ι → List ℕ}
    (hZ : Has m B s (a w) x (fun i => accZ (acc i)))
    (hOS : Has m B s (a w) x (fun i => (Layout.std (E.own n h μ r i)).tape
        (fun j => E.slotSize (n i) (h i) (μ i * r) (Nat.nth (E.srcP (n i) (h i) (μ i) r) j))))
    (hC3 : Has m B s (a w) x (fun i => (Layout.std (E.cons (n i) (h i) (μ i * r))).tape
        (fun k => E.csz (n i) (h i) (μ i * r) k)))
    (hL : Knows m B s x (fun i => (acc i).length)) (hown : Knows m B s x (E.own n h μ r))
    (hcons : Knows m B s x (fun i => E.cons (n i) (h i) (μ i * r)))
    (hsm : Small B (fun i => (acc i ++ E.accR (n i) (h i) (μ i) r).length)) :
    Can m B s (a w) x (fun i => accZ (acc i ++ E.accR (n i) (h i) (μ i) r))
      (fun i => (acc i ++ E.accR (n i) (h i) (μ i) r).length + 1) := by
  have hlen : ∀ i, (acc i ++ E.accR (n i) (h i) (μ i) r).length =
      (acc i).length + (E.own n h μ r i + E.cons (n i) (h i) (μ i * r)) := fun i => by
    rw [List.length_append, E.accR_len]
  exact ((can_cat3 (f1 := fun i k => (acc i).getD k 0)
    (f2 := fun i j => E.slotSize (n i) (h i) (μ i * r) (Nat.nth (E.srcP (n i) (h i) (μ i) r) j))
    (f3 := fun i k => E.csz (n i) (h i) (μ i * r) k) (g := fun i k => (acc i ++ E.accR (n i) (h i) (μ i) r).getD k 0)
    hZ hOS hC3 hL hown hcons (hsm.mono (fun i => (hlen i).ge)) (fun i k _ => E.acc_getD _ _ _ _ _ _)).cong
    (fun _ => rfl) (fun i => by unfold accZ; rw [hlen i])).mono (fun i => by rw [hlen i])

end Block3

lemma scatter_J (n h μ : ℕ) (sup : ℕ → Bits n → ℂ) (V : E.CState n (h+1) μ) (o : ℕ)
    (l : ρ) (r : ℕ) (z : Fin r → Space α) (ind : LinearIndependent F z) (hr : r ≤ E.X.n)
    (hrs : ∀ a, a < E.W → r ≤ E.tq a) (p : Fin (E.NUc n (h+1) μ)) (e : Bits n) :
    hlow n (E.slotSize n h (μ * r) (E.slotR n h μ r p))
      (cjob E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc n (h+1) μ) V (E.flR n h μ r) (E.ppR n h μ r)
        (E.siR n h μ r o) (E.ppR_lt n h μ r) sup (E.slotR n h μ r p)) e =
    hlow n (r * E.cUc n (h+1) μ p) (blockJob (bS z ind) (bX (α:=α) r) _ _ n
      (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc n (h+1) μ p)) l (V p)) e := by
  obtain ⟨_, hf, hpp, hsz⟩ := E.slotR_spec n h μ r hrs p
  rw [hsz, E.cjob_fed n h μ sup V o l r z ind hr _ hf]
  exact @congrArg (Fin (E.NUc n (h+1) μ)) ℂ ⟨E.ppR n h μ r (E.slotR n h μ r p), E.ppR_lt n h μ r _ hf⟩ p
    (fun q => hlow n (r * E.cUc n (h+1) μ p) (blockJob (bS z ind) (bX (α:=α) r) (E.cUc n (h+1) μ q)
      (E.iUc n (h+1) μ q) n (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc n (h+1) μ q)) l (V q)) e) (Fin.ext hpp)

section BlockUp
universe V
variable {ι : Type V} {m : Bool} {cl : Paint}

lemma blk_bound (n h μ r L : ℕ) (Wsum : ℕ)
    (hW : Wsum ≤ E.idxCost n h (μ * r) +
      (0 + E.NUc n h (μ * r) * E.W + E.NUc n h (μ * r) * E.W * (h + 2)) +
      (0 + E.NUc n h (μ * r) * E.W + E.NUc n h (μ * r) * E.W * (E.NUc n h (μ * r) * E.W + 1)) +
      (E.NUc n h (μ * r) * E.W * (0 + 1) + 1) +
      E.NUc n h (μ * r) * E.W * (2^n + 1) +
      E.passCost n (E.NUc n (h+1) μ) +
      (0 + (E.ownSrc n h μ r).length + (E.ownSrc n h μ r).length * (E.NUc n h (μ * r) * E.W * (0 + 1) + 1 + 0)) +
      (0 + (E.ownSrc n h μ r).length + (E.ownSrc n h μ r).length *
        (E.NUc n h (μ * r) * E.W * (0 + 1) + 1 + (h + 1))) +
      2 * (L + (E.accR n h μ r).length + 1)) :
    Wsum ≤ (E.R.n + 41) * E.blkCost n h μ r L := by
  have hN : E.NUc n h (μ * r) * E.W ≤ E.W^(h+1) := by
    rw [Nat.pow_succ]; exact Nat.mul_le_mul_right _ (E.NU_le' _ _ _)
  have hown : (E.ownSrc n h μ r).length ≤ E.NUc n h (μ * r) * E.W := by
    rw [E.ownSrc_len]; exact MXR.count_le_self _
  have hB : E.blkCost n h μ r L = E.idxCost n h (μ * r) + 8 * (E.W^(h+1) + 1) * (E.W^(h+1) + 1) * (h + 3) + 8 +
      (E.NUc n h (μ * r) * E.W + E.NUc n (h+1) μ) * 2^n + 2 * (L + (E.accR n h μ r).length) + 20 := rfl
  have hPC : E.passCost n (E.NUc n (h+1) μ) =
      E.NUc n (h+1) μ + E.NUc n (h+1) μ * ((E.R.n + 1) * 2^n) := rfl
  have hP0 : 1 ≤ 2^n := Nat.one_le_two_pow
  generalize E.blkCost n h μ r L = Bk at *
  generalize E.NUc n h (μ * r) * E.W = N at *
  generalize E.W^(h+1) = Wh at *
  generalize (E.ownSrc n h μ r).length = ow at *
  generalize E.NUc n (h+1) μ = NU at *
  generalize 2^n = P at *
  generalize E.R.n = Rn at *
  rw [hPC] at hW
  have e8 : 8 * (Wh + 1) * (Wh + 1) * (h + 3) = 8 * ((Wh + 1) * (Wh + 1) * (h + 3)) := by
    rw [Nat.mul_assoc 8 (Wh + 1) (Wh + 1), Nat.mul_assoc 8 ((Wh + 1) * (Wh + 1)) (h + 3)]
  have eNP : (N + NU) * P = N * P + NU * P := Nat.add_mul _ _ _
  have eM : NU * ((Rn + 1) * P) = (Rn + 1) * (NU * P) := Nat.mul_left_comm _ _ _
  have f1 : N * (N + 1) ≤ (Wh + 1) * (Wh + 1) * (h + 3) :=
    le_trans (Nat.mul_le_mul (by omega) (by omega)) (Nat.le_mul_of_pos_right _ (by omega))
  have f2 : N * (h + 2) ≤ (Wh + 1) * (Wh + 1) * (h + 3) :=
    Nat.mul_le_mul (le_trans (by omega : N ≤ Wh + 1) (Nat.le_mul_of_pos_left _ (by omega))) (by omega)
  have f3 : ow * (N + 1) ≤ N * (N + 1) := Nat.mul_le_mul_right _ hown
  have f4 : ow * (h + 1) ≤ N * (h + 2) := Nat.mul_le_mul hown (by omega)
  have f5 : N ≤ (Wh + 1) * (Wh + 1) * (h + 3) :=
    le_trans (by omega) (le_trans (Nat.le_mul_of_pos_left (Wh + 1) (by omega)) (Nat.le_mul_of_pos_right _ (by omega)))
  have f6 : NU ≤ NU * P := Nat.le_mul_of_pos_right _ (by omega)
  have e1 : N * (P + 1) = N * P + N := Nat.mul_succ _ _
  have e2 : ow * (N * (0 + 1) + 1 + (h + 1)) = ow * (N + 1) + ow * (h + 1) := by
    simp only [Nat.zero_add, Nat.mul_one]; exact Nat.mul_add _ _ _
  have e3 : ow * (N * (0 + 1) + 1 + 0) = ow * (N + 1) := by simp only [Nat.zero_add, Nat.mul_one, Nat.add_zero]
  have f8 : (Rn + 1) * (NU * P) ≤ (Rn + 1) * Bk := Nat.mul_le_mul_left _ (by omega)
  have e5 : (Rn + 41) * Bk = 40 * Bk + (Rn + 1) * Bk := by rw [show Rn + 41 = 40 + (Rn + 1) by omega, Nat.add_mul]
  rw [e5]
  omega

theorem able_blockUp {b : Bank (portM cl) ι} {s : Ty} {y : ι → T s} {n h μ o BS : ι → ℕ}
    {sup : ∀ i, ℕ → Bits (n i) → ℂ}
    (ci : CIn m b.B s y n (fun i => h i + 1) μ) (c : E.Ctx m b.B s y n (fun i => h i + 1) μ)
    (hidx : Has m b.B s IdxT y (fun i => E.idxVal (n i) (h i + 1) (μ i)))
    (hsup : Has m b.B s (jobsT cl) y (fun i => jobsTape (n i) (BS i) (sup i)))
    (ho : Knows m b.B s y o) (hBS : Small b.B BS)
    {l : ρ} {r : ℕ} {z : Fin r → Space α} {ind : LinearIndependent F z}
    (hm : GMove.old (BMove.block l r z ind) ∈ E.wd)
    (V : ∀ i, E.CState (n i) (h i + 1) (μ i)) (acc : ι → List ℕ)
    (hfitB : ∀ i, o i + (acc i ++ E.accR (n i) (h i) (μ i) r).length ≤ BS i)
    {τ : ι → MDesc → ℕ}
    (hcall : ∀ i, (b.use i (E.enc cl (E.childC (n i) (h i) (μ i) (BS i) (sup i) (V i) (o i + (acc i).length)
        l r z ind (E.wd_block hm).2.le))).OK
      (E.out cl (E.childC (n i) (h i) (μ i) (BS i) (sup i) (V i) (o i + (acc i).length) l r z ind
        (E.wd_block hm).2.le))
      (τ i (E.childC (n i) (h i) (μ i) (BS i) (sup i) (V i) (o i + (acc i).length) l r z ind
        (E.wd_block hm).2.le)) (b.ext i)) :
    Able m b (SwT s cl) (SwT s cl)
      (fun i => (y i, (E.tabV n (fun i => h i + 1) μ V i, (accA (n i) (acc i) (o i) (sup i), accZ (acc i)))))
      (fun i => (y i, (E.tabV n (fun i => h i + 1) μ
          (fun i => E.stepV (V i) (GMove.old (BMove.block l r z ind))) i,
        (accA (n i) (acc i ++ E.accR (n i) (h i) (μ i) r) (o i) (sup i),
         accZ (acc i ++ E.accR (n i) (h i) (μ i) r)))))
      (fun i => E.blkCost (n i) (h i) (μ i) r (acc i).length)
      (fun i => τ i (E.childC (n i) (h i) (μ i) (BS i) (sup i) (V i) (o i + (acc i).length) l r z ind
        (E.wd_block hm).2.le)) := by
  have hr : r ≤ E.X.n := (E.wd_block hm).2.le
  have hrs : ∀ a, a < E.W → r ≤ E.tq a := E.rk_le_tq hm
  let oc (i : ι) : ℕ := o i + (acc i).length
  have hlenR : ∀ i, (acc i ++ E.accR (n i) (h i) (μ i) r).length =
      (acc i).length + (E.own n h μ r i + E.cons (n i) (h i) (μ i * r)) := fun i => by
    rw [List.length_append, E.accR_len]
  have hs : Small b.B (fun i => E.W^(h i + 1)) := ci.powS E.W
  have hNs : Small b.B (E.Nc n h μ r) := hs.mono (fun i => E.Nc_le r i)
  have hsm : Small b.B (fun i => (acc i ++ E.accR (n i) (h i) (μ i) r).length) :=
    hBS.mono (fun i => by have := hfitB i; omega)
  have hownS : Small b.B (E.own n h μ r) := hsm.mono (fun i => by rw [hlenR]; omega)
  have hLS : Small b.B (fun i => (acc i).length) := hsm.mono (fun i => by rw [hlenR]; omega)
  have hoS : Small b.B o := hBS.mono (fun i => by have := hfitB i; omega)
  let x0 (i : ι) : T (SwT s cl) :=
    (y i, (E.tabV n (fun i => h i + 1) μ V i, (accA (n i) (acc i) (o i) (sup i), accZ (acc i))))
  have ci0 : CIn m b.B (SwT s cl) x0 n (fun i => h i + 1) μ := ci.ext _
  have H0 := E.can_index (ci0.child r)
  let x1 (i : ι) : T (p (SwT s cl) IdxT) := (x0 i, E.idxVal (n i) (h i) (μ i * r))
  have ci1 : CIn m b.B (p (SwT s cl) IdxT) x1 n (fun i => h i + 1) μ := ci0.ext _
  have hNU1 : Knows m b.B (p (SwT s cl) IdxT) x1 (fun i => E.NUc (n i) (h i) (μ i * r)) :=
    Can.fst (Can.snd Can.second)
  have hNUs : Small b.B (fun i => E.NUc (n i) (h i) (μ i * r)) :=
    hNs.mono (fun i => Nat.le_mul_of_pos_right _ E.W_pos)
  have hN1 : Knows m b.B (p (SwT s cl) IdxT) x1 (E.Nc n h μ r) :=
    hNU1.times (Can.wc _) hNUs (Small.const _ _)
  have hU1 : Has m b.B (p (SwT s cl) IdxT) (a w) x1 (E.UTc n h μ r) := Can.snd (Can.snd (Can.snd Can.second))
  have hWh1 : Knows m b.B (p (SwT s cl) IdxT) x1 (fun i => E.W^(h i + 1)) :=
    (Can.first.then_do Can.first).then_do (Can.fst hidx)
  have H1 := E.can_IT ci1 r hN1 hU1 hWh1
  let x2 (i : ι) : T (p (p (SwT s cl) IdxT) (a w)) := (x1 i, E.ITt n h μ r i)
  have hN2 : Knows m b.B _ x2 (E.Nc n h μ r) := Can.first.then_do hN1
  have H2 := E.can_CT r hN2 hNs Can.second
  let x3 (i : ι) : T (p (p (p (SwT s cl) IdxT) (a w)) (a w)) := (x2 i, E.CTt n h μ r i)
  have hN3 : Knows m b.B _ x3 (E.Nc n h μ r) := Can.first.then_do hN2
  have hIT3 : Has m b.B _ (a w) x3 (E.ITt n h μ r) := Can.first.then_do Can.second
  have H3 := E.can_own r hN3 hNs hIT3
  let x4 (i : ι) : T (p (p (p (p (SwT s cl) IdxT) (a w)) (a w)) w) :=
    (x3 i, Nat.count (E.srcP (n i) (h i) (μ i) r) (E.Nc n h μ r i))
  have p40 : Has m b.B _ (SwT s cl) x4 x0 :=
    Can.first.then_do (Can.first.then_do (Can.first.then_do Can.first))
  have p4y : Has m b.B _ s x4 y := p40.then_do Can.first
  have c4 : E.Ctx m b.B _ x4 n (fun i => h i + 1) μ := c.reindex id x4 p4y
  have hown4 : Knows m b.B _ x4 (E.own n h μ r) :=
    Can.second.cong (fun _ => rfl) (fun i => (E.own_eq r i).symm)
  have hL4 : Knows m b.B _ x4 (fun i => (acc i).length) :=
    (p40.then_do (Can.fst (Can.snd Can.second))).len (hLS.mono (fun _ => le_rfl))
  have hoc4 : Knows m b.B _ x4 oc := (p4y.then_do ho).plus hL4 hoS hLS
  have H4 := E.can_OJ c4 (l := l) (z := z) (ind := ind) hr (V := V) (p40.then_do (Can.fst Can.second))
    (p4y.then_do (Can.fst (Can.snd (Can.snd hidx)))) ((Can.first.then_do (Can.first.then_do Can.first)).then_do hU1)
    (Can.first.then_do (Can.first.then_do Can.second)) (Can.first.then_do Can.second) (oc := oc) hoc4
    (p4y.then_do hsup)
    (fun i => by have := hfitB i; rw [hlenR, E.own_eq] at this; show o i + (acc i).length + _ ≤ _; omega)
    ((Can.first.then_do (Can.first.then_do Can.first)).then_do hN1) hNs hs hBS
  let x5 (i : ι) : T (p (p (p (p (p (SwT s cl) IdxT) (a w)) (a w)) w) (jobsT cl)) :=
    (x4 i, jobsTape (n i) (E.Nc n h μ r i) (E.cjobF n h μ l r z ind hr V oc sup i))
  have p5y : Has m b.B _ s x5 y := Can.first.then_do p4y
  have hin : Has m b.B _ (portIn cl) x5
      (fun i => E.enc cl (E.childC (n i) (h i) (μ i) (BS i) (sup i) (V i) (oc i) l r z ind hr)) := by
    have hn := p5y.then_do ci.nK
    have hI := p5y.then_do ci.imag
    have hk := p5y.then_do ci.hK
    have hμr := (p5y.then_do ci.μK).times (Can.wc r) ci.μS (Small.const _ r)
    exact (hn.pair (hI.pair (hk.pair (hμr.pair ((((Can.first.then_do hoc4).plus (Can.first.then_do hown4)
      (hoS.add hLS) hownS)).pair (Can.second.pair (p5y.then_do hsup))))))).cong (fun _ => rfl) (fun _ => rfl)
  have Hc := (Able.of_can (b := b) hin).comp (Able.use_call (m := m) (b := b) hcall)
  let outv (i : ι) : T (portOut cl) :=
    E.out cl (E.childC (n i) (h i) (μ i) (BS i) (sup i) (V i) (oc i) l r z ind hr)
  let x6 (i : ι) : T (p (p (p (p (p (p (SwT s cl) IdxT) (a w)) (a w)) w) (jobsT cl)) (portOut cl)) := (x5 i, outv i)
  have p65 : Has m b.B _ _ x6 x5 := Can.first
  have p64 : Has m b.B _ _ x6 x4 := p65.then_do Can.first
  have p60 : Has m b.B _ (SwT s cl) x6 x0 := p64.then_do p40
  have p6y : Has m b.B _ s x6 y := p60.then_do Can.first
  have c6 : E.Ctx m b.B _ x6 n (fun i => h i + 1) μ := c.reindex id x6 p6y
  have ci6 : CIn m b.B _ x6 n (fun i => h i + 1) μ := ci.reindex id x6 p6y
  have hN6 : Knows m b.B _ x6 (E.Nc n h μ r) := p64.then_do (Can.first.then_do (Can.first.then_do hN2))
  have hIT6 : Has m b.B _ (a w) x6 (E.ITt n h μ r) := p64.then_do (Can.first.then_do hIT3)
  have hU6 : Has m b.B _ (a w) x6 (E.UTc n h μ r) :=
    p64.then_do ((Can.first.then_do (Can.first.then_do Can.first)).then_do hU1)
  have hown6 : Knows m b.B _ x6 (E.own n h μ r) := p64.then_do hown4
  have hO1 : Has m b.B _ (jobsT cl) x6 (fun i => jobsTape (n i) (E.Nc n h μ r i)
      (fun t => hlow (n i) (E.slotSize (n i) (h i) (μ i * r) t) (E.cjobF n h μ l r z ind hr V oc sup i t))) :=
    Can.fst Can.second
  have hO2 : Has m b.B _ (jobsT cl) x6 (fun i => jobsTape (n i) (E.cons (n i) (h i) (μ i * r))
      (fun k => hlow (n i) (E.csz (n i) (h i) (μ i * r) k) (sup i (o i + (acc i).length + E.own n h μ r i + k)))) :=
    Can.fst (Can.snd Can.second)
  have hO3 : Has m b.B _ (a w) x6 (fun i => (Layout.std (E.cons (n i) (h i) (μ i * r))).tape
      (fun k => E.csz (n i) (h i) (μ i * r) k)) :=
    Can.snd (Can.snd Can.second)
  have hcons6 : Knows m b.B _ x6 (fun i => E.cons (n i) (h i) (μ i * r)) :=
    hO3.len (hsm.mono (fun i => by rw [hlenR]; show E.cons _ _ _ ≤ _; omega))
  have HT := E.can_scatter (l := l) (z := z) (ind := ind) c6 hr hrs (p60.then_do (Can.fst Can.second))
    (p6y.then_do (Can.snd (Can.snd (Can.snd hidx)))) (p64.then_do ((Can.first.then_do (Can.first.then_do
      Can.first)).then_do (Can.fst (Can.snd (Can.snd Can.second))))) hO1
    (fun i p e => E.scatter_J (n i) (h i) (μ i) (sup i) (V i) (oc i) l r z ind hr hrs p e) hs
  have HOA := E.can_OA r hN6 hNs hIT6 hown6 hownS hO1
  have HOS := E.can_OS r (ci6.child r) hN6 hNs hIT6 hU6 hown6 hownS
  let x7 (i : ι) : T (p (p (p (p (p (p (p (SwT s cl) IdxT) (a w)) (a w)) w) (jobsT cl)) (portOut cl))
      (p (jobsT cl) (a w))) := (x6 i, (jobsTape (n i) (E.own n h μ r i) (fun j => hlow (n i)
      (E.slotSize (n i) (h i) (μ i * r) (Nat.nth (E.srcP (n i) (h i) (μ i) r) j))
      (E.cjobF n h μ l r z ind hr V oc sup i (Nat.nth (E.srcP (n i) (h i) (μ i) r) j))),
    (Layout.std (E.own n h μ r i)).tape
      (fun j => E.slotSize (n i) (h i) (μ i * r) (Nat.nth (E.srcP (n i) (h i) (μ i) r) j))))
  have p76 : Has m b.B _ _ x7 x6 := Can.first
  have HA := E.can_accA (x := x7) r (acc := acc) (o := o) (sup := sup)
    (J' := fun i t => hlow (n i) (E.slotSize (n i) (h i) (μ i * r) t) (E.cjobF n h μ l r z ind hr V oc sup i t))
    (p76.then_do (p60.then_do (Can.fst (Can.snd Can.second)))) (Can.fst Can.second) (p76.then_do hO2)
    (fun i j hj => by
      obtain ⟨_, hsrc, hcnt⟩ := E.nth_lt r i hj
      show hlow (n i) (E.slotSize (n i) (h i) (μ i * r) (Nat.nth (E.srcP (n i) (h i) (μ i) r) j))
        (E.cjobF n h μ l r z ind hr V oc sup i (Nat.nth (E.srcP (n i) (h i) (μ i) r) j)) = _
      dsimp only [Eng.cjobF]
      rw [E.cjob_src _ _ _ _ _ _ l r z ind hr _ hsrc]
      exact congrArg (fun k => hlow (n i) (E.slotSize (n i) (h i) (μ i * r) (Nat.nth (E.srcP (n i) (h i) (μ i) r) j))
        (sup i (oc i + k))) hcnt)
    (p76.then_do (p64.then_do hL4)) (p76.then_do hown6) (p76.then_do hcons6) hsm
  have HZ := E.can_accZ (x := x7) r (acc := acc) (p76.then_do (p60.then_do (Can.snd (Can.snd Can.second))))
    (Can.snd Can.second) (p76.then_do hO3) (p76.then_do (p64.then_do hL4)) (p76.then_do hown6)
    (p76.then_do hcons6) hsm
  have Hfin := (HOA.fork HOS).save ((p76.then_do p6y).fork ((p76.pipe HT).fork (HA.fork HZ)))
  have Hall := ((Able.of_can (b := b) (H0.save (H1.save (H2.save (H3.save (H4.save
    (Can.id (W := fun _ => 0)))))))).comp (Hc.save (Able.id (W := fun _ => 0) (Z := fun _ => 0)))).comp
    (Able.of_can (b := b) Hfin)
  refine Hall.weaken (dom_mul (E.R.n + 41) (fun i => E.blk_bound _ _ _ _ _ _ ?_)) ?_
  swap
  · intro i; simp [Eng.kidsC]
  -- CHECK: the cost of the composed program, term by term
  dsimp only [Eng.Nc, Eng.own]
  have : (acc i ++ E.accR (n i) (h i) (μ i) r).length = (acc i).length + (E.accR (n i) (h i) (μ i) r).length :=
    List.length_append
  omega

end BlockUp

lemma cU_zero (n μ : ℕ) (p : Fin (E.NUc n 0 μ)) : E.cUc n 0 μ p = μ := by
  show μ * colS E.W E.tq 0 _ = μ
  rw [colS_zero, Nat.mul_one]

lemma pass_le (n NU : ℕ) : E.passCost n NU ≤ (E.R.n + 2) * (NU * 2^n) := by
  unfold passCost
  have h1 : NU ≤ NU * 2^n := Nat.le_mul_of_pos_right _ (Nat.two_pow_pos n)
  rw [Nat.mul_left_comm NU (E.R.n + 1) (2^n), show E.R.n + 2 = (E.R.n + 1) + 1 by omega,
    Nat.add_mul (E.R.n + 1) 1, Nat.one_mul]
  omega

lemma cost_close (n NU L W : ℕ) (hNL : NU * 2^n ≤ L) (hW : W ≤ 6 * L + E.passCost n NU) :
    W ≤ (E.R.n + 8) * L := by
  have h1 := (E.pass_le n NU).trans (Nat.mul_le_mul_left (E.R.n + 2) hNL)
  have e : (E.R.n + 8) * L = 6 * L + (E.R.n + 2) * L := by
    rw [show E.R.n + 8 = 6 + (E.R.n + 2) by omega, Nat.add_mul]
  omega

lemma exJobs_unit {n0 μ0 : ℕ} (V : E.CState n0 0 μ0) (l : ρ) (r : ℕ) (z : Fin r → Space α)
    (ind : LinearIndependent F z) (hr : r ≤ E.X.n) (p : Fin (E.NUc n0 0 μ0)) :
    exJobs E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc n0 0 μ0) V p.val =
      blockJob (bS z ind) (bX (α:=α) r) _ _ n0 (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc n0 0 μ0 p)) l (V p) := by
  have hf : exFl (E.NUc n0 0 μ0) p.val ≠ 0 := by unfold exFl; rw [if_pos p.2]; omega
  unfold exJobs cjob
  rw [dif_pos hf]
  rfl

lemma exitC_eq {n0 μ0 : ℕ} (V : E.CState n0 0 μ0) (l : ρ) (r : ℕ) (z : Fin r → Space α)
    (ind : LinearIndependent F z) (hr : r ≤ E.X.n) (hk : r * μ0 ≤ n0) :
    E.exitC n0 μ0 V l r z ind hr = MDesc.top (r * μ0) (E.NUc n0 0 μ0 * 2^(n0 - r * μ0))
      (toVec n0 (r * μ0) hk (exJobs E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc n0 0 μ0) V)) := by
  unfold exitC
  rw [dif_pos hk]

lemma exit_hit {n0 μ0 : ℕ} (V : E.CState n0 0 μ0) {l : ρ} {r : ℕ} {z : Fin r → Space α}
    {ind : LinearIndependent F z} (hr : r ≤ E.X.n) (hk : r * μ0 ≤ n0)
    (p : Fin (E.NUc n0 0 μ0)) (q : Bits (E.iUc n0 0 μ0 p)) (g : Grid α 0 (E.cUc n0 0 μ0 p)) :
    ripple (r * μ0) (toVec n0 (r * μ0) hk
        (exJobs E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc n0 0 μ0) V)
        (p.val * 2^(n0 - r * μ0) + (bits (n0 - r * μ0)).loc ((catB (r * μ0) (n0 - r * μ0)).symm
          ((castB (Nat.add_sub_cancel' hk)).symm (placeS (bS z ind) (bX (α:=α) r) _ _ n0
            (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc n0 0 μ0 p)) (q, g.2)))).2))
      ((catB (r * μ0) (n0 - r * μ0)).symm ((castB (Nat.add_sub_cancel' hk)).symm
        (placeS (bS z ind) (bX (α:=α) r) _ _ n0 (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc n0 0 μ0 p))
          (q, g.2)))).1 =
    E.stepV V (GMove.old (BMove.block l r z ind)) p q (l, g) := by
  rw [E.stepV_block V l r z ind hr p q g]
  have h1 := fromVec_ripple n0 (r * μ0) hk
    (exJobs E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc n0 0 μ0) V) p.val
  rw [E.exJobs_unit _ _ _ _ _ hr] at h1
  rw [show r * E.cUc n0 0 μ0 p = r * μ0 by rw [E.cU_zero], ← h1]
  rfl

section Exit
universe V
variable {ι : Type V} {m : Bool} {cl : Paint}

theorem able_exit {b : Bank (portM cl) ι} {s : Ty} {y : ι → T s} {n μ : ι → ℕ}
    (ci : CIn m b.B s y n (fun _ => 0) μ) (c : E.Ctx m b.B s y n (fun _ => 0) μ)
    (hfit0 : ∀ i, E.X.n * μ i ≤ n i)
    {l : ρ} {r : ℕ} {z : Fin r → Space α} {ind : LinearIndependent F z}
    (hm : GMove.old (BMove.block l r z ind) ∈ E.wd) (V : ∀ i, E.CState (n i) 0 (μ i)) {τ : ι → MDesc → ℕ}
    (hcall : ∀ i, (b.use i (E.enc cl (E.exitC (n i) (μ i) (V i) l r z ind (E.wd_block hm).2.le))).OK
      (E.out cl (E.exitC (n i) (μ i) (V i) l r z ind (E.wd_block hm).2.le))
      (τ i (E.exitC (n i) (μ i) (V i) l r z ind (E.wd_block hm).2.le)) (b.ext i)) :
    Able m b (p s (ctabT cl)) (p s (ctabT cl))
      (fun i => (y i, E.tabV n (fun _ => 0) μ V i))
      (fun i => (y i, E.tabV n (fun _ => 0) μ (fun i => E.stepV (V i) (GMove.old (BMove.block l r z ind))) i))
      (fun i => E.NUc (n i) 0 (μ i) * 2^(n i) + 2 * n i + 2)
      (fun i => τ i (E.exitC (n i) (μ i) (V i) l r z ind (E.wd_block hm).2.le)) := by
  have hr : r ≤ E.X.n := (E.wd_block hm).2.le
  have hk : ∀ i, r * μ i ≤ n i := fun i => le_trans (Nat.mul_le_mul_right _ hr) (hfit0 i)
  let k (i : ι) : ℕ := r * μ i
  let NV (i : ι) : ℕ := E.NUc (n i) 0 (μ i) * 2^(n i - k i)
  let exJ (i : ι) : ℕ → Bits (n i) → ℂ :=
    exJobs E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc (n i) 0 (μ i)) (V i)
  let vec (i : ι) : ℕ → Bits (k i) → ℂ := toVec (n i) (k i) (hk i) (exJ i)
  let x0 (i : ι) : T (p s (ctabT cl)) := (y i, E.tabV n (fun _ => 0) μ V i)
  have p0y : Has m b.B _ s x0 y := Can.first
  have c0 : E.Ctx m b.B _ x0 n (fun _ => 0) μ := c.ext _
  have hn0 : Knows m b.B _ x0 n := p0y.then_do ci.nK
  have hns : Small b.B n := ci.nS
  have hkK : Knows m b.B _ x0 k := (p0y.then_do ci.μK).times (Can.wc r) ci.μS (Small.const _ r) |>.cong
    (fun _ => rfl) (fun i => Nat.mul_comm _ _)
  have hkS : Small b.B k := hns.mono hk
  have h2kS : Small b.B (fun i => 2^(k i)) := ci.big.mono (fun i => Nat.pow_le_pow_right (by omega) (hk i))
  have H2k : Can m b.B _ w x0 (fun i => 2^(k i)) k := (hkK.mono (fun _ => Nat.zero_le _)).wTwo hkS h2kS (Dom.self _)
  let x1 (i : ι) : T (p (p s (ctabT cl)) w) := (x0 i, 2^(k i))
  have p1y : Has m b.B _ s x1 y := Can.first.then_do p0y
  have h2k1 : Knows m b.B _ x1 (fun i => 2^(k i)) := Can.second
  have h2n1 : Knows m b.B _ x1 (fun i => 2^(n i)) := p1y.then_do ci.p2n
  have hqS : ∀ i, 2^(n i - k i) * 2^(k i) = 2^(n i) := fun i => by
    rw [← Nat.pow_add, Nat.sub_add_cancel (hk i)]
  have h2nk1 : Knows m b.B _ x1 (fun i => 2^(n i - k i)) :=
    (h2n1.dvdW h2k1 ci.big).cong (fun _ => rfl) (fun i => by
      rw [← hqS i, Nat.mul_div_cancel _ (Nat.two_pow_pos _)])
  have hNU1 : Knows m b.B _ x1 (fun i => E.NUc (n i) 0 (μ i)) := p1y.then_do c.nuK
  have hNVS : Small b.B NV := (c.nuS.mul ci.big).mono (fun i =>
    Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) (Nat.sub_le _ _)))
  have hNV1 : Knows m b.B _ x1 NV := hNU1.times h2nk1 c.nuS (ci.big.mono (fun i =>
    Nat.pow_le_pow_right (by omega) (Nat.sub_le _ _)))
  have Hvec : Can m b.B _ (jobsT cl) x1 (fun i => jobsTape (k i) (NV i) (vec i)) (fun i => NV i * (2^(k i) + 1)) := by
    let EL := Σ u : UnitF NV, Bits (k u.1)
    let yE (d : EL) : T (p (p (p (p s (ctabT cl)) w) w) w) := ((x1 d.1.1, d.1.2.val), (bits (k d.1.1)).loc d.2)
    have l1 : ∀ {t : Ty} {v : ι → T t}, Has m b.B _ t x1 v → Has m (fun d : EL => b.B d.1.1) _ t yE (fun d => v d.1.1) :=
      fun hv => (Can.first.then_do Can.first).then_do (hv.reindex (fun d : EL => d.1.1))
    have ht : Knows m (fun d : EL => b.B d.1.1) _ yE (fun d => d.1.2.val) := Can.first.then_do Can.second
    have htS : Small (fun d : EL => b.B d.1.1) (fun d => d.1.2.val) :=
      (hNVS.reindex (fun d : EL => d.1.1)).mono (fun d => d.1.2.2.le)
    have hpos : ∀ i, 0 < 2^(n i - k i) := fun i => Nat.two_pow_pos _
    have hp : ∀ d : EL, d.1.2.val / 2^(n d.1.1 - k d.1.1) < E.NUc (n d.1.1) 0 (μ d.1.1) := fun d =>
      (Nat.div_lt_iff_lt_mul (hpos _)).2 d.1.2.2
    let jU (d : EL) : UnitF (fun i => E.NUc (n i) 0 (μ i)) := ⟨d.1.1, ⟨_, hp d⟩⟩
    have hdiv : Knows m (fun d : EL => b.B d.1.1) _ yE (fun d => d.1.2.val / 2^(n d.1.1 - k d.1.1)) :=
      ht.dvdW (l1 h2nk1) htS
    have hmod : Knows m (fun d : EL => b.B d.1.1) _ yE (fun d => d.1.2.val % 2^(n d.1.1 - k d.1.1)) :=
      ht.modW (l1 h2nk1) htS
    let e (d : EL) : Bits (n d.1.1) :=
      castB (Nat.add_sub_cancel' (hk d.1.1)) (catB (k d.1.1) (n d.1.1 - k d.1.1) (d.2, bitsOf (n d.1.1 - k d.1.1) d.1.2.val))
    have hbig : Small (fun d : EL => b.B d.1.1) (fun d => 2^(n d.1.1)) := ci.big.reindex _
    have he : Knows m (fun d : EL => b.B d.1.1) _ yE (fun d => (bits (n d.1.1)).loc (e d)) := by
      have hx : Knows m (fun d : EL => b.B d.1.1) _ yE (fun d => (bits (k d.1.1)).loc d.2) := Can.second
      have sx : Small (fun d : EL => b.B d.1.1) (fun d => (bits (k d.1.1)).loc d.2) :=
        (h2kS.reindex (fun d : EL => d.1.1)).mono (fun d => ((bits _).bd _).le)
      have sm : Small (fun d : EL => b.B d.1.1) (fun d => d.1.2.val % 2^(n d.1.1 - k d.1.1)) := htS.mod
      have sT : ∀ d : EL, (bits (k d.1.1)).loc d.2 + 2^(k d.1.1) * (d.1.2.val % 2^(n d.1.1 - k d.1.1)) ≤ 2^(n d.1.1) :=
        fun d => by
          have := (bits (n d.1.1)).bd (e d)
          rw [bits_len, show (bits (n d.1.1)).loc (e d) = _ from loc_castB_catB _ _ (hk d.1.1) _ _,
            bitsOf_loc] at this
          exact Nat.le_of_lt this
      refine ((hx.plus ((l1 h2k1).times hmod (h2kS.reindex _) sm) sx
        (hbig.mono (fun d => le_trans (Nat.le_add_left _ _) (sT d))))).cong (fun _ => rfl) (fun d => ?_)
      rw [loc_castB_catB _ _ (hk d.1.1), bitsOf_loc]
    have hrd := E.has_placeRead c (V := V) jU ((l1 p1y).pair hdiv) (l1 (Can.first.then_do Can.second))
      (bS z ind) (bX (α:=α) r) (E.bX_n hr) l e he
    have hel : Has m (fun d : EL => b.B d.1.1) _ (Ty.c cl) yE (fun d => vec d.1.1 d.1.2.val d.2) :=
      hrd.cong (fun _ => rfl) (fun d => by
        show _ = exJobs E.X (bS z ind) (bX (α:=α) r) (E.bX_n hr) l (E.fitc (n d.1.1) 0 (μ d.1.1)) (V d.1.1)
          ((jU d).2 : ℕ) (e d)
        rw [E.exJobs_unit (V d.1.1) l r z ind hr (jU d).2]
        rfl)
    exact can_jobsTape (N := NV) (n := k) hNV1 h2k1 hNVS h2kS hel
  let x2 (i : ι) : T (p (p (p s (ctabT cl)) w) (jobsT cl)) := (x1 i, jobsTape (k i) (NV i) (vec i))
  have hin : Has m b.B _ (portIn cl) x2
      (fun i => E.enc cl (E.exitC (n i) (μ i) (V i) l r z ind hr)) := by
    have hk2 : Knows m b.B _ x2 k := Can.first.then_do (Can.first.then_do hkK)
    refine (hk2.pair ((Can.first.then_do (p1y.then_do ci.imag)).pair ((Can.wc 0).pair ((Can.wc 0).pair
      ((Can.wc 0).pair (Can.second.pair (has_jobs0 (n := k) (fun _ _ _ => 0)))))))).cong (fun _ => rfl)
      (fun i => ?_)
    rw [E.exitC_eq _ _ _ _ _ hr (hk i)]
    rfl
  have Hc := (Able.of_can (b := b) hin).comp (Able.use_call (m := m) (b := b) hcall)
  let outv (i : ι) : T (portOut cl) := E.out cl (E.exitC (n i) (μ i) (V i) l r z ind hr)
  let x3 (i : ι) : T (p (p (p (p s (ctabT cl)) w) (jobsT cl)) (portOut cl)) := (x2 i, outv i)
  have p3y : Has m b.B _ s x3 y := (Can.first.then_do (Can.first.then_do Can.first)).then_do p0y
  have c3 : E.Ctx m b.B _ x3 n (fun _ => 0) μ := c.reindex id x3 p3y
  have p31 : Has m b.B _ _ x3 x1 := Can.first.then_do Can.first
  have p0' : Has m b.B _ _ x3 x0 := p31.then_do Can.first
  have hY : Has m b.B _ (jobsT cl) x3 (fun i => jobsTape (k i) (NV i) (fun t => ripple (k i) (vec i t))) :=
    (Can.fst Can.second).cong (fun _ => rfl) (fun i => by
      show (E.out cl (E.exitC (n i) (μ i) (V i) l r z ind hr)).1 = _
      rw [E.exitC_eq _ _ _ _ _ hr (hk i)]
      rfl)
  have HT : Can m b.B _ (ctabT cl) x3
      (E.tabV n (fun _ => 0) μ (fun i => E.stepV (V i) (GMove.old (BMove.block l r z ind))))
      (fun i => E.passCost (n i) (E.NUc (n i) 0 (μ i))) := by
    refine E.can_scatterG c3 (p0'.then_do Can.second) l
      (fun i p q b hb => E.scatter_miss (V i) p q b hb) ?_
    let K := {d : E.ElemF n (fun _ => 0) μ // d.2.1 = l}
    have lK : ∀ {t : Ty} {v : ι → T t}, Has m b.B _ t x3 v →
        Has m (fun d : K => b.B d.1.1.1.1) (p (IEnv _) w) t (fun d => E.elemEnv x3 n (fun _ => 0) μ d.1)
          (fun d => v d.1.1.1.1) :=
      fun hv => (Can.first.then_do (Can.first.then_do Can.first)).then_do (hv.reindex (fun d : K => d.1.1.1.1))
    have hpK : Knows m (fun d : K => b.B d.1.1.1.1) _ (fun d => E.elemEnv x3 n (fun _ => 0) μ d.1)
        (fun d => d.1.1.1.2.val) := Can.first.then_do (Can.first.then_do Can.second)
    have hbigK : Small (fun d : K => b.B d.1.1.1.1) (fun d => 2^(n d.1.1.1.1)) := ci.big.reindex _
    have he := E.knows_hitAddr c3 l (bS z ind) (bX (α:=α) r) (E.bX_n hr)
    let e' (d : K) : Bits (n d.1.1.1.1) := placeS (bS z ind) (bX (α:=α) r) _ _ (n d.1.1.1.1)
      (fitk (bX (α:=α) r) (E.bX_n hr) (E.fitc _ _ _ d.1.1.1.2)) (d.1.1.2, d.1.2.2.2)
    let z' (d : K) := (catB (k d.1.1.1.1) (n d.1.1.1.1 - k d.1.1.1.1)).symm
      ((castB (Nat.add_sub_cancel' (hk d.1.1.1.1))).symm (e' d))
    have hzl : ∀ d : K, (bits (k d.1.1.1.1)).loc (z' d).1 < 2^(k d.1.1.1.1) := fun d => by
      have := (bits (k d.1.1.1.1)).bd (z' d).1; rwa [bits_len] at this
    have hsp : ∀ d : K, (bits (n d.1.1.1.1)).loc (e' d) =
        (bits (k d.1.1.1.1)).loc (z' d).1 + 2^(k d.1.1.1.1) * (bits (n d.1.1.1.1 - k d.1.1.1.1)).loc (z' d).2 :=
      fun d => by
        rw [← loc_castB_catB _ _ (hk d.1.1.1.1), Prod.mk.eta, Equiv.apply_symm_apply, Equiv.apply_symm_apply]
    have h2kK : Knows m (fun d : K => b.B d.1.1.1.1) _ (fun d => E.elemEnv x3 n (fun _ => 0) μ d.1)
        (fun d => 2^(k d.1.1.1.1)) := lK (p31.then_do h2k1)
    have sE : Small (fun d : K => b.B d.1.1.1.1) (fun d => (bits (n d.1.1.1.1)).loc (e' d)) :=
      hbigK.mono (fun d => ((bits _).bd _).le)
    have hlo : Knows m (fun d : K => b.B d.1.1.1.1) _ (fun d => E.elemEnv x3 n (fun _ => 0) μ d.1)
        (fun d => (bits (k d.1.1.1.1)).loc (z' d).1) :=
      (he.modW h2kK sE).cong (fun _ => rfl) (fun d => by rw [hsp]; exact EngArith.mod_join' (hzl d))
    have hhi : Knows m (fun d : K => b.B d.1.1.1.1) _ (fun d => E.elemEnv x3 n (fun _ => 0) μ d.1)
        (fun d => (bits (n d.1.1.1.1 - k d.1.1.1.1)).loc (z' d).2) :=
      (he.dvdW h2kK sE).cong (fun _ => rfl) (fun d => by rw [hsp]; exact EngArith.div_join' (hzl d))
    have hhiS : ∀ d : K, (bits (n d.1.1.1.1 - k d.1.1.1.1)).loc (z' d).2 < 2^(n d.1.1.1.1 - k d.1.1.1.1) :=
      fun d => by have := (bits (n d.1.1.1.1 - k d.1.1.1.1)).bd (z' d).2; rwa [bits_len] at this
    have sP : Small (fun d : K => b.B d.1.1.1.1) (fun d => d.1.1.1.2.val) :=
      (c.nuS.reindex (fun d : K => d.1.1.1.1)).mono (fun d => d.1.1.1.2.2.le)
    have s2 : Small (fun d : K => b.B d.1.1.1.1) (fun d => 2^(n d.1.1.1.1 - k d.1.1.1.1)) :=
      hbigK.mono (fun d => Nat.pow_le_pow_right (by omega) (Nat.sub_le _ _))
    have hix := (hpK.times (lK (p31.then_do h2nk1)) sP s2).plus hhi (sP.mul s2)
      (s2.mono (fun d => (hhiS d).le))
    have hrd := has_jobsRead (n := fun d : K => k d.1.1.1.1) (N := fun d => NV d.1.1.1.1)
      (J := fun d t => ripple (k d.1.1.1.1) (vec d.1.1.1.1 t)) (lK hY) hix
      (fun d => EngArith.lt_join d.1.1.1.2.2 (hhiS d)) hlo
    refine hrd.cong (fun _ => rfl) (fun d => ?_)
    have hd : d.1.2 = (l, d.1.2.2) := Prod.ext d.2 rfl
    show _ = E.stepV (V d.1.1.1.1) _ d.1.1.1.2 d.1.1.2 d.1.2
    rw [hd]
    exact E.exit_hit (V d.1.1.1.1) hr (hk d.1.1.1.1) d.1.1.1.2 d.1.1.2 d.1.2.2
  have Hall := ((Able.of_can (b := b) (H2k.save (Hvec.save (Can.id (W := fun _ => 0))))).comp
    (Hc.save (Able.id (W := fun _ => 0) (Z := fun _ => 0)))).comp
    (Able.of_can (b := b) ((Can.first.then_do (Can.first.then_do (Can.first.then_do p0y))).fork HT))
  refine Hall.weaken (dom_mul (E.R.n + 8) (fun i => ?_)) ?_
  swap
  · intro i; simp [Eng.kidsC]
  -- CHECK: cost arithmetic
  have h2 : NV i * (2^(k i) + 1) ≤ 2 * (E.NUc (n i) 0 (μ i) * 2^(n i)) := by
    show E.NUc (n i) 0 (μ i) * 2^(n i - k i) * (2^(k i) + 1) ≤ _
    rw [Nat.mul_add, Nat.mul_one, Nat.mul_assoc, hqS i]
    have : E.NUc (n i) 0 (μ i) * 2^(n i - k i) ≤ E.NUc (n i) 0 (μ i) * 2^(n i) :=
      Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) (Nat.sub_le _ _))
    omega
  have h3 := hk i
  have hk3 : k i = r * μ i := rfl
  try dsimp only at h2 ⊢
  exact E.cost_close (n i) (E.NUc (n i) 0 (μ i)) _ _ (by omega) (by omega)

end Exit

lemma free_dom (n NU S : ℕ) : E.passCost n NU + S ≤ (E.R.n + 3) * (NU * 2^n + S) := by
  have h1 := E.pass_le n NU
  have hA : (E.R.n + 3) * (NU * 2^n + S) = (E.R.n + 3) * (NU * 2^n) + (E.R.n + 3) * S := Nat.mul_add _ _ _
  have hB : (E.R.n + 3) * (NU * 2^n) = (E.R.n + 2) * (NU * 2^n) + NU * 2^n := by
    rw [show E.R.n + 3 = E.R.n + 2 + 1 from rfl, Nat.add_mul, Nat.one_mul]
  have h3 : S ≤ (E.R.n + 3) * S := Nat.le_mul_of_pos_left _ (by omega)
  omega

section Sweep
universe V
variable {ι : Type V} {m : Bool} {cl : Paint}

theorem able_sweepUp {b : Bank (portM cl) ι} {s : Ty} {y : ι → T s} {n h μ o BS : ι → ℕ}
    {sup : ∀ i, ℕ → Bits (n i) → ℂ}
    (ci : CIn m b.B s y n (fun i => h i + 1) μ) (c : E.Ctx m b.B s y n (fun i => h i + 1) μ)
    (hidx : Has m b.B s IdxT y (fun i => E.idxVal (n i) (h i + 1) (μ i)))
    (hsup : Has m b.B s (jobsT cl) y (fun i => jobsTape (n i) (BS i) (sup i)))
    (ho : Knows m b.B s y o) (hBS : Small b.B BS) {τ : ι → MDesc → ℕ} :
    ∀ (ws : GWord α ρ), (∀ mv ∈ ws, mv ∈ E.wd) → ∀ (V : ∀ i, E.CState (n i) (h i + 1) (μ i)) (acc : ι → List ℕ),
      (∀ i, o i + (acc i ++ E.accW (n i) (h i) (μ i) ws).length ≤ BS i) →
      (∀ i, ∀ c' ∈ E.kidsUp (n i) (h i) (μ i) (BS i) (sup i) (V i) (o i + (acc i).length) ws,
        (b.use i (E.enc cl c')).OK (E.out cl c') (τ i c') (b.ext i)) →
      Able m b (SwT s cl) (SwT s cl)
        (fun i => (y i, (E.tabV n (fun i => h i + 1) μ V i, (accA (n i) (acc i) (o i) (sup i), accZ (acc i)))))
        (fun i => (y i, (E.tabV n (fun i => h i + 1) μ (fun i => E.runV (V i) ws) i,
          (accA (n i) (acc i ++ E.accW (n i) (h i) (μ i) ws) (o i) (sup i),
           accZ (acc i ++ E.accW (n i) (h i) (μ i) ws)))))
        (fun i => E.swCost (n i) (h i) (μ i) (acc i).length ws)
        (fun i => ((E.kidsUp (n i) (h i) (μ i) (BS i) (sup i) (V i) (o i + (acc i).length) ws).map (τ i)).sum) := by
  intro ws
  induction ws with
  | nil =>
    intro _ V acc _ _
    refine ((Able.id (W := fun _ => 0) (Z := fun _ => 0)).cong (fun _ => rfl) (fun i => ?_)).mono
      (fun _ => Nat.zero_le _) (fun _ => Nat.zero_le _)
    show _ = (y i, (E.tabV n (fun i => h i + 1) μ V i, (accA (n i) (acc i ++ []) (o i) (sup i),
      accZ (acc i ++ []))))
    rw [List.append_nil]
  | cons mv ws ih =>
    intro hws V acc hfit hcalls
    have hws' : ∀ mv ∈ ws, mv ∈ E.wd := fun mv' h' => hws mv' (List.mem_cons_of_mem _ h')
    let x0 (i : ι) : T (SwT s cl) :=
      (y i, (E.tabV n (fun i => h i + 1) μ V i, (accA (n i) (acc i) (o i) (sup i), accZ (acc i))))
    rcases GMove.rk_cases mv with hmv | ⟨l, r, z, ind, rfl⟩
    · have hacc : ∀ i, E.accW (n i) (h i) (μ i) (mv :: ws) = E.accW (n i) (h i) (μ i) ws := fun i => by
        rw [E.accW_cons, hmv, List.nil_append]
      have IH := ih hws' (fun i => E.stepV (V i) mv) acc (fun i => by rw [← hacc]; exact hfit i)
        (fun i c' hc => hcalls i c' (by rw [E.kidsUp_free _ _ _ _ _ _ _ _ _ hmv]; exact hc))
      have c0 : E.Ctx m b.B (SwT s cl) x0 n (fun i => h i + 1) μ := c.ext _
      have HF := E.can_free c0 (Can.fst Can.second) mv hmv
      have Hs : Can m b.B (SwT s cl) (SwT s cl) x0
          (fun i => (y i, (E.tabV n (fun i => h i + 1) μ (fun i => E.stepV (V i) mv) i,
            (accA (n i) (acc i) (o i) (sup i), accZ (acc i)))))
          (fun i => 0 + (E.passCost (n i) (E.NUc (n i) (h i + 1) (μ i)) + 0)) :=
        (Can.first (W := fun _ => 0)).fork (HF.fork (Can.snd Can.second))
      refine (((Able.of_can (b := b) Hs).comp IH).cong (fun _ => rfl) (fun i => ?_)).weaken
        (dom_mul (E.R.n + 3) (fun i => ?_)) (fun i => ?_)
      · show _ = (y i, (E.tabV n (fun i => h i + 1) μ (fun i => E.runV (E.stepV (V i) mv) ws) i,
          (accA (n i) (acc i ++ E.accW (n i) (h i) (μ i) (mv :: ws)) (o i) (sup i),
           accZ (acc i ++ E.accW (n i) (h i) (μ i) (mv :: ws)))))
        rw [hacc]
      · show 0 + (E.passCost (n i) (E.NUc (n i) (h i + 1) (μ i)) + 0) + E.swCost (n i) (h i) (μ i) (acc i).length ws ≤ _
        simp only [swCost, hmv, Nat.add_zero, Nat.zero_add]
        exact E.free_dom _ _ _
      · rw [E.kidsUp_free _ _ _ _ _ _ _ _ _ hmv]; simp
    · have hmem := hws _ List.mem_cons_self
      have hr : r ≤ E.X.n := (E.wd_block hmem).2.le
      have hacc : ∀ i, E.accW (n i) (h i) (μ i) (GMove.old (BMove.block l r z ind) :: ws) =
          E.accR (n i) (h i) (μ i) r ++ E.accW (n i) (h i) (μ i) ws := fun i => by
        simp only [E.accW_cons, GMove.rk_block]
      have hoff : ∀ i, o i + (acc i).length + (E.ownSrc (n i) (h i) (μ i) r).length + E.cons (n i) (h i) (μ i * r) =
          o i + (acc i ++ E.accR (n i) (h i) (μ i) r).length := fun i => by
        rw [List.length_append, E.accR_len]; omega
      have hfitB : ∀ i, o i + (acc i ++ E.accR (n i) (h i) (μ i) r).length ≤ BS i := fun i => by
        have := hfit i; rw [hacc, ← List.append_assoc, List.length_append] at this; omega
      have IH := ih hws' (fun i => E.stepV (V i) (GMove.old (BMove.block l r z ind)))
        (fun i => acc i ++ E.accR (n i) (h i) (μ i) r)
        (fun i => by rw [List.append_assoc, ← hacc]; exact hfit i)
        (fun i c' hc => hcalls i c' (by
          rw [E.kidsUp_block _ _ _ _ _ _ _ l r z ind ws hr, hoff]
          exact List.mem_cons_of_mem _ hc))
      have HB := E.able_blockUp ci c hidx hsup ho hBS hmem V acc hfitB (τ := τ)
        (fun i => hcalls i _ (by rw [E.kidsUp_block _ _ _ _ _ _ _ l r z ind ws hr]; exact List.mem_cons_self))
      refine ((HB.comp IH).cong (fun _ => rfl) (fun i => ?_)).mono (fun i => ?_) (fun i => ?_)
      · show _ = (y i, (E.tabV n (fun i => h i + 1) μ
            (fun i => E.runV (E.stepV (V i) (GMove.old (BMove.block l r z ind))) ws) i,
          (accA (n i) (acc i ++ E.accW (n i) (h i) (μ i) (GMove.old (BMove.block l r z ind) :: ws)) (o i) (sup i),
           accZ (acc i ++ E.accW (n i) (h i) (μ i) (GMove.old (BMove.block l r z ind) :: ws)))))
        rw [hacc, List.append_assoc]
      · show E.blkCost _ _ _ r _ + E.swCost _ _ _ (acc i ++ E.accR (n i) (h i) (μ i) r).length ws ≤ _
        simp only [swCost, GMove.rk_block, List.length_append]
        exact le_rfl
      · rw [E.kidsUp_block _ _ _ _ _ _ _ l r z ind ws hr, hoff]
        simp

theorem able_sweepLeaf {b : Bank (portM cl) ι} {s : Ty} {y : ι → T s} {n μ : ι → ℕ}
    (ci : CIn m b.B s y n (fun _ => 0) μ) (c : E.Ctx m b.B s y n (fun _ => 0) μ)
    (hfit0 : ∀ i, E.X.n * μ i ≤ n i) {τ : ι → MDesc → ℕ} :
    ∀ (ws : GWord α ρ), (∀ mv ∈ ws, mv ∈ E.wd) → ∀ (V : ∀ i, E.CState (n i) 0 (μ i)),
      (∀ i, ∀ c' ∈ E.kidsLeaf (n i) (μ i) (V i) ws, (b.use i (E.enc cl c')).OK (E.out cl c') (τ i c') (b.ext i)) →
      Able m b (p s (ctabT cl)) (p s (ctabT cl))
        (fun i => (y i, E.tabV n (fun _ => 0) μ V i))
        (fun i => (y i, E.tabV n (fun _ => 0) μ (fun i => E.runV (V i) ws) i))
        (fun i => E.lfCost (n i) (μ i) ws)
        (fun i => ((E.kidsLeaf (n i) (μ i) (V i) ws).map (τ i)).sum) := by
  intro ws
  induction ws with
  | nil =>
    intro _ V _
    exact ((Able.id (W := fun _ => 0) (Z := fun _ => 0)).mono (fun _ => Nat.zero_le _) (fun _ => Nat.zero_le _))
  | cons mv ws ih =>
    intro hws V hcalls
    have hws' : ∀ mv ∈ ws, mv ∈ E.wd := fun mv' h' => hws mv' (List.mem_cons_of_mem _ h')
    let x0 (i : ι) : T (p s (ctabT cl)) := (y i, E.tabV n (fun _ => 0) μ V i)
    rcases GMove.rk_cases mv with hmv | ⟨l, r, z, ind, rfl⟩
    · have IH := ih hws' (fun i => E.stepV (V i) mv)
        (fun i c' hc => hcalls i c' (by rw [E.kidsLeaf_free _ _ _ _ _ hmv]; exact hc))
      have c0 : E.Ctx m b.B _ x0 n (fun _ => 0) μ := c.ext _
      have HF := E.can_free c0 Can.second mv hmv
      have Hs : Can m b.B (p s (ctabT cl)) (p s (ctabT cl)) x0
          (fun i => (y i, E.tabV n (fun _ => 0) μ (fun i => E.stepV (V i) mv) i))
          (fun i => 0 + E.passCost (n i) (E.NUc (n i) 0 (μ i))) := (Can.first (W := fun _ => 0)).fork HF
      refine ((Able.of_can (b := b) Hs).comp IH).weaken (dom_mul (E.R.n + 3) (fun i => ?_)) (fun i => ?_)
      · show 0 + E.passCost (n i) (E.NUc (n i) 0 (μ i)) + E.lfCost (n i) (μ i) ws ≤ _
        simp only [lfCost, hmv, Nat.zero_add]
        exact E.free_dom _ _ _
      · rw [E.kidsLeaf_free _ _ _ _ _ hmv]; simp
    · have hmem := hws _ List.mem_cons_self
      have hr : r ≤ E.X.n := (E.wd_block hmem).2.le
      have IH := ih hws' (fun i => E.stepV (V i) (GMove.old (BMove.block l r z ind)))
        (fun i c' hc => hcalls i c' (by
          rw [E.kidsLeaf_block _ _ _ l r z ind ws hr]; exact List.mem_cons_of_mem _ hc))
      have HX := E.able_exit ci c hfit0 hmem V (τ := τ)
        (fun i => hcalls i _ (by rw [E.kidsLeaf_block _ _ _ l r z ind ws hr]; exact List.mem_cons_self))
      refine (HX.comp IH).mono (fun i => ?_) (fun i => ?_)
      · simp only [lfCost, GMove.rk_block]
        exact le_rfl
      · rw [E.kidsLeaf_block _ _ _ l r z ind ws hr]; simp

end Sweep

section Body
universe V
variable {ι : Type V} {m : Bool} {cl : Paint}

abbrev envC (cl : Paint) : Ty := ClsT (p (portIn cl) w)

lemma can_prefix {B : ι → ℕ} {n H μ o BS : ι → ℕ} {J sup : ∀ i, ℕ → Bits (n i) → ℂ}
    (hB2 : Small B (fun i => 2^(n i))) (hle : ∀ i, H i ≤ n i) (hμ : ∀ i, μ i ≤ n i) :
    let x0 : ι → T (portIn cl) := fun i => E.enc cl (MDesc.cls (n i) (H i) (μ i) (o i) (BS i) (J i) (sup i))
    let x4 : ι → T (envC cl) := fun i => ((((x0 i, 2^(n i)), E.idxVal (n i) (H i) (μ i)), E.unitVal (n i) (H i) (μ i)),
      E.gearVal (n i) (H i) (μ i))
    CIn m B (envC cl) x4 n H μ ∧ E.Ctx m B (envC cl) x4 n H μ ∧
    Can m B (portIn cl) (p (envC cl) (ctabT cl)) x0
      (fun i => (x4 i, E.tabV n H μ (fun i => E.V0 (n i) (H i) (μ i) (J i)) i))
      (fun i => n i + (E.idxCost (n i) (H i) (μ i) + (E.NUc (n i) (H i) (μ i) * (4 * n i + 4 * H i + 8) +
        (E.NUc (n i) (H i) (μ i) * (2 * 2^(n i) + 2) + (E.passCost (n i) (E.NUc (n i) (H i) (μ i)) + 0))))) := by
  intro x0 x4
  have hns : Small B n := hB2.mono (fun _ => Nat.lt_two_pow_self.le)
  have hnK : Knows m B (portIn cl) x0 n := Can.first
  have hkK : Knows m B (portIn cl) x0 (fun i => H i + 1) := Can.fst (Can.snd Can.second)
  have hμK : Knows m B (portIn cl) x0 μ := Can.fst (Can.snd (Can.snd Can.second))
  have hI : Has m B (portIn cl) sc x0 (fun _ => Complex.I) := Can.fst Can.second
  have H2n : Can m B (portIn cl) w x0 (fun i => 2^(n i)) n :=
    (hnK.mono (fun _ => Nat.zero_le _)).wTwo hns hB2 (Dom.self _)
  let x1 (i : ι) : T (p (portIn cl) w) := (x0 i, 2^(n i))
  have c1 : CIn m B (p (portIn cl) w) x1 n H μ :=
    ⟨Can.first.then_do hnK,
     Can.first.then_do ((hkK.minus (Can.wc 1) ((hns.add (Small.const _ 1)).mono
        (fun i => by have := hle i; omega))).cong (fun _ => rfl) (fun i => Nat.add_sub_cancel _ _)),
     Can.first.then_do hμK, Can.second, Can.first.then_do hI, hB2, hle, hns.mono hμ⟩
  have c4 := E.cctx c1
  have ci4 : CIn m B (envC cl) x4 n H μ := ((c1.ext _).ext _).ext _
  refine ⟨ci4, c4, ?_⟩
  have hJ : Has m B (envC cl) (jobsT cl) x4
      (fun i => jobsTape (n i) (E.NUc (n i) (H i) (μ i) * E.W) (J i)) :=
    (Can.first.then_do (Can.first.then_do (Can.first.then_do Can.first))).then_do
      (Can.fst (Can.snd (Can.snd (Can.snd (Can.snd Can.second)))))
  have HL := E.can_load c4 hJ
  exact H2n.save ((E.can_index c1).save ((E.can_units c1).save ((E.can_gears c1).save
    (HL.save (Can.id (W := fun _ => 0))))))

lemma out_eq (n h μ o BS : ℕ) (J sup : ℕ → Bits n → ℂ) :
    E.out cl (MDesc.cls n h μ o BS J sup) =
      (jobsTape n (E.NUc n h μ * E.W) (E.unl n h μ (E.runV (E.V0 n h μ J) E.wd)),
       jobsTape n (E.cons n h μ) (fun k => hlow n (E.csz n h μ k) (sup (o + k))),
       (Layout.std (E.cons n h μ)).tape (fun k => E.csz n h μ k)) := by
  show (jobsTape n (E.NUc n h μ * E.W) (fun t => hlow n (E.slotSize n h μ t) (J t)), _) = _
  rw [jobsTape_congr (fun t ht => (E.unl_run n h μ J t ht).symm)]

theorem able_classLeaf {b : Bank (portM cl) ι} {n μ o BS : ι → ℕ} {J sup : ∀ i, ℕ → Bits (n i) → ℂ}
    {τ : ι → MDesc → ℕ} (hB2 : Small b.B (fun i => 2^(n i))) (hfit0 : ∀ i, E.X.n * μ i ≤ n i)
    (hkc : ∀ i c', c' ∈ E.kidsC (MDesc.cls (n i) 0 (μ i) (o i) (BS i) (J i) (sup i)) →
      (b.use i (E.enc cl c')).OK (E.out cl c') (τ i c') (b.ext i)) :
    Able m b (portIn cl) (portOut cl)
      (fun i => E.enc cl (MDesc.cls (n i) 0 (μ i) (o i) (BS i) (J i) (sup i)))
      (fun i => E.out cl (MDesc.cls (n i) 0 (μ i) (o i) (BS i) (J i) (sup i)))
      (fun i => E.locLeaf (n i) (μ i))
      (fun i => ((E.kidsC (MDesc.cls (n i) 0 (μ i) (o i) (BS i) (J i) (sup i))).map (τ i)).sum) := by
  have hμ : ∀ i, μ i ≤ n i := fun i => le_trans (Nat.le_mul_of_pos_left _ (by have := E.three; omega)) (hfit0 i)
  obtain ⟨ci4, c4, HP⟩ := E.can_prefix (cl := cl) (m := m) (B := b.B) (H := fun _ => 0) (o := o) (BS := BS)
    (J := J) (sup := sup) hB2 (fun _ => Nat.zero_le _) hμ
  have HS := E.able_sweepLeaf ci4 c4 hfit0 (τ := τ) E.wd (fun _ h' => h') (fun i => E.V0 (n i) 0 (μ i) (J i))
    (fun i c' hc => hkc i c' hc)
  let x4 : ι → T (envC cl) := fun i => ((((E.enc cl (MDesc.cls (n i) 0 (μ i) (o i) (BS i) (J i) (sup i)), 2^(n i)),
      E.idxVal (n i) 0 (μ i)), E.unitVal (n i) 0 (μ i)), E.gearVal (n i) 0 (μ i))
  have hVf : Has m b.B (p (envC cl) (ctabT cl)) (ctabT cl) (fun i => (x4 i, E.tabV n (fun _ => 0) μ
      (fun i => E.runV (E.V0 (n i) 0 (μ i) (J i)) E.wd) i))
      (E.tabV n (fun _ => 0) μ (fun i => E.runV (E.V0 (n i) 0 (μ i) (J i)) E.wd)) := Can.second
  have HU := E.can_unload (c4.ext _) hVf
  have Hfin := HU.fork ((has_jobs0 (m := m) (B := b.B) (cl := cl) n (fun i k => hlow (n i) (E.csz (n i) 0 (μ i) k)
    (sup i (o i + k)))).pair (has_tape0 (t := w) (fun i (k : Fin 0) => E.csz (n i) 0 (μ i) k)))
  refine (((Able.of_can (b := b) HP).comp (HS.comp (Able.of_can (b := b) Hfin))).cong (fun _ => rfl)
    (fun i => (E.out_eq _ _ _ _ _ _ _).symm)).weaken (dom_mul (E.R.n + 8) (fun i => ?_)) ?_
  swap
  · intro i; simp [Eng.kidsC]
  -- CHECK: cost arithmetic
  have h2 : E.NUc (n i) 0 (μ i) * E.W ≤ E.NUc (n i) 0 (μ i) * E.W * 2^(n i) :=
    Nat.le_mul_of_pos_right _ (Nat.two_pow_pos _)
  have h3 : E.NUc (n i) 0 (μ i) ≤ E.NUc (n i) 0 (μ i) * 2^(n i) := Nat.le_mul_of_pos_right _ (Nat.two_pow_pos _)
  have hL : E.locLeaf (n i) (μ i) = (n i + 1) + E.idxCost (n i) 0 (μ i) +
      E.NUc (n i) 0 (μ i) * (4 * n i + 4 * 0 + 8) + E.NUc (n i) 0 (μ i) * (2 * 2^(n i) + 2) +
      E.NUc (n i) 0 (μ i) * 2^(n i) + E.lfCost (n i) (μ i) E.wd + E.NUc (n i) 0 (μ i) * E.W * 2^(n i) := rfl
  have hU : E.NUc (n i) 0 (μ i) * E.W * (2^(n i) + 1) =
      E.NUc (n i) 0 (μ i) * E.W * 2^(n i) + E.NUc (n i) 0 (μ i) * E.W := Nat.mul_succ _ _
  try dsimp only at hL hU ⊢
  exact E.cost_close (n i) (E.NUc (n i) 0 (μ i)) _ _ (by rw [hL]; omega) (by rw [hL]; omega)

theorem able_classUp {b : Bank (portM cl) ι} {n h μ o BS : ι → ℕ} {J sup : ∀ i, ℕ → Bits (n i) → ℂ}
    {τ : ι → MDesc → ℕ} (hB2 : Small b.B (fun i => 2^(n i))) (hBS : Small b.B BS)
    (hle : ∀ i, h i + 1 ≤ n i) (hμ : ∀ i, μ i ≤ n i) (hfit : ∀ i, o i + E.cons (n i) (h i + 1) (μ i) ≤ BS i)
    (hkc : ∀ i c', c' ∈ E.kidsC (MDesc.cls (n i) (h i + 1) (μ i) (o i) (BS i) (J i) (sup i)) →
      (b.use i (E.enc cl c')).OK (E.out cl c') (τ i c') (b.ext i)) :
    Able m b (portIn cl) (portOut cl)
      (fun i => E.enc cl (MDesc.cls (n i) (h i + 1) (μ i) (o i) (BS i) (J i) (sup i)))
      (fun i => E.out cl (MDesc.cls (n i) (h i + 1) (μ i) (o i) (BS i) (J i) (sup i)))
      (fun i => E.locUp (n i) (h i) (μ i))
      (fun i => ((E.kidsC (MDesc.cls (n i) (h i + 1) (μ i) (o i) (BS i) (J i) (sup i))).map (τ i)).sum) := by
  obtain ⟨ci4, c4, HP⟩ := E.can_prefix (cl := cl) (m := m) (B := b.B) (H := fun i => h i + 1) (o := o) (BS := BS)
    (J := J) (sup := sup) hB2 hle hμ
  let x4 : ι → T (envC cl) := fun i => ((((E.enc cl (MDesc.cls (n i) (h i + 1) (μ i) (o i) (BS i) (J i) (sup i)), 2^(n i)),
      E.idxVal (n i) (h i + 1) (μ i)), E.unitVal (n i) (h i + 1) (μ i)), E.gearVal (n i) (h i + 1) (μ i))
  have p40 : Has m b.B (envC cl) (portIn cl) x4
      (fun i => E.enc cl (MDesc.cls (n i) (h i + 1) (μ i) (o i) (BS i) (J i) (sup i))) :=
    Can.first.then_do (Can.first.then_do (Can.first.then_do Can.first))
  have hidx : Has m b.B (envC cl) IdxT x4 (fun i => E.idxVal (n i) (h i + 1) (μ i)) :=
    Can.first.then_do (Can.first.then_do Can.second)
  have hsup : Has m b.B (envC cl) (jobsT cl) x4 (fun i => jobsTape (n i) (BS i) (sup i)) :=
    p40.then_do (Can.snd (Can.snd (Can.snd (Can.snd (Can.snd Can.second)))))
  have ho : Knows m b.B (envC cl) x4 o := p40.then_do (Can.fst (Can.snd (Can.snd (Can.snd Can.second))))
  have H0 : Can m b.B (p (envC cl) (ctabT cl)) (SwT (envC cl) cl)
      (fun i => (x4 i, E.tabV n (fun i => h i + 1) μ (fun i => E.V0 (n i) (h i + 1) (μ i) (J i)) i))
      (fun i => (x4 i, (E.tabV n (fun i => h i + 1) μ (fun i => E.V0 (n i) (h i + 1) (μ i) (J i)) i,
        (accA (n i) [] (o i) (sup i), accZ ([] : List ℕ)))))
      (fun _ => 0) :=
    Can.first.pair (Can.second.pair ((has_jobs0 n (fun i k => hlow (n i) (([] : List ℕ).getD k 0)
      (sup i (o i + k)))).pair (has_tape0 (t := w) (fun _ (k : Fin 0) => ([] : List ℕ).getD k 0))))
  have HS := E.able_sweepUp ci4 c4 hidx hsup ho hBS (τ := τ) E.wd (fun _ h' => h')
    (fun i => E.V0 (n i) (h i + 1) (μ i) (J i)) (fun _ => [])
    (fun i => by rw [List.nil_append, E.accW_wd]; exact hfit i)
    (fun i c' hc => hkc i c' (by simp only [List.length_nil, Nat.add_zero] at hc; exact hc))
  have hVf : Has m b.B (SwT (envC cl) cl) (ctabT cl) (fun i => (x4 i, (E.tabV n (fun i => h i + 1) μ
      (fun i => E.runV (E.V0 (n i) (h i + 1) (μ i) (J i)) E.wd) i,
      (accA (n i) (([] : List ℕ) ++ E.accW (n i) (h i) (μ i) E.wd) (o i) (sup i),
       accZ (([] : List ℕ) ++ E.accW (n i) (h i) (μ i) E.wd)))))
      (E.tabV n (fun i => h i + 1) μ (fun i => E.runV (E.V0 (n i) (h i + 1) (μ i) (J i)) E.wd)) := Can.fst Can.second
  have HU := E.can_unload (c4.ext _) hVf
  have Hfin := HU.fork (Can.snd (Can.second (W := fun _ => 0)))
  refine (((Able.of_can (b := b) (HP.pipe H0)).comp (HS.comp (Able.of_can (b := b) Hfin))).cong (fun _ => rfl)
    (fun i => ?_)).weaken (dom_mul (E.R.n + 8) (fun i => ?_)) (fun i => ?_)
  · rw [E.out_eq]
    rfl
  · -- CHECK: cost arithmetic
    have h2 : E.NUc (n i) (h i + 1) (μ i) * E.W ≤ E.NUc (n i) (h i + 1) (μ i) * E.W * 2^(n i) :=
      Nat.le_mul_of_pos_right _ (Nat.two_pow_pos _)
    have h3 : E.NUc (n i) (h i + 1) (μ i) ≤ E.NUc (n i) (h i + 1) (μ i) * 2^(n i) :=
      Nat.le_mul_of_pos_right _ (Nat.two_pow_pos _)
    have hL : E.locUp (n i) (h i) (μ i) = (n i + 1) + E.idxCost (n i) (h i + 1) (μ i) +
        E.NUc (n i) (h i + 1) (μ i) * (4 * n i + 4 * (h i + 1) + 8) +
        E.NUc (n i) (h i + 1) (μ i) * (2 * 2^(n i) + 2) + E.NUc (n i) (h i + 1) (μ i) * 2^(n i) +
        E.swCost (n i) (h i) (μ i) 0 E.wd + E.NUc (n i) (h i + 1) (μ i) * E.W * 2^(n i) := rfl
    have hU : E.NUc (n i) (h i + 1) (μ i) * E.W * (2^(n i) + 1) =
        E.NUc (n i) (h i + 1) (μ i) * E.W * 2^(n i) + E.NUc (n i) (h i + 1) (μ i) * E.W := Nat.mul_succ _ _
    simp only [List.length_nil]
    try dsimp only at hL hU ⊢
    exact E.cost_close (n i) (E.NUc (n i) (h i + 1) (μ i)) _ _ (by rw [hL]; omega) (by rw [hL]; omega)
  · simp only [List.length_nil, Nat.add_zero, Nat.zero_add]; exact Nat.le_refl _

end Body

theorem class_body_valid {kmin : ℕ} (hk : E.KMin kmin) {ι : Type U} {m : Bool} {cl : Paint}
    {b : Bank (portM cl) ι} {n h μ o BS : ι → ℕ} {J sup : ∀ i, ℕ → Bits (n i) → ℂ} {τ : ι → MDesc → ℕ}
    (hB2 : Small b.B (fun i => 2^(n i))) (hBS : Small b.B BS)
    (hd : ∀ i, E.Valid kmin (MDesc.cls (n i) (h i) (μ i) (o i) (BS i) (J i) (sup i)))
    (hkc : ∀ i c, c ∈ E.kidsC (MDesc.cls (n i) (h i) (μ i) (o i) (BS i) (J i) (sup i)) →
      (b.use i (E.enc cl c)).OK (E.out cl c) (τ i c) (b.ext i)) :
    Able m b (portIn cl) (portOut cl)
      (fun i => E.enc cl (MDesc.cls (n i) (h i) (μ i) (o i) (BS i) (J i) (sup i)))
      (fun i => E.out cl (MDesc.cls (n i) (h i) (μ i) (o i) (BS i) (J i) (sup i)))
      (fun i => E.clsLoc (n i) (h i) (μ i))
      (fun i => ((E.kidsC (MDesc.cls (n i) (h i) (μ i) (o i) (BS i) (J i) (sup i))).map (τ i)).sum) := by
  have hf := fun i => E.valid_facts hk (hd i)
  have hkind : Can m b.B (portIn cl) w (fun i => E.enc cl (MDesc.cls (n i) (h i) (μ i) (o i) (BS i) (J i) (sup i)))
      h (fun _ => 0) :=
    ((Can.fst (Can.snd Can.second)).minus (Can.wc 1)
      ((hB2.mono (fun i => Nat.lt_two_pow_self.le)).add (Small.const _ 1) |>.mono
        (fun i => by have := (hf i).2.1; show h i + 1 ≤ _; omega))).cong (fun _ => rfl)
      (fun i => Nat.add_sub_cancel _ _)
  refine Able.branch (hkind.mono (fun _ => Nat.zero_le _)) (fun i => h i = 0) (fun _ => Iff.rfl) ?_ ?_
  · -- leaf classes
    have H := E.able_classLeaf (b := b.comap (fun i : {i // h i = 0} => i.1)) (cl := cl) (m := m)
      (n := fun i => n i.1) (μ := fun i => μ i.1) (o := fun i => o i.1) (BS := fun i => BS i.1)
      (J := fun i => J i.1) (sup := fun i => sup i.1) (τ := fun i => τ i.1) (hB2.reindex _)
      (fun i => (hf i.1).1 i.2)
      (fun i c' hc => hkc i.1 c' (by rw [i.2]; exact hc))
    refine (H.cong (fun i => by rw [i.2]) (fun i => by rw [i.2])).mono
      (fun i => by show _ ≤ E.clsLoc _ (h i.1) _; rw [i.2]; simp [clsLoc]) (fun i => by rw [i.2])
  · -- up classes
    have hh : ∀ i : {i // ¬ h i = 0}, h i.1 = (h i.1 - 1) + 1 := fun i => by have := i.2; omega
    have H := E.able_classUp (b := b.comap (fun i : {i // ¬ h i = 0} => i.1)) (cl := cl) (m := m)
      (n := fun i => n i.1) (h := fun i => h i.1 - 1) (μ := fun i => μ i.1) (o := fun i => o i.1)
      (BS := fun i => BS i.1) (J := fun i => J i.1) (sup := fun i => sup i.1) (τ := fun i => τ i.1)
      (hB2.reindex _) (hBS.reindex _) (fun i => by rw [← hh i]; exact (hf i.1).2.1)
      (fun i => (hf i.1).2.2.1) (fun i => by rw [← hh i]; exact (hf i.1).2.2.2)
      (fun i c' hc => hkc i.1 c' (by rw [hh i]; exact hc))
    refine (H.cong (fun i => ?_) (fun i => ?_)).mono (fun i => ?_) (fun i => ?_)
    · exact congrArg (fun k => E.enc cl (MDesc.cls (n i.1) k (μ i.1) (o i.1) (BS i.1) (J i.1) (sup i.1))) (hh i).symm
    · exact congrArg (fun k => E.out cl (MDesc.cls (n i.1) k (μ i.1) (o i.1) (BS i.1) (J i.1) (sup i.1))) (hh i).symm
    · show _ ≤ E.clsLoc _ (h i.1) _
      unfold clsLoc
      rw [if_neg i.2]
    · exact le_of_eq (congrArg (fun k => ((E.kidsC (MDesc.cls (n i.1) k (μ i.1) (o i.1) (BS i.1) (J i.1)
        (sup i.1))).map (τ i.1)).sum) (hh i).symm)

end Eng
end
end PowerSaving.RAM
end OAI

