import Submission.Work.Mixed.Prog.Merged2
import Submission.Work.MixedCost.TopMain
import Mathlib.Data.Fin.Tuple.NatAntidiagonal
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Algebra.Order.BigOperators.GroupWithZero.Finset
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Submission.Work.Mixed.Prog.Seq
import Mathlib.Algebra.Module.BigOperators
import Submission.Work.Scratch.Engine
import Submission.Work.MixedCost.Close
import Mathlib.Analysis.SpecialFunctions.Pow.Real
import Submission.Work.Mixed.Prog.Sem
import Submission.Work.Kit.RAMEnv

private theorem rpow_one_add_le_one_add_mul_self {s : ℝ} (hs : -1 ≤ s) {p : ℝ} (hp1 : 0 ≤ p) (hp2 : p ≤ 1) :
    (1 + s) ^ p ≤ 1 + p * s := by
  rcases eq_or_lt_of_le hs with h | h
  · have h0 : 1 + s = 0 := by linarith
    rw [h0]
    rcases eq_or_lt_of_le hp1 with hp | hp
    · subst hp; simp
    · rw [Real.zero_rpow hp.ne']; nlinarith
  · have a0 : 0 < 1 + s := by linarith
    have A0 : 0 < p * (1 + s) + (1 - p) := by
      rcases eq_or_lt_of_le hp2 with hp | hp
      · subst hp; linarith
      · nlinarith [mul_nonneg hp1 a0.le]
    have h1 := Real.log_le_sub_one_of_pos (div_pos a0 A0)
    have h2 := Real.log_le_sub_one_of_pos (inv_pos.mpr A0)
    rw [Real.log_div a0.ne' A0.ne'] at h1
    rw [Real.log_inv] at h2
    have e : p * ((1 + s) / (p * (1 + s) + (1 - p))) + (1 - p) * (p * (1 + s) + (1 - p))⁻¹ = 1 := by
      field_simp
    have key : p * Real.log (1 + s) ≤ Real.log (p * (1 + s) + (1 - p)) := by
      nlinarith [mul_le_mul_of_nonneg_left h1 hp1, mul_le_mul_of_nonneg_left h2 (sub_nonneg.mpr hp2)]
    calc (1 + s) ^ p = Real.exp (Real.log (1 + s) * p) := Real.rpow_def_of_pos a0 p
      _ ≤ Real.exp (Real.log (p * (1 + s) + (1 - p))) := Real.exp_le_exp.mpr (by linarith [key])
      _ = p * (1 + s) + (1 - p) := Real.exp_log A0
      _ = 1 + p * s := by ring


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR MCost
noncomputable section

universe U

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable (E : Eng α ρ σ)

def kidsAll (kmin n0 : ℕ) : MDesc → List MDesc
  | .top n B v => E.kidsTop kmin n0 n B v
  | .cls n h μ o BS J sup => E.kidsC (.cls n h μ o BS J sup)

lemma topG_spec (kmin n : ℕ) (hn : E.mx ≤ n) : E.mx * 1 * kmin ^ E.topG kmin n ≤ n := by
  rw [Nat.mul_one]
  exact Nat.findGreatest_spec (P := fun g => E.mx * kmin ^ g ≤ n) (Nat.zero_le n) (by simpa using hn)

lemma kidsTop_valid (kmin n0 : ℕ) (hn0 : E.mx ≤ n0) (n B : ℕ) (v : ℕ → Bits n → ℂ) :
    ∀ c ∈ E.kidsTop kmin n0 n B v, E.Valid kmin c := by
  intro c hc
  unfold kidsTop at hc
  split_ifs at hc with hif
  · obtain ⟨t, ht, hc⟩ := List.mem_flatMap.1 hc
    rw [List.mem_range] at ht
    rcases List.mem_cons.1 hc with hc | hc
    · subst hc
      refine ⟨le_rfl, E.topG_spec kmin n (le_trans hn0 hif.1), ?_⟩
      have hN := hif.2
      have h1 : (t + 1) * E.topN kmin n ≤ B / E.topN kmin n * E.topN kmin n :=
        Nat.mul_le_mul_right _ ht
      have h2 : B / E.topN kmin n * E.topN kmin n ≤ B := Nat.div_mul_le_self _ _
      have h3 : t * E.topN kmin n + E.topNU0 kmin n * E.W + E.cons n (E.topG kmin n) 1 =
          (t + 1) * E.topN kmin n := by unfold topN; ring
      show t * E.topN kmin n + E.topNU0 kmin n * E.W + E.cons n (E.topG kmin n) 1 ≤ B
      omega
    · obtain ⟨j, _, rfl⟩ := List.mem_map.1 hc
      trivial
  · simp at hc

lemma kidsAll_valid {kmin : ℕ} (hk : E.KMin kmin) (n0 : ℕ) (hn0 : E.mx ≤ n0) (d : MDesc)
    (hd : E.Valid kmin d) : ∀ c ∈ E.kidsAll kmin n0 d, E.Valid kmin c := by
  cases d with
  | top n B v => exact E.kidsTop_valid kmin n0 hn0 n B v
  | cls n h μ o BS J sup => exact E.kidsC_valid hk _ hd

abbrev VD (kmin : ℕ) := {d : MDesc // E.Valid kmin d}

def kidsV {kmin : ℕ} (hk : E.KMin kmin) (n0 : ℕ) (hn0 : E.mx ≤ n0) (d : E.VD kmin) : List (E.VD kmin) :=
  (E.kidsAll kmin n0 d.1).attach.map (fun c => ⟨c.1, E.kidsAll_valid hk n0 hn0 d.1 d.2 c.1 c.2⟩)

def encV (kmin : ℕ) (cl : Paint) (d : E.VD kmin) : T (portIn cl) := E.enc cl d.1
def outV (kmin : ℕ) (cl : Paint) (d : E.VD kmin) : T (portOut cl) := E.out cl d.1

def bndD : MDesc → ℕ
  | .top n B _ => (B + 2) * 2^n
  | .cls n _ _ _ BS _ _ => (BS + 2) * 2^n

def locD (kmin n0 : ℕ) : MDesc → ℕ
  | .top n B _ => E.locTop kmin n0 n B
  | .cls n h μ _ _ _ _ => E.clsLoc n h μ

lemma sum_attach_map {β : Type*} (P : β → Prop) [DecidablePred P] (l : List β) (hP : ∀ c ∈ l, P c) (g : {c // P c} → ℕ) :
    ((l.attach.map (fun c => (⟨c.1, hP c.1 c.2⟩ : {c // P c}))).map g).sum =
      (l.map (fun c => if hc : P c then g ⟨c, hc⟩ else 0)).sum := by
  induction l with
  | nil => rfl
  | cons a l ih =>
    simp only [List.attach_cons, List.map_cons, List.map_map, List.sum_cons]
    rw [dif_pos (hP a List.mem_cons_self)]
    congr 1
    have := ih (fun c hc => hP c (List.mem_cons_of_mem _ hc))
    rw [← this, List.map_map]
    rfl

def isTop : MDesc → Prop
  | .top _ _ _ => True
  | .cls _ _ _ _ _ _ _ => False
instance : DecidablePred isTop := fun d => by cases d <;> unfold isTop <;> infer_instance

def topF : MDesc → Σ n : ℕ, ℕ × (ℕ → Bits n → ℂ)
  | .top n B v => ⟨n, B, v⟩
  | .cls n _ _ _ _ _ _ => ⟨n, 0, fun _ _ => 0⟩
lemma topF_eq (d : MDesc) (hd : isTop d) : d = MDesc.top (topF d).1 (topF d).2.1 (topF d).2.2 := by
  cases d with
  | top n B v => rfl
  | cls => exact absurd hd (by simp [isTop])

def clsF : MDesc → Σ n : ℕ, ℕ × ℕ × ℕ × ℕ × (ℕ → Bits n → ℂ) × (ℕ → Bits n → ℂ)
  | .top n _ _ => ⟨n, 0, 0, 0, 0, fun _ _ => 0, fun _ _ => 0⟩
  | .cls n h μ o BS J sup => ⟨n, h, μ, o, BS, J, sup⟩
lemma clsF_eq (d : MDesc) (hd : ¬ isTop d) :
    d = MDesc.cls (clsF d).1 (clsF d).2.1 (clsF d).2.2.1 (clsF d).2.2.2.1 (clsF d).2.2.2.2.1 (clsF d).2.2.2.2.2.1
      (clsF d).2.2.2.2.2.2 := by
  cases d with
  | top => exact absurd trivial hd
  | cls n h μ o BS J sup => rfl

open Classical in
theorem hbody {kmin : ℕ} (hk : E.KMin kmin) (n0 : ℕ) (hn0 : E.mx ≤ n0) (m : Bool) (cl : Paint) :
    Able m (gfunds (E.encV kmin cl) (E.outV kmin cl)
        (fun d c => c ∈ (↑(E.kidsV hk n0 hn0 d) : Multiset (E.VD kmin))) (fun d => bndD d.1))
      (portIn cl) (portOut cl) (fun i => E.encV kmin cl i.d) (fun i => E.outV kmin cl i.d)
      (fun i => E.locD kmin n0 i.d.1)
      (fun i => (((↑(E.kidsV hk n0 hn0 i.d) : Multiset (E.VD kmin))).map i.tau).sum) := by
  let Kid := fun (d c : E.VD kmin) => c ∈ (↑(E.kidsV hk n0 hn0 d) : Multiset (E.VD kmin))
  let bk := gfunds (E.encV kmin cl) (E.outV kmin cl) Kid (fun d => bndD d.1)
  let G := GDesc (E.encV kmin cl) (E.outV kmin cl) Kid
  -- the kind of the input
  have hkind : Knows m bk.B (portIn cl) (fun i : G => E.encV kmin cl i.d)
      (fun i => (E.encV kmin cl i.d).2.2.1) := Can.fst (Can.snd Can.second)
  -- calls are answered
  have hmem : ∀ (i : G) (c : MDesc) (hc : c ∈ E.kidsAll kmin n0 i.d.1),
      (⟨c, E.kidsAll_valid hk n0 hn0 i.d.1 i.d.2 c hc⟩ : E.VD kmin) ∈
        (↑(E.kidsV hk n0 hn0 i.d) : Multiset (E.VD kmin)) := by
    intro i c hc
    rw [Multiset.mem_coe]
    exact List.mem_map.2 ⟨⟨c, hc⟩, List.mem_attach _ _, rfl⟩
  let tau (i : G) (c : MDesc) : ℕ := if hc : E.Valid kmin c then i.tau ⟨c, hc⟩ else 0
  have hcall : ∀ (i : G) (c : MDesc), c ∈ E.kidsAll kmin n0 i.d.1 →
      (i.use (E.enc cl c)).OK (E.out cl c) (tau i c) i.peak := by
    intro i c hc
    have hv := E.kidsAll_valid hk n0 hn0 i.d.1 i.d.2 c hc
    have := i.works ⟨c, hv⟩ (hmem i c hc)
    simp only [tau, dif_pos hv]
    exact this
  have hsum : ∀ i : G, (((↑(E.kidsV hk n0 hn0 i.d) : Multiset (E.VD kmin))).map i.tau).sum =
      ((E.kidsAll kmin n0 i.d.1).map (tau i)).sum := by
    intro i
    rw [Multiset.map_coe, Multiset.sum_coe]
    exact sum_attach_map (E.Valid kmin) _ (E.kidsAll_valid hk n0 hn0 i.d.1 i.d.2) i.tau
  apply Able.branch (hkind.mono (W':=fun i => E.locD kmin n0 i.d.1) (fun _ => Nat.zero_le _))
    (fun i => isTop i.d.1) (fun i => by
      rcases hd : i.d with ⟨d, hv⟩
      cases d <;> simp [encV, enc, mkIn, isTop])
  · -- top jobs: e-r3cost's body
    let K := {i : G // isTop i.d.1}
    let tn (k : K) := (topF k.1.d.1).1
    let tB (k : K) := (topF k.1.d.1).2.1
    let tv (k : K) : ℕ → Bits (tn k) → ℂ := (topF k.1.d.1).2.2
    have heq : ∀ k : K, k.1.d.1 = MDesc.top (tn k) (tB k) (tv k) := fun k => topF_eq _ k.2
    have hbig : Small (bk.comap (fun k : K => k.1)).B (fun k => (tB k + 1) * 2^(tn k)) :=
      (Small.self _).mono (fun k => by
        show (tB k + 1) * 2^(tn k) ≤ bndD k.1.d.1
        rw [heq k]; show (tB k + 1) * 2^(tn k) ≤ (tB k + 2) * 2^(tn k)
        exact Nat.mul_le_mul_right _ (by omega))
    have H := E.top_body kmin n0 hk.two hn0 (m:=m) (cl:=cl) (b:=bk.comap (fun k : K => k.1)) tn tB tv hbig
      (fun k => tau k.1) (fun k c hc => hcall k.1 c (by rw [heq k]; exact hc))
    refine (H.cong (fun k => ?_) (fun k => ?_)).mono (fun k => le_of_eq ?_) (fun k => le_of_eq ?_)
    · show E.enc cl (MDesc.top (tn k) (tB k) (tv k)) = E.encV kmin cl k.1.d
      unfold encV; rw [← heq k]
    · show E.out cl (MDesc.top (tn k) (tB k) (tv k)) = E.outV kmin cl k.1.d
      unfold outV; rw [← heq k]
    · show E.locTop kmin n0 (tn k) (tB k) = E.locD kmin n0 k.1.d.1
      rw [heq k]; rfl
    · show _ = (((↑(E.kidsV hk n0 hn0 k.1.d) : Multiset (E.VD kmin))).map k.1.tau).sum
      rw [hsum k.1, heq k]; rfl
  · -- classes: the class body
    let K := {i : G // ¬ isTop i.d.1}
    let cf (k : K) := clsF k.1.d.1
    have heq : ∀ k : K, k.1.d.1 = MDesc.cls (cf k).1 (cf k).2.1 (cf k).2.2.1 (cf k).2.2.2.1 (cf k).2.2.2.2.1
        (cf k).2.2.2.2.2.1 (cf k).2.2.2.2.2.2 := fun k => clsF_eq _ k.2
    have hval : ∀ k : K, E.Valid kmin (MDesc.cls (cf k).1 (cf k).2.1 (cf k).2.2.1 (cf k).2.2.2.1 (cf k).2.2.2.2.1
        (cf k).2.2.2.2.2.1 (cf k).2.2.2.2.2.2) := fun k => by rw [← heq k]; exact k.1.d.2
    have hbnd : ∀ k : K, (bk.comap (fun k : K => k.1)).B k = ((cf k).2.2.2.2.1 + 2) * 2^((cf k).1) := fun k => by
      show bndD k.1.d.1 = _
      rw [heq k]; rfl
    have hB2 : Small (bk.comap (fun k : K => k.1)).B (fun k => 2^((cf k).1)) :=
      (Small.self _).mono (fun k => by rw [hbnd k]; exact Nat.le_mul_of_pos_left _ (by omega))
    have hBS : Small (bk.comap (fun k : K => k.1)).B (fun k => (cf k).2.2.2.2.1) :=
      (Small.self _).mono (fun k => by
        rw [hbnd k]
        calc (cf k).2.2.2.2.1 ≤ (cf k).2.2.2.2.1 + 2 := by omega
          _ ≤ _ := Nat.le_mul_of_pos_right _ (Nat.two_pow_pos _))
    have H := E.class_body_valid hk (m:=m) (cl:=cl) (b:=bk.comap (fun k : K => k.1))
      (n:=fun k => (cf k).1) (h:=fun k => (cf k).2.1) (μ:=fun k => (cf k).2.2.1) (o:=fun k => (cf k).2.2.2.1)
      (BS:=fun k => (cf k).2.2.2.2.1) (J:=fun k => (cf k).2.2.2.2.2.1) (sup:=fun k => (cf k).2.2.2.2.2.2)
      (τ:=fun k => tau k.1) hB2 hBS hval
      (fun k c hc => hcall k.1 c (by rw [heq k]; exact hc))
    refine (H.cong (fun k => ?_) (fun k => ?_)).mono (fun k => le_of_eq ?_) (fun k => le_of_eq ?_)
    · show E.enc cl (MDesc.cls _ _ _ _ _ _ _) = E.encV kmin cl k.1.d
      unfold encV; rw [← heq k]
    · show E.out cl (MDesc.cls _ _ _ _ _ _ _) = E.outV kmin cl k.1.d
      unfold outV; rw [← heq k]
    · show E.clsLoc _ _ _ = E.locD kmin n0 k.1.d.1
      rw [heq k]; rfl
    · show _ = (((↑(E.kidsV hk n0 hn0 k.1.d) : Multiset (E.VD kmin))).map k.1.tau).sum
      rw [hsum k.1, heq k]; rfl

end Eng

end
end PowerSaving.RAM
end OAI

namespace OAI.PowerSaving.MX

open Finset

structure Rule where
  K : ℕ
  kr : Fin K → ℕ
  Wk : Fin K → ℕ
  m : ℕ
  P : ℕ
  rk : Fin P → ℕ
  kmin : ℕ
  rmax : ℕ
  kmin_le : ∀ k, kmin ≤ kr k
  kr_le : ∀ k, kr k ≤ m
  rk_pos : ∀ j, 1 ≤ rk j
  rk_le : ∀ j, rk j ≤ rmax
  sep : rmax < kmin
  two_le_kmin : 2 ≤ kmin
  kmin_att : ∃ k, kr k = kmin ∧ 1 ≤ Wk k

lemma mem_nsmul_single {c x s : ℕ} (hx : x ∈ c • ({s} : Multiset ℕ)) : x = s := by
  rcases Multiset.mem_nsmul.1 hx with ⟨_, h⟩
  simpa using h

namespace Rule

variable (R : Rule)

abbrev Pt := Fin R.K → ℕ

def col (a : R.Pt) : ℕ := ∏ k, R.kr k ^ a k

def e (k : Fin R.K) : R.Pt := Pi.single k 1

def W : ℕ := ∑ k, R.Wk k

def uh : ℕ → R.Pt → ℕ
  | 0, a => if a = 0 then 1 else 0
  | h + 1, a => ∑ k, if 1 ≤ a k then R.Wk k * uh h (a - R.e k) else 0

def G (n : ℕ) : ℕ := Nat.findGreatest (fun g => R.m * R.kmin ^ g ≤ n) n

def pts (n h ρ : ℕ) : Finset R.Pt :=
  (Finset.Nat.antidiagonalTuple R.K h).filter (fun b => R.m * ρ * R.col b ≤ n)

def inMS (n h ρ : ℕ) : Multiset ℕ :=
  ∑ b ∈ R.pts n h ρ, ∑ k, (R.uh h b * R.Wk k) • ({ρ * R.kr k * R.col b} : Multiset ℕ)

def outMS (n h ρ : ℕ) (j : Fin R.P) : Multiset ℕ :=
  ∑ b ∈ R.pts n h ρ, R.uh h b • ({ρ * R.rk j * R.col b} : Multiset ℕ)

def srcMS (n h ρ ρp : ℕ) : Multiset ℕ :=
  ∑ b ∈ R.pts n h ρ, ∑ k,
    if n < R.m * ρp * R.col (b + R.e k) then (R.uh h b * R.Wk k) • ({ρ * R.kr k * R.col b} : Multiset ℕ)
    else 0

def unitsC (n h ρ : ℕ) : ℕ := ∑ b ∈ R.pts n h ρ, R.uh h b

def exitsSub (n : ℕ) : ℕ → ℕ → Multiset ℕ
  | 0, ρ => ∑ j, R.outMS n 0 ρ j
  | h + 1, ρ => ∑ j, exitsSub n h (ρ * R.rk j)

def srcBelow (n : ℕ) : ℕ → ℕ → Multiset ℕ
  | 0, _ => 0
  | h + 1, ρ => ∑ j, (R.srcMS n h (ρ * R.rk j) ρ + srcBelow n h (ρ * R.rk j))

def unitsSub (n : ℕ) : ℕ → ℕ → ℕ
  | 0, ρ => R.unitsC n 0 ρ
  | h + 1, ρ => R.unitsC n (h + 1) ρ + ∑ j, unitsSub n h (ρ * R.rk j)

def srcT (n : ℕ) : Multiset ℕ := R.inMS n (R.G n) 1 + R.srcBelow n (R.G n) 1

def exT (n : ℕ) : Multiset ℕ := R.exitsSub n (R.G n) 1

def unitsT (n : ℕ) : ℕ := R.unitsSub n (R.G n) 1

def Nsrc (n : ℕ) : ℕ := Multiset.card (R.srcT n)

lemma e_apply (k k' : Fin R.K) : R.e k k' = if k' = k then 1 else 0 := by
  unfold e; rw [Pi.single_apply]

lemma sum_add_e (b : R.Pt) (k : Fin R.K) : ∑ i, (b + R.e k) i = ∑ i, b i + 1 := by
  simp only [Pi.add_apply, Finset.sum_add_distrib, e_apply, Finset.sum_ite_eq', Finset.mem_univ, ite_true]

lemma col_add_e (b : R.Pt) (k : Fin R.K) : R.col (b + R.e k) = R.kr k * R.col b := by
  unfold col
  simp only [Pi.add_apply, pow_add, Finset.prod_mul_distrib, e_apply]
  rw [mul_comm]
  congr 1
  rw [Finset.prod_eq_single k]
  · simp
  · intro b _ hb; simp [hb]
  · simp

lemma sub_e_add_e (a : R.Pt) (k : Fin R.K) (h : 1 ≤ a k) : a - R.e k + R.e k = a := by
  funext i
  simp only [Pi.add_apply, Pi.sub_apply, e_apply]
  split_ifs with hi
  · subst hi; omega
  · omega

lemma add_e_sub_e (b : R.Pt) (k : Fin R.K) : b + R.e k - R.e k = b := by
  funext i
  simp only [Pi.add_apply, Pi.sub_apply, e_apply]
  omega

lemma add_e_apply_self (b : R.Pt) (k : Fin R.K) : 1 ≤ (b + R.e k) k := by
  simp [e_apply]

lemma sum_shift {M : Type*} [AddCommMonoid M] (h : ℕ) (F : R.Pt → Fin R.K → M) :
    ∑ b ∈ Finset.Nat.antidiagonalTuple R.K h, ∑ k, F b k =
      ∑ a ∈ Finset.Nat.antidiagonalTuple R.K (h + 1), ∑ k, if 1 ≤ a k then F (a - R.e k) k else 0 := by
  rw [Finset.sum_comm, Finset.sum_comm (s := Finset.Nat.antidiagonalTuple R.K (h + 1))]
  refine Finset.sum_congr rfl (fun k _ => ?_)
  rw [← Finset.sum_filter]
  refine Finset.sum_nbij' (fun b => b + R.e k) (fun a => a - R.e k) ?_ ?_ ?_ ?_ ?_
  · intro b hb
    simp only [Finset.mem_coe, Finset.mem_filter, Finset.Nat.mem_antidiagonalTuple] at hb ⊢
    exact ⟨by rw [R.sum_add_e, hb], R.add_e_apply_self b k⟩
  · intro a ha
    simp only [Finset.mem_coe, Finset.mem_filter, Finset.Nat.mem_antidiagonalTuple] at ha ⊢
    have h1 := R.sum_add_e (a - R.e k) k
    rw [R.sub_e_add_e a k ha.2, ha.1] at h1
    omega
  · intro b _; exact R.add_e_sub_e b k
  · intro a ha
    simp only [Finset.mem_filter] at ha
    exact R.sub_e_add_e a k ha.2
  · intro b _; rw [R.add_e_sub_e]

lemma rk_lt_kr (j : Fin R.P) (k : Fin R.K) : R.rk j < R.kr k :=
  lt_of_le_of_lt (R.rk_le j) (lt_of_lt_of_le R.sep (R.kmin_le k))

lemma two_le_m : 2 ≤ R.m := by
  obtain ⟨k, hk, _⟩ := R.kmin_att
  have := R.kr_le k; have := R.two_le_kmin; omega

lemma kmin_pos : 0 < R.kmin := by have := R.two_le_kmin; omega

lemma kr_pos (k : Fin R.K) : 0 < R.kr k := lt_of_lt_of_le R.kmin_pos (R.kmin_le k)

lemma col_pos (b : R.Pt) : 0 < R.col b := by
  unfold col; exact Finset.prod_pos (fun k _ => pow_pos (R.kr_pos k) _)

lemma pow_le_col (b : R.Pt) : R.kmin ^ (∑ i, b i) ≤ R.col b := by
  unfold col
  rw [← Finset.prod_pow_eq_pow_sum]
  exact Finset.prod_le_prod' (fun k _ => Nat.pow_le_pow_left (R.kmin_le k) _)

lemma col_zero : R.col 0 = 1 := by simp [col]

lemma mem_T_zero {b : R.Pt} (hb : b ∈ Finset.Nat.antidiagonalTuple R.K 0) : b = 0 := by
  rw [Finset.Nat.antidiagonalTuple_zero_right, Finset.mem_singleton] at hb; exact hb

lemma m_kmin_pow_G_le {n : ℕ} (hn : R.m ≤ n) : R.m * R.kmin ^ R.G n ≤ n :=
  Nat.findGreatest_spec (P := fun g => R.m * R.kmin ^ g ≤ n) (Nat.zero_le n) (by simpa using hn)

lemma lt_m_kmin_pow_G_succ (n : ℕ) : n < R.m * R.kmin ^ (R.G n + 1) := by
  by_cases hle : R.G n + 1 ≤ n
  · have := Nat.findGreatest_is_greatest (P := fun g => R.m * R.kmin ^ g ≤ n) (Nat.lt_succ_self _) hle
    exact Nat.lt_of_not_le this
  · have h1 : n < 2 ^ (R.G n + 1) := lt_of_lt_of_le (by omega : n < R.G n + 1) (Nat.lt_two_pow_self).le
    have h2 : 2 ^ (R.G n + 1) ≤ R.kmin ^ (R.G n + 1) := Nat.pow_le_pow_left R.two_le_kmin _
    have h3 : R.kmin ^ (R.G n + 1) ≤ R.m * R.kmin ^ (R.G n + 1) :=
      Nat.le_mul_of_pos_left _ (by have := R.two_le_m; omega)
    omega


theorem balance (n h ρp : ℕ) (j : Fin R.P) :
    R.inMS n h (ρp * R.rk j) = R.outMS n (h + 1) ρp j + R.srcMS n h (ρp * R.rk j) ρp := by
  set ρ := ρp * R.rk j with hρ
  -- split every input by whether its producer lies in the parent's region
  have hsplit : R.inMS n h ρ =
      (∑ b ∈ R.pts n h ρ, ∑ k, if n < R.m * ρp * R.col (b + R.e k) then 0
          else (R.uh h b * R.Wk k) • ({ρ * R.kr k * R.col b} : Multiset ℕ)) + R.srcMS n h ρ ρp := by
    unfold inMS srcMS
    rw [← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl (fun b _ => ?_)
    rw [← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl (fun k _ => ?_)
    split_ifs <;> simp
  rw [hsplit, add_left_inj]
  -- move to sums over the whole antidiagonal and shift
  unfold outMS pts
  rw [Finset.sum_filter, Finset.sum_filter]
  have hL : (∑ b ∈ Finset.Nat.antidiagonalTuple R.K h, if R.m * ρ * R.col b ≤ n then
        ∑ k, (if n < R.m * ρp * R.col (b + R.e k) then 0
          else (R.uh h b * R.Wk k) • ({ρ * R.kr k * R.col b} : Multiset ℕ)) else 0) =
      ∑ b ∈ Finset.Nat.antidiagonalTuple R.K h, ∑ k,
        (if R.m * ρ * R.col b ≤ n ∧ ¬ n < R.m * ρp * R.col (b + R.e k) then
          (R.uh h b * R.Wk k) • ({ρ * R.kr k * R.col b} : Multiset ℕ) else 0) := by
    refine Finset.sum_congr rfl (fun b _ => ?_)
    split_ifs with h1
    · refine Finset.sum_congr rfl (fun k _ => ?_)
      split_ifs <;> simp_all
    · symm; refine Finset.sum_eq_zero (fun k _ => ?_)
      rw [if_neg]; tauto
  rw [hL, R.sum_shift h]
  refine Finset.sum_congr rfl (fun a ha => ?_)
  -- the parent side: expand `uh (h+1) a` by Pascal's rule
  have hR : (if R.m * ρp * R.col a ≤ n then R.uh (h + 1) a • ({ρp * R.rk j * R.col a} : Multiset ℕ) else 0) =
      ∑ k, if 1 ≤ a k then (if R.m * ρp * R.col a ≤ n then
        (R.Wk k * R.uh h (a - R.e k)) • ({ρp * R.rk j * R.col a} : Multiset ℕ) else 0) else 0 := by
    split_ifs with h1
    · simp only [uh]
      rw [← Finset.sum_nsmul_assoc]
      refine Finset.sum_congr rfl (fun k _ => ?_)
      split_ifs <;> simp
    · simp
  rw [hR]
  refine Finset.sum_congr rfl (fun k _ => ?_)
  by_cases hak : 1 ≤ a k
  · rw [if_pos hak, if_pos hak]
    have hcol : R.col a = R.kr k * R.col (a - R.e k) := by
      conv_lhs => rw [← R.sub_e_add_e a k hak]
      exact R.col_add_e _ _
    rw [R.sub_e_add_e a k hak]
    have hiff : (R.m * ρ * R.col (a - R.e k) ≤ n ∧ ¬ n < R.m * ρp * R.col a) ↔ R.m * ρp * R.col a ≤ n := by
      constructor
      · rintro ⟨_, h2⟩; omega
      · intro h2
        refine ⟨?_, by omega⟩
        rw [hρ]
        have := R.rk_lt_kr j k
        calc R.m * (ρp * R.rk j) * R.col (a - R.e k) = R.m * ρp * (R.rk j * R.col (a - R.e k)) := by ring
          _ ≤ R.m * ρp * (R.kr k * R.col (a - R.e k)) :=
              Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ this.le)
          _ = R.m * ρp * R.col a := by rw [hcol]
          _ ≤ n := h2
    by_cases hc : R.m * ρp * R.col a ≤ n
    · rw [if_pos (hiff.2 hc), if_pos hc, mul_comm (R.uh h _), hcol, hρ,
        show ρp * R.rk j * R.kr k * R.col (a - R.e k) = ρp * R.rk j * (R.kr k * R.col (a - R.e k)) by ring]
    · rw [if_neg (fun h' => hc (hiff.1 h')), if_neg hc]
  · rw [if_neg hak, if_neg hak]

lemma mem_srcMS {n h ρp : ℕ} {j : Fin R.P} {x : ℕ} (hx : x ∈ R.srcMS n h (ρp * R.rk j) ρp) :
    n < R.m * x ∧ x ≤ n := by
  unfold srcMS at hx
  obtain ⟨b, hb, hx⟩ := Multiset.mem_sum.1 hx
  obtain ⟨k, -, hx⟩ := Multiset.mem_sum.1 hx
  simp only [pts, Finset.mem_filter] at hb
  split_ifs at hx with hc
  · have hx := mem_nsmul_single hx
    subst hx
    rw [R.col_add_e] at hc
    have h1 := R.rk_pos j
    have h2 := R.kr_le k
    constructor
    · calc n < R.m * ρp * (R.kr k * R.col b) := hc
        _ = 1 * (R.m * (ρp * R.kr k * R.col b)) := by ring
        _ ≤ R.rk j * (R.m * (ρp * R.kr k * R.col b)) := Nat.mul_le_mul_right _ h1
        _ = R.m * (ρp * R.rk j * R.kr k * R.col b) := by ring
    · calc ρp * R.rk j * R.kr k * R.col b ≤ ρp * R.rk j * R.m * R.col b :=
            Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ h2)
        _ = R.m * (ρp * R.rk j) * R.col b := by ring
        _ ≤ n := hb.2
  · simp at hx

lemma mem_srcBelow {n h ρ x : ℕ} (hx : x ∈ R.srcBelow n h ρ) : n < R.m * x ∧ x ≤ n := by
  induction h generalizing ρ with
  | zero => simp [srcBelow] at hx
  | succ h ih =>
    simp only [srcBelow] at hx
    obtain ⟨j, -, hx⟩ := Multiset.mem_sum.1 hx
    rcases Multiset.mem_add.1 hx with hx | hx
    · exact R.mem_srcMS hx
    · exact ih hx

lemma mem_inMS_root {n x : ℕ} (hx : x ∈ R.inMS n (R.G n) 1) : n < R.m * x ∧ x ≤ n := by
  unfold inMS at hx
  obtain ⟨b, hb, hx⟩ := Multiset.mem_sum.1 hx
  obtain ⟨k, -, hx⟩ := Multiset.mem_sum.1 hx
  have hx := mem_nsmul_single hx
  subst hx
  simp only [pts, Finset.mem_filter, Finset.Nat.mem_antidiagonalTuple] at hb
  constructor
  · have h1 := R.lt_m_kmin_pow_G_succ n
    have h2 := R.pow_le_col (b + R.e k)
    rw [R.sum_add_e, hb.1, R.col_add_e] at h2
    calc n < R.m * R.kmin ^ (R.G n + 1) := h1
      _ ≤ R.m * (R.kr k * R.col b) := Nat.mul_le_mul_left _ h2
      _ = R.m * (1 * R.kr k * R.col b) := by ring
  · have h2 := R.kr_le k
    calc 1 * R.kr k * R.col b ≤ R.m * R.col b := by rw [one_mul]; exact Nat.mul_le_mul_right _ h2
      _ = R.m * 1 * R.col b := by ring
      _ ≤ n := hb.2

theorem src_size {n x : ℕ} (hx : x ∈ R.srcT n) : n < R.m * x ∧ x ≤ n := by
  rcases Multiset.mem_add.1 hx with hx | hx
  · exact R.mem_inMS_root hx
  · exact R.mem_srcBelow hx

lemma src_pos {n x : ℕ} (hx : x ∈ R.srcT n) : 1 ≤ x := by
  have := (R.src_size hx).1
  rcases Nat.eq_zero_or_pos x with h | h
  · subst h; simp at this
  · exact h

lemma mem_exitsSub {n h ρ x : ℕ} (hx : x ∈ R.exitsSub n h ρ) :
    ∃ ρ' : ℕ, ∃ j : Fin R.P, x = ρ' * R.rk j ∧ R.m * ρ' ≤ n ∧ ρ ≤ ρ' ∧ ρ' ≤ ρ * R.rmax ^ h := by
  induction h generalizing ρ with
  | zero =>
    simp only [exitsSub] at hx
    obtain ⟨j, -, hx⟩ := Multiset.mem_sum.1 hx
    unfold outMS at hx
    obtain ⟨b, hb, hx⟩ := Multiset.mem_sum.1 hx
    have hx := mem_nsmul_single hx
    simp only [pts, Finset.mem_filter] at hb
    have hb0 := R.mem_T_zero hb.1
    subst hb0
    rw [R.col_zero] at hx hb
    exact ⟨ρ, j, by rw [hx]; ring, by simpa using hb.2, le_rfl, by simp⟩
  | succ h ih =>
    simp only [exitsSub] at hx
    obtain ⟨j, -, hx⟩ := Multiset.mem_sum.1 hx
    obtain ⟨ρ', j', h1, h2, h3, h4⟩ := ih hx
    refine ⟨ρ', j', h1, h2, ?_, ?_⟩
    · exact le_trans (Nat.le_mul_of_pos_right _ (R.rk_pos j)) h3
    · calc ρ' ≤ ρ * R.rk j * R.rmax ^ h := h4
        _ ≤ ρ * R.rmax * R.rmax ^ h := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ (R.rk_le j))
        _ = ρ * R.rmax ^ (h + 1) := by ring

theorem exit_size {n x : ℕ} (hx : x ∈ R.exT n) : 1 ≤ x ∧ x ≤ R.rmax ^ (R.G n + 1) ∧ x < n := by
  obtain ⟨ρ', j, rfl, h2, h3, h4⟩ := R.mem_exitsSub hx
  have hr := R.rk_pos j
  refine ⟨Nat.one_le_iff_ne_zero.2 (Nat.mul_ne_zero (by omega) (by omega)), ?_, ?_⟩
  · calc ρ' * R.rk j ≤ (1 * R.rmax ^ R.G n) * R.rmax := Nat.mul_le_mul h4 (R.rk_le j)
      _ = R.rmax ^ (R.G n + 1) := by ring
  · have h5 : R.rk j < R.m := lt_of_lt_of_le (R.rk_lt_kr j (R.kmin_att.choose)) (R.kr_le _)
    calc ρ' * R.rk j < ρ' * R.m := Nat.mul_lt_mul_of_pos_left h5 (by omega)
      _ = R.m * ρ' := by ring
      _ ≤ n := h2

lemma uh_single (k : Fin R.K) (h : ℕ) (hW : 1 ≤ R.Wk k) : 1 ≤ R.uh h (Pi.single k h) := by
  induction h with
  | zero => simp [uh]
  | succ h ih =>
    simp only [uh]
    have hk : 1 ≤ (Pi.single k (h + 1) : R.Pt) k := by simp
    have hsub : (Pi.single k (h + 1) : R.Pt) - R.e k = Pi.single k h := by
      funext i; simp only [Pi.sub_apply, e_apply, Pi.single_apply]; split_ifs <;> omega
    calc 1 ≤ R.Wk k * R.uh h (Pi.single k h) := Nat.one_le_iff_ne_zero.2 (Nat.mul_ne_zero (by omega) (by omega))
      _ = (fun k' => if 1 ≤ (Pi.single k (h + 1) : R.Pt) k' then
            R.Wk k' * R.uh h ((Pi.single k (h + 1) : R.Pt) - R.e k') else 0) k := by
          simp only [if_pos hk, hsub]
      _ ≤ ∑ k', (if 1 ≤ (Pi.single k (h + 1) : R.Pt) k' then
            R.Wk k' * R.uh h ((Pi.single k (h + 1) : R.Pt) - R.e k') else 0) :=
          Finset.single_le_sum (f := fun k' => if 1 ≤ (Pi.single k (h + 1) : R.Pt) k' then
            R.Wk k' * R.uh h ((Pi.single k (h + 1) : R.Pt) - R.e k') else 0)
            (fun _ _ => Nat.zero_le _) (Finset.mem_univ k)

lemma card_inMS (n h ρ : ℕ) :
    Multiset.card (R.inMS n h ρ) = ∑ b ∈ R.pts n h ρ, ∑ k, R.uh h b * R.Wk k := by
  simp [inMS, Multiset.card_sum, Multiset.card_nsmul]

theorem Nsrc_pos {n : ℕ} (hn : R.m ≤ n) : 1 ≤ R.Nsrc n := by
  obtain ⟨k, hk, hW⟩ := R.kmin_att
  obtain ⟨b, hbdef⟩ : ∃ b : R.Pt, b = Pi.single k (R.G n) := ⟨_, rfl⟩
  have hub : 1 ≤ R.uh (R.G n) b := by rw [hbdef]; exact R.uh_single k (R.G n) hW
  have hbT : b ∈ R.pts n (R.G n) 1 := by
    simp only [pts, Finset.mem_filter, Finset.Nat.mem_antidiagonalTuple]
    refine ⟨by simp [hbdef], ?_⟩
    have : R.col b = R.kmin ^ R.G n := by
      simp only [col, hbdef, Pi.single_apply]
      rw [Finset.prod_eq_single k]
      · simp [hk]
      · intro i _ hi; simp [hi]
      · simp
    rw [this, mul_one]; exact R.m_kmin_pow_G_le hn
  have h1 : 1 ≤ R.uh (R.G n) b * R.Wk k := Nat.one_le_iff_ne_zero.2
    (Nat.mul_ne_zero (by omega) (by omega))
  have h2 : R.uh (R.G n) b * R.Wk k ≤ ∑ k', R.uh (R.G n) b * R.Wk k' :=
    Finset.single_le_sum (f := fun k' => R.uh (R.G n) b * R.Wk k') (fun _ _ => Nat.zero_le _) (Finset.mem_univ k)
  have h3 : ∑ k', R.uh (R.G n) b * R.Wk k' ≤ ∑ b' ∈ R.pts n (R.G n) 1, ∑ k', R.uh (R.G n) b' * R.Wk k' :=
    Finset.single_le_sum (f := fun b' => ∑ k', R.uh (R.G n) b' * R.Wk k') (fun _ _ => Nat.zero_le _) hbT
  unfold Nsrc srcT
  rw [Multiset.card_add, card_inMS]
  omega

theorem sum_uh (h : ℕ) : ∑ b ∈ Finset.Nat.antidiagonalTuple R.K h, R.uh h b = R.W ^ h := by
  induction h with
  | zero =>
    rw [Finset.Nat.antidiagonalTuple_zero_right]; simp [uh]
  | succ h ih =>
    have := R.sum_shift h (fun b k => R.Wk k * R.uh h b)
    simp only [uh]
    rw [← this]
    simp_rw [← Finset.sum_mul]
    rw [← Finset.mul_sum, ih]; unfold W; ring

lemma card_inMS_le (n h ρ : ℕ) : Multiset.card (R.inMS n h ρ) ≤ R.W ^ (h + 1) := by
  rw [card_inMS]
  calc ∑ b ∈ R.pts n h ρ, ∑ k, R.uh h b * R.Wk k
      = ∑ b ∈ R.pts n h ρ, R.uh h b * R.W := by simp_rw [← Finset.mul_sum]; rfl
    _ ≤ ∑ b ∈ Finset.Nat.antidiagonalTuple R.K h, R.uh h b * R.W :=
        Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) (fun _ _ _ => Nat.zero_le _)
    _ = R.W ^ (h + 1) := by rw [← Finset.sum_mul, sum_uh, pow_succ]

lemma card_srcMS_le (n h ρ ρp : ℕ) : Multiset.card (R.srcMS n h ρ ρp) ≤ Multiset.card (R.inMS n h ρ) := by
  unfold srcMS inMS
  simp only [Multiset.card_sum]
  refine Finset.sum_le_sum (fun b _ => Finset.sum_le_sum (fun k _ => ?_))
  split_ifs <;> simp

lemma card_sub_le (n h ρ : ℕ) :
    Multiset.card (R.inMS n h ρ) + Multiset.card (R.srcBelow n h ρ) ≤ (R.P + R.W + 1) ^ (h + 1) := by
  induction h generalizing ρ with
  | zero =>
    simp only [srcBelow, Multiset.card_zero, add_zero, zero_add, pow_one]
    have := R.card_inMS_le n 0 ρ
    simp at this; omega
  | succ h ih =>
    have h1 := R.card_inMS_le n (h + 1) ρ
    have h2 : Multiset.card (R.srcBelow n (h + 1) ρ) ≤ R.P * (R.P + R.W + 1) ^ (h + 1) := by
      simp only [srcBelow, Multiset.card_sum, Multiset.card_add]
      calc ∑ j, (Multiset.card (R.srcMS n h (ρ * R.rk j) ρ) + Multiset.card (R.srcBelow n h (ρ * R.rk j)))
          ≤ ∑ _j : Fin R.P, (R.P + R.W + 1) ^ (h + 1) := Finset.sum_le_sum (fun j _ =>
            le_trans (Nat.add_le_add_right (R.card_srcMS_le n h _ ρ) _) (ih _))
        _ = R.P * (R.P + R.W + 1) ^ (h + 1) := by simp
    have h3 : R.W ^ (h + 1 + 1) ≤ R.W * (R.P + R.W + 1) ^ (h + 1) := by
      rw [pow_succ', ]
      exact Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (by omega) _)
    calc Multiset.card (R.inMS n (h + 1) ρ) + Multiset.card (R.srcBelow n (h + 1) ρ)
        ≤ R.W * (R.P + R.W + 1) ^ (h + 1) + R.P * (R.P + R.W + 1) ^ (h + 1) := by omega
      _ ≤ (R.P + R.W + 1) * (R.P + R.W + 1) ^ (h + 1) := by
          rw [← add_mul]; exact Nat.mul_le_mul_right _ (by omega)
      _ = (R.P + R.W + 1) ^ (h + 1 + 1) := by ring

theorem Nsrc_le (n : ℕ) : R.Nsrc n ≤ (R.P + R.W + 1) ^ (R.G n + 1) := by
  unfold Nsrc srcT; rw [Multiset.card_add]; exact R.card_sub_le n (R.G n) 1

end Rule

end OAI.PowerSaving.MX


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable (E : Eng α ρ σ)

lemma slotR_ppR (n h μ r t : ℕ) (hf : E.fedP n h μ r t) : E.slotR n h μ r (E.ppR n h μ r t) = t := by
  obtain ⟨ht, hin⟩ := hf
  have hW := E.W_pos
  have hU : E.Uc n (h+1) μ (E.ppR n h μ r t) = E.parCode n h μ r t := U_PC hin
  have hq : t / E.W < E.NUc n h (μ * r) := (Nat.div_lt_iff_lt_mul hW).2 ht
  have e1 : E.parCode n h μ r t % E.W = t % E.W := by
    unfold parCode; rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt (Nat.mod_lt _ hW)]
  have e2 : E.parCode n h μ r t / E.W = E.Uc n h (μ * r) (t / E.W) := by
    unfold parCode; rw [Nat.add_mul_div_left _ _ hW, Nat.div_eq_of_lt (Nat.mod_lt _ hW), zero_add]
  unfold slotR
  rw [hU, e1, e2]
  have : E.PCc n h (μ * r) (E.Uc n h (μ * r) (t / E.W)) = t / E.W := PC_U hq
  rw [this, Nat.mul_comm]
  exact Nat.div_add_mod t E.W

lemma slots_le (n h μ r : ℕ) :
    E.NUc n h (μ * r) * E.W ≤ E.NUc n (h+1) μ + Nat.count (E.srcP n h μ r) (E.NUc n h (μ * r) * E.W) := by
  set NJ := E.NUc n h (μ * r) * E.W
  have hsplit : Nat.count (E.fedP n h μ r) NJ + Nat.count (E.srcP n h μ r) NJ = NJ := by
    rw [Nat.count_eq_card_filter_range, Nat.count_eq_card_filter_range]
    have e1 : (range NJ).filter (E.fedP n h μ r) =
        (range NJ).filter (fun t => inRS E.W E.tq E.mx n (h+1) μ (E.parCode n h μ r t)) := by
      ext t; simp only [mem_filter, mem_range, fedP]; constructor
      · rintro ⟨h1, _, h2⟩; exact ⟨h1, h2⟩
      · rintro ⟨h1, h2⟩; exact ⟨h1, h1, h2⟩
    have e2 : (range NJ).filter (E.srcP n h μ r) =
        (range NJ).filter (fun t => ¬ inRS E.W E.tq E.mx n (h+1) μ (E.parCode n h μ r t)) := by
      ext t; simp only [mem_filter, mem_range, srcP]; constructor
      · rintro ⟨h1, _, h2⟩; exact ⟨h1, h2⟩
      · rintro ⟨h1, h2⟩; exact ⟨h1, h1, h2⟩
    rw [e1, e2, Finset.card_filter_add_card_filter_not, card_range]
  have hfed : Nat.count (E.fedP n h μ r) NJ ≤ E.NUc n (h+1) μ := by
    rw [Nat.count_eq_card_filter_range]
    have : ((range NJ).filter (E.fedP n h μ r)).card ≤ (range (E.NUc n (h+1) μ)).card := by
      apply Finset.card_le_card_of_injOn (E.ppR n h μ r)
      · intro t ht
        simp only [coe_filter, Set.mem_setOf_eq, mem_coe, mem_range] at ht ⊢
        exact PC_lt ht.2.2
      · intro t1 ht1 t2 ht2 heq
        simp only [coe_filter, Set.mem_setOf_eq] at ht1 ht2
        rw [← E.slotR_ppR n h μ r t1 ht1.2, ← E.slotR_ppR n h μ r t2 ht2.2, heq]
    simpa using this
  omega

lemma ownSrc_le_accR (n h μ r : ℕ) : (E.ownSrc n h μ r).length ≤ (E.accR n h μ r).length := by
  simp [accR]

def rtB (n h : ℕ) : ℕ := 9 * (E.W^(h+1) + 1) * (E.W^(h+1) + 1) * (h + 3) + 8

lemma rtCost_le (n h μ r : ℕ) : E.rtCost n h μ r ≤ E.rtB n h := by
  unfold rtCost rtB idxCost
  have h1 : E.W^h ≤ E.W^(h+1) := Nat.pow_le_pow_right E.W_pos (by omega)
  have h2 : (E.W^h + 1) * (E.W^h + 1) * (h + 2) ≤ (E.W^(h+1) + 1) * (E.W^(h+1) + 1) * (h + 3) := by
    gcongr <;> omega
  nlinarith

def letB (n h μ C : ℕ) : ℕ := E.rtB n h + (2 * E.NUc n (h+1) μ + C) * 2^n + 2 * C + 20

lemma swCost_le (n h μ C : ℕ) :
    ∀ (ws : GWord α ρ) (L : ℕ), L + (E.accW n h μ ws).length ≤ C →
      E.swCost n h μ L ws ≤ ws.length * E.letB n h μ C := by
  intro ws
  induction ws with
  | nil => intro L _; simp [swCost]
  | cons mv ws ih =>
    intro L hL
    rw [accW_cons] at hL
    simp only [swCost, List.length_cons]
    rcases hmv : mv.rk? with _ | r
    · simp only [hmv, List.nil_append, Nat.add_zero] at hL ⊢
      have := ih L hL
      have h1 : E.NUc n (h+1) μ * 2^n ≤ E.letB n h μ C := by
        unfold letB; nlinarith [Nat.two_pow_pos n]
      nlinarith
    · simp only [hmv, List.length_append] at hL ⊢
      have := ih (L + (E.accR n h μ r).length) (by omega)
      have h1 : E.blkCost n h μ r L ≤ E.letB n h μ C := by
        unfold blkCost letB
        have e1 := E.rtCost_le n h μ r
        have e2 := E.slots_le n h μ r
        have e3 := E.ownSrc_len n h μ r
        have e4 := E.ownSrc_le_accR n h μ r
        have e5 : (E.NUc n h (μ * r) * E.W + E.NUc n (h+1) μ) * 2^n ≤ (2 * E.NUc n (h+1) μ + C) * 2^n := by
          apply Nat.mul_le_mul_right; omega
        omega
      nlinarith

lemma lfCost_le (n μ : ℕ) : ∀ ws : GWord α ρ, E.lfCost n μ ws ≤ ws.length * (E.NUc n 0 μ * 2^n + 2 * n + 2) := by
  intro ws
  induction ws with
  | nil => simp [lfCost]
  | cons mv ws ih =>
    simp only [lfCost, List.length_cons]
    rcases hmv : mv.rk? with _ | r
    · simp only [hmv]; nlinarith
    · simp only [hmv]; nlinarith

lemma arith_leaf (a P W n Q T Cn lf : ℕ) (hT1 : n + 1 ≤ T) (hQ : 8 ≤ Q) (hlf : lf ≤ P * (a * T + 2 * n + 2)) :
    n + 1 + 8 + a * (4 * n + 4 * 0 + 8) + a * (2 * T + 2) + a * T + lf + a * W * T ≤
      100 * (P + 1) * (W + 1) * (T * (a + Cn) + Q + n + 1) := by
  set K := (P + 1) * (W + 1) with hK
  have hP : P ≤ K := by rw [hK]; nlinarith
  have hW : W ≤ K := by rw [hK]; nlinarith
  have hK1 : 1 ≤ K := by rw [hK]; nlinarith
  have f1 : a * (4 * n + 4 * 0 + 8) ≤ 8 * (a * T) := by
    have : 4 * n + 4 * 0 + 8 ≤ 8 * T := by omega
    calc a * (4 * n + 4 * 0 + 8) ≤ a * (8 * T) := Nat.mul_le_mul_left _ this
      _ = 8 * (a * T) := by ring
  have f2 : a * (2 * T + 2) ≤ 4 * (a * T) := by
    have : 2 * T + 2 ≤ 4 * T := by omega
    calc a * (2 * T + 2) ≤ a * (4 * T) := Nat.mul_le_mul_left _ this
      _ = 4 * (a * T) := by ring
  have f3 : P * (a * T + 2 * n + 2) ≤ K * (a * T) + K * (2 * n + 2) := by
    calc P * (a * T + 2 * n + 2) ≤ K * (a * T + 2 * n + 2) := Nat.mul_le_mul_right _ hP
      _ = K * (a * T) + K * (2 * n + 2) := by ring
  have f4 : a * W * T ≤ K * (a * T) := by
    calc a * W * T = W * (a * T) := by ring
      _ ≤ K * (a * T) := Nat.mul_le_mul_right _ hW
  have f5 : 100 * (P + 1) * (W + 1) * (T * (a + Cn) + Q + n + 1) ≥ 100 * K * (a * T + Q + n + 1) := by
    have : a * T + Q + n + 1 ≤ T * (a + Cn) + Q + n + 1 := by nlinarith
    calc 100 * K * (a * T + Q + n + 1) ≤ 100 * K * (T * (a + Cn) + Q + n + 1) := Nat.mul_le_mul_left _ this
      _ = _ := by rw [hK]; ring
  have f6 : 100 * K * (a * T + Q + n + 1) = 100 * (K * (a * T)) + 100 * (K * Q) + 100 * (K * (n + 1)) := by ring
  have f7 : K * (2 * n + 2) = 2 * (K * (n + 1)) := by ring
  have g1 : a * T ≤ K * (a * T) := Nat.le_mul_of_pos_left _ hK1
  have g2 : Q ≤ K * Q := Nat.le_mul_of_pos_left _ hK1
  have g3 : n + 1 ≤ K * (n + 1) := Nat.le_mul_of_pos_left _ hK1
  omega

lemma arith_up (h' a P W n Q T Cn sw idx : ℕ) (hT1 : n + 1 ≤ T) (hh : h' + 1 ≤ n) (hidx : idx ≤ Q)
    (hsw : sw ≤ P * (9 * Q + 8 + (2 * (a * T) + Cn * T) + 2 * Cn + 20)) :
    n + 1 + idx + a * (4 * n + 4 * (h' + 1) + 8) + a * (2 * T + 2) + a * T + sw + a * W * T ≤
      100 * (P + 1) * (W + 1) * (T * (a + Cn) + Q + n + 1) := by
  set K := (P + 1) * (W + 1) with hK
  have hP : P ≤ K := by rw [hK]; nlinarith
  have hW : W ≤ K := by rw [hK]; nlinarith
  have hK1 : 1 ≤ K := by rw [hK]; nlinarith
  have f1 : a * (4 * n + 4 * (h' + 1) + 8) ≤ 16 * (a * T) := by
    have : 4 * n + 4 * (h' + 1) + 8 ≤ 16 * T := by omega
    calc a * (4 * n + 4 * (h' + 1) + 8) ≤ a * (16 * T) := Nat.mul_le_mul_left _ this
      _ = 16 * (a * T) := by ring
  have f2 : a * (2 * T + 2) ≤ 4 * (a * T) := by
    have : 2 * T + 2 ≤ 4 * T := by omega
    calc a * (2 * T + 2) ≤ a * (4 * T) := Nat.mul_le_mul_left _ this
      _ = 4 * (a * T) := by ring
  have hCn : Cn ≤ Cn * T := Nat.le_mul_of_pos_right _ (by omega)
  have f3 : P * (9 * Q + 8 + (2 * (a * T) + Cn * T) + 2 * Cn + 20) ≤
      9 * (K * Q) + 28 * K + 2 * (K * (a * T)) + 3 * (K * (Cn * T)) := by
    have h1 : 9 * Q + 8 + (2 * (a * T) + Cn * T) + 2 * Cn + 20 ≤ 9 * Q + 28 + 2 * (a * T) + 3 * (Cn * T) := by
      omega
    calc P * (9 * Q + 8 + (2 * (a * T) + Cn * T) + 2 * Cn + 20) ≤ K * (9 * Q + 28 + 2 * (a * T) + 3 * (Cn * T)) :=
          Nat.mul_le_mul hP h1
      _ = _ := by ring
  have f4 : a * W * T ≤ K * (a * T) := by
    calc a * W * T = W * (a * T) := by ring
      _ ≤ K * (a * T) := Nat.mul_le_mul_right _ hW
  have f5 : 100 * (P + 1) * (W + 1) * (T * (a + Cn) + Q + n + 1) =
      100 * (K * (a * T)) + 100 * (K * (Cn * T)) + 100 * (K * Q) + 100 * (K * (n + 1)) := by rw [hK]; ring
  have g1 : a * T ≤ K * (a * T) := Nat.le_mul_of_pos_left _ hK1
  have g2 : Q ≤ K * Q := Nat.le_mul_of_pos_left _ hK1
  have g3 : n + 1 ≤ K * (n + 1) := Nat.le_mul_of_pos_left _ hK1
  have g4 : K ≤ K * (n + 1) := Nat.le_mul_of_pos_right _ (by omega)
  omega

theorem clsLoc_le {kmin : ℕ} (hk : E.KMin kmin) : ∃ C : ℕ, ∀ (n h μ o BS : ℕ) (J sup : ℕ → Bits n → ℂ),
    E.Valid kmin (MDesc.cls n h μ o BS J sup) →
    E.clsLoc n h μ ≤ C * (2^n * (E.NUc n h μ + E.cons n h μ) + (E.W^(h+1) + 1) * (E.W^(h+1) + 1) * (h + 3) + n + 1) := by
  refine ⟨100 * (E.wd.length + 1) * (E.W + 1), fun n h μ o BS J sup hd => ?_⟩
  obtain ⟨_, hhn, _, _⟩ := E.valid_facts hk hd
  have hn1 : n + 1 ≤ 2^n := Nat.lt_two_pow_self
  have hW := E.W_pos
  unfold clsLoc
  split_ifs with h0
  · subst h0
    unfold locLeaf
    have e2 : E.idxCost n 0 μ = 8 := by simp [idxCost]
    rw [e2]
    have hQ8 : 8 ≤ (E.W^(0+1) + 1) * (E.W^(0+1) + 1) * (0 + 3) := by
      simp only [zero_add, pow_one]; nlinarith
    exact arith_leaf _ _ _ _ _ _ _ _ hn1 hQ8 (E.lfCost_le n μ E.wd)
  · obtain ⟨h', rfl⟩ : ∃ h', h = h' + 1 := ⟨h - 1, by omega⟩
    simp only [Nat.add_sub_cancel]
    unfold locUp
    have hcons : (E.accW n h' μ E.wd).length = E.cons n (h'+1) μ := rfl
    have e1 := E.swCost_le n h' μ (E.cons n (h'+1) μ) E.wd 0 (by omega)
    unfold letB at e1
    have e2 : E.idxCost n (h'+1) μ ≤ (E.W^(h'+1+1) + 1) * (E.W^(h'+1+1) + 1) * (h' + 1 + 3) := by
      unfold idxCost
      have : E.W^(h'+1) ≤ E.W^(h'+1+1) := Nat.pow_le_pow_right hW (by omega)
      gcongr <;> omega
    have e3 : E.rtB n h' ≤ 9 * ((E.W^(h'+1+1) + 1) * (E.W^(h'+1+1) + 1) * (h' + 1 + 3)) + 8 := by
      unfold rtB
      have : E.W^(h'+1) ≤ E.W^(h'+1+1) := Nat.pow_le_pow_right hW (by omega)
      have h4 : (E.W^(h'+1) + 1) * (E.W^(h'+1) + 1) * (h' + 3) ≤
          (E.W^(h'+1+1) + 1) * (E.W^(h'+1+1) + 1) * (h' + 1 + 3) := by gcongr <;> omega
      nlinarith
    refine arith_up h' _ _ _ _ _ _ _ _ _ hn1 hhn e2 ?_
    refine le_trans e1 (Nat.mul_le_mul_left _ ?_)
    have : (2 * E.NUc n (h' + 1) μ + E.cons n (h' + 1) μ) * 2^n =
        2 * (E.NUc n (h' + 1) μ * 2^n) + E.cons n (h' + 1) μ * 2^n := by ring
    omega

end Eng

end
end PowerSaving.RAM
end OAI

namespace OAI.PowerSaving.MX

theorem poly_le_two_pow (D d : ℕ) : ∃ T, ∀ t, T ≤ t → D * (t + 1) ^ d ≤ 2 ^ t := by
  obtain ⟨c, hc⟩ : ∃ c, c = 2 * d + 2 := ⟨_, rfl⟩
  obtain ⟨X, hX⟩ : ∃ X, X = D * c ^ d := ⟨_, rfl⟩
  refine ⟨2 * X + 2, fun t ht => ?_⟩
  have hc0 : 0 < c := by omega
  obtain ⟨u, hu⟩ : ∃ u, u = t / c := ⟨_, rfl⟩
  have h1 : t + 1 ≤ c * (u + 1) := by rw [hu]; exact Nat.lt_mul_div_succ t hc0
  have h2 : u * c ≤ t := by rw [hu]; exact Nat.div_mul_le_self t c
  have h3 : (u + 1) ^ d ≤ 2 ^ (u * d) := by
    rw [pow_mul]
    exact Nat.pow_le_pow_left Nat.lt_two_pow_self d
  have h4 : u * c = 2 * (u * d) + 2 * u := by rw [hc]; ring
  have h5 : (t + 1) ^ d ≤ c ^ d * 2 ^ (t / 2) := by
    calc (t + 1) ^ d ≤ (c * (u + 1)) ^ d := Nat.pow_le_pow_left h1 d
      _ = c ^ d * (u + 1) ^ d := by rw [mul_pow]
      _ ≤ c ^ d * 2 ^ (u * d) := Nat.mul_le_mul_left _ h3
      _ ≤ c ^ d * 2 ^ (t / 2) := Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by norm_num) (by omega))
  have h6 : X ≤ 2 ^ (t / 2) := by
    have h7 : X < 2 ^ X := Nat.lt_two_pow_self
    have h8 : 2 ^ X ≤ 2 ^ (t / 2) := Nat.pow_le_pow_right (by norm_num) (by omega)
    omega
  calc D * (t + 1) ^ d ≤ D * (c ^ d * 2 ^ (t / 2)) := Nat.mul_le_mul_left _ h5
    _ = X * 2 ^ (t / 2) := by rw [hX]; ring
    _ ≤ 2 ^ (t / 2) * 2 ^ (t / 2) := Nat.mul_le_mul_right _ h6
    _ = 2 ^ (t / 2 + t / 2) := by rw [pow_add]
    _ ≤ 2 ^ t := Nat.pow_le_pow_right (by norm_num) (by omega)

theorem succ_pow_le_two_pow (c : ℕ) : ∃ D : ℕ, ∀ n : ℕ, (n + 1) ^ c ≤ D * 2 ^ n := by
  obtain ⟨T, hT⟩ := poly_le_two_pow 1 c
  refine ⟨(T + 1) ^ c, fun n => ?_⟩
  have hD : 0 < (T + 1) ^ c := pow_pos (Nat.succ_pos T) c
  have h2 : 0 < 2 ^ n := Nat.two_pow_pos n
  by_cases hn : T ≤ n
  · have h := hT n hn
    rw [one_mul] at h
    exact h.trans (Nat.le_mul_of_pos_left _ hD)
  · exact (Nat.pow_le_pow_left (by omega) c).trans (Nat.le_mul_of_pos_right _ h2)

namespace Rule

variable (R : Rule)

lemma kmin_pow_G_le_succ (n : ℕ) : R.kmin ^ R.G n ≤ n + 1 := by
  by_cases h0 : R.G n = 0
  · rw [h0]; simp
  · have hP : R.m * R.kmin ^ R.G n ≤ n := Nat.findGreatest_of_ne_zero (P := fun g => R.m * R.kmin ^ g ≤ n) (n := n) (m := R.G n) rfl h0
    have hm := R.two_le_m
    have : R.kmin ^ R.G n ≤ R.m * R.kmin ^ R.G n := Nat.le_mul_of_pos_left _ (by omega)
    omega

def Q : ℕ := R.P + R.W + 1

lemma Q_pow_G_le (x : ℕ) : R.Q ^ R.G x ≤ (x + 1) ^ R.Q := by
  have h1 : R.Q ≤ R.kmin ^ R.Q :=
    le_trans Nat.lt_two_pow_self.le (Nat.pow_le_pow_left R.two_le_kmin _)
  calc R.Q ^ R.G x ≤ (R.kmin ^ R.Q) ^ R.G x := Nat.pow_le_pow_left h1 _
    _ = (R.kmin ^ R.G x) ^ R.Q := by rw [← pow_mul, ← pow_mul, mul_comm]
    _ ≤ (x + 1) ^ R.Q := Nat.pow_le_pow_left (R.kmin_pow_G_le_succ x) _

lemma Nsrc_poly (x : ℕ) : R.Nsrc x ≤ R.Q * (x + 1) ^ R.Q := by
  have h := R.Nsrc_le x
  calc R.Nsrc x ≤ R.Q ^ (R.G x + 1) := h
    _ = R.Q ^ R.G x * R.Q := pow_succ _ _
    _ ≤ (x + 1) ^ R.Q * R.Q := Nat.mul_le_mul_right _ (R.Q_pow_G_le x)
    _ = R.Q * (x + 1) ^ R.Q := mul_comm _ _

theorem Nsrc_poly_ex : ∃ A c : ℕ, ∀ n, R.Nsrc n ≤ A * (n + 1) ^ c := ⟨R.Q, R.Q, R.Nsrc_poly⟩

end Rule

end OAI.PowerSaving.MX


namespace OAI.PowerSaving.MX

open Finset

inductive Shape where
  | top (n B : ℕ)
  | cls (n h ρ : ℕ)
  deriving DecidableEq

def Shape.rank : Shape → ℕ
  | .top n _ => (n + 1) * (n + 2)
  | .cls n h _ => (n + 1) * (n + 1) + h

def PhiN (g : ℕ → ℕ) : Multiset ℕ →+ ℕ where
  toFun s := (s.map g).sum
  map_zero' := by simp
  map_add' := by intro a b; simp

@[simp] lemma PhiN_apply (g : ℕ → ℕ) (s : Multiset ℕ) : PhiN g s = (s.map g).sum := rfl

namespace Rule

variable (R : Rule)

def InvS : Shape → Prop
  | .top _ _ => True
  | .cls n h ρ => 1 ≤ ρ ∧ R.m * ρ * R.kmin ^ h ≤ n

def restMS (n lam : ℕ) : Multiset Shape :=
  lam • (R.srcT n).map (fun s => Shape.top (n - s) (2 ^ s))

def kidsS (n0 : ℕ) : Shape → Multiset Shape
  | .top n B =>
      if n0 ≤ n ∧ R.Nsrc n ≤ B then
        Multiset.replicate (B / R.Nsrc n) (Shape.cls n (R.G n) 1) + R.restMS n (B / R.Nsrc n)
      else 0
  | .cls n (h + 1) ρ => Finset.univ.val.map (fun j : Fin R.P => Shape.cls n h (ρ * R.rk j))
  | .cls n 0 ρ =>
      Finset.univ.val.map (fun j : Fin R.P => Shape.top (ρ * R.rk j) (2 ^ (n - ρ * R.rk j)))

def locS (n0 : ℕ) : Shape → ℕ
  | .top n B =>
      if n0 ≤ n then (B + 1) * 2 ^ n + (B % R.Nsrc n) * (n + 1) * 2 ^ n
      else (B + 1) * (n + 1) * 2 ^ n
  | .cls n h ρ => 2 ^ n * (R.unitsC n h ρ + Multiset.card (R.srcBelow n h ρ))

def LftS (n0 n B : ℕ) : ℕ := if n0 ≤ n then (B % R.Nsrc n) * (n + 1) * 2 ^ n else 0

def topCost (n0 : ℕ) (J : ℕ → ℕ) (n B : ℕ) : ℕ :=
  B * J n + R.LftS n0 n B + (n + 1) * 2 ^ n + 1

def clsCost (n0 : ℕ) (J : ℕ → ℕ) (n : ℕ) : ℕ → ℕ → ℕ
  | 0, ρ => 2 ^ n * R.unitsC n 0 ρ + 1 +
      ∑ j : Fin R.P, R.topCost n0 J (ρ * R.rk j) (2 ^ (n - ρ * R.rk j))
  | h + 1, ρ => 2 ^ n * (R.unitsC n (h + 1) ρ + Multiset.card (R.srcBelow n (h + 1) ρ)) + 1 +
      ∑ j : Fin R.P, clsCost n0 J n h (ρ * R.rk j)

def costS (n0 : ℕ) (J : ℕ → ℕ) : Shape → ℕ
  | .top n B => R.topCost n0 J n B
  | .cls n h ρ => R.clsCost n0 J n h ρ

def exF (J : ℕ → ℕ) (n e : ℕ) : ℕ := 2 ^ (n - e) * J e + (R.Nsrc e + 1) * (e + 1) * 2 ^ e + 1

def srF (J : ℕ → ℕ) (n s : ℕ) : ℕ :=
  2 ^ s * J (n - s) + (R.Nsrc (n - s) + 1) * (n - s + 1) * 2 ^ (n - s) + 1

def treeCost (J : ℕ → ℕ) (n : ℕ) : ℕ :=
  (2 * R.unitsT n + R.Nsrc n * (R.G n + 1)) * 2 ^ n
    + ((R.exT n).map (fun e => 2 ^ (n - e) * J e)).sum
    + ((R.srcT n).map (fun s => 2 ^ s * J (n - s))).sum

def Rnd (n : ℕ) : ℕ :=
  ((R.exT n).map (fun e => (R.Nsrc e + 1) * (e + 1) * 2 ^ e + 1)).sum
    + ((R.srcT n).map (fun s => (R.Nsrc (n - s) + 1) * (n - s + 1) * 2 ^ (n - s) + 1)).sum

def JobRec (n0 : ℕ) (J : ℕ → ℕ) : Prop :=
  (∀ n, n < n0 → (n + 1) * 2 ^ n ≤ J n) ∧
    ∀ n, n0 ≤ n → R.treeCost J n + R.Rnd n ≤ R.Nsrc n * J n

lemma treeCost_add_Rnd (J : ℕ → ℕ) (n : ℕ) :
    R.treeCost J n + R.Rnd n =
      R.Nsrc n * 2 ^ n + (2 ^ n * (2 * R.unitsT n + R.G n * R.Nsrc n)
        + PhiN (R.exF J n) (R.exT n) + PhiN (R.srF J n) (R.srcT n)) := by
  unfold treeCost Rnd exF srF
  simp only [PhiN_apply, Multiset.sum_map_add]
  ring

lemma card_srcBelow_zero (n ρ : ℕ) : Multiset.card (R.srcBelow n 0 ρ) = 0 := by
  simp [srcBelow]

lemma pts_zero {n ρ : ℕ} (hρ : R.m * ρ ≤ n) : R.pts n 0 ρ = {0} := by
  unfold pts
  rw [Finset.Nat.antidiagonalTuple_zero_right, Finset.filter_singleton, if_pos]
  rw [R.col_zero, mul_one]; exact hρ

lemma unitsC_zero {n ρ : ℕ} (hρ : R.m * ρ ≤ n) : R.unitsC n 0 ρ = 1 := by
  unfold unitsC; rw [R.pts_zero hρ, Finset.sum_singleton]; simp [uh]

lemma outMS_zero {n ρ : ℕ} (hρ : R.m * ρ ≤ n) (j : Fin R.P) : R.outMS n 0 ρ j = {ρ * R.rk j} := by
  unfold outMS; rw [R.pts_zero hρ, Finset.sum_singleton]; simp [uh, R.col_zero, one_nsmul]

lemma PhiN_exitsSub_zero {n ρ : ℕ} (hρ : R.m * ρ ≤ n) (g : ℕ → ℕ) :
    PhiN g (R.exitsSub n 0 ρ) = ∑ j : Fin R.P, g (ρ * R.rk j) := by
  simp only [exitsSub, map_sum, R.outMS_zero hρ]
  simp

lemma PhiN_exitsSub_succ (n h ρ : ℕ) (g : ℕ → ℕ) :
    PhiN g (R.exitsSub n (h + 1) ρ) = ∑ j : Fin R.P, PhiN g (R.exitsSub n h (ρ * R.rk j)) := by
  simp only [exitsSub, map_sum]

lemma card_srcBelow_succ (n h ρ : ℕ) :
    ∑ j : Fin R.P, Multiset.card (R.srcBelow n h (ρ * R.rk j)) ≤
      Multiset.card (R.srcBelow n (h + 1) ρ) := by
  simp only [srcBelow, Multiset.card_sum, Multiset.card_add]
  exact Finset.sum_le_sum (fun j _ => Nat.le_add_left _ _)

lemma unitsC_pos {n h ρ : ℕ} (hinv : R.m * ρ * R.kmin ^ h ≤ n) : 1 ≤ R.unitsC n h ρ := by
  obtain ⟨k, hk, hW⟩ := R.kmin_att
  obtain ⟨b, hbdef⟩ : ∃ b : R.Pt, b = Pi.single k h := ⟨_, rfl⟩
  have hub : 1 ≤ R.uh h b := by rw [hbdef]; exact R.uh_single k h hW
  have hcol : R.col b = R.kmin ^ h := by
    simp only [col, hbdef, Pi.single_apply]
    rw [Finset.prod_eq_single k]
    · simp [hk]
    · intro i _ hi; simp [hi]
    · simp
  have hb : b ∈ R.pts n h ρ := by
    simp only [pts, Finset.mem_filter, Finset.Nat.mem_antidiagonalTuple]
    exact ⟨by simp [hbdef], by rw [hcol]; exact hinv⟩
  unfold unitsC
  exact le_trans hub (Finset.single_le_sum (f := fun b => R.uh h b) (fun _ _ => Nat.zero_le _) hb)

lemma rk_le_kmin (j : Fin R.P) : R.rk j ≤ R.kmin := le_trans (R.rk_le j) R.sep.le

lemma rk_lt_m (j : Fin R.P) : R.rk j < R.m := by
  obtain ⟨k, -, -⟩ := R.kmin_att
  exact lt_of_lt_of_le (R.rk_lt_kr j k) (R.kr_le k)

lemma inv_child {n h ρ : ℕ} (j : Fin R.P) (hinv : R.m * ρ * R.kmin ^ (h + 1) ≤ n) :
    R.m * (ρ * R.rk j) * R.kmin ^ h ≤ n := by
  calc R.m * (ρ * R.rk j) * R.kmin ^ h = R.m * ρ * (R.rk j * R.kmin ^ h) := by ring
    _ ≤ R.m * ρ * (R.kmin * R.kmin ^ h) :=
        Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ (R.rk_le_kmin j))
    _ = R.m * ρ * R.kmin ^ (h + 1) := by ring
    _ ≤ n := hinv

lemma Nsrc_pos_of {n0 n : ℕ} (hn0 : R.m ≤ n0) (h : n0 ≤ n) : 1 ≤ R.Nsrc n :=
  R.Nsrc_pos (le_trans hn0 h)

lemma LftS_le {n0 : ℕ} (hn0 : R.m ≤ n0) (n B : ℕ) : R.LftS n0 n B ≤ R.Nsrc n * (n + 1) * 2 ^ n := by
  unfold LftS
  split_ifs with h
  · have hN := R.Nsrc_pos_of hn0 h
    have : B % R.Nsrc n ≤ R.Nsrc n := (Nat.mod_lt _ (by omega)).le
    exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_right _ this)
  · exact Nat.zero_le _

lemma topCost_exit_le {n0 : ℕ} (hn0 : R.m ≤ n0) (J : ℕ → ℕ) (n e : ℕ) :
    R.topCost n0 J e (2 ^ (n - e)) ≤ R.exF J n e := by
  unfold topCost exF
  have := R.LftS_le hn0 e (2 ^ (n - e))
  nlinarith

theorem clsCost_le {n0 : ℕ} (hn0 : R.m ≤ n0) (J : ℕ → ℕ) (n : ℕ) :
    ∀ h ρ, R.m * ρ * R.kmin ^ h ≤ n →
      R.clsCost n0 J n h ρ ≤ 2 ^ n * (2 * R.unitsSub n h ρ + h * Multiset.card (R.srcBelow n h ρ))
        + PhiN (R.exF J n) (R.exitsSub n h ρ) := by
  intro h
  induction h with
  | zero =>
    intro ρ hinv
    have hρ : R.m * ρ ≤ n := by simpa using hinv
    simp only [clsCost, unitsSub, R.unitsC_zero hρ, R.PhiN_exitsSub_zero hρ, R.card_srcBelow_zero,
      zero_mul, add_zero]
    have h1 : 1 ≤ 2 ^ n := Nat.one_le_two_pow
    have h2 : ∑ j : Fin R.P, R.topCost n0 J (ρ * R.rk j) (2 ^ (n - ρ * R.rk j)) ≤
        ∑ j : Fin R.P, R.exF J n (ρ * R.rk j) :=
      Finset.sum_le_sum (fun j _ => R.topCost_exit_le hn0 J n _)
    omega
  | succ h ih =>
    intro ρ hinv
    simp only [clsCost, unitsSub, R.PhiN_exitsSub_succ]
    have hU := R.unitsC_pos hinv
    have hk : ∀ j : Fin R.P, R.clsCost n0 J n h (ρ * R.rk j) ≤
        2 ^ n * (2 * R.unitsSub n h (ρ * R.rk j) + h * Multiset.card (R.srcBelow n h (ρ * R.rk j)))
          + PhiN (R.exF J n) (R.exitsSub n h (ρ * R.rk j)) :=
      fun j => ih (ρ * R.rk j) (R.inv_child j hinv)
    have hsum := Finset.sum_le_sum (fun j (_ : j ∈ (Finset.univ : Finset (Fin R.P))) => hk j)
    rw [Finset.sum_add_distrib, ← Finset.mul_sum, Finset.sum_add_distrib, ← Finset.mul_sum,
      ← Finset.mul_sum] at hsum
    have hc := R.card_srcBelow_succ n h ρ
    have hc' : h * ∑ j : Fin R.P, Multiset.card (R.srcBelow n h (ρ * R.rk j)) ≤
        h * Multiset.card (R.srcBelow n (h + 1) ρ) := Nat.mul_le_mul_left _ hc
    have h1 : 1 ≤ 2 ^ n := Nat.one_le_two_pow
    have h2 : 2 ^ n * 1 ≤ 2 ^ n * R.unitsC n (h + 1) ρ := Nat.mul_le_mul_left _ hU
    have h3 : 2 ^ n * (h * ∑ j : Fin R.P, Multiset.card (R.srcBelow n h (ρ * R.rk j))) ≤
        2 ^ n * (h * Multiset.card (R.srcBelow n (h + 1) ρ)) := Nat.mul_le_mul_left _ hc'
    nlinarith

theorem rootCost_le {n0 : ℕ} (hn0 : R.m ≤ n0) (J : ℕ → ℕ) {n : ℕ} (hn : R.m ≤ n) :
    R.clsCost n0 J n (R.G n) 1 ≤ 2 ^ n * (2 * R.unitsT n + R.G n * R.Nsrc n)
      + PhiN (R.exF J n) (R.exT n) := by
  have h := R.clsCost_le hn0 J n (R.G n) 1 (by simpa using R.m_kmin_pow_G_le hn)
  have hc : Multiset.card (R.srcBelow n (R.G n) 1) ≤ R.Nsrc n := by
    unfold Nsrc srcT; rw [Multiset.card_add]; exact Nat.le_add_left _ _
  have : 2 ^ n * (2 * R.unitsSub n (R.G n) 1 + R.G n * Multiset.card (R.srcBelow n (R.G n) 1)) ≤
      2 ^ n * (2 * R.unitsT n + R.G n * R.Nsrc n) := by
    unfold unitsT
    exact Nat.mul_le_mul_left _ (Nat.add_le_add_left (Nat.mul_le_mul_left _ hc) _)
  unfold exT
  omega

lemma J_ge {n0 : ℕ} (hn0 : R.m ≤ n0) {J : ℕ → ℕ} (hJ : R.JobRec n0 J) (n : ℕ) : 2 ^ n ≤ J n := by
  by_cases h : n < n0
  · exact le_trans (Nat.le_mul_of_pos_left _ (Nat.succ_pos n)) (hJ.1 n h)
  · push_neg at h
    have hN := R.Nsrc_pos_of hn0 h
    have h2 := hJ.2 n h
    have h3 : R.Nsrc n * 2 ^ n ≤ R.treeCost J n := by
      unfold treeCost
      have : R.Nsrc n * 2 ^ n ≤ (2 * R.unitsT n + R.Nsrc n * (R.G n + 1)) * 2 ^ n :=
        Nat.mul_le_mul_right _ (le_trans (Nat.le_mul_of_pos_right _ (Nat.succ_pos _))
          (Nat.le_add_left _ _))
      omega
    exact Nat.le_of_mul_le_mul_left (le_trans h3 (le_trans (Nat.le_add_right _ _) h2)) hN

lemma charge_rest (n0 : ℕ) (J : ℕ → ℕ) (n lam : ℕ) :
    ((R.restMS n lam).map (R.costS n0 J)).sum =
      lam * ((R.srcT n).map (fun s => R.topCost n0 J (n - s) (2 ^ s))).sum := by
  unfold restMS
  rw [Multiset.map_nsmul, Multiset.sum_nsmul, Multiset.map_map, smul_eq_mul]
  rfl

lemma rest_le {n0 : ℕ} (hn0 : R.m ≤ n0) (J : ℕ → ℕ) (n lam : ℕ) (hlam : 1 ≤ lam) :
    ((R.restMS n lam).map (R.costS n0 J)).sum ≤ lam * PhiN (R.srF J n) (R.srcT n) := by
  rw [R.charge_rest, PhiN_apply]
  refine Nat.mul_le_mul_left _ (Multiset.sum_map_le_sum_map _ _ (fun s _ => ?_))
  have hL := R.LftS_le hn0 (n - s) (2 ^ s)
  unfold topCost srF
  have hA : R.Nsrc (n - s) * (n - s + 1) * 2 ^ (n - s) + (n - s + 1) * 2 ^ (n - s) =
      (R.Nsrc (n - s) + 1) * (n - s + 1) * 2 ^ (n - s) := by ring
  omega

theorem bill_top {n0 : ℕ} (hn0 : R.m ≤ n0) {J : ℕ → ℕ} (hJ : R.JobRec n0 J) (n B : ℕ) :
    R.locS n0 (.top n B) + 1 + ((R.kidsS n0 (.top n B)).map (R.costS n0 J)).sum ≤
      R.costS n0 J (.top n B) := by
  have hJn := R.J_ge hn0 hJ n
  simp only [locS, kidsS, costS, topCost, LftS]
  by_cases hn : n0 ≤ n
  · have hN := R.Nsrc_pos_of hn0 hn
    rw [if_pos hn, if_pos hn]
    by_cases hB : R.Nsrc n ≤ B
    · rw [if_pos ⟨hn, hB⟩, Multiset.map_add, Multiset.sum_add, Multiset.map_replicate,
        Multiset.sum_replicate, smul_eq_mul]
      set N := R.Nsrc n
      set lam := B / N
      set r := B % N
      have hlam : 1 ≤ lam := (Nat.le_div_iff_mul_le (by omega)).2 (by simpa using hB)
      have hBd : N * lam + r = B := Nat.div_add_mod B N
      have hroot := R.rootCost_le hn0 J (le_trans hn0 hn)
      have hrest := R.rest_le hn0 J n lam hlam
      have hrec := hJ.2 n hn
      rw [R.treeCost_add_Rnd] at hrec
      set T := 2 ^ n * (2 * R.unitsT n + R.G n * N) + PhiN (R.exF J n) (R.exT n) +
        PhiN (R.srF J n) (R.srcT n)
      have hroot' : R.costS n0 J (Shape.cls n (R.G n) 1) ≤ 2 ^ n * (2 * R.unitsT n + R.G n * N)
          + PhiN (R.exF J n) (R.exT n) := hroot
      have hlr : lam * R.costS n0 J (Shape.cls n (R.G n) 1) + lam * PhiN (R.srF J n) (R.srcT n)
          ≤ lam * T := by
        rw [← Nat.mul_add]; exact Nat.mul_le_mul_left _ (by simp only [T]; omega)
      have hl2 : lam * (N * 2 ^ n + T) ≤ lam * (N * J n) := Nat.mul_le_mul_left _ hrec
      have hr2 : r * 2 ^ n ≤ r * J n := Nat.mul_le_mul_left _ hJn
      have h1 : 2 ^ n ≤ (n + 1) * 2 ^ n := Nat.le_mul_of_pos_left _ (Nat.succ_pos n)
      rw [← hBd]
      nlinarith
    · rw [if_neg (fun h => hB h.2)]
      simp only [Multiset.map_zero, Multiset.sum_zero, add_zero]
      have hr : B % R.Nsrc n = B := Nat.mod_eq_of_lt (by omega)
      rw [hr]
      have h1 : B * 2 ^ n ≤ B * J n := Nat.mul_le_mul_left _ hJn
      have h2 : 2 ^ n ≤ (n + 1) * 2 ^ n := Nat.le_mul_of_pos_left _ (Nat.succ_pos n)
      nlinarith
  · rw [if_neg hn, if_neg hn, if_neg (fun h => hn h.1)]
    simp only [Multiset.map_zero, Multiset.sum_zero, add_zero]
    push_neg at hn
    have h1 := hJ.1 n hn
    have h2 : B * ((n + 1) * 2 ^ n) ≤ B * J n := Nat.mul_le_mul_left _ h1
    nlinarith

theorem bill_cls (n0 : ℕ) (J : ℕ → ℕ) (n h ρ : ℕ) :
    R.locS n0 (.cls n h ρ) + 1 + ((R.kidsS n0 (.cls n h ρ)).map (R.costS n0 J)).sum ≤
      R.costS n0 J (.cls n h ρ) := by
  cases h with
  | zero =>
    simp only [locS, kidsS, costS, clsCost, R.card_srcBelow_zero, add_zero, Multiset.map_map]
    rfl
  | succ h =>
    simp only [locS, kidsS, costS, clsCost, Multiset.map_map]
    rfl

theorem bill {n0 : ℕ} (hn0 : R.m ≤ n0) {J : ℕ → ℕ} (hJ : R.JobRec n0 J) (d : Shape) :
    R.locS n0 d + 1 + ((R.kidsS n0 d).map (R.costS n0 J)).sum ≤ R.costS n0 J d := by
  cases d with
  | top n B => exact R.bill_top hn0 hJ n B
  | cls n h ρ => exact R.bill_cls n0 J n h ρ

lemma mem_kidsS_top {n0 n B : ℕ} {c : Shape} (hc : c ∈ R.kidsS n0 (.top n B)) :
    n0 ≤ n ∧ R.Nsrc n ≤ B ∧ (c = Shape.cls n (R.G n) 1 ∨
      ∃ s ∈ R.srcT n, c = Shape.top (n - s) (2 ^ s)) := by
  simp only [kidsS] at hc
  split_ifs at hc with h
  · refine ⟨h.1, h.2, ?_⟩
    rcases Multiset.mem_add.1 hc with hc | hc
    · exact Or.inl (Multiset.eq_of_mem_replicate hc)
    · right
      unfold restMS at hc
      obtain ⟨s, hs, rfl⟩ := Multiset.mem_map.1 (Multiset.mem_of_mem_nsmul hc)
      exact ⟨s, hs, rfl⟩
  · simp at hc

theorem kids_inv {n0 : ℕ} (hn0 : R.m ≤ n0) {d c : Shape} (hd : R.InvS d) (hc : c ∈ R.kidsS n0 d) :
    R.InvS c := by
  cases d with
  | top n B =>
    obtain ⟨hn, -, h | ⟨s, -, rfl⟩⟩ := R.mem_kidsS_top hc
    · subst h
      exact ⟨le_rfl, by simpa using R.m_kmin_pow_G_le (le_trans hn0 hn)⟩
    · trivial
  | cls n h ρ =>
    cases h with
    | zero =>
      simp only [kidsS] at hc
      obtain ⟨j, -, rfl⟩ := Multiset.mem_map.1 hc
      trivial
    | succ h =>
      simp only [kidsS] at hc
      obtain ⟨j, -, rfl⟩ := Multiset.mem_map.1 hc
      exact ⟨le_trans hd.1 (Nat.le_mul_of_pos_right _ (R.rk_pos j)), R.inv_child j hd.2⟩

theorem kids_rank {n0 : ℕ} {d c : Shape} (hd : R.InvS d) (hc : c ∈ R.kidsS n0 d) :
    c.rank < d.rank := by
  cases d with
  | top n B =>
    obtain ⟨-, -, h | ⟨s, hs, rfl⟩⟩ := R.mem_kidsS_top hc
    · subst h
      simp only [Shape.rank]
      have : R.G n ≤ n := Nat.findGreatest_le n
      have h2 : (n + 1) * (n + 2) = (n + 1) * (n + 1) + n + 1 := by ring
      omega
    · simp only [Shape.rank]
      have h1 := R.src_pos hs
      have h2 := (R.src_size hs).2
      have h3 : n - s + 1 ≤ n := by omega
      have h4 : (n - s + 1) * (n - s + 2) ≤ n * (n + 1) := Nat.mul_le_mul h3 (by omega)
      have h5 : n * (n + 1) < (n + 1) * (n + 2) := by nlinarith
      omega
  | cls n h ρ =>
    cases h with
    | zero =>
      simp only [kidsS] at hc
      obtain ⟨j, -, rfl⟩ := Multiset.mem_map.1 hc
      simp only [Shape.rank]
      have hρ : R.m * ρ ≤ n := by simpa using hd.2
      have hr := R.rk_lt_m j
      have h1 : ρ * R.rk j < n := by
        calc ρ * R.rk j < ρ * R.m := Nat.mul_lt_mul_of_pos_left hr (by have := hd.1; omega)
          _ = R.m * ρ := by ring
          _ ≤ n := hρ
      have h2 : (ρ * R.rk j + 1) * (ρ * R.rk j + 2) ≤ n * (n + 1) :=
        Nat.mul_le_mul (Nat.succ_le_of_lt h1) (by omega)
      have h3 : n * (n + 1) < (n + 1) * (n + 1) := by nlinarith
      omega
    | succ h =>
      simp only [kidsS] at hc
      obtain ⟨j, -, rfl⟩ := Multiset.mem_map.1 hc
      simp only [Shape.rank]
      omega

lemma treeCost_congr {J J' : ℕ → ℕ} {n : ℕ} (he : ∀ e ∈ R.exT n, J e = J' e)
    (hs : ∀ s ∈ R.srcT n, J (n - s) = J' (n - s)) : R.treeCost J n = R.treeCost J' n := by
  unfold treeCost
  rw [Multiset.map_congr rfl (fun e h => by rw [he e h]),
    Multiset.map_congr (s := R.srcT n) rfl (fun s h => by rw [hs s h])]

def allotF (n0 : ℕ) : ℕ → ℕ → ℕ
  | 0, _ => 0
  | f + 1, n => if n < n0 then (n + 1) * 2 ^ n
      else (R.treeCost (allotF n0 f) n + R.Rnd n) / R.Nsrc n + 1

lemma allotF_stable (n0 : ℕ) : ∀ n f g, n < f → n < g → R.allotF n0 f n = R.allotF n0 g n := by
  intro n
  induction n using Nat.strong_induction_on with
  | _ n ih =>
  intro f g hf hg
  obtain ⟨f, rfl⟩ : ∃ f', f = f' + 1 := ⟨f - 1, by omega⟩
  obtain ⟨g, rfl⟩ : ∃ g', g = g' + 1 := ⟨g - 1, by omega⟩
  simp only [allotF]
  split_ifs with h
  · rfl
  · rw [R.treeCost_congr (J := R.allotF n0 f) (J' := R.allotF n0 g)]
    · intro e he
      have := (R.exit_size he).2.2
      exact ih e this f g (by omega) (by omega)
    · intro s hs
      have := R.src_pos hs
      have := (R.src_size hs).2
      exact ih (n - s) (by omega) f g (by omega) (by omega)

def allotM (n0 : ℕ) (n : ℕ) : ℕ := R.allotF n0 (n + 1) n

lemma allotM_eq (n0 n : ℕ) : R.allotM n0 n =
    if n < n0 then (n + 1) * 2 ^ n else (R.treeCost (R.allotM n0) n + R.Rnd n) / R.Nsrc n + 1 := by
  show R.allotF n0 (n + 1) n = _
  simp only [allotF]
  split_ifs with h
  · rfl
  · rw [R.treeCost_congr (J := R.allotF n0 n) (J' := R.allotM n0)]
    · intro e he
      have := (R.exit_size he).2.2
      exact R.allotF_stable n0 e n (e + 1) this (by omega)
    · intro s hs
      have := R.src_pos hs
      have := (R.src_size hs).2
      exact R.allotF_stable n0 (n - s) n (n - s + 1) (by omega) (by omega)

theorem allotM_jobRec {n0 : ℕ} (hn0 : R.m ≤ n0) : R.JobRec n0 (R.allotM n0) := by
  refine ⟨fun n hn => by rw [R.allotM_eq, if_pos hn], fun n hn => ?_⟩
  rw [R.allotM_eq, if_neg (by omega)]
  have hN := R.Nsrc_pos_of hn0 hn
  set X := R.treeCost (R.allotM n0) n + R.Rnd n
  have := Nat.lt_mul_div_succ X (show 0 < R.Nsrc n by omega)
  omega

theorem allotM_upper {n0 : ℕ} (hn0 : R.m ≤ n0) :
    (∀ n, n < n0 → R.allotM n0 n = (n + 1) * 2 ^ n) ∧
    ∀ n, n0 ≤ n → R.Nsrc n * R.allotM n0 n ≤ R.treeCost (R.allotM n0) n + R.Rnd n + R.Nsrc n := by
  refine ⟨fun n hn => by rw [R.allotM_eq, if_pos hn], fun n hn => ?_⟩
  rw [R.allotM_eq, if_neg (by omega), Nat.mul_add, mul_one]
  exact Nat.add_le_add_right (Nat.mul_div_le _ _) _

end Rule

end OAI.PowerSaving.MX


namespace OAI.PowerSaving.MX

open Finset

lemma sum_range_mul_split {M : Type*} [AddCommMonoid M] (g : ℕ → M) (W N : ℕ) :
    ∑ s ∈ range (N * W), g s = ∑ τ ∈ range N, ∑ x ∈ range W, g (x + W * τ) := by
  induction N with
  | zero => simp
  | succ N ih =>
    rw [Nat.succ_mul, Finset.sum_range_add, ih, Finset.sum_range_succ]
    congr 1
    refine Finset.sum_congr rfl (fun x _ => ?_)
    congr 1; ring

namespace Rule

variable (R : Rule)

def cntS (typ : ℕ → Fin R.K) (W : ℕ) : ℕ → ℕ → R.Pt
  | 0, _ => 0
  | h + 1, s => R.e (typ (s % W)) + cntS typ W h (s / W)

lemma cntS_cons (typ : ℕ → Fin R.K) {W : ℕ} (h x τ : ℕ) (hx : x < W) :
    R.cntS typ W (h + 1) (x + W * τ) = R.e (typ x) + R.cntS typ W h τ := by
  have hW : 0 < W := lt_of_le_of_lt (Nat.zero_le _) hx
  have h1 : (x + W * τ) % W = x := by rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hx]
  have h2 : (x + W * τ) / W = τ := by
    rw [Nat.add_mul_div_left _ _ hW, Nat.div_eq_of_lt hx, zero_add]
  simp only [cntS, h1, h2]

lemma colS_eq_col (typ : ℕ → Fin R.K) {W : ℕ} (hW : 0 < W) {tq : ℕ → ℕ}
    (htq : ∀ x, x < W → tq x = R.kr (typ x)) (h s : ℕ) :
    MXR.colS W tq h s = R.col (R.cntS typ W h s) := by
  induction h generalizing s with
  | zero => simp [cntS, R.col_zero]
  | succ h ih =>
    rw [MXR.colS_succ, ih, cntS, add_comm, R.col_add_e, htq _ (Nat.mod_lt _ hW)]

lemma sum_roles_by_type {M : Type*} [AddCommMonoid M] (typ : ℕ → Fin R.K) {W : ℕ}
    (hW : ∀ k, ((range W).filter (fun x => typ x = k)).card = R.Wk k) (G : Fin R.K → M) :
    ∑ x ∈ range W, G (typ x) = ∑ k, R.Wk k • G k := by
  rw [← Finset.sum_fiberwise (range W) typ (fun x => G (typ x))]
  refine Finset.sum_congr rfl (fun k _ => ?_)
  rw [Finset.sum_congr rfl (fun x hx => by rw [(Finset.mem_filter.1 hx).2]), Finset.sum_const, hW k]

theorem sum_codes {M : Type*} [AddCommMonoid M] (typ : ℕ → Fin R.K) {W : ℕ}
    (hW : ∀ k, ((range W).filter (fun x => typ x = k)).card = R.Wk k) (h : ℕ) (f : R.Pt → M) :
    ∑ s ∈ range (W ^ h), f (R.cntS typ W h s) =
      ∑ a ∈ Finset.Nat.antidiagonalTuple R.K h, R.uh h a • f a := by
  induction h generalizing f with
  | zero =>
    simp [cntS, uh, Finset.Nat.antidiagonalTuple_zero_right]
  | succ h ih =>
    rw [pow_succ, sum_range_mul_split]
    -- the inner sums run over the letters `x < W`
    have e1 : ∑ τ ∈ range (W ^ h), ∑ x ∈ range W, f (R.cntS typ W (h + 1) (x + W * τ)) =
        ∑ x ∈ range W, ∑ τ ∈ range (W ^ h), f (R.e (typ x) + R.cntS typ W h τ) := by
      rw [Finset.sum_comm]
      refine Finset.sum_congr rfl (fun x hx => Finset.sum_congr rfl (fun τ _ => ?_))
      rw [R.cntS_cons typ h x τ (Finset.mem_range.1 hx)]
    rw [e1]
    rw [Finset.sum_congr rfl (fun x _ => ih (fun b => f (R.e (typ x) + b)))]
    rw [R.sum_roles_by_type typ hW (fun k => ∑ a ∈ Finset.Nat.antidiagonalTuple R.K h,
      R.uh h a • f (R.e k + a))]
    have e2 : ∑ k, R.Wk k • ∑ a ∈ Finset.Nat.antidiagonalTuple R.K h, R.uh h a • f (R.e k + a) =
        ∑ a ∈ Finset.Nat.antidiagonalTuple R.K h, ∑ k, (R.Wk k * R.uh h a) • f (a + R.e k) := by
      rw [Finset.sum_comm]
      simp_rw [Finset.smul_sum]
      refine Finset.sum_congr rfl (fun a _ => Finset.sum_congr rfl (fun k _ => ?_))
      rw [mul_smul, add_comm]
    rw [e2, R.sum_shift h (fun b k => (R.Wk k * R.uh h b) • f (b + R.e k))]
    refine Finset.sum_congr rfl (fun a _ => ?_)
    rw [show R.uh (h + 1) a = ∑ k, (if 1 ≤ a k then R.Wk k * R.uh h (a - R.e k) else 0) from rfl]
    rw [Finset.sum_smul]
    refine Finset.sum_congr rfl (fun k _ => ?_)
    split_ifs with hak
    · rw [R.sub_e_add_e a k hak]
    · rw [zero_smul]

theorem NU_eq_unitsC (typ : ℕ → Fin R.K) {W : ℕ} (hW0 : 0 < W) {tq : ℕ → ℕ}
    (htq : ∀ x, x < W → tq x = R.kr (typ x))
    (hW : ∀ k, ((range W).filter (fun x => typ x = k)).card = R.Wk k) (n h ρ : ℕ) :
    MXR.NU W tq R.m n h ρ = R.unitsC n h ρ := by
  unfold MXR.NU MXR.PC
  rw [Nat.count_eq_card_filter_range, Finset.card_filter]
  have e1 : ∑ s ∈ range (W ^ h), (if MXR.inRS W tq R.m n h ρ s then 1 else 0) =
      ∑ s ∈ range (W ^ h), (fun a => if R.m * ρ * R.col a ≤ n then 1 else 0) (R.cntS typ W h s) := by
    refine Finset.sum_congr rfl (fun s hs => ?_)
    have hs' := Finset.mem_range.1 hs
    simp only [MXR.inRS, hs', true_and, R.colS_eq_col typ hW0 htq, mul_assoc]
  rw [e1, R.sum_codes typ hW h (fun a => if R.m * ρ * R.col a ≤ n then 1 else 0), unitsC, pts,
    Finset.sum_filter]
  refine Finset.sum_congr rfl (fun a _ => ?_)
  split_ifs <;> simp

theorem card_srcMS_eq (typ : ℕ → Fin R.K) {W : ℕ} (hW0 : 0 < W) {tq : ℕ → ℕ}
    (htq : ∀ x, x < W → tq x = R.kr (typ x))
    (hW : ∀ k, ((range W).filter (fun x => typ x = k)).card = R.Wk k) (n h ρ ρp : ℕ) :
    ∑ s ∈ (range (W ^ h)).filter (MXR.inRS W tq R.m n h ρ),
        ((range W).filter (fun x => n < R.m * (ρp * MXR.colS W tq (h + 1) (x + W * s)))).card =
      Multiset.card (R.srcMS n h ρ ρp) := by
  -- move to a sum over all codes of a function of the type point
  let F : R.Pt → ℕ := fun b => if R.m * ρ * R.col b ≤ n then
      ∑ k, R.Wk k * (if n < R.m * ρp * R.col (b + R.e k) then 1 else 0) else 0
  have e1 : ∑ s ∈ (range (W ^ h)).filter (MXR.inRS W tq R.m n h ρ),
        ((range W).filter (fun x => n < R.m * (ρp * MXR.colS W tq (h + 1) (x + W * s)))).card =
      ∑ s ∈ range (W ^ h), F (R.cntS typ W h s) := by
    rw [Finset.sum_filter]
    refine Finset.sum_congr rfl (fun s hs => ?_)
    have hs' := Finset.mem_range.1 hs
    simp only [MXR.inRS, hs', true_and, F, R.colS_eq_col typ hW0 htq, ← mul_assoc]
    split_ifs with hc
    · rw [Finset.card_filter]
      have e2 : ∀ x ∈ range W, (if n < R.m * ρp * R.col (R.cntS typ W (h + 1) (x + W * s)) then 1 else 0)
          = (fun k => if n < R.m * ρp * R.col (R.cntS typ W h s + R.e k) then 1 else 0) (typ x) := by
        intro x hx
        rw [R.cntS_cons typ h x s (Finset.mem_range.1 hx), add_comm]
      rw [Finset.sum_congr rfl e2, R.sum_roles_by_type typ hW
        (fun k => if n < R.m * ρp * R.col (R.cntS typ W h s + R.e k) then 1 else 0)]
      simp only [smul_eq_mul]
    · rfl
  rw [e1, R.sum_codes typ hW h F]
  simp only [srcMS, Multiset.card_sum]
  rw [pts, Finset.sum_filter]
  refine Finset.sum_congr rfl (fun b _ => ?_)
  simp only [F]
  split_ifs with hb
  · rw [smul_eq_mul, Finset.mul_sum]
    refine Finset.sum_congr rfl (fun k _ => ?_)
    split_ifs <;> simp [Multiset.card_nsmul]
  · simp

end Rule

end OAI.PowerSaving.MX


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable (E : Eng α ρ σ)

def repCode (a0 : ℕ) : ℕ → ℕ
  | 0 => 0
  | h + 1 => a0 + E.W * repCode a0 h

lemma repCode_spec (a0 : ℕ) (ha : a0 < E.W) :
    ∀ h, E.repCode a0 h < E.W^h ∧ colS E.W E.tq h (E.repCode a0 h) = E.tq a0 ^ h := by
  intro h
  induction h with
  | zero => simp [repCode]
  | succ h ih =>
    refine ⟨lt_of_cons E.W h a0 _ ha ih.1, ?_⟩
    simp only [repCode]
    rw [colS_cons E.W E.tq h a0 _ ha, ih.2, pow_succ, Nat.mul_comm]

lemma NU_pos {kmin : ℕ} (hk : E.KMin kmin) {n h μ o BS : ℕ} {J sup : ℕ → Bits n → ℂ}
    (hd : E.Valid kmin (MDesc.cls n h μ o BS J sup)) : 1 ≤ E.NUc n h μ := by
  obtain ⟨hμ, hreg, _⟩ := hd
  obtain ⟨l, hl⟩ := hk.att
  let a0 := E.Q.loc l
  have ha : a0 < E.W := E.Q.bd l
  have htq : E.tq a0 = kmin := by
    unfold tq; rw [dif_pos ha]
    have : E.Q.atFin ⟨a0, ha⟩ = l := by
      apply E.Q.inj; rw [Layout.loc_atFin]
    rw [this, hl]
  obtain ⟨hlt, hcol⟩ := E.repCode_spec a0 ha h
  have hin : inRS E.W E.tq E.mx n h μ (E.repCode a0 h) := by
    refine ⟨hlt, ?_⟩
    rw [hcol, htq, ← Nat.mul_assoc]; exact hreg
  have := count_lt_of_mem hin hlt
  exact Nat.one_le_iff_ne_zero.2 (by unfold NUc MXR.NU MXR.PC at *; omega)

lemma poly_valid {kmin : ℕ} (hk : E.KMin kmin) {n h μ o BS : ℕ} {J sup : ℕ → Bits n → ℂ}
    (hd : E.Valid kmin (MDesc.cls n h μ o BS J sup)) :
    (E.W^(h+1) + 1) * (E.W^(h+1) + 1) * (h + 3) + n + 1 ≤ 12 * (E.W + 1) * (E.W + 1) * (n + 1)^(2 * E.W + 1) := by
  obtain ⟨hμ, hreg, _⟩ := hd
  have hm : 1 ≤ E.mx := le_trans (by norm_num) E.three
  have hkh : kmin ^ h ≤ n := le_trans (Nat.le_mul_of_pos_left _ (Nat.mul_pos hm hμ)) hreg
  have hWk : E.W ≤ kmin ^ E.W := le_trans (Nat.lt_two_pow_self).le (Nat.pow_le_pow_left hk.two _)
  have hhn : h ≤ n := by
    have : h < 2^h := Nat.lt_two_pow_self
    have : 2^h ≤ kmin^h := Nat.pow_le_pow_left hk.two _
    omega
  have hWh : E.W^h ≤ (n + 1)^E.W := by
    calc E.W^h ≤ (kmin ^ E.W)^h := Nat.pow_le_pow_left hWk _
      _ = (kmin ^ h)^E.W := by rw [← pow_mul, ← pow_mul, Nat.mul_comm]
      _ ≤ (n + 1)^E.W := Nat.pow_le_pow_left (by omega) _
  have hW1 : E.W^(h+1) + 1 ≤ (E.W + 1) * (n + 1)^E.W := by
    rw [pow_succ]
    have h1 : 1 ≤ (n + 1)^E.W := Nat.one_le_pow _ _ (by omega)
    nlinarith
  set X := (n + 1)^E.W with hX
  have hX1 : 1 ≤ X := Nat.one_le_pow _ _ (by omega)
  have e : (n + 1)^(2 * E.W + 1) = X * X * (n + 1) := by rw [hX, pow_succ, two_mul, pow_add]
  rw [e]
  have h2 : (E.W^(h+1) + 1) * (E.W^(h+1) + 1) ≤ ((E.W + 1) * X) * ((E.W + 1) * X) := Nat.mul_le_mul hW1 hW1
  have h3 : h + 3 ≤ 3 * (n + 1) := by omega
  have h4 := Nat.mul_le_mul h2 h3
  have h5 : n + 1 ≤ (E.W + 1) * (E.W + 1) * (X * X * (n + 1)) := by
    have : 1 ≤ (E.W + 1) * (E.W + 1) * (X * X) := by
      have : 0 < (E.W + 1) * (E.W + 1) * (X * X) := by positivity
      omega
    nlinarith
  nlinarith

theorem clsLoc_dom {kmin : ℕ} (hk : E.KMin kmin) : ∃ C : ℕ, ∀ (n h μ o BS : ℕ) (J sup : ℕ → Bits n → ℂ),
    E.Valid kmin (MDesc.cls n h μ o BS J sup) →
    E.clsLoc n h μ + 1 ≤ C * (2^n * (E.NUc n h μ + E.cons n h μ) + 1) := by
  obtain ⟨C1, hC1⟩ := E.clsLoc_le hk
  obtain ⟨D, hD⟩ := MX.succ_pow_le_two_pow (2 * E.W + 1)
  refine ⟨C1 * (1 + 12 * (E.W + 1) * (E.W + 1) * D) + 1, fun n h μ o BS J sup hd => ?_⟩
  have h1 := hC1 n h μ o BS J sup hd
  have h2 := E.poly_valid hk hd
  have h3 := hD n
  have hNU := E.NU_pos hk hd
  set Y := 2^n * (E.NUc n h μ + E.cons n h μ)
  have hY : 2^n ≤ Y := by
    calc 2^n = 2^n * 1 := by ring
      _ ≤ Y := Nat.mul_le_mul_left _ (by omega)
  have h4 : (E.W^(h+1) + 1) * (E.W^(h+1) + 1) * (h + 3) + n + 1 ≤ 12 * (E.W + 1) * (E.W + 1) * D * Y := by
    calc _ ≤ 12 * (E.W + 1) * (E.W + 1) * (n + 1)^(2 * E.W + 1) := h2
      _ ≤ 12 * (E.W + 1) * (E.W + 1) * (D * 2^n) := Nat.mul_le_mul_left _ h3
      _ ≤ 12 * (E.W + 1) * (E.W + 1) * (D * Y) := Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ hY)
      _ = _ := by ring
  have h5 : E.clsLoc n h μ ≤ C1 * (Y + 12 * (E.W + 1) * (E.W + 1) * D * Y) := by
    calc E.clsLoc n h μ ≤ C1 * (Y + (E.W^(h+1) + 1) * (E.W^(h+1) + 1) * (h + 3) + n + 1) := h1
      _ ≤ C1 * (Y + 12 * (E.W + 1) * (E.W + 1) * D * Y) := by
        apply Nat.mul_le_mul_left; omega
  have h6 : C1 * (Y + 12 * (E.W + 1) * (E.W + 1) * D * Y) = C1 * (1 + 12 * (E.W + 1) * (E.W + 1) * D) * Y := by ring
  rw [h6] at h5
  set K := C1 * (1 + 12 * (E.W + 1) * (E.W + 1) * D)
  have h7 : (K + 1) * (Y + 1) = K * Y + K + Y + 1 := by ring
  rw [h7]
  omega

end Eng

end
end PowerSaving.RAM
end OAI


namespace OAI.PowerSaving.MX

open PowerSaving.RAM

namespace Rule

variable (R : Rule)

def adapterCost (n0 : ℕ) (J : ℕ → ℕ) (k : ℕ) : ℕ :=
  R.topCost n0 J (k / 2) (2 ^ (k - k / 2)) + R.topCost n0 J (k - k / 2) (2 ^ (k / 2)) + 2 ^ k

lemma J_part_le {J : ℕ → ℕ} {z C : ℝ} (hz : 0 ≤ z)
    (hJ : ∀ n, (J n : ℝ) ≤ C * 2 ^ n * ((n : ℝ) + 1) ^ z) {k n : ℕ} (hn : n ≤ k) :
    2 ^ (k - n) * J n ≤ Nat.ceil C * (2 ^ k * envelope z k) := by
  have hk : (2:ℝ) ^ (k - n) * 2 ^ n = 2 ^ k := by rw [← pow_add, Nat.sub_add_cancel hn]
  have h1 : ((n : ℝ) + 1) ^ z ≤ ((k : ℝ) + 1) ^ z :=
    Real.rpow_le_rpow (by positivity) (by exact_mod_cast Nat.add_le_add_right hn 1) hz
  have h2 : ((k : ℝ) + 1) ^ z ≤ (envelope z k : ℝ) := Nat.le_ceil _
  have hJn := hJ n
  have hC0 : 0 ≤ C := by
    by_contra hneg
    push_neg at hneg
    have : C * 2 ^ n * ((n : ℝ) + 1) ^ z < 0 :=
      mul_neg_of_neg_of_pos (mul_neg_of_neg_of_pos hneg (by positivity)) (by positivity)
    have : (0 : ℝ) ≤ J n := Nat.cast_nonneg _
    linarith
  have key : ((2 ^ (k - n) * J n : ℕ) : ℝ) ≤ ((Nat.ceil C * (2 ^ k * envelope z k) : ℕ) : ℝ) := by
    push_cast
    calc (2:ℝ) ^ (k - n) * J n ≤ 2 ^ (k - n) * (C * 2 ^ n * ((n : ℝ) + 1) ^ z) :=
          mul_le_mul_of_nonneg_left hJn (by positivity)
      _ = C * (2 ^ (k - n) * 2 ^ n) * ((n : ℝ) + 1) ^ z := by ring
      _ = C * 2 ^ k * ((n : ℝ) + 1) ^ z := by rw [hk]
      _ ≤ C * 2 ^ k * (envelope z k : ℝ) :=
          mul_le_mul_of_nonneg_left (le_trans h1 h2) (by positivity)
      _ ≤ (Nat.ceil C : ℝ) * (2 ^ k * (envelope z k : ℝ)) := by
          rw [mul_assoc]
          exact mul_le_mul_of_nonneg_right (Nat.le_ceil C) (by positivity)
  exact_mod_cast key

lemma adapter_rest_le {n0 : ℕ} (hn0 : R.m ≤ n0) :
    ∃ E : ℕ, ∀ k, R.LftS n0 (k / 2) (2 ^ (k - k / 2)) + ((k / 2 + 1) * 2 ^ (k / 2) + 1)
      + (R.LftS n0 (k - k / 2) (2 ^ (k / 2)) + ((k - k / 2 + 1) * 2 ^ (k - k / 2) + 1)) + 2 ^ k
      ≤ E * 2 ^ k := by
  obtain ⟨A, c, hA⟩ := R.Nsrc_poly_ex
  obtain ⟨D, hD⟩ := succ_pow_le_two_pow (c + 1)
  obtain ⟨D1, hD1⟩ := succ_pow_le_two_pow 1
  refine ⟨3 * A * D + 3 * D1 + 4, fun k => ?_⟩
  set a := k / 2
  set b := k - k / 2
  have hab : a + b = k := by omega
  have hab1 : a ≤ b := by omega
  have hba : b ≤ a + 1 := by omega
  have hk : 2 ^ k = 2 ^ a * 2 ^ b := by rw [← pow_add, hab]
  have haa : 2 ^ a * 2 ^ a ≤ 2 ^ k := by rw [hk]; exact Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by norm_num) hab1)
  have hbb : 2 ^ b * 2 ^ b ≤ 2 * 2 ^ k := by
    rw [hk]
    have : 2 ^ b ≤ 2 * 2 ^ a := by
      calc 2 ^ b ≤ 2 ^ (a + 1) := Nat.pow_le_pow_right (by norm_num) hba
        _ = 2 * 2 ^ a := by ring
    calc 2 ^ b * 2 ^ b ≤ (2 * 2 ^ a) * 2 ^ b := Nat.mul_le_mul_right _ this
      _ = 2 * (2 ^ a * 2 ^ b) := by ring
  -- the leftovers: `Nsrc x * (x+1) * 2^x ≤ A * D * 2^x * 2^x`
  have hL : ∀ x B, R.LftS n0 x B ≤ A * D * (2 ^ x * 2 ^ x) := by
    intro x B
    have h1 := R.LftS_le hn0 x B
    have h2 : R.Nsrc x * (x + 1) ≤ A * (x + 1) ^ (c + 1) := by
      calc R.Nsrc x * (x + 1) ≤ A * (x + 1) ^ c * (x + 1) := Nat.mul_le_mul_right _ (hA x)
        _ = A * (x + 1) ^ (c + 1) := by ring
    have h3 : A * (x + 1) ^ (c + 1) ≤ A * (D * 2 ^ x) := Nat.mul_le_mul_left _ (hD x)
    calc R.LftS n0 x B ≤ R.Nsrc x * (x + 1) * 2 ^ x := h1
      _ ≤ A * (D * 2 ^ x) * 2 ^ x := Nat.mul_le_mul_right _ (le_trans h2 h3)
      _ = A * D * (2 ^ x * 2 ^ x) := by ring
  have hN : ∀ x, (x + 1) * 2 ^ x + 1 ≤ (D1 + 1) * (2 ^ x * 2 ^ x) := by
    intro x
    have h1 : x + 1 ≤ D1 * 2 ^ x := by simpa using hD1 x
    have h2 : 1 ≤ 2 ^ x * 2 ^ x := Nat.one_le_iff_ne_zero.2 (by positivity)
    calc (x + 1) * 2 ^ x + 1 ≤ D1 * 2 ^ x * 2 ^ x + 2 ^ x * 2 ^ x := Nat.add_le_add (Nat.mul_le_mul_right _ h1) h2
      _ = (D1 + 1) * (2 ^ x * 2 ^ x) := by ring
  have e1 := hL a (2 ^ b)
  have e2 := hL b (2 ^ a)
  have e3 := hN a
  have e4 := hN b
  have f1 : A * D * (2 ^ a * 2 ^ a) ≤ A * D * 2 ^ k := Nat.mul_le_mul_left _ haa
  have f2 : A * D * (2 ^ b * 2 ^ b) ≤ A * D * (2 * 2 ^ k) := Nat.mul_le_mul_left _ hbb
  have f3 : (D1 + 1) * (2 ^ a * 2 ^ a) ≤ (D1 + 1) * 2 ^ k := Nat.mul_le_mul_left _ haa
  have f4 : (D1 + 1) * (2 ^ b * 2 ^ b) ≤ (D1 + 1) * (2 * 2 ^ k) := Nat.mul_le_mul_left _ hbb
  have : A * D * 2 ^ k + A * D * (2 * 2 ^ k) + (D1 + 1) * 2 ^ k + (D1 + 1) * (2 * 2 ^ k) + 2 ^ k
      = (3 * A * D + 3 * D1 + 4) * 2 ^ k := by ring
  linarith

theorem seam_dom {n0 : ℕ} (hn0 : R.m ≤ n0) {J : ℕ → ℕ} {z C : ℝ} (hz : 0 ≤ z)
    (hJ : ∀ n, (J n : ℝ) ≤ C * 2 ^ n * ((n : ℝ) + 1) ^ z) {ι : Type*} (k : ι → ℕ) :
    Dom (fun i => 2 ^ k i * envelope z (k i)) (fun i => R.adapterCost n0 J (k i)) := by
  obtain ⟨E, hE⟩ := R.adapter_rest_le hn0
  refine ⟨2 * Nat.ceil C + E + 1, fun i => ?_⟩
  dsimp only
  set x := k i
  set W := 2 ^ x * envelope z x
  have hW : 2 ^ x ≤ W := Nat.le_mul_of_pos_right _ (envelope_pos z x)
  have j1 : 2 ^ (x - x / 2) * J (x / 2) ≤ Nat.ceil C * W := J_part_le hz hJ (Nat.div_le_self x 2)
  have j2 : 2 ^ (x - (x - x / 2)) * J (x - x / 2) ≤ Nat.ceil C * W := J_part_le hz hJ (Nat.sub_le x _)
  have hxx : x - (x - x / 2) = x / 2 := by omega
  rw [hxx] at j2
  have hr := hE x
  have hEW : E * 2 ^ x ≤ E * W := Nat.mul_le_mul_left _ hW
  unfold adapterCost topCost
  have hW1 : (2 * Nat.ceil C + E + 1) * (W + 1) = 2 * Nat.ceil C * W + E * W + W
      + (2 * Nat.ceil C + E + 1) := by ring
  linarith

end Rule

end OAI.PowerSaving.MX


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ] (E : Eng α ρ σ)

structure BridgeHyp (R : MX.Rule) (typ : ℕ → Fin R.K) (kmin : ℕ) : Prop where
  hm : R.m = E.mx
  hP : R.P = E.nB
  hrk : ∀ j : Fin R.P, R.rk j = E.rkI j
  htq : ∀ x, x < E.W → E.tq x = R.kr (typ x)
  hW : ∀ k, ((range E.W).filter (fun x => typ x = k)).card = R.Wk k
  hkmin : R.kmin = kmin

variable {E} {R : MX.Rule} {typ : ℕ → Fin R.K} {kmin : ℕ}

lemma BridgeHyp.topG_eq (H : E.BridgeHyp R typ kmin) (n : ℕ) : E.topG kmin n = R.G n := by
  unfold topG MX.Rule.G; rw [H.hm, H.hkmin]

lemma BridgeHyp.NUc_eq (H : E.BridgeHyp R typ kmin) (n h μ : ℕ) : E.NUc n h μ = R.unitsC n h μ := by
  have := R.NU_eq_unitsC typ E.W_pos (tq := E.tq) H.htq H.hW n h μ
  rw [← this, H.hm]

lemma BridgeHyp.W_eq (H : E.BridgeHyp R typ kmin) : R.W = E.W := by
  unfold MX.Rule.W
  simp_rw [← H.hW]
  rw [← Finset.card_eq_sum_card_fiberwise (f := typ) (s := range E.W) (t := Finset.univ)
    (fun _ _ => Finset.mem_univ _)]
  simp

lemma srcU_iff (H : E.BridgeHyp R typ kmin) (n h μ r sc x : ℕ) (hs : sc < E.W^h) (hx : x < E.W) :
    E.srcU n h μ r (x + E.W * sc) ↔
      (inRS E.W E.tq R.m n h (μ * r) sc ∧ n < R.m * (μ * MXR.colS E.W E.tq (h + 1) (x + E.W * sc))) := by
  have hW := E.W_pos
  have hdiv : (x + E.W * sc) / E.W = sc := by
    rw [Nat.add_mul_div_left _ _ hW, Nat.div_eq_of_lt hx, zero_add]
  have hlt : x + E.W * sc < E.W^(h+1) := by
    have h1 : x + E.W * sc < E.W + E.W * sc := Nat.add_lt_add_right hx _
    have h2 : E.W + E.W * sc = E.W * (sc + 1) := by ring
    have h3 : E.W * (sc + 1) ≤ E.W * E.W^h := Nat.mul_le_mul_left _ hs
    have h4 : E.W * E.W^h = E.W^(h+1) := by ring
    omega
  unfold srcU inRS
  rw [hdiv, H.hm]
  constructor
  · rintro ⟨h1, h2⟩
    exact ⟨h1, Nat.lt_of_not_le (fun h3 => h2 ⟨hlt, h3⟩)⟩
  · rintro ⟨h1, h2⟩
    exact ⟨h1, fun h3 => Nat.not_le.mpr h2 h3.2⟩

lemma count_srcU_eq (H : E.BridgeHyp R typ kmin) (n h μ r : ℕ) :
    Nat.count (E.srcU n h μ r) (E.W^h * E.W) = Multiset.card (R.srcMS n h (μ * r) μ) := by
  rw [← R.card_srcMS_eq typ E.W_pos (tq := E.tq) H.htq H.hW n h (μ * r) μ]
  rw [Nat.count_eq_card_filter_range, Finset.card_filter, MX.sum_range_mul_split]
  rw [Finset.sum_filter]
  refine Finset.sum_congr rfl (fun sc hsc => ?_)
  have hs := Finset.mem_range.1 hsc
  rw [Finset.card_filter]
  by_cases hin : inRS E.W E.tq R.m n h (μ * r) sc
  · rw [if_pos hin]
    refine Finset.sum_congr rfl (fun x hx => ?_)
    have key := srcU_iff H n h μ r sc x hs (Finset.mem_range.1 hx)
    by_cases hk : E.srcU n h μ r (x + E.W * sc)
    · rw [if_pos hk, if_pos (key.1 hk).2]
    · rw [if_neg hk, if_neg (fun h2 => hk (key.2 ⟨hin, h2⟩))]
  · rw [if_neg hin]
    refine Finset.sum_eq_zero (fun x hx => ?_)
    have key := srcU_iff H n h μ r sc x hs (Finset.mem_range.1 hx)
    rw [if_neg (fun hk => hin (key.1 hk).1)]

theorem BridgeHyp.card_srcBelow_eq (H : E.BridgeHyp R typ kmin) (n : ℕ) :
    ∀ h μ, Multiset.card (R.srcBelow n h μ) = E.cons n h μ := by
  intro h
  induction h with
  | zero => intro μ; simp [MX.Rule.srcBelow, cons_zero]
  | succ h ih =>
    intro μ
    rw [cons_succ_idx]
    simp only [MX.Rule.srcBelow, Multiset.card_sum, Multiset.card_add]
    rw [← Fin.sum_univ_eq_sum_range (fun j => Nat.count (E.srcU n h μ (E.rkI j)) (E.W^h * E.W) +
      E.cons n h (μ * E.rkI j)) E.nB]
    have hP := H.hP
    refine Fintype.sum_equiv (finCongr hP) _ _ (fun j => ?_)
    rw [ih, ← count_srcU_eq H, H.hrk j]
    rfl

theorem BridgeHyp.topN_eq (H : E.BridgeHyp R typ kmin) (n : ℕ) : E.topN kmin n = R.Nsrc n := by
  unfold topN topNU0 MX.Rule.Nsrc MX.Rule.srcT
  rw [Multiset.card_add, R.card_inMS, ← H.topG_eq n, H.card_srcBelow_eq n, H.NUc_eq]
  congr 1
  unfold MX.Rule.unitsC
  rw [Finset.sum_mul]
  refine Finset.sum_congr rfl (fun b _ => ?_)
  rw [← Finset.mul_sum, ← H.W_eq]
  rfl


lemma sum_units {M : Type*} [AddCommMonoid M] (n h μ : ℕ) (g : ℕ → M) :
    ∑ p ∈ Finset.range (E.NUc n h μ), g (E.Uc n h μ p) =
      ∑ sc ∈ (Finset.range (E.W^h)).filter (inRS E.W E.tq E.mx n h μ), g sc := by
  refine Finset.sum_bij (fun p _ => E.Uc n h μ p) ?_ ?_ ?_ ?_
  · intro p hp
    have hU := U_spec (Finset.mem_range.1 hp)
    simp only [Finset.mem_filter, Finset.mem_range]
    exact ⟨hU.2.1, hU.1⟩
  · intro p1 hp1 p2 hp2 heq
    have e1 := PC_U (Finset.mem_range.1 hp1)
    have e2 := PC_U (Finset.mem_range.1 hp2)
    rw [← e1, ← e2]; exact congrArg _ heq
  · intro sc hsc
    simp only [Finset.mem_filter, Finset.mem_range] at hsc
    exact ⟨E.PCc n h μ sc, Finset.mem_range.2 (PC_lt hsc.2), U_PC hsc.2⟩
  · intro p _; rfl

lemma coe_map_range_split (N : ℕ) (f : ℕ → ℕ) :
    ((List.range (N * E.W)).map f : Multiset ℕ) = ∑ p ∈ Finset.range N, ∑ a ∈ Finset.range E.W, {f (a + E.W * p)} := by
  have : ((List.range (N * E.W)).map f : Multiset ℕ) = ∑ t ∈ Finset.range (N * E.W), {f t} := by
    induction (N * E.W) with
    | zero => simp
    | succ M ih => rw [List.range_succ, List.map_append, ← Multiset.coe_add, ih, Finset.sum_range_succ]; simp
  rw [this, MX.sum_range_mul_split]

theorem BridgeHyp.own_sizes (H : E.BridgeHyp R typ kmin) (n h μ : ℕ) :
    ((List.range (E.NUc n h μ * E.W)).map (E.slotSize n h μ) : Multiset ℕ) = R.inMS n h μ := by
  rw [coe_map_range_split]
  have hW := E.W_pos
  have e1 : ∀ p a, a < E.W → E.slotSize n h μ (a + E.W * p) = E.tq a * E.cUc n h μ p := by
    intro p a ha
    unfold slotSize
    rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt ha, Nat.add_mul_div_left _ _ hW, Nat.div_eq_of_lt ha, zero_add]
  have e2 : ∀ p ∈ Finset.range (E.NUc n h μ), ∑ a ∈ Finset.range E.W, ({E.slotSize n h μ (a + E.W * p)} : Multiset ℕ) =
      (fun sc => ∑ a ∈ Finset.range E.W, ({E.tq a * (μ * MXR.colS E.W E.tq h sc)} : Multiset ℕ)) (E.Uc n h μ p) := by
    intro p _
    refine Finset.sum_congr rfl (fun a ha => ?_)
    rw [e1 p a (Finset.mem_range.1 ha)]; rfl
  rw [Finset.sum_congr rfl e2, sum_units (E := E) n h μ
    (fun sc => ∑ a ∈ Finset.range E.W, ({E.tq a * (μ * MXR.colS E.W E.tq h sc)} : Multiset ℕ))]
  -- to a sum over all codes of a function of the type point
  let F : R.Pt → Multiset ℕ := fun b => if R.m * μ * R.col b ≤ n then
      ∑ k, R.Wk k • ({μ * R.kr k * R.col b} : Multiset ℕ) else 0
  have e3 : ∑ sc ∈ (Finset.range (E.W^h)).filter (inRS E.W E.tq E.mx n h μ),
      ∑ a ∈ Finset.range E.W, ({E.tq a * (μ * MXR.colS E.W E.tq h sc)} : Multiset ℕ) =
      ∑ sc ∈ Finset.range (E.W^h), F (R.cntS typ E.W h sc) := by
    rw [Finset.sum_filter]
    refine Finset.sum_congr rfl (fun sc hsc => ?_)
    have hs := Finset.mem_range.1 hsc
    have hcol := R.colS_eq_col typ hW H.htq h sc
    simp only [F, inRS, hs, true_and, hcol, H.hm, mul_assoc]
    split_ifs with hc
    · rw [Finset.sum_congr rfl (fun a ha => by rw [H.htq a (Finset.mem_range.1 ha)])]
      rw [R.sum_roles_by_type typ H.hW (fun k => ({R.kr k * (μ * R.col (R.cntS typ E.W h sc))} : Multiset ℕ))]
      refine Finset.sum_congr rfl (fun k _ => ?_)
      congr 2; ring
    · rfl
  rw [e3, R.sum_codes typ H.hW h F]
  unfold MX.Rule.inMS MX.Rule.pts
  rw [Finset.sum_filter]
  refine Finset.sum_congr rfl (fun b _ => ?_)
  simp only [F]
  split_ifs with hb
  · rw [Finset.smul_sum]
    refine Finset.sum_congr rfl (fun k _ => ?_)
    rw [smul_smul, mul_comm]
  · simp


lemma coe_filterMap_range (N : ℕ) (P : ℕ → Prop) [DecidablePred P] (f : ℕ → ℕ) :
    (((List.range N).filterMap (fun t => if P t then some (f t) else none)) : Multiset ℕ) =
      ∑ t ∈ Finset.range N, (if P t then ({f t} : Multiset ℕ) else 0) := by
  induction N with
  | zero => simp
  | succ N ih =>
    rw [List.range_succ, List.filterMap_append, ← Multiset.coe_add, ih, Finset.sum_range_succ]
    by_cases hp : P N <;> simp [hp]

lemma Gs_eq (H : E.BridgeHyp R typ kmin) (n h μ r sc : ℕ) (hs : sc < E.W^h) :
    ∑ a ∈ Finset.range E.W, (if ¬ inRS E.W E.tq E.mx n (h+1) μ (a + E.W * sc) then
      ({E.tq a * (μ * r * MXR.colS E.W E.tq h sc)} : Multiset ℕ) else 0) =
    ∑ k, R.Wk k • (if n < R.m * μ * R.col (R.cntS typ E.W h sc + R.e k) then
      ({μ * r * R.kr k * R.col (R.cntS typ E.W h sc)} : Multiset ℕ) else 0) := by
  have hW := E.W_pos
  have hcol := R.colS_eq_col typ hW H.htq h sc
  have e4 : ∀ a ∈ Finset.range E.W, (if ¬ inRS E.W E.tq E.mx n (h+1) μ (a + E.W * sc) then
      ({E.tq a * (μ * r * MXR.colS E.W E.tq h sc)} : Multiset ℕ) else 0) =
      (fun k => if n < R.m * μ * R.col (R.cntS typ E.W h sc + R.e k) then
        ({μ * r * R.kr k * R.col (R.cntS typ E.W h sc)} : Multiset ℕ) else 0) (typ a) := by
    intro a ha
    have ha' := Finset.mem_range.1 ha
    have hlt : a + E.W * sc < E.W^(h+1) := by
      have h1 : a + E.W * sc < E.W + E.W * sc := Nat.add_lt_add_right ha' _
      have h2 : E.W + E.W * sc = E.W * (sc + 1) := by ring
      have h3 : E.W * (sc + 1) ≤ E.W * E.W^h := Nat.mul_le_mul_left _ hs
      have h4 : E.W * E.W^h = E.W^(h+1) := by ring
      omega
    have hc1 : MXR.colS E.W E.tq (h+1) (a + E.W * sc) = R.kr (typ a) * R.col (R.cntS typ E.W h sc) := by
      rw [MXR.colS_cons _ _ _ _ _ ha', H.htq a ha', hcol]
    have hc2 : R.col (R.cntS typ E.W h sc + R.e (typ a)) = R.kr (typ a) * R.col (R.cntS typ E.W h sc) :=
      R.col_add_e _ _
    have hiff : ¬ inRS E.W E.tq E.mx n (h+1) μ (a + E.W * sc) ↔
        n < R.m * μ * R.col (R.cntS typ E.W h sc + R.e (typ a)) := by
      unfold inRS
      rw [hc1, hc2, ← H.hm]
      constructor
      · intro h1; by_contra h2; push_neg at h2; exact h1 ⟨hlt, by rw [← mul_assoc]; exact h2⟩
      · intro h1 h2; have := h2.2; rw [← mul_assoc] at this; omega
    have hval : E.tq a * (μ * r * MXR.colS E.W E.tq h sc) = μ * r * R.kr (typ a) * R.col (R.cntS typ E.W h sc) := by
      rw [H.htq a ha', hcol]; ring
    show _ = if n < R.m * μ * R.col (R.cntS typ E.W h sc + R.e (typ a)) then
        ({μ * r * R.kr (typ a) * R.col (R.cntS typ E.W h sc)} : Multiset ℕ) else 0
    by_cases hc : n < R.m * μ * R.col (R.cntS typ E.W h sc + R.e (typ a))
    · rw [if_pos (hiff.2 hc), if_pos hc, hval]
    · rw [if_neg (fun h1 => hc (hiff.1 h1)), if_neg hc]
  rw [Finset.sum_congr rfl e4, R.sum_roles_by_type typ H.hW (fun k =>
    if n < R.m * μ * R.col (R.cntS typ E.W h sc + R.e k) then
      ({μ * r * R.kr k * R.col (R.cntS typ E.W h sc)} : Multiset ℕ) else 0)]

theorem BridgeHyp.ownSrc_sizes (H : E.BridgeHyp R typ kmin) (n h μ r : ℕ) :
    ((E.ownSrc n h μ r) : Multiset ℕ) = R.srcMS n h (μ * r) μ := by
  have hW := E.W_pos
  unfold ownSrc
  rw [coe_filterMap_range, MX.sum_range_mul_split]
  let Gs : ℕ → Multiset ℕ := fun sc => ∑ a ∈ Finset.range E.W,
    (if ¬ inRS E.W E.tq E.mx n (h+1) μ (a + E.W * sc) then
      ({E.tq a * (μ * r * MXR.colS E.W E.tq h sc)} : Multiset ℕ) else 0)
  have e2 : ∀ p ∈ Finset.range (E.NUc n h (μ * r)), ∑ a ∈ Finset.range E.W,
      (if E.srcP n h μ r (a + E.W * p) then ({E.slotSize n h (μ * r) (a + E.W * p)} : Multiset ℕ) else 0) =
      Gs (E.Uc n h (μ * r) p) := by
    intro p hp
    refine Finset.sum_congr rfl (fun a ha => ?_)
    have ha' := Finset.mem_range.1 ha
    have hp' := Finset.mem_range.1 hp
    have hmod : (a + E.W * p) % E.W = a := by rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt ha']
    have hdiv : (a + E.W * p) / E.W = p := by rw [Nat.add_mul_div_left _ _ hW, Nat.div_eq_of_lt ha', zero_add]
    have hlt : a + E.W * p < E.NUc n h (μ * r) * E.W := by
      calc a + E.W * p < E.W + E.W * p := Nat.add_lt_add_right ha' _
        _ = (p + 1) * E.W := by ring
        _ ≤ E.NUc n h (μ * r) * E.W := Nat.mul_le_mul_right _ hp'
    have hpar : E.parCode n h μ r (a + E.W * p) = a + E.W * E.Uc n h (μ * r) p := by
      unfold parCode; rw [hmod, hdiv]
    have hsrc : E.srcP n h μ r (a + E.W * p) ↔ ¬ inRS E.W E.tq E.mx n (h+1) μ (a + E.W * E.Uc n h (μ * r) p) := by
      unfold srcP; rw [hpar]; exact ⟨fun h1 => h1.2, fun h1 => ⟨hlt, h1⟩⟩
    have hsz : E.slotSize n h (μ * r) (a + E.W * p) = E.tq a * (μ * r * MXR.colS E.W E.tq h (E.Uc n h (μ * r) p)) := by
      unfold slotSize; rw [hmod, hdiv]; rfl
    show _ = if ¬ inRS E.W E.tq E.mx n (h+1) μ (a + E.W * E.Uc n h (μ * r) p) then
      ({E.tq a * (μ * r * MXR.colS E.W E.tq h (E.Uc n h (μ * r) p))} : Multiset ℕ) else 0
    by_cases hc : E.srcP n h μ r (a + E.W * p)
    · rw [if_pos hc, if_pos (hsrc.1 hc), hsz]
    · rw [if_neg hc, if_neg (fun h1 => hc (hsrc.2 h1))]
  rw [Finset.sum_congr rfl e2, sum_units (E := E) n h (μ * r) Gs]
  let F : R.Pt → Multiset ℕ := fun b => if R.m * (μ * r) * R.col b ≤ n then
      ∑ k, R.Wk k • (if n < R.m * μ * R.col (b + R.e k) then ({μ * r * R.kr k * R.col b} : Multiset ℕ) else 0)
      else 0
  have e3 : ∑ sc ∈ (Finset.range (E.W^h)).filter (inRS E.W E.tq E.mx n h (μ * r)), Gs sc =
      ∑ sc ∈ Finset.range (E.W^h), F (R.cntS typ E.W h sc) := by
    rw [Finset.sum_filter]
    refine Finset.sum_congr rfl (fun sc hsc => ?_)
    have hs := Finset.mem_range.1 hsc
    have hcol := R.colS_eq_col typ hW H.htq h sc
    have hreg : inRS E.W E.tq E.mx n h (μ * r) sc ↔ R.m * (μ * r) * R.col (R.cntS typ E.W h sc) ≤ n := by
      have e : R.m * (μ * r * R.col (R.cntS typ E.W h sc)) = R.m * (μ * r) * R.col (R.cntS typ E.W h sc) := by ring
      unfold inRS; rw [hcol, ← H.hm, e]; exact ⟨fun h1 => h1.2, fun h1 => ⟨hs, h1⟩⟩
    show _ = if R.m * (μ * r) * R.col (R.cntS typ E.W h sc) ≤ n then _ else 0
    by_cases hc : R.m * (μ * r) * R.col (R.cntS typ E.W h sc) ≤ n
    · rw [if_pos (hreg.2 hc), if_pos hc]
      exact Gs_eq H n h μ r sc hs
    · rw [if_neg (fun h1 => hc (hreg.1 h1)), if_neg hc]
  rw [e3, R.sum_codes typ H.hW h F]
  unfold MX.Rule.srcMS MX.Rule.pts
  rw [Finset.sum_filter]
  refine Finset.sum_congr rfl (fun b _ => ?_)
  simp only [F]
  split_ifs with hb
  · rw [Finset.smul_sum]
    refine Finset.sum_congr rfl (fun k _ => ?_)
    split_ifs <;> simp [smul_smul, mul_comm]
  · simp


lemma coe_flatMap {β γ : Type*} (L : List β) (f : β → List γ) :
    ((L.flatMap f : List γ) : Multiset γ) = (L.map (fun x => ((f x : List γ) : Multiset γ))).sum := by
  induction L with
  | nil => simp
  | cons a L ih => rw [List.flatMap_cons, ← Multiset.coe_add, ih, List.map_cons, List.sum_cons]

lemma sum_map_getD' {β M : Type*} [AddCommMonoid M] (L : List β) (z : β) (g : β → M) :
    (L.map g).sum = ∑ j ∈ Finset.range L.length, g (L.getD j z) := RAM.sum_map_getD L z g

theorem BridgeHyp.srcSizes_eq (H : E.BridgeHyp R typ kmin) (n : ℕ) :
    ∀ h μ, ((E.srcSizes n h μ : List ℕ) : Multiset ℕ) = R.srcBelow n h μ := by
  intro h
  induction h with
  | zero => intro μ; simp [srcSizes, MX.Rule.srcBelow]
  | succ h ih =>
    intro μ
    simp only [srcSizes, MX.Rule.srcBelow]
    rw [coe_flatMap, sum_map_getD' _ 0]
    rw [← Fin.sum_univ_eq_sum_range (fun j => (((E.ownSrc n h μ ((blockRanks E.wd).getD j 0) ++
      E.srcSizes n h (μ * (blockRanks E.wd).getD j 0)) : List ℕ) : Multiset ℕ)) (blockRanks E.wd).length]
    refine (Fintype.sum_equiv (finCongr H.hP) _ _ (fun j => ?_)).symm
    rw [← Multiset.coe_add, ih, H.ownSrc_sizes, H.hrk j]
    rfl

lemma map_getD_range {β : Type*} (L : List β) (z : β) : (List.range L.length).map (fun k => L.getD k z) = L := by
  apply List.ext_getElem (by simp)
  intro k h1 h2
  simp [List.getElem?_eq_getElem h2]

theorem BridgeHyp.topSz_eq (H : E.BridgeHyp R typ kmin) (n : ℕ) :
    (((List.range (E.topN kmin n)).map (E.topSz kmin n) : List ℕ) : Multiset ℕ) = R.srcT n := by
  unfold topN MX.Rule.srcT
  rw [List.range_add, List.map_append, ← Multiset.coe_add, ← H.topG_eq n]
  congr 1
  · rw [show (List.range (E.topNU0 kmin n * E.W)).map (E.topSz kmin n) =
        (List.range (E.NUc n (E.topG kmin n) 1 * E.W)).map (E.slotSize n (E.topG kmin n) 1) from
      List.map_congr_left (fun j hj => by
        unfold topSz; rw [if_pos (List.mem_range.1 hj)])]
    exact H.own_sizes n _ 1
  · rw [List.map_map]
    rw [show (List.range (E.cons n (E.topG kmin n) 1)).map (E.topSz kmin n ∘ (E.topNU0 kmin n * E.W + ·)) =
        (List.range (E.srcSizes n (E.topG kmin n) 1).length).map (fun k => (E.srcSizes n (E.topG kmin n) 1).getD k 0) from
      List.map_congr_left (fun k hk => by
        simp only [Function.comp, topSz]
        rw [if_neg (by omega), Nat.add_sub_cancel_left]; rfl)]
    rw [map_getD_range, H.srcSizes_eq]


theorem BridgeHyp.kidsTop_shape (H : E.BridgeHyp R typ kmin) (sh : MDesc → MX.Shape)
    (hsh1 : ∀ n B v, sh (MDesc.top n B v) = MX.Shape.top n B)
    (hsh2 : ∀ n h μ o BS J sup, sh (MDesc.cls n h μ o BS J sup) = MX.Shape.cls n h μ)
    (n0 n B : ℕ) (v : ℕ → Bits n → ℂ) :
    (((E.kidsTop kmin n0 n B v).map sh : List MX.Shape) : Multiset MX.Shape) = R.kidsS n0 (MX.Shape.top n B) := by
  unfold kidsTop
  simp only [MX.Rule.kidsS]
  rw [H.topN_eq n]
  by_cases hc : n0 ≤ n ∧ R.Nsrc n ≤ B
  · rw [if_pos hc, if_pos hc]
    rw [List.map_flatMap, coe_flatMap, ← H.topN_eq n]
    have e1 : ∀ t, (((E.topRoot kmin n B v t :: (List.range (E.topN kmin n)).map (E.topRest kmin n v t)).map sh :
        List MX.Shape) : Multiset MX.Shape) =
        {MX.Shape.cls n (R.G n) 1} + (R.srcT n).map (fun s => MX.Shape.top (n - s) (2 ^ s)) := by
      intro t
      rw [List.map_cons, List.map_map, ← Multiset.cons_coe, Multiset.singleton_add]
      congr 1
      · unfold topRoot; rw [hsh2, H.topG_eq]
      · rw [← H.topSz_eq n, Multiset.map_coe, List.map_map]
        congr 1
        refine List.map_congr_left (fun j _ => ?_)
        simp only [Function.comp]
        unfold topRest; rw [hsh1]
    simp_rw [e1]
    rw [List.map_const', List.sum_replicate, List.length_range, nsmul_add, Multiset.nsmul_singleton]
    unfold MX.Rule.restMS
    rfl
  · rw [if_neg hc, if_neg hc]
    rfl

end Eng

end
end PowerSaving.RAM
end OAI


namespace OAI
namespace PowerSaving.MCost
open PowerSaving.RAM PowerSaving.MX Ty

universe U V

section
variable {D : Type V}

def msCharge (kidsD : D → Multiset D) (d : D) (tau : D → ℕ) : ℕ := ((kidsD d).map tau).sum

theorem msCharge_hom (kidsD : D → Multiset D) (d : D) (K : ℕ) (f : D → ℕ) :
    msCharge kidsD d (fun c => K * f c) ≤ K * msCharge kidsD d f :=
  le_of_eq Multiset.sum_map_mul_left

theorem mixed_close (R : Rule) {n0 : ℕ} (hn0 : R.m ≤ n0) {J : ℕ → ℕ} (hJ : R.JobRec n0 J)
    (m : Bool) {s t : Ty} (enc : D → T s) (out : D → T t) (shape : D → Shape)
    (kidsD : D → Multiset D) (bnd loc fuel : D → ℕ)
    (hbody : Able m (gfunds enc out (fun d c => c ∈ kidsD d) bnd) s t (fun i => enc i.d)
      (fun i => out i.d) (fun i => loc i.d) (fun i => ((kidsD i.d).map i.tau).sum))
    (hloc : Dom (fun d => R.locS n0 (shape d)) loc)
    (hkids : ∀ d, R.InvS (shape d) → (kidsD d).map shape = R.kidsS n0 (shape d))
    (hbd : ∀ d c, R.InvS (shape d) → c ∈ kidsD d → bnd c ≤ bnd d)
    (hfuel : Can m (fun d : {d // R.InvS (shape d)} => bnd d.1) s Ty.w (fun d => enc d.1)
      (fun d => fuel d.1) (fun d => R.costS n0 J (shape d.1)))
    (hrf : ∀ d, R.InvS (shape d) → (shape d).rank < fuel d)
    (hfs : Small (fun d : {d // R.InvS (shape d)} => bnd d.1) (fun d => fuel d.1))
    {ι : Type U} (dd : ι → D) (hdd : ∀ i, R.InvS (shape (dd i))) :
    Can m (fun i => bnd (dd i)) s t (fun i => enc (dd i)) (fun i => out (dd i))
      (fun i => R.costS n0 J (shape (dd i))) := by
  -- the body's local work, measured by `locS` of the shape
  have hbody' : Able m (gfunds enc out (fun d c => c ∈ kidsD d) bnd) s t (fun i => enc i.d)
      (fun i => out i.d) (fun i => R.locS n0 (shape i.d)) (fun i => msCharge kidsD i.d i.tau) := by
    refine hbody.weaken ?_ (fun _ => le_rfl)
    obtain ⟨C, hC⟩ := hloc
    exact ⟨C, fun i => hC i.d⟩
  have hmem : ∀ d c, c ∈ kidsD d → shape c ∈ (kidsD d).map shape :=
    fun d c hc => Multiset.mem_map_of_mem shape hc
  refine recurse_inv m enc out (fun d c => c ∈ kidsD d) (fun d => R.InvS (shape d)) bnd
    (fun d => R.locS n0 (shape d)) (fun d => (shape d).rank) fuel (fun d => R.costS n0 J (shape d))
    (msCharge kidsD) hbody' ?_ ?_ hbd (fun d _ => msCharge_hom kidsD d) ?_ hfuel hrf hfs dd hdd
  · intro d c hd hc
    have h := hmem d c hc
    rw [hkids d hd] at h
    exact R.kids_inv hn0 hd h
  · intro d c hd hc
    have h := hmem d c hc
    rw [hkids d hd] at h
    exact R.kids_rank hd h
  · intro d hd
    have h := R.bill hn0 hJ (shape d)
    rw [← hkids d hd, Multiset.map_map] at h
    exact h

end

end PowerSaving.MCost
end OAI


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable {E : Eng α ρ σ} {R : MX.Rule} {typ : ℕ → Fin R.K} {kmin : ℕ}

lemma BridgeHyp.kminE (H : E.BridgeHyp R typ kmin) : E.KMin kmin := by
  refine ⟨by rw [← H.hkmin]; exact R.two_le_kmin, ?_⟩
  obtain ⟨k, hk, hW⟩ := R.kmin_att
  have hcard := H.hW k
  rw [← hcard] at hW
  obtain ⟨x, hx⟩ := Finset.card_pos.1 hW
  rw [Finset.mem_filter, Finset.mem_range] at hx
  refine ⟨E.Q.atFin ⟨x, hx.1⟩, ?_⟩
  have h1 := H.htq x hx.1
  rw [hx.2, hk, H.hkmin] at h1
  unfold tq at h1; rw [dif_pos hx.1] at h1
  exact h1

lemma BridgeHyp.cons_eq (H : E.BridgeHyp R typ kmin) (n h μ : ℕ) :
    E.cons n h μ = Multiset.card (R.srcBelow n h μ) := by
  rw [← H.srcSizes_eq n h μ, Multiset.coe_card]; rfl

theorem BridgeHyp.clsLoc_dom (H : E.BridgeHyp R typ kmin) (n0 : ℕ) :
    ∃ C : ℕ, ∀ (n h μ o BS : ℕ) (J sup : ℕ → Bits n → ℂ), E.Valid kmin (MDesc.cls n h μ o BS J sup) →
      E.clsLoc n h μ + 1 ≤ C * (R.locS n0 (MX.Shape.cls n h μ) + 1) := by
  obtain ⟨C, hC⟩ := E.clsLoc_dom H.kminE
  refine ⟨C, fun n h μ o BS J sup hd => ?_⟩
  have := hC n h μ o BS J sup hd
  rw [H.NUc_eq, H.cons_eq] at this
  exact this

lemma kidsUp_shape (sh : MDesc → MX.Shape)
    (hsh2 : ∀ n h μ o BS J sup, sh (MDesc.cls n h μ o BS J sup) = MX.Shape.cls n h μ)
    (n h μ BS : ℕ) (sup : ℕ → Bits n → ℂ) :
    ∀ (ws : GWord α ρ), ws.Proper E.X.n → ∀ (V : E.CState n (h+1) μ) (o : ℕ),
      (E.kidsUp n h μ BS sup V o ws).map sh = (blockRanks ws).map (fun r => MX.Shape.cls n h (μ * r)) := by
  intro ws
  induction ws with
  | nil => intro _ V o; rfl
  | cons mv ws ih =>
    intro hP V o
    cases mv with
    | old mv =>
      cases mv with
      | localM g => exact ih hP.tail _ _
      | shift l z => exact ih hP.tail _ _
      | block l r z ind =>
        have hr : r ≤ E.X.n := (show 1 ≤ r ∧ r < E.X.n from hP.head).2.le
        simp only [kidsUp, dif_pos hr, List.singleton_append, List.map_cons, blockRanks, List.filterMap_cons]
        rw [ih hP.tail]
        simp only [GMove.rk?, GMove.shadow, BMove.rk?, childC, hsh2]
        rfl
    | perm l G => exact ih hP.tail _ _
    | phase l z c => exact ih hP.tail _ _
    | localG gr gi => exact ih hP.tail _ _

lemma kidsLeaf_shape (sh : MDesc → MX.Shape) (hsh1 : ∀ n B v, sh (MDesc.top n B v) = MX.Shape.top n B)
    (n μ : ℕ) (h1 : E.NUc n 0 μ = 1) (hfit : E.X.n * μ ≤ n) :
    ∀ (ws : GWord α ρ), ws.Proper E.X.n → ∀ (V : E.CState n 0 μ),
      (E.kidsLeaf n μ V ws).map sh = (blockRanks ws).map (fun r => MX.Shape.top (μ * r) (2^(n - μ * r))) := by
  intro ws
  induction ws with
  | nil => intro _ V; rfl
  | cons mv ws ih =>
    intro hP V
    cases mv with
    | old mv =>
      cases mv with
      | localM g => exact ih hP.tail _
      | shift l z => exact ih hP.tail _
      | block l r z ind =>
        have hr : r ≤ E.X.n := (show 1 ≤ r ∧ r < E.X.n from hP.head).2.le
        have hk : r * μ ≤ n := le_trans (Nat.mul_le_mul_right _ hr) hfit
        simp only [kidsLeaf, dif_pos hr, List.singleton_append, List.map_cons, blockRanks, List.filterMap_cons]
        rw [ih hP.tail]
        simp only [GMove.rk?, GMove.shadow, BMove.rk?, exitC, dif_pos hk, hsh1, h1, one_mul]
        rw [Nat.mul_comm r μ]
        rfl
    | perm l G => exact ih hP.tail _
    | phase l z c => exact ih hP.tail _
    | localG gr gi => exact ih hP.tail _

lemma ofFn_getD_map {β : Type*} (L : List ℕ) (P : ℕ) (hP : P = L.length) (f : ℕ → β) (g : Fin P → ℕ)
    (hg : ∀ j : Fin P, g j = L.getD j 0) : List.ofFn (fun j => f (g j)) = L.map f := by
  subst hP
  apply List.ext_getElem (by simp)
  intro i h1 h2
  simp only [List.getElem_ofFn, List.getElem_map, hg]
  rw [List.getD_eq_getElem _ _ (by simpa using h1)]

theorem BridgeHyp.kidsC_shape (H : E.BridgeHyp R typ kmin) (sh : MDesc → MX.Shape)
    (hsh1 : ∀ n B v, sh (MDesc.top n B v) = MX.Shape.top n B)
    (hsh2 : ∀ n h μ o BS J sup, sh (MDesc.cls n h μ o BS J sup) = MX.Shape.cls n h μ) (n0 : ℕ)
    (n h μ o BS : ℕ) (J sup : ℕ → Bits n → ℂ) (hd : E.Valid kmin (MDesc.cls n h μ o BS J sup)) :
    (((E.kidsC (MDesc.cls n h μ o BS J sup)).map sh : List MX.Shape) : Multiset MX.Shape) =
      R.kidsS n0 (MX.Shape.cls n h μ) := by
  have hPl : R.P = (blockRanks E.wd).length := H.hP
  cases h with
  | zero =>
    have hk := H.kminE
    have hfit := (E.valid_facts hk hd).1 rfl
    have h1 : E.NUc n 0 μ = 1 := le_antisymm (by simpa using E.NU_le' n 0 μ) (E.NU_pos hk hd)
    simp only [kidsC, MX.Rule.kidsS]
    rw [E.kidsLeaf_shape sh hsh1 n μ h1 hfit E.wd E.hP, Fin.univ_val_map]
    congr 1
    exact (ofFn_getD_map (blockRanks E.wd) R.P hPl (fun r => MX.Shape.top (μ * r) (2^(n - μ * r))) R.rk
      (fun j => H.hrk j)).symm
  | succ h =>
    simp only [kidsC, MX.Rule.kidsS]
    rw [E.kidsUp_shape sh hsh2 n h μ BS sup E.wd E.hP, Fin.univ_val_map]
    congr 1
    exact (ofFn_getD_map (blockRanks E.wd) R.P hPl (fun r => MX.Shape.cls n h (μ * r)) R.rk
      (fun j => H.hrk j)).symm

lemma kidsUp_bnd (n h μ BS : ℕ) (sup : ℕ → Bits n → ℂ) :
    ∀ (ws : GWord α ρ) (V : E.CState n (h+1) μ) (o : ℕ), ∀ c ∈ E.kidsUp n h μ BS sup V o ws,
      bndD c = (BS + 2) * 2^n := by
  intro ws
  induction ws with
  | nil => intro V o c hc; simp [kidsUp] at hc
  | cons mv ws ih =>
    intro V o c hc
    cases mv with
    | old mv =>
      cases mv with
      | localM g => exact ih _ _ c hc
      | shift l z => exact ih _ _ c hc
      | block l r z ind =>
        simp only [kidsUp] at hc
        rcases List.mem_append.1 hc with hc | hc
        · split_ifs at hc with hr
          · rw [List.mem_singleton] at hc; subst hc; rfl
          · simp at hc
        · exact ih _ _ c hc
    | perm l G => exact ih _ _ c hc
    | phase l z c' => exact ih _ _ c hc
    | localG gr gi => exact ih _ _ c hc

lemma kidsLeaf_bnd (n μ BS : ℕ) (hNU : E.NUc n 0 μ ≤ 1) (hμ : 1 ≤ μ) (hfit : E.X.n * μ ≤ n) :
    ∀ (ws : GWord α ρ), ws.Proper E.X.n → ∀ (V : E.CState n 0 μ), ∀ c ∈ E.kidsLeaf n μ V ws,
      bndD c ≤ (BS + 2) * 2^n := by
  intro ws
  induction ws with
  | nil => intro _ V c hc; simp [kidsLeaf] at hc
  | cons mv ws ih =>
    intro hP V c hc
    cases mv with
    | old mv =>
      cases mv with
      | localM g => exact ih hP.tail _ c hc
      | shift l z => exact ih hP.tail _ c hc
      | block l r z ind =>
        have hpr : 1 ≤ r ∧ r < E.X.n := hP.head
        simp only [kidsLeaf] at hc
        rcases List.mem_append.1 hc with hc | hc
        · split_ifs at hc with hr
          · rw [List.mem_singleton] at hc; subst hc
            unfold exitC
            split_ifs with hk
            · show (E.NUc n 0 μ * 2^(n - r * μ) + 2) * 2^(r * μ) ≤ (BS + 2) * 2^n
              have hlt : r * μ < n := lt_of_lt_of_le (Nat.mul_lt_mul_of_pos_right hpr.2 hμ) hfit
              have e1 : 2^(n - r * μ) * 2^(r * μ) = 2^n := by rw [← pow_add, Nat.sub_add_cancel hk]
              have e2 : 2 * 2^(r * μ) ≤ 2^n := by
                rw [← pow_succ']; exact Nat.pow_le_pow_right (by omega) hlt
              have e3 : E.NUc n 0 μ * 2^(n - r * μ) ≤ 2^(n - r * μ) := by
                calc E.NUc n 0 μ * 2^(n - r * μ) ≤ 1 * 2^(n - r * μ) := Nat.mul_le_mul_right _ hNU
                  _ = _ := one_mul _
              have e4 : (E.NUc n 0 μ * 2^(n - r * μ) + 2) * 2^(r * μ) ≤ 2^n + 2^n := by
                calc (E.NUc n 0 μ * 2^(n - r * μ) + 2) * 2^(r * μ) ≤ (2^(n - r * μ) + 2) * 2^(r * μ) :=
                      Nat.mul_le_mul_right _ (by omega)
                  _ = 2^(n - r * μ) * 2^(r * μ) + 2 * 2^(r * μ) := by ring
                  _ ≤ 2^n + 2^n := by rw [e1]; omega
              have e5 : 2^n + 2^n ≤ (BS + 2) * 2^n := by
                calc 2^n + 2^n = 2 * 2^n := by ring
                  _ ≤ (BS + 2) * 2^n := Nat.mul_le_mul_right _ (by omega)
              exact le_trans e4 e5
            · show (0 + 2) * 2^0 ≤ (BS + 2) * 2^n
              simp only [pow_zero, mul_one]; nlinarith [Nat.one_le_two_pow (n:=n)]
          · simp at hc
        · exact ih hP.tail _ c hc
    | perm l G => exact ih hP.tail _ c hc
    | phase l z c' => exact ih hP.tail _ c hc
    | localG gr gi => exact ih hP.tail _ c hc

lemma bnd_kidsC (hk : E.KMin kmin) (n h μ o BS : ℕ) (J sup : ℕ → Bits n → ℂ)
    (hd : E.Valid kmin (MDesc.cls n h μ o BS J sup)) :
    ∀ c ∈ E.kidsC (MDesc.cls n h μ o BS J sup), bndD c ≤ bndD (MDesc.cls n h μ o BS J sup) := by
  intro c hc
  cases h with
  | zero =>
    have hfit := (E.valid_facts hk hd).1 rfl
    have hNU : E.NUc n 0 μ ≤ 1 := by simpa using E.NU_le' n 0 μ
    exact E.kidsLeaf_bnd n μ BS hNU hd.1 hfit E.wd E.hP _ c hc
  | succ h =>
    exact le_of_eq (E.kidsUp_bnd n h μ BS sup E.wd _ o c hc)

end Eng

end
end PowerSaving.RAM
end OAI

namespace OAI.PowerSaving.MX

open Finset

def Phi (g : ℕ → ℝ) : Multiset ℕ →+ ℝ where
  toFun s := (s.map g).sum
  map_zero' := by simp
  map_add' := by intro a b; simp

@[simp] lemma Phi_apply (g : ℕ → ℝ) (s : Multiset ℕ) : Phi g s = (s.map g).sum := rfl

lemma Phi_single (g : ℕ → ℝ) (x : ℕ) : Phi g {x} = g x := by simp

lemma Phi_nsmul_single (g : ℕ → ℝ) (c x : ℕ) : Phi g (c • ({x} : Multiset ℕ)) = (c : ℝ) * g x := by
  rw [map_nsmul, Phi_single, nsmul_eq_mul]

lemma Phi_nonneg {g : ℕ → ℝ} {s : Multiset ℕ} (h : ∀ x ∈ s, 0 ≤ g x) : 0 ≤ Phi g s := by
  simp only [Phi_apply]
  exact Multiset.sum_nonneg (fun y hy => by
    obtain ⟨x, hx, rfl⟩ := Multiset.mem_map.1 hy; exact h x hx)

noncomputable def pw (z : ℝ) : ℕ → ℝ := fun x => (x : ℝ) ^ z

lemma pw_nonneg (z : ℝ) (x : ℕ) : 0 ≤ pw z x := Real.rpow_nonneg (Nat.cast_nonneg x) z

lemma pw_mul (z : ℝ) (a b : ℕ) : pw z (a * b) = pw z a * pw z b := by
  unfold pw; push_cast; exact Real.mul_rpow (Nat.cast_nonneg a) (Nat.cast_nonneg b)

lemma one_le_pw {z : ℝ} (hz : 0 ≤ z) {x : ℕ} (hx : 1 ≤ x) : 1 ≤ pw z x :=
  Real.one_le_rpow (by exact_mod_cast hx) hz

namespace Rule

variable (R : Rule)

def RateQ (z q : ℝ) : Prop := ∑ j, (R.rk j : ℝ) ^ z ≤ q * ∑ k, (R.Wk k : ℝ) * (R.kr k : ℝ) ^ z

theorem phi_out_le {z q : ℝ} (hq : 0 ≤ q) (hrate : R.RateQ z q) (n h ρ : ℕ) :
    Phi (pw z) (∑ j, R.outMS n h ρ j) ≤ q * Phi (pw z) (R.inMS n h ρ) := by
  simp only [outMS, inMS, map_sum, Phi_nsmul_single]
  have hL : ∑ j, ∑ b ∈ R.pts n h ρ, (R.uh h b : ℝ) * pw z (ρ * R.rk j * R.col b) =
      ∑ b ∈ R.pts n h ρ, ((R.uh h b : ℝ) * pw z (ρ * R.col b)) * ∑ j, (R.rk j : ℝ) ^ z := by
    rw [Finset.sum_comm]
    refine Finset.sum_congr rfl (fun b _ => ?_)
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl (fun j _ => ?_)
    rw [show ρ * R.rk j * R.col b = R.rk j * (ρ * R.col b) by ring, pw_mul]
    unfold pw; ring
  have hR : q * ∑ b ∈ R.pts n h ρ, ∑ k, ((R.uh h b * R.Wk k : ℕ) : ℝ) * pw z (ρ * R.kr k * R.col b) =
      ∑ b ∈ R.pts n h ρ, ((R.uh h b : ℝ) * pw z (ρ * R.col b)) *
        (q * ∑ k, (R.Wk k : ℝ) * (R.kr k : ℝ) ^ z) := by
    rw [Finset.mul_sum]
    refine Finset.sum_congr rfl (fun b _ => ?_)
    rw [Finset.mul_sum, Finset.mul_sum, Finset.mul_sum]
    refine Finset.sum_congr rfl (fun k _ => ?_)
    rw [show ρ * R.kr k * R.col b = R.kr k * (ρ * R.col b) by ring, pw_mul]
    unfold pw; push_cast; ring
  rw [hL, hR]
  refine Finset.sum_le_sum (fun b _ => ?_)
  exact mul_le_mul_of_nonneg_left hrate (mul_nonneg (Nat.cast_nonneg _) (pw_nonneg _ _))

theorem phi_exitsSub_le {z : ℝ} (hrate : R.RateQ z 1) (n : ℕ) :
    ∀ h ρ, Phi (pw z) (R.exitsSub n h ρ) ≤ Phi (pw z) (R.inMS n h ρ) + Phi (pw z) (R.srcBelow n h ρ) := by
  intro h
  induction h with
  | zero =>
    intro ρ
    simp only [exitsSub, srcBelow, map_zero, add_zero]
    have := R.phi_out_le zero_le_one hrate n 0 ρ
    rwa [one_mul] at this
  | succ h ih =>
    intro ρ
    simp only [exitsSub, srcBelow, map_sum, map_add]
    have hout := R.phi_out_le zero_le_one hrate n (h + 1) ρ
    rw [one_mul, map_sum] at hout
    calc ∑ j, Phi (pw z) (R.exitsSub n h (ρ * R.rk j))
        ≤ ∑ j, (Phi (pw z) (R.inMS n h (ρ * R.rk j)) + Phi (pw z) (R.srcBelow n h (ρ * R.rk j))) :=
          Finset.sum_le_sum (fun j _ => ih _)
      _ = ∑ j, Phi (pw z) (R.outMS n (h + 1) ρ j) +
            ∑ j, (Phi (pw z) (R.srcMS n h (ρ * R.rk j) ρ) + Phi (pw z) (R.srcBelow n h (ρ * R.rk j))) := by
          rw [← Finset.sum_add_distrib]
          refine Finset.sum_congr rfl (fun j _ => ?_)
          rw [R.balance n h ρ j, map_add]; ring
      _ ≤ Phi (pw z) (R.inMS n (h + 1) ρ) +
            ∑ j, (Phi (pw z) (R.srcMS n h (ρ * R.rk j) ρ) + Phi (pw z) (R.srcBelow n h (ρ * R.rk j))) := by
          linarith

theorem phi_exT_le {z : ℝ} (hrate : R.RateQ z 1) (n : ℕ) : Phi (pw z) (R.exT n) ≤ Phi (pw z) (R.srcT n) := by
  unfold exT srcT; rw [map_add]; exact R.phi_exitsSub_le hrate n _ _

lemma W_pos : 1 ≤ R.W := by
  obtain ⟨k, _, hk⟩ := R.kmin_att
  exact le_trans hk (Finset.single_le_sum (f := R.Wk) (fun _ _ => Nat.zero_le _) (Finset.mem_univ k))

lemma unitsC_le {z : ℝ} (hz : 0 ≤ z) (n h ρ : ℕ) (hρ : 1 ≤ ρ) :
    (R.unitsC n h ρ : ℝ) ≤ Phi (pw z) (R.inMS n h ρ) := by
  simp only [unitsC, inMS, map_sum, Phi_nsmul_single]
  push_cast
  refine Finset.sum_le_sum (fun b _ => ?_)
  have hW : (1 : ℝ) ≤ ∑ k, (R.Wk k : ℝ) := by exact_mod_cast R.W_pos
  calc (R.uh h b : ℝ) = (R.uh h b : ℝ) * 1 := by ring
    _ ≤ (R.uh h b : ℝ) * ∑ k, (R.Wk k : ℝ) := mul_le_mul_of_nonneg_left hW (Nat.cast_nonneg _)
    _ = ∑ k, (R.uh h b : ℝ) * (R.Wk k : ℝ) * 1 := by rw [Finset.mul_sum]; simp
    _ ≤ ∑ k, (R.uh h b : ℝ) * (R.Wk k : ℝ) * pw z (ρ * R.kr k * R.col b) := by
        refine Finset.sum_le_sum (fun k _ => mul_le_mul_of_nonneg_left (one_le_pw hz ?_) (by positivity))
        have := R.kr_pos k; have := R.col_pos b
        exact Nat.one_le_iff_ne_zero.2 (by positivity)

theorem unitsSub_le {z q α : ℝ} (hz : 0 ≤ z) (hq : 0 ≤ q) (hrate : R.RateQ z q) (hα0 : 0 ≤ α)
    (hα : 1 ≤ α * (1 - q)) (n : ℕ) :
    ∀ h ρ, 1 ≤ ρ → (R.unitsSub n h ρ : ℝ) ≤ α * (Phi (pw z) (R.inMS n h ρ) + Phi (pw z) (R.srcBelow n h ρ)) := by
  have hα1 : 1 ≤ α := by nlinarith
  intro h
  induction h with
  | zero =>
    intro ρ hρ
    simp only [unitsSub, srcBelow, map_zero, add_zero]
    have h1 := R.unitsC_le hz n 0 ρ hρ
    have h2 : 0 ≤ Phi (pw z) (R.inMS n 0 ρ) := Phi_nonneg (fun x _ => pw_nonneg z x)
    nlinarith
  | succ h ih =>
    intro ρ hρ
    simp only [unitsSub, srcBelow, map_sum, map_add]
    push_cast
    have hout := R.phi_out_le hq hrate n (h + 1) ρ
    rw [map_sum] at hout
    have h1 := R.unitsC_le hz n (h + 1) ρ hρ
    have hin0 : 0 ≤ Phi (pw z) (R.inMS n (h + 1) ρ) := Phi_nonneg (fun x _ => pw_nonneg z x)
    have hsub : ∑ j, (R.unitsSub n h (ρ * R.rk j) : ℝ) ≤
        α * (∑ j, Phi (pw z) (R.outMS n (h + 1) ρ j) +
          ∑ j, (Phi (pw z) (R.srcMS n h (ρ * R.rk j) ρ) + Phi (pw z) (R.srcBelow n h (ρ * R.rk j)))) := by
      rw [← Finset.sum_add_distrib, Finset.mul_sum]
      refine Finset.sum_le_sum (fun j _ => ?_)
      have := ih (ρ * R.rk j) (le_trans hρ (Nat.le_mul_of_pos_right _ (R.rk_pos j)))
      rw [R.balance n h ρ j, map_add] at this
      linarith
    have : α * ∑ j, Phi (pw z) (R.outMS n (h + 1) ρ j) ≤ α * (q * Phi (pw z) (R.inMS n (h + 1) ρ)) :=
      mul_le_mul_of_nonneg_left hout hα0
    nlinarith

theorem units_le {z q α : ℝ} (hz : 0 ≤ z) (hq : 0 ≤ q) (hrate : R.RateQ z q) (hα0 : 0 ≤ α)
    (hα : 1 ≤ α * (1 - q)) (n : ℕ) : (R.unitsT n : ℝ) ≤ α * Phi (pw z) (R.srcT n) := by
  unfold unitsT srcT; rw [map_add]; exact R.unitsSub_le hz hq hrate hα0 hα n _ _ le_rfl

theorem rate_mono {z1 z : ℝ} (h1 : R.RateQ z1 1) (hz : z1 ≤ z) :
    R.RateQ z (((R.rmax : ℝ) / R.kmin) ^ (z - z1)) := by
  unfold RateQ at *
  rw [one_mul] at h1
  set δ := z - z1 with hδ
  have hδ0 : 0 ≤ δ := by linarith
  have hk0 : (0 : ℝ) < R.kmin := by exact_mod_cast R.kmin_pos
  have hzs : z = z1 + δ := by ring
  have hL : ∑ j, (R.rk j : ℝ) ^ z ≤ (R.rmax : ℝ) ^ δ * ∑ j, (R.rk j : ℝ) ^ z1 := by
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum (fun j _ => ?_)
    have hr : (0 : ℝ) < R.rk j := by exact_mod_cast R.rk_pos j
    rw [hzs, Real.rpow_add hr, mul_comm]
    exact mul_le_mul_of_nonneg_right (Real.rpow_le_rpow hr.le (by exact_mod_cast R.rk_le j) hδ0)
      (Real.rpow_nonneg hr.le _)
  have hR : (R.kmin : ℝ) ^ δ * ∑ k, (R.Wk k : ℝ) * (R.kr k : ℝ) ^ z1 ≤ ∑ k, (R.Wk k : ℝ) * (R.kr k : ℝ) ^ z := by
    rw [Finset.mul_sum]
    refine Finset.sum_le_sum (fun k _ => ?_)
    have hkr : (0 : ℝ) < R.kr k := by exact_mod_cast R.kr_pos k
    rw [hzs, Real.rpow_add hkr]
    have : (R.kmin : ℝ) ^ δ ≤ (R.kr k : ℝ) ^ δ := Real.rpow_le_rpow hk0.le (by exact_mod_cast R.kmin_le k) hδ0
    have h2 : 0 ≤ (R.Wk k : ℝ) * (R.kr k : ℝ) ^ z1 := by positivity
    nlinarith
  have hkd : 0 < (R.kmin : ℝ) ^ δ := Real.rpow_pos_of_pos hk0 _
  rw [Real.div_rpow (Nat.cast_nonneg _) hk0.le]
  have hS : 0 ≤ ∑ j, (R.rk j : ℝ) ^ z1 := Finset.sum_nonneg (fun j _ => Real.rpow_nonneg (Nat.cast_nonneg _) _)
  have hrm : 0 ≤ (R.rmax : ℝ) ^ δ := Real.rpow_nonneg (Nat.cast_nonneg _) _
  calc ∑ j, (R.rk j : ℝ) ^ z ≤ (R.rmax : ℝ) ^ δ * ∑ j, (R.rk j : ℝ) ^ z1 := hL
    _ ≤ (R.rmax : ℝ) ^ δ * ∑ k, (R.Wk k : ℝ) * (R.kr k : ℝ) ^ z1 := mul_le_mul_of_nonneg_left h1 hrm
    _ = (R.rmax : ℝ) ^ δ / (R.kmin : ℝ) ^ δ * ((R.kmin : ℝ) ^ δ * ∑ k, (R.Wk k : ℝ) * (R.kr k : ℝ) ^ z1) := by
        field_simp
    _ ≤ (R.rmax : ℝ) ^ δ / (R.kmin : ℝ) ^ δ * ∑ k, (R.Wk k : ℝ) * (R.kr k : ℝ) ^ z :=
        mul_le_mul_of_nonneg_left hR (div_nonneg hrm hkd.le)

lemma rate_factor_lt_one {δ : ℝ} (hδ : 0 < δ) : ((R.rmax : ℝ) / R.kmin) ^ δ < 1 := by
  have hk0 : (0 : ℝ) < R.kmin := by exact_mod_cast R.kmin_pos
  refine Real.rpow_lt_one (div_nonneg (Nat.cast_nonneg _) hk0.le) ?_ hδ
  rw [div_lt_one hk0]; exact_mod_cast R.sep

end Rule

end OAI.PowerSaving.MX

namespace OAI.PowerSaving.MX

theorem eta_step {m n s : ℕ} {z : ℝ} (hm : 1 ≤ m) (hz0 : 0 ≤ z) (hz1 : z ≤ 1) (hlt : n < m * s) (hle : s ≤ n) :
    (((n - s : ℕ) : ℝ) + 1) ^ z ≤ ((n : ℝ) + 1) ^ z - z / m * (s : ℝ) ^ z := by
  set N1 : ℝ := (n : ℝ) + 1 with hN1def
  have hN1 : 0 < N1 := by positivity
  have hmR : (0 : ℝ) < m := by exact_mod_cast hm
  set x : ℝ := (s : ℝ) / N1 with hxdef
  have hsR : (s : ℝ) ≤ n := by exact_mod_cast hle
  have hx0 : 0 ≤ x := div_nonneg (Nat.cast_nonneg _) hN1.le
  have hx1 : x ≤ 1 := by rw [div_le_one hN1]; linarith
  have hmx : 1 ≤ (m : ℝ) * x := by
    have h1 : ((n : ℝ) + 1) ≤ (m : ℝ) * s := by exact_mod_cast hlt
    rw [hxdef, ← mul_div_assoc, le_div_iff₀ hN1]; linarith
  have hcast : (((n - s : ℕ) : ℝ) + 1) = N1 * (1 - x) := by
    rw [Nat.cast_sub hle, hxdef, hN1def]; field_simp; ring
  have hs : (s : ℝ) = x * N1 := by rw [hxdef]; field_simp
  rw [hcast, Real.mul_rpow hN1.le (by linarith)]
  have hb : (1 - x) ^ z ≤ 1 - z * x := by
    have := rpow_one_add_le_one_add_mul_self (s := -x) (by linarith) hz0 hz1
    simpa [sub_eq_add_neg, mul_neg] using this
  have hxz : x ^ z ≤ 1 := Real.rpow_le_one hx0 hx1 hz0
  have hsz : (s : ℝ) ^ z = x ^ z * N1 ^ z := by rw [hs, Real.mul_rpow hx0 hN1.le]
  have hNz : 0 ≤ N1 ^ z := Real.rpow_nonneg hN1.le _
  rw [hsz]
  have key : z / m * (x ^ z * N1 ^ z) ≤ z * x * N1 ^ z := by
    have h1 : z / m * x ^ z ≤ z * x := by
      rw [div_mul_eq_mul_div, div_le_iff₀ hmR]
      nlinarith [mul_nonneg hz0 hx0]
    nlinarith
  nlinarith [mul_le_mul_of_nonneg_left hb hNz]

theorem lemmaA (t : ℕ → ℝ) (src ex : ℕ → Multiset ℕ) (I : ℕ → ℝ) (n0 : ℕ) {z A η : ℝ}
    (hz : 0 ≤ z) (hA : 0 ≤ A) (hη : 0 < η)
    (hN : ∀ n, n0 ≤ n → src n ≠ 0)
    (hrec : ∀ n, n0 ≤ n → (Multiset.card (src n) : ℝ) * t n ≤
        I n + ((ex n).map t).sum + ((src n).map (fun s => t (n - s))).sum)
    (hsrc : ∀ n, n0 ≤ n → ∀ s ∈ src n, 1 ≤ s ∧ s ≤ n ∧
        (((n - s : ℕ) : ℝ) + 1) ^ z ≤ ((n : ℝ) + 1) ^ z - η * (s : ℝ) ^ z)
    (hex : ∀ n, n0 ≤ n → ∀ e ∈ ex n, e < n)
    (hexPhi : ∀ n, n0 ≤ n →
        ((ex n).map (fun e : ℕ => ((e : ℝ) + 1) ^ z)).sum ≤ η / 2 * ((src n).map (fun s : ℕ => (s : ℝ) ^ z)).sum)
    (hI : ∀ n, n0 ≤ n → I n ≤ A * ((src n).map (fun s : ℕ => (s : ℝ) ^ z)).sum) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ n, t n ≤ C * ((n : ℝ) + 1) ^ z := by
  set S : ℝ := ∑ k ∈ Finset.range n0, |t k| with hS
  have hS0 : 0 ≤ S := Finset.sum_nonneg (fun k _ => abs_nonneg _)
  refine ⟨max (2 * A / η) S, le_trans hS0 (le_max_right _ _), ?_⟩
  set C := max (2 * A / η) S with hC
  have hC0 : 0 ≤ C := le_trans hS0 (le_max_right _ _)
  have hCη : 2 * A ≤ C * η := by
    have := le_max_left (2 * A / η) S
    rw [div_le_iff₀ hη] at this; linarith
  intro n
  induction n using Nat.strong_induction_on with
  | _ n ih =>
  have hpow1 : 1 ≤ ((n : ℝ) + 1) ^ z := Real.one_le_rpow (by linarith [(Nat.cast_nonneg n : (0:ℝ) ≤ n)]) hz
  by_cases hn : n < n0
  · have h1 : t n ≤ |t n| := le_abs_self _
    have h2 : |t n| ≤ S := Finset.single_le_sum (f := fun k => |t k|) (fun _ _ => abs_nonneg _)
      (Finset.mem_range.2 hn)
    have h3 : S ≤ C := le_max_right _ _
    nlinarith
  · push Not at hn
    set Φ : ℝ := ((src n).map (fun s : ℕ => (s : ℝ) ^ z)).sum with hΦ
    have hΦ0 : 0 ≤ Φ := Multiset.sum_nonneg (fun y hy => by
      obtain ⟨x, _, rfl⟩ := Multiset.mem_map.1 hy; exact Real.rpow_nonneg (Nat.cast_nonneg _) _)
    set N : ℝ := (Multiset.card (src n) : ℝ) with hNdef
    have hNpos : 0 < N := by
      rw [hNdef]; exact_mod_cast Multiset.card_pos.2 (hN n hn)
    -- exits
    have hE : ((ex n).map t).sum ≤ C * (η / 2 * Φ) := by
      calc ((ex n).map t).sum ≤ ((ex n).map (fun e : ℕ => C * (((e : ℝ) + 1) ^ z))).sum :=
            Multiset.sum_map_le_sum_map _ _ (fun e he => ih e (hex n hn e he))
        _ = C * ((ex n).map (fun e : ℕ => ((e : ℝ) + 1) ^ z)).sum := Multiset.sum_map_mul_left
        _ ≤ C * (η / 2 * Φ) := mul_le_mul_of_nonneg_left (hexPhi n hn) hC0
    -- rests
    have hRst : ((src n).map (fun s => t (n - s))).sum ≤ C * (N * ((n : ℝ) + 1) ^ z - η * Φ) := by
      calc ((src n).map (fun s => t (n - s))).sum
          ≤ ((src n).map (fun s : ℕ => C * (((n : ℝ) + 1) ^ z - η * (s : ℝ) ^ z))).sum := by
            refine Multiset.sum_map_le_sum_map _ _ (fun s hs => ?_)
            obtain ⟨h1, h2, h3⟩ := hsrc n hn s hs
            have := ih (n - s) (by omega)
            calc t (n - s) ≤ C * (((n - s : ℕ) : ℝ) + 1) ^ z := this
              _ ≤ C * (((n : ℝ) + 1) ^ z - η * (s : ℝ) ^ z) := mul_le_mul_of_nonneg_left h3 hC0
        _ = C * (N * ((n : ℝ) + 1) ^ z - η * Φ) := by
            rw [Multiset.sum_map_mul_left, Multiset.sum_map_sub, Multiset.sum_map_mul_left,
              Multiset.map_const', Multiset.sum_replicate, nsmul_eq_mul]
    have hrec' := hrec n hn
    have hI' := hI n hn
    have key : N * t n ≤ N * (C * ((n : ℝ) + 1) ^ z) := by nlinarith
    exact le_of_mul_le_mul_left key hNpos

end OAI.PowerSaving.MX

namespace OAI.PowerSaving.MX

open Finset

lemma cast_sum_map (s : Multiset ℕ) (f : ℕ → ℕ) :
    ((((s.map f).sum : ℕ)) : ℝ) = (s.map fun x => (f x : ℝ)).sum := by
  rw [Nat.cast_multiset_sum, Multiset.map_map]; rfl

namespace Rule

variable (R : Rule)

lemma exT_lt {n e : ℕ} (he : e ∈ R.exT n) : e < n := (R.exit_size he).2.2

lemma G_zero_or (x : ℕ) : R.G x = 0 ∨ R.m * R.kmin ^ R.G x ≤ x := by
  by_cases h : R.G x = 0
  · exact Or.inl h
  · exact Or.inr (Nat.findGreatest_of_ne_zero (P := fun g => R.m * R.kmin ^ g ≤ x) (n := x) rfl h)

lemma kmin_pow_G_le_src {n s : ℕ} (hs : s ∈ R.srcT n) : R.kmin ^ R.G n ≤ s := by
  rcases R.G_zero_or n with h | h
  · rw [h, pow_zero]; exact R.src_pos hs
  · have h1 := (R.src_size hs).1
    have h2 : R.m * R.kmin ^ R.G n < R.m * s := lt_of_le_of_lt h h1
    exact (Nat.lt_of_mul_lt_mul_left h2).le

lemma exists_N2 : ∃ N2, ∀ n, N2 ≤ n → (R.Q + 2) * (n + 1) ^ (R.Q + 1) ≤ 2 ^ (n / R.m) := by
  obtain ⟨T, hT⟩ := poly_le_two_pow ((R.Q + 2) * R.m ^ (R.Q + 1)) (R.Q + 1)
  have hm : 0 < R.m := by have := R.two_le_m; omega
  refine ⟨R.m * T, fun n hn => ?_⟩
  have ht : T ≤ n / R.m := (Nat.le_div_iff_mul_le hm).2 (by rw [mul_comm]; exact hn)
  have h1 : n + 1 ≤ R.m * (n / R.m + 1) := Nat.lt_mul_div_succ n hm
  calc (R.Q + 2) * (n + 1) ^ (R.Q + 1) ≤ (R.Q + 2) * (R.m * (n / R.m + 1)) ^ (R.Q + 1) :=
        Nat.mul_le_mul_left _ (Nat.pow_le_pow_left h1 _)
    _ = (R.Q + 2) * R.m ^ (R.Q + 1) * (n / R.m + 1) ^ (R.Q + 1) := by rw [mul_pow]; ring
    _ ≤ 2 ^ (n / R.m) := hT _ ht

lemma bracket_le {N2 : ℕ} (hN2 : ∀ n, N2 ≤ n → (R.Q + 2) * (n + 1) ^ (R.Q + 1) ≤ 2 ^ (n / R.m))
    {n x y : ℕ} (hn : N2 ≤ n) (hxy : x + y = n) (hy : n ≤ R.m * y) :
    (R.Nsrc x + 1) * (x + 1) * 2 ^ x + 1 ≤ 2 ^ n := by
  have hx : x + 1 ≤ n + 1 := by omega
  have h0 : 1 ≤ (n + 1) ^ R.Q := Nat.one_le_pow _ _ (by omega)
  have h2 : R.Nsrc x + 1 ≤ (R.Q + 1) * (n + 1) ^ R.Q := by
    have := le_trans (R.Nsrc_poly x) (Nat.mul_le_mul_left R.Q (Nat.pow_le_pow_left hx R.Q))
    have e : (R.Q + 1) * (n + 1) ^ R.Q = R.Q * (n + 1) ^ R.Q + (n + 1) ^ R.Q := by ring
    omega
  have h3 : 1 ≤ (n + 1) ^ (R.Q + 1) := Nat.one_le_pow _ _ (by omega)
  have h1 : (R.Nsrc x + 1) * (x + 1) + 1 ≤ (R.Q + 2) * (n + 1) ^ (R.Q + 1) := by
    have h4 := Nat.mul_le_mul h2 hx
    have h5 : (R.Q + 1) * (n + 1) ^ R.Q * (n + 1) = (R.Q + 1) * (n + 1) ^ (R.Q + 1) := by rw [pow_succ]; ring
    have h6 : (R.Q + 2) * (n + 1) ^ (R.Q + 1) = (R.Q + 1) * (n + 1) ^ (R.Q + 1) + (n + 1) ^ (R.Q + 1) := by ring
    omega
  have h4 : 2 ^ (n / R.m) ≤ 2 ^ y := Nat.pow_le_pow_right (by norm_num) (Nat.div_le_of_le_mul hy)
  have h5 : ((R.Nsrc x + 1) * (x + 1) + 1) * 2 ^ x ≤ 2 ^ y * 2 ^ x :=
    Nat.mul_le_mul_right _ (le_trans h1 (le_trans (hN2 n hn) h4))
  have h6 : 2 ^ y * 2 ^ x = 2 ^ n := by rw [← pow_add]; congr 1; omega
  have h7 : 1 ≤ 2 ^ x := Nat.one_le_two_pow
  have h8 : ((R.Nsrc x + 1) * (x + 1) + 1) * 2 ^ x = (R.Nsrc x + 1) * (x + 1) * 2 ^ x + 2 ^ x := by ring
  omega

lemma exit_room {n e : ℕ} (he : e ∈ R.exT n) : n ≤ R.m * (n - e) := by
  have hlt := R.exT_lt he
  obtain ⟨ρ', j, hej, h2, -, -⟩ := R.mem_exitsSub he
  have h5 : R.rk j < R.m := lt_of_lt_of_le (R.rk_lt_kr j (R.kmin_att.choose)) (R.kr_le _)
  have h6 : R.m * e ≤ n * (R.m - 1) := by
    rw [hej]
    calc R.m * (ρ' * R.rk j) = (R.m * ρ') * R.rk j := by ring
      _ ≤ n * R.rk j := Nat.mul_le_mul_right _ h2
      _ ≤ n * (R.m - 1) := Nat.mul_le_mul_left _ (by omega)
  have h9 : R.m * (n - e) + R.m * e = R.m * n := by rw [← mul_add, Nat.sub_add_cancel hlt.le]
  have h10 : n * (R.m - 1) + n = n * R.m := by
    rw [← mul_add_one]; congr 1; have := R.two_le_m; omega
  have h11 : R.m * n = n * R.m := mul_comm _ _
  omega

lemma Rnd_le {N2 : ℕ} (hN2 : ∀ n, N2 ≤ n → (R.Q + 2) * (n + 1) ^ (R.Q + 1) ≤ 2 ^ (n / R.m))
    {n : ℕ} (hn : N2 ≤ n) : R.Rnd n ≤ (Multiset.card (R.exT n) + R.Nsrc n) * 2 ^ n := by
  unfold Rnd
  rw [add_mul]
  refine Nat.add_le_add ?_ ?_
  · have h := Multiset.sum_le_card_nsmul ((R.exT n).map fun e => (R.Nsrc e + 1) * (e + 1) * 2 ^ e + 1) (2 ^ n)
      (by
        intro y hy
        obtain ⟨e, he, rfl⟩ := Multiset.mem_map.1 hy
        exact R.bracket_le hN2 hn (x := e) (y := n - e) (by have := R.exT_lt he; omega) (R.exit_room he))
    rw [Multiset.card_map, smul_eq_mul] at h
    exact h
  · have h := Multiset.sum_le_card_nsmul
      ((R.srcT n).map fun s => (R.Nsrc (n - s) + 1) * (n - s + 1) * 2 ^ (n - s) + 1) (2 ^ n)
      (by
        intro y hy
        obtain ⟨s, hs, rfl⟩ := Multiset.mem_map.1 hy
        have h1 := R.src_size hs
        exact R.bracket_le hN2 hn (x := n - s) (y := s) (by omega) h1.1.le)
    rw [Multiset.card_map, smul_eq_mul] at h
    exact h

lemma G_ge {n g : ℕ} (hn : R.m * R.kmin ^ g ≤ n) : g ≤ R.G n := by
  show g ≤ Nat.findGreatest (fun g => R.m * R.kmin ^ g ≤ n) n
  have h1 : g < 2 ^ g := Nat.lt_two_pow_self
  have h2 : 2 ^ g ≤ R.kmin ^ g := Nat.pow_le_pow_left R.two_le_kmin g
  have h3 : R.kmin ^ g ≤ R.m * R.kmin ^ g := Nat.le_mul_of_pos_left _ (by have := R.two_le_m; omega)
  exact Nat.le_findGreatest (by omega) hn

theorem exits_small {z1 z η : ℝ} (h12 : z1 < z) (hz : z ≤ 1) (hz0 : 0 ≤ z) (hη : 0 < η)
    (hrate : R.RateQ z1 1) :
    ∃ N, ∀ n, N ≤ n → ((R.exT n).map (fun e : ℕ => ((e : ℝ) + 1) ^ z)).sum ≤
      η / 2 * ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z)).sum := by
  obtain ⟨δ, hδ⟩ : ∃ δ : ℝ, δ = z - z1 := ⟨_, rfl⟩
  have hδ0 : 0 < δ := by rw [hδ]; linarith
  obtain ⟨r, hr⟩ : ∃ r : ℝ, r = (R.rmax : ℝ) / R.kmin := ⟨_, rfl⟩
  have hk0 : (0 : ℝ) < R.kmin := by exact_mod_cast R.kmin_pos
  have hr0 : 0 ≤ r := by rw [hr]; exact div_nonneg (Nat.cast_nonneg _) hk0.le
  have hr1 : r < 1 := by rw [hr, div_lt_one hk0]; exact_mod_cast R.sep
  obtain ⟨ε, hε⟩ : ∃ ε : ℝ, ε = (η / 4) ^ δ⁻¹ := ⟨_, rfl⟩
  have hε0 : 0 < ε := by rw [hε]; exact Real.rpow_pos_of_pos (by linarith) _
  have hR1 : (0 : ℝ) < R.rmax + 1 := by positivity
  obtain ⟨g, hg⟩ := exists_pow_lt_of_lt_one (div_pos hε0 hR1) hr1
  refine ⟨R.m * R.kmin ^ g, fun n hn => ?_⟩
  have hmpos : 0 < R.m := by have := R.two_le_m; omega
  have hmn : R.m ≤ n := le_trans (Nat.le_mul_of_pos_right _ (pow_pos R.kmin_pos g)) hn
  have hG : g ≤ R.G n := R.G_ge hn
  have hm0 : (0 : ℝ) < R.m := by exact_mod_cast hmpos
  obtain ⟨E, hE⟩ : ∃ E : ℝ, E = (R.rmax : ℝ) ^ (R.G n + 1) := ⟨_, rfl⟩
  obtain ⟨Y, hY⟩ : ∃ Y : ℝ, Y = (n : ℝ) / R.m := ⟨_, rfl⟩
  have hY0 : 0 < Y := by
    rw [hY]; exact div_pos (by exact_mod_cast (show 0 < n by omega)) hm0
  have hkG : (R.kmin : ℝ) ^ R.G n ≤ Y := by
    rw [hY, le_div_iff₀ hm0]
    have h := R.m_kmin_pow_G_le hmn
    have h' : R.kmin ^ R.G n * R.m ≤ n := by rw [mul_comm]; exact h
    exact_mod_cast h'
  have hkG0 : (R.kmin : ℝ) ^ R.G n ≠ 0 := by positivity
  have hEY : E ≤ ((R.rmax : ℝ) * r ^ R.G n) * Y := by
    have h : E = ((R.rmax : ℝ) * r ^ R.G n) * (R.kmin : ℝ) ^ R.G n := by
      calc E = (R.rmax : ℝ) * (R.rmax : ℝ) ^ R.G n := by rw [hE, pow_succ, mul_comm]
        _ = (R.rmax : ℝ) * (r ^ R.G n * (R.kmin : ℝ) ^ R.G n) := by
            rw [hr, div_pow, div_mul_cancel₀ _ hkG0]
        _ = ((R.rmax : ℝ) * r ^ R.G n) * (R.kmin : ℝ) ^ R.G n := by ring
    rw [h]
    exact mul_le_mul_of_nonneg_left hkG (mul_nonneg (Nat.cast_nonneg _) (pow_nonneg hr0 _))
  have hrG : (R.rmax : ℝ) * r ^ R.G n ≤ ε := by
    have h1 : r ^ R.G n ≤ r ^ g := pow_le_pow_of_le_one hr0 hr1.le hG
    have h2 : (R.rmax : ℝ) ≤ R.rmax + 1 := by linarith
    have h3 : r ^ g * ((R.rmax : ℝ) + 1) < ε := by rwa [lt_div_iff₀ hR1] at hg
    calc (R.rmax : ℝ) * r ^ R.G n ≤ ((R.rmax : ℝ) + 1) * r ^ g :=
          mul_le_mul h2 h1 (pow_nonneg hr0 _) hR1.le
      _ ≤ ε := by linarith [mul_comm (r ^ g) ((R.rmax : ℝ) + 1)]
  have hE0 : 0 ≤ E := by rw [hE]; positivity
  have hEδ : E ^ δ ≤ η / 4 * Y ^ δ := by
    have hb0 : 0 ≤ (R.rmax : ℝ) * r ^ R.G n := mul_nonneg (Nat.cast_nonneg _) (pow_nonneg hr0 _)
    calc E ^ δ ≤ (((R.rmax : ℝ) * r ^ R.G n) * Y) ^ δ := Real.rpow_le_rpow hE0 hEY hδ0.le
      _ = ((R.rmax : ℝ) * r ^ R.G n) ^ δ * Y ^ δ := Real.mul_rpow hb0 hY0.le
      _ ≤ ε ^ δ * Y ^ δ :=
          mul_le_mul_of_nonneg_right (Real.rpow_le_rpow hb0 hrG hδ0.le) (Real.rpow_nonneg hY0.le _)
      _ = η / 4 * Y ^ δ := by rw [hε, Real.rpow_inv_rpow (by linarith) hδ0.ne']
  -- each exit
  have hexit : ∀ e ∈ R.exT n, ((e : ℝ) + 1) ^ z ≤ 2 * E ^ δ * (e : ℝ) ^ z1 := by
    intro e he
    obtain ⟨h1, h2, -⟩ := R.exit_size he
    have he0 : (1 : ℝ) ≤ e := by exact_mod_cast h1
    have heE : (e : ℝ) ≤ E := by rw [hE]; exact_mod_cast h2
    have h2z : (2 : ℝ) ^ z ≤ 2 := by
      calc (2 : ℝ) ^ z ≤ 2 ^ (1 : ℝ) := Real.rpow_le_rpow_of_exponent_le (by norm_num) hz
        _ = 2 := Real.rpow_one 2
    calc ((e : ℝ) + 1) ^ z ≤ (2 * (e : ℝ)) ^ z := Real.rpow_le_rpow (by positivity) (by linarith) hz0
      _ = 2 ^ z * (e : ℝ) ^ z := Real.mul_rpow (by norm_num) (by positivity)
      _ ≤ 2 * (e : ℝ) ^ z := mul_le_mul_of_nonneg_right h2z (by positivity)
      _ = 2 * ((e : ℝ) ^ z1 * (e : ℝ) ^ δ) := by
          rw [← Real.rpow_add (by linarith)]; congr 2; rw [hδ]; ring
      _ ≤ 2 * ((e : ℝ) ^ z1 * E ^ δ) :=
          mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left
            (Real.rpow_le_rpow (by positivity) heE hδ0.le) (by positivity)) (by norm_num)
      _ = 2 * E ^ δ * (e : ℝ) ^ z1 := by ring
  -- each source
  have hsrc : ∀ s ∈ R.srcT n, Y ^ δ * (s : ℝ) ^ z1 ≤ (s : ℝ) ^ z := by
    intro s hs
    have h1 := (R.src_size hs).1
    have hsY : Y ≤ s := by
      rw [hY, div_le_iff₀ hm0]
      have h' : n ≤ s * R.m := by rw [mul_comm]; exact h1.le
      exact_mod_cast h'
    have hs0 : (0 : ℝ) < s := lt_of_lt_of_le hY0 hsY
    calc Y ^ δ * (s : ℝ) ^ z1 ≤ (s : ℝ) ^ δ * (s : ℝ) ^ z1 :=
          mul_le_mul_of_nonneg_right (Real.rpow_le_rpow hY0.le hsY hδ0.le) (Real.rpow_nonneg hs0.le _)
      _ = (s : ℝ) ^ z := by rw [← Real.rpow_add hs0]; congr 1; rw [hδ]; ring
  -- assemble with Lemma D at z1
  have hD := R.phi_exT_le hrate n
  simp only [Phi_apply, pw] at hD
  have hA : ((R.exT n).map (fun e : ℕ => ((e : ℝ) + 1) ^ z)).sum ≤
      2 * E ^ δ * ((R.exT n).map (fun e : ℕ => (e : ℝ) ^ z1)).sum := by
    rw [← Multiset.sum_map_mul_left]
    exact Multiset.sum_map_le_sum_map _ _ hexit
  have hB : Y ^ δ * ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z1)).sum ≤
      ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z)).sum := by
    rw [← Multiset.sum_map_mul_left]
    exact Multiset.sum_map_le_sum_map _ _ hsrc
  have hS1 : 0 ≤ ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z1)).sum :=
    Multiset.sum_nonneg (fun y hy => by
      obtain ⟨x, _, rfl⟩ := Multiset.mem_map.1 hy; exact Real.rpow_nonneg (Nat.cast_nonneg _) _)
  have hEd0 : 0 ≤ E ^ δ := Real.rpow_nonneg hE0 _
  calc ((R.exT n).map (fun e : ℕ => ((e : ℝ) + 1) ^ z)).sum
      ≤ 2 * E ^ δ * ((R.exT n).map (fun e : ℕ => (e : ℝ) ^ z1)).sum := hA
    _ ≤ 2 * E ^ δ * ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z1)).sum :=
        mul_le_mul_of_nonneg_left hD (by linarith)
    _ ≤ 2 * (η / 4 * Y ^ δ) * ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z1)).sum :=
        mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hEδ (by norm_num)) hS1
    _ = η / 2 * (Y ^ δ * ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z1)).sum) := by ring
    _ ≤ η / 2 * ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z)).sum :=
        mul_le_mul_of_nonneg_left hB (by linarith)

lemma G_succ_le {z : ℝ} (hz : 0 < z) :
    ∃ c : ℝ, 0 ≤ c ∧ ∀ n s, s ∈ R.srcT n → ((R.G n : ℝ) + 1) ≤ c * (s : ℝ) ^ z := by
  have hl : 0 < Real.log 2 := Real.log_pos (by norm_num)
  have hpos : 0 < z * Real.log 2 := mul_pos hz hl
  refine ⟨1 / (z * Real.log 2) + 1, by positivity, fun n s hs => ?_⟩
  have hG2 : (R.G n : ℝ) * (z * Real.log 2) + 1 ≤ (2 : ℝ) ^ ((R.G n : ℝ) * z) := by
    rw [Real.rpow_def_of_pos (by norm_num)]
    have := Real.add_one_le_exp (Real.log 2 * ((R.G n : ℝ) * z))
    have e : Real.log 2 * ((R.G n : ℝ) * z) = (R.G n : ℝ) * (z * Real.log 2) := by ring
    linarith
  have h2s : (2 : ℝ) ^ ((R.G n : ℝ) * z) ≤ (s : ℝ) ^ z := by
    rw [Real.rpow_mul (by norm_num), Real.rpow_natCast]
    apply Real.rpow_le_rpow (by positivity) _ hz.le
    have : 2 ^ R.G n ≤ s := le_trans (Nat.pow_le_pow_left R.two_le_kmin _) (R.kmin_pow_G_le_src hs)
    exact_mod_cast this
  have h1le : 1 ≤ (2 : ℝ) ^ ((R.G n : ℝ) * z) := Real.one_le_rpow (by norm_num) (by positivity)
  have hGle : (R.G n : ℝ) ≤ (2 : ℝ) ^ ((R.G n : ℝ) * z) / (z * Real.log 2) := by
    rw [le_div_iff₀ hpos]; linarith
  calc (R.G n : ℝ) + 1 ≤ (2 : ℝ) ^ ((R.G n : ℝ) * z) / (z * Real.log 2) + (2 : ℝ) ^ ((R.G n : ℝ) * z) := by
        linarith
    _ = (1 / (z * Real.log 2) + 1) * (2 : ℝ) ^ ((R.G n : ℝ) * z) := by ring
    _ ≤ (1 / (z * Real.log 2) + 1) * (s : ℝ) ^ z := mul_le_mul_of_nonneg_left h2s (by positivity)

lemma treeCost_real (J : ℕ → ℕ) (n : ℕ) :
    ((R.treeCost J n : ℕ) : ℝ) = (((2 * R.unitsT n + R.Nsrc n * (R.G n + 1) : ℕ) : ℝ)
      + ((R.exT n).map (fun e => (J e : ℝ) / 2 ^ e)).sum
      + ((R.srcT n).map (fun s => (J (n - s) : ℝ) / 2 ^ (n - s))).sum) * 2 ^ n := by
  have hex : ((((R.exT n).map fun e => 2 ^ (n - e) * J e).sum : ℕ) : ℝ) =
      ((R.exT n).map (fun e => (J e : ℝ) / 2 ^ e)).sum * 2 ^ n := by
    rw [cast_sum_map, ← Multiset.sum_map_mul_right]
    congr 1
    refine Multiset.map_congr rfl (fun e he => ?_)
    have hle : e ≤ n := (R.exT_lt he).le
    have h2 : (2 : ℝ) ^ n = 2 ^ (n - e) * 2 ^ e := by rw [← pow_add, Nat.sub_add_cancel hle]
    have h3 : (2 : ℝ) ^ e ≠ 0 := by positivity
    rw [h2]; push_cast; field_simp
  have hsr : ((((R.srcT n).map fun s => 2 ^ s * J (n - s)).sum : ℕ) : ℝ) =
      ((R.srcT n).map (fun s => (J (n - s) : ℝ) / 2 ^ (n - s))).sum * 2 ^ n := by
    rw [cast_sum_map, ← Multiset.sum_map_mul_right]
    congr 1
    refine Multiset.map_congr rfl (fun s hs => ?_)
    have hle : s ≤ n := (R.src_size hs).2
    have h2 : (2 : ℝ) ^ n = 2 ^ s * 2 ^ (n - s) := by rw [← pow_add, Nat.add_sub_cancel' hle]
    have h3 : (2 : ℝ) ^ (n - s) ≠ 0 := by positivity
    rw [h2]; push_cast; field_simp
  unfold treeCost
  rw [Nat.cast_add, Nat.cast_add, hex, hsr, Nat.cast_mul (2 * R.unitsT n + R.Nsrc n * (R.G n + 1)) (2 ^ n),
    Nat.cast_pow, Nat.cast_ofNat]
  ring

theorem allotM_bound {z1 z : ℝ} (hrate : R.RateQ z1 1) (hz1 : 0 < z1) (h12 : z1 < z) (hz : z ≤ 1)
    {n0 : ℕ} (hn0 : R.m ≤ n0) :
    ∃ C : ℝ, 0 ≤ C ∧ ∀ n, (R.allotM n0 n : ℝ) ≤ C * 2 ^ n * ((n : ℝ) + 1) ^ z := by
  have hz0 : 0 < z := by linarith
  have hm1 : 1 ≤ R.m := by have := R.two_le_m; omega
  have hmR : (0 : ℝ) < R.m := by exact_mod_cast hm1
  have hmR1 : (1 : ℝ) ≤ R.m := by exact_mod_cast hm1
  have hη : 0 < z / (R.m : ℝ) := div_pos hz0 hmR
  have hη1 : z / (R.m : ℝ) ≤ 1 := by rw [div_le_one hmR]; linarith
  obtain ⟨N1, hN1⟩ := R.exits_small h12 hz hz0.le hη hrate
  obtain ⟨N2, hN2⟩ := R.exists_N2
  obtain ⟨cG, hcG0, hcG⟩ := R.G_succ_le hz0
  -- the unit count (Lemma E) at z, with the strict rate factor q
  obtain ⟨q, hq⟩ : ∃ q : ℝ, q = ((R.rmax : ℝ) / R.kmin) ^ (z - z1) := ⟨_, rfl⟩
  have hq0 : 0 ≤ q := by
    rw [hq]; exact Real.rpow_nonneg (div_nonneg (Nat.cast_nonneg _) (Nat.cast_nonneg _)) _
  have hq1 : q < 1 := by rw [hq]; exact R.rate_factor_lt_one (by linarith)
  have hrq : R.RateQ z q := by rw [hq]; exact R.rate_mono hrate h12.le
  obtain ⟨α, hα⟩ : ∃ α : ℝ, α = 1 / (1 - q) := ⟨_, rfl⟩
  have h1q : 0 < 1 - q := by linarith
  have hα0 : 0 ≤ α := by rw [hα]; positivity
  have hα1 : 1 ≤ α * (1 - q) := by rw [hα, one_div, inv_mul_cancel₀ h1q.ne']
  have hunits := R.units_le hz0.le hq0 hrq hα0 hα1
  obtain ⟨A, hA⟩ : ∃ A : ℝ, A = 2 * α + cG + 3 := ⟨_, rfl⟩
  have hA0 : 0 ≤ A := by rw [hA]; linarith
  obtain ⟨n1, hn1⟩ : ∃ n1, n1 = max (max n0 R.m) (max N1 N2) := ⟨_, rfl⟩
  obtain ⟨t, ht⟩ : ∃ t : ℕ → ℝ, t = fun n => (R.allotM n0 n : ℝ) / 2 ^ n := ⟨_, rfl⟩
  obtain ⟨I, hI⟩ : ∃ I : ℕ → ℝ, I = fun n => ((2 * R.unitsT n + R.Nsrc n * (R.G n + 1) : ℕ) : ℝ)
      + ((R.Rnd n + R.Nsrc n : ℕ) : ℝ) / 2 ^ n := ⟨_, rfl⟩
  have hNn : ∀ n, n1 ≤ n → R.srcT n ≠ 0 := by
    intro n hn
    have h := R.Nsrc_pos (n := n) (by rw [hn1] at hn; omega)
    exact Multiset.card_pos.1 (by unfold Nsrc at h; omega)
  have hrec : ∀ n, n1 ≤ n → (Multiset.card (R.srcT n) : ℝ) * t n ≤
      I n + ((R.exT n).map t).sum + ((R.srcT n).map (fun s => t (n - s))).sum := by
    intro n hn
    have hnn0 : n0 ≤ n := by rw [hn1] at hn; omega
    have hle := (R.allotM_upper hn0).2 n hnn0
    have hleR : ((R.Nsrc n * R.allotM n0 n : ℕ) : ℝ) ≤
        ((R.treeCost (R.allotM n0) n + R.Rnd n + R.Nsrc n : ℕ) : ℝ) := by exact_mod_cast hle
    rw [Nat.cast_add, Nat.cast_add, R.treeCost_real, Nat.cast_mul] at hleR
    have h2 : (0 : ℝ) < 2 ^ n := by positivity
    simp only [ht, hI]
    rw [show (Multiset.card (R.srcT n) : ℝ) = (R.Nsrc n : ℝ) from rfl, mul_div_assoc', div_le_iff₀ h2]
    have hx : (((2 * R.unitsT n + R.Nsrc n * (R.G n + 1) : ℕ) : ℝ) + ((R.Rnd n + R.Nsrc n : ℕ) : ℝ) / 2 ^ n
        + ((R.exT n).map (fun e => (R.allotM n0 e : ℝ) / 2 ^ e)).sum
        + ((R.srcT n).map (fun s => (R.allotM n0 (n - s) : ℝ) / 2 ^ (n - s))).sum) * 2 ^ n =
        (((2 * R.unitsT n + R.Nsrc n * (R.G n + 1) : ℕ) : ℝ)
        + ((R.exT n).map (fun e => (R.allotM n0 e : ℝ) / 2 ^ e)).sum
        + ((R.srcT n).map (fun s => (R.allotM n0 (n - s) : ℝ) / 2 ^ (n - s))).sum) * 2 ^ n
        + ((R.Rnd n : ℝ) + (R.Nsrc n : ℝ)) := by
      push_cast; field_simp; ring
    rw [hx]
    linarith
  have hsrc : ∀ n, n1 ≤ n → ∀ s ∈ R.srcT n, 1 ≤ s ∧ s ≤ n ∧
      (((n - s : ℕ) : ℝ) + 1) ^ z ≤ ((n : ℝ) + 1) ^ z - z / (R.m : ℝ) * (s : ℝ) ^ z := by
    intro n _ s hs
    have h1 := R.src_size hs
    exact ⟨R.src_pos hs, h1.2, eta_step hm1 hz0.le hz h1.1 h1.2⟩
  have hex : ∀ n, n1 ≤ n → ∀ e ∈ R.exT n, e < n := fun n _ e he => R.exT_lt he
  have hexPhi : ∀ n, n1 ≤ n → ((R.exT n).map (fun e : ℕ => ((e : ℝ) + 1) ^ z)).sum ≤
      z / (R.m : ℝ) / 2 * ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z)).sum := by
    intro n hn
    exact hN1 n (by rw [hn1] at hn; omega)
  have hIb : ∀ n, n1 ≤ n → I n ≤ A * ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z)).sum := by
    intro n hn
    have hnN1 : N1 ≤ n := by rw [hn1] at hn; omega
    have hnN2 : N2 ≤ n := by rw [hn1] at hn; omega
    obtain ⟨Φ, hΦ⟩ : ∃ Φ : ℝ, Φ = ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z)).sum := ⟨_, rfl⟩
    rw [← hΦ]
    -- units
    have hU : (R.unitsT n : ℝ) ≤ α * Φ := by
      have h := hunits n
      rw [hΦ]; exact h
    -- card of sources
    have hNs : (R.Nsrc n : ℝ) ≤ Φ := by
      rw [hΦ]
      have h : ((R.srcT n).map (fun _ : ℕ => (1 : ℝ))).sum ≤ ((R.srcT n).map (fun s : ℕ => (s : ℝ) ^ z)).sum :=
        Multiset.sum_map_le_sum_map _ _ (fun s hs => Real.one_le_rpow (by exact_mod_cast R.src_pos hs) hz0.le)
      rw [Multiset.map_const', Multiset.sum_replicate, nsmul_eq_mul, mul_one] at h
      exact h
    -- source copies
    have hGs : (R.Nsrc n : ℝ) * ((R.G n : ℝ) + 1) ≤ cG * Φ := by
      rw [hΦ]
      have h : ((R.srcT n).map (fun _ : ℕ => (R.G n : ℝ) + 1)).sum ≤
          ((R.srcT n).map (fun s : ℕ => cG * (s : ℝ) ^ z)).sum :=
        Multiset.sum_map_le_sum_map _ _ (fun s hs => hcG n s hs)
      rw [Multiset.map_const', Multiset.sum_replicate, nsmul_eq_mul, Multiset.sum_map_mul_left] at h
      exact h
    -- exits count
    have hEx : (Multiset.card (R.exT n) : ℝ) ≤ Φ := by
      have h1 : ((R.exT n).map (fun _ : ℕ => (1 : ℝ))).sum ≤ ((R.exT n).map (fun e : ℕ => ((e : ℝ) + 1) ^ z)).sum :=
        Multiset.sum_map_le_sum_map _ _ (fun e _ => Real.one_le_rpow (by linarith [(Nat.cast_nonneg e : (0:ℝ) ≤ e)]) hz0.le)
      rw [Multiset.map_const', Multiset.sum_replicate, nsmul_eq_mul, mul_one] at h1
      have h2 := hN1 n hnN1
      rw [← hΦ] at h2
      have hΦ0 : 0 ≤ Φ := le_trans (Nat.cast_nonneg _) hNs
      nlinarith
    -- leftovers
    have hR : ((R.Rnd n + R.Nsrc n : ℕ) : ℝ) / 2 ^ n ≤ (Multiset.card (R.exT n) : ℝ) + 2 * (R.Nsrc n : ℝ) := by
      have h := R.Rnd_le hN2 hnN2
      have h2 : (0 : ℝ) < 2 ^ n := by positivity
      have h1 : (1 : ℝ) ≤ 2 ^ n := one_le_pow₀ (by norm_num)
      rw [div_le_iff₀ h2]
      have hR' : (R.Rnd n : ℝ) ≤ ((Multiset.card (R.exT n) : ℝ) + (R.Nsrc n : ℝ)) * 2 ^ n := by
        exact_mod_cast h
      push_cast
      nlinarith [(Nat.cast_nonneg (R.Nsrc n) : (0:ℝ) ≤ R.Nsrc n)]
    simp only [hI]
    push_cast at hR ⊢
    rw [hA]
    linarith
  have hL := lemmaA t R.srcT R.exT I n1 hz0.le hA0 hη hNn hrec hsrc hex hexPhi hIb
  obtain ⟨C, hC0, hC⟩ := hL
  refine ⟨C, hC0, fun n => ?_⟩
  have h := hC n
  have h2 : (0 : ℝ) < 2 ^ n := by positivity
  rw [ht] at h
  simp only at h
  rw [div_le_iff₀ h2] at h
  linarith

end Rule

end OAI.PowerSaving.MX


namespace OAI
namespace PowerSaving.MCost
open PowerSaving.RAM PowerSaving.Binary PowerSaving.MX Ty Matrix Finset

noncomputable section

universe U


lemma tape_catB (a b : ℕ) (w : Bits (a+b) → ℂ) :
    (bits (a+b)).tape w = ((bits b).pair (bits a)).tape (fun z => w (catB a b (z.2, z.1))) := by
  refine Layout.verify _ _ 0 _ ?_ ?_
  · change 2 ^ (a + b) = 2 ^ b * 2 ^ a
    rw [pow_add, mul_comm]
  · intro z
    have hl : ((bits b).pair (bits a)).loc z = (bits (a+b)).loc (catB a b (z.2, z.1)) := by
      rw [Layout.pair_loc, catB_loc]
      change (bits b).loc z.1 * 2 ^ a + (bits a).loc z.2 = (bits a).loc z.2 + 2 ^ a * (bits b).loc z.1
      ring
    rw [hl, Layout.read]

lemma tape_castB {k a b : ℕ} (h : a + b = k) (v : Bits k → ℂ) :
    (bits k).tape v = (bits (a+b)).tape (fun z => v (castB h z)) := by
  subst h
  rfl

lemma ripple_castB {k a b : ℕ} (h : a + b = k) (v : Bits k → ℂ) :
    (bits k).tape (ripple k v) = (bits (a+b)).tape (ripple (a+b) (fun z => v (castB h z))) := by
  subst h
  rfl

section
variable {m : Bool} {ι : Type U} {cl : Paint} {s : Ty} {x : ι → T s} {B : ι → ℕ}

theorem transposeC {α β : ι → Type} {L : ∀ i, Layout (α i)} {M : ∀ i, Layout (β i)}
    {f : ∀ i, α i × β i → ℂ}
    (ht : Has m B s (bundle cl) x (fun i => ((L i).pair (M i)).tape (f i)))
    (hL : Knows m B s x (fun i => (L i).n)) (hM : Knows m B s x (fun i => (M i).n))
    (hLs : Small B (fun i => (L i).n)) (hMs : Small B (fun i => (M i).n)) :
    Can m B s (bundle cl) x (fun i => ((M i).pair (L i)).tape (fun z => f i (z.2, z.1)))
      (fun i => (M i).n * (L i).n) := by
  let Q := Σ i, β i × α i
  let σ : Q → ι := Sigma.fst
  let pos (d : Q) : ℕ := ((M d.1).pair (L d.1)).loc d.2
  let E (d : Q) : T (p s w) := (x d.1, pos d)
  have hLQ : Knows m (fun d : Q => B d.1) (p s w) E (fun d => (L d.1).n) :=
    Has.extE (hL.reindex σ)
  have hMQ : Knows m (fun d : Q => B d.1) (p s w) E (fun d => (M d.1).n) :=
    Has.extE (hM.reindex σ)
  have hpos : Knows m (fun d : Q => B d.1) (p s w) E
      (fun d => ((M d.1).pair (L d.1)).loc d.2) := Can.second
  have hsQ : Small (fun d : Q => B d.1) (fun d => (M d.1).n * (L d.1).n) :=
    (hMs.mul hLs).reindex σ
  have hy : Knows m (fun d : Q => B d.1) (p s w) E (fun d => (M d.1).loc d.2.1) :=
    Can.addr_high (L := fun d : Q => M d.1) (R := fun d : Q => L d.1) (u := fun d : Q => d.2) hpos hLQ hsQ
  have hx : Knows m (fun d : Q => B d.1) (p s w) E (fun d => (L d.1).loc d.2.2) :=
    Can.addr_low (L := fun d : Q => M d.1) (R := fun d : Q => L d.1) (u := fun d : Q => d.2) hpos hLQ hsQ
  have hadr : Knows m (fun d : Q => B d.1) (p s w) E
      (fun d => ((L d.1).pair (M d.1)).loc (d.2.2, d.2.1)) :=
    Can.addr_join (L := fun d : Q => L d.1) (R := fun d : Q => M d.1) (u := fun d : Q => (d.2.2, d.2.1))
      hx hy hMQ (hLs.reindex σ) (hMs.reindex σ)
  have hval : Has m (fun d : Q => B d.1) (p s w) (c cl) E (fun d => f d.1 (d.2.2, d.2.1)) :=
    Can.fetch (t := c cl) (L := fun d : Q => (L d.1).pair (M d.1)) (v := fun d : Q => f d.1)
      (i := fun d : Q => (d.2.2, d.2.1)) (Has.extE (ht.reindex σ)) hadr
  have hn : Knows m B s x (fun i => ((M i).pair (L i)).n) := hM.times hL hMs hLs
  have H := Can.layout (L := fun i => (M i).pair (L i)) (t := c cl) (P := fun _ => 0)
    (v := fun i z => f i (z.2, z.1)) hn hval (hMs.mul hLs)
  refine H.mono (fun i => ?_)
  simp

lemma adapter_entry (a b : ℕ) (w : Bits (a+b) → ℂ) (x : Bits a) (y : Bits b) :
    whole b (fun z : Bits a × Bits b => whole a (fun z' : Bits b × Bits a => w (catB a b (z'.2, z'.1)))
      (z.2, z.1)) (x, y) = ripple (a+b) w (catB a b (x, y)) := by
  have e2 : whole b (fun z : Bits a × Bits b =>
      whole a (fun z' : Bits b × Bits a => w (catB a b (z'.2, z'.1))) (z.2, z.1)) (x, y)
      = ripple b (fun y' => hlow (a+b) a w (catB a b (x, y'))) y := by
    show ripple b (fun j => whole a (fun z' : Bits b × Bits a => w (catB a b (z'.2, z'.1))) (j, x)) y = _
    congr 1
    funext y'
    show ripple a (fun j => w (catB a b (j, y'))) x = _
    exact (Binary.hlow_catB a b w x y').symm
  rw [e2, ← Binary.hhigh_catB, hhigh_hlow]

theorem adapter_program (R : Rule) (n0 : ℕ) (J : ℕ → ℕ) (cl : Paint) (m : Bool) {ι : Type U}
    (hTop : ∀ (n b : ι → ℕ) (u : ∀ i, Sim (Bits (b i)) (n i) → ℂ),
      Can m (fun i => (2 ^ b i + 1) * 2 ^ n i) (simIn cl) (bundle cl)
        (fun i => loaded cl (bits (b i)) (n i) (u i))
        (fun i => (sim (bits (b i)) (n i)).tape (whole (n i) (u i)))
        (fun i => R.topCost n0 J (n i) (2 ^ b i)))
    (k : ι → ℕ) (v : ∀ i, Bits (k i) → ℂ) :
    Can m (fun i => 2 ^ k i) (simIn cl) (bundle cl) (fun i => givenBits cl (k i) (v i))
      (fun i => (bits (k i)).tape (ripple (k i) (v i))) (fun i => R.adapterCost n0 J (k i)) := by
  let a : ι → ℕ := fun i => k i / 2
  let b : ι → ℕ := fun i => k i - k i / 2
  have hab : ∀ i, a i + b i = k i := fun i => by simp only [a, b]; omega
  let vw (i : ι) : Bits (a i + b i) → ℂ := fun z => v i (castB (hab i) z)
  let Bd : ι → ℕ := fun i => 2 ^ k i
  let Wt : ι → ℕ := fun i => R.adapterCost n0 J (k i)
  -- sizes
  have hk2 : ∀ i, k i ≤ 2 ^ k i := fun i => (Nat.lt_two_pow_self).le
  have sK : Small Bd k := ⟨1, fun i => by simp only [Bd, pow_one]; have := hk2 i; omega⟩
  have sA : Small Bd a := sK.mono (fun i => Nat.div_le_self _ _)
  have sB : Small Bd b := sK.mono (fun i => Nat.sub_le _ _)
  have h2ak : ∀ i, 2 ^ a i ≤ 2 ^ k i := fun i => Nat.pow_le_pow_right (by norm_num) (Nat.div_le_self _ _)
  have h2bk : ∀ i, 2 ^ b i ≤ 2 ^ k i := fun i => Nat.pow_le_pow_right (by norm_num) (Nat.sub_le _ _)
  have s2A : Small Bd (fun i => 2 ^ a i) := ⟨1, fun i => by simp only [Bd, pow_one]; have := h2ak i; omega⟩
  have s2B : Small Bd (fun i => 2 ^ b i) := ⟨1, fun i => by simp only [Bd, pow_one]; have := h2bk i; omega⟩
  have hkab : ∀ i, 2 ^ a i * 2 ^ b i = 2 ^ k i := fun i => by rw [← pow_add, hab i]
  have sD1 : Small Bd (fun i => (2 ^ b i + 1) * 2 ^ a i) := ⟨2, fun i => by
    have h1 : (2 ^ b i + 1) * 2 ^ a i ≤ 2 * 2 ^ k i := by
      have := hkab i; have := h2ak i; nlinarith
    simp only [Bd]; nlinarith⟩
  have sD2 : Small Bd (fun i => (2 ^ a i + 1) * 2 ^ b i) := ⟨2, fun i => by
    have h1 : (2 ^ a i + 1) * 2 ^ b i ≤ 2 * 2 ^ k i := by
      have := hkab i; have := h2bk i; nlinarith
    simp only [Bd]; nlinarith⟩
  -- the budget
  have hWk : ∀ i, 2 ^ k i ≤ Wt i := fun i => by simp only [Wt, Rule.adapterCost]; exact Nat.le_add_left _ _
  have hW1 : ∀ i, R.topCost n0 J (a i) (2 ^ b i) ≤ Wt i := fun i => by
    simp only [Wt, Rule.adapterCost, a, b]; exact le_trans (Nat.le_add_right _ _) (Nat.le_add_right _ _)
  have hW2 : ∀ i, R.topCost n0 J (b i) (2 ^ a i) ≤ Wt i := fun i => by
    simp only [Wt, Rule.adapterCost, a, b]; exact le_trans (Nat.le_add_left _ _) (Nat.le_add_right _ _)
  have dA : Dom Wt a := Dom.of_le (fun i => le_trans (Nat.div_le_self _ _) (le_trans (hk2 i) (hWk i)))
  have dB : Dom Wt b := Dom.of_le (fun i => le_trans (Nat.sub_le _ _) (le_trans (hk2 i) (hWk i)))
  -- stage A: the input and the two powers
  let x0 : ι → T (simIn cl) := fun i => givenBits cl (k i) (v i)
  have hk : Knows m Bd (simIn cl) x0 k := Can.first
  have ha : Knows m Bd (simIn cl) x0 a := hk.dvdW (Can.wc 2) sK
  have hb : Knows m Bd (simIn cl) x0 b := hk.minus ha sK
  have h2a : Can m Bd (simIn cl) w x0 (fun i => 2 ^ a i) Wt :=
    Can.wTwo (Has.atW ha) sA s2A dA
  have h2b : Can m Bd (simIn cl) w x0 (fun i => 2 ^ b i) Wt :=
    Can.wTwo (Has.atW hb) sB s2B dB
  let sE : Ty := p (simIn cl) (p w w)
  let E0 : ι → T sE := fun i => (x0 i, (2 ^ a i, 2 ^ b i))
  have hE0 : Can m Bd (simIn cl) sE x0 E0 Wt := Can.pair Can.id (Can.pair h2a h2b)
  -- stage B: pass 1, the kernel on the low `a` bits of each of the `2^b` slices
  let u1 (i : ι) : Sim (Bits (b i)) (a i) → ℂ := fun z => vw i (catB (a i) (b i) (z.2, z.1))
  have hin1 : Can m Bd sE (simIn cl) E0 (fun i => loaded cl (bits (b i)) (a i) (u1 i)) Wt := by
    have ha' : Knows m Bd sE E0 a := Has.extE ha
    have hr : Has m Bd sE (p sc (bundle cl)) E0 (fun i => (x0 i).2) := Has.extE Can.second
    refine (Has.atW (Can.pair ha' hr)).cong (fun _ => rfl) (fun i => ?_)
    show (a i, (x0 i).2) = loaded cl (bits (b i)) (a i) (u1 i)
    simp only [x0, givenBits, loaded]
    rw [tape_castB (hab i), tape_catB]
    rfl
  let t1 : ι → T (bundle cl) := fun i => (sim (bits (b i)) (a i)).tape (whole (a i) (u1 i))
  have hp1 : Can m Bd (simIn cl) (bundle cl) (fun i => loaded cl (bits (b i)) (a i) (u1 i)) t1 Wt :=
    ((hTop a b u1).ambient sD1).mono hW1
  have hT1 : Can m Bd sE (bundle cl) E0 t1 Wt := hin1.then_do hp1
  -- stage C: transpose
  let u2 (i : ι) : Sim (Bits (a i)) (b i) → ℂ := fun z => whole (a i) (u1 i) (z.2, z.1)
  let t1' : ι → T (bundle cl) := fun i => ((bits (a i)).pair (bits (b i))).tape (u2 i)
  have hTr1 : Can m Bd (p sE (bundle cl)) (bundle cl) (fun i => (E0 i, t1 i)) t1' Wt := by
    have H := transposeC (m := m) (B := Bd) (cl := cl) (s := p sE (bundle cl))
      (x := fun i => (E0 i, t1 i)) (L := fun i => bits (b i)) (M := fun i => bits (a i))
      (f := fun i => whole (a i) (u1 i)) Can.second
      (Has.extE (Can.second.then_do Can.second))
      (Has.extE (Can.second.then_do Can.first)) s2B s2A
    refine H.mono (fun i => ?_)
    change 2 ^ a i * 2 ^ b i ≤ Wt i
    rw [hkab i]; exact hWk i
  have hT1' : Can m Bd sE (bundle cl) E0 t1' Wt := Can.bind hT1 hTr1
  -- stage D: pass 2, the kernel on the high `b` bits
  have hin2 : Can m Bd (p sE (bundle cl)) (simIn cl) (fun i => (E0 i, t1' i))
      (fun i => loaded cl (bits (a i)) (b i) (u2 i)) Wt := by
    have hb2 : Knows m Bd (p sE (bundle cl)) (fun i => (E0 i, t1' i)) b :=
      Has.extE (Has.extE hb)
    have hI : Has m Bd (p sE (bundle cl)) sc (fun i => (E0 i, t1' i)) (fun i => (x0 i).2.1) :=
      Has.extE (Has.extE Can.second.fst)
    have ht : Has m Bd (p sE (bundle cl)) (bundle cl) (fun i => (E0 i, t1' i)) t1' := Can.second
    exact (Has.atW (Can.pair hb2 (Can.pair hI ht))).cong (fun _ => rfl)
      (fun i => rfl)
  let t2 : ι → T (bundle cl) := fun i => (sim (bits (a i)) (b i)).tape (whole (b i) (u2 i))
  have hp2 : Can m Bd (simIn cl) (bundle cl) (fun i => loaded cl (bits (a i)) (b i) (u2 i)) t2 Wt :=
    ((hTop b a u2).ambient sD2).mono hW2
  have hT2 : Can m Bd sE (bundle cl) E0 t2 Wt := Can.bind hT1' (hin2.then_do hp2)
  -- stage E: transpose back
  let t3 : ι → T (bundle cl) := fun i =>
    ((bits (b i)).pair (bits (a i))).tape (fun z => whole (b i) (u2 i) (z.2, z.1))
  have hTr2 : Can m Bd (p sE (bundle cl)) (bundle cl) (fun i => (E0 i, t2 i)) t3 Wt := by
    have H := transposeC (m := m) (B := Bd) (cl := cl) (s := p sE (bundle cl))
      (x := fun i => (E0 i, t2 i)) (L := fun i => bits (a i)) (M := fun i => bits (b i))
      (f := fun i => whole (b i) (u2 i)) Can.second
      (Has.extE (Can.second.then_do Can.first))
      (Has.extE (Can.second.then_do Can.second)) s2A s2B
    refine H.mono (fun i => ?_)
    change 2 ^ b i * 2 ^ a i ≤ Wt i
    rw [mul_comm, hkab i]; exact hWk i
  have hT3 : Can m Bd sE (bundle cl) E0 t3 Wt := Can.bind hT2 hTr2
  -- the output is the kernel on all `k` bits
  refine (hE0.then_do hT3).cong (fun _ => rfl) (fun i => ?_)
  show t3 i = (bits (k i)).tape (ripple (k i) (v i))
  rw [ripple_castB (hab i), tape_catB]
  simp only [t3]
  congr 1
  funext z
  exact adapter_entry (a i) (b i) (vw i) z.2 z.1

end

end
end PowerSaving.MCost
end OAI


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

universe U

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable (E : Eng α ρ σ)

def shapeD : MDesc → MX.Shape
  | .top n B _ => .top n B
  | .cls n h μ _ _ _ _ => .cls n h μ

def nD : MDesc → ℕ
  | .top n _ _ => n
  | .cls n _ _ _ _ _ _ => n

def fuelD (d : MDesc) : ℕ := (nD d + 1) * (nD d + 2) + 1

lemma enc_fst (cl : Paint) (d : MDesc) : (E.enc cl d).1 = nD d := by
  cases d <;> rfl

lemma bndD_ge (d : MDesc) : 2 ^ nD d ≤ bndD d := by
  cases d with
  | top n B v => exact Nat.le_mul_of_pos_left _ (by omega)
  | cls n h μ o BS J sup => exact Nat.le_mul_of_pos_left _ (by omega)

lemma can_fuel {kmin : ℕ} (cl : Paint) (m : Bool) {P : E.VD kmin → Prop} :
    Can m (fun d : {d : E.VD kmin // P d} => bndD d.1.1) (portIn cl) w (fun d => E.encV kmin cl d.1)
      (fun d => fuelD d.1.1) (fun _ => 0) := by
  have hn : Knows m (fun d : {d : E.VD kmin // P d} => bndD d.1.1) (portIn cl) (fun d => E.encV kmin cl d.1)
      (fun d => nD d.1.1) := (Can.first).cong (fun _ => rfl) (fun d => E.enc_fst cl d.1.1)
  have hns : Small (fun d : {d : E.VD kmin // P d} => bndD d.1.1) (fun d => nD d.1.1) :=
    ⟨1, fun d => by have := bndD_ge d.1.1; have := (Nat.lt_two_pow_self : nD d.1.1 < 2 ^ nD d.1.1); simp; omega⟩
  have h1 := hn.plus (Can.wc 1) hns (Small.const _ 1)
  have h2 := hn.plus (Can.wc 2) hns (Small.const _ 2)
  have h3 := h1.times h2 (hns.add (Small.const _ 1)) (hns.add (Small.const _ 2))
  exact h3.plus (Can.wc 1) ((hns.add (Small.const _ 1)).mul (hns.add (Small.const _ 2))) (Small.const _ 1)

lemma small_fuel {kmin : ℕ} {P : E.VD kmin → Prop} :
    Small (fun d : {d : E.VD kmin // P d} => bndD d.1.1) (fun d => fuelD d.1.1) := by
  refine ⟨2, fun d => ?_⟩
  have h1 := bndD_ge d.1.1
  have h2 : nD d.1.1 < 2 ^ nD d.1.1 := Nat.lt_two_pow_self
  unfold fuelD
  nlinarith

lemma rank_lt_fuel (R : MX.Rule) (d : MDesc) (hd : R.InvS (shapeD d)) : (shapeD d).rank < fuelD d := by
  cases d with
  | top n B v => simp only [shapeD, MX.Shape.rank, fuelD, nD]; omega
  | cls n h μ o BS J sup =>
    simp only [shapeD, MX.Rule.InvS] at hd
    simp only [shapeD, MX.Shape.rank, fuelD, nD]
    have h1 : 2 ^ h ≤ R.kmin ^ h := Nat.pow_le_pow_left R.two_le_kmin _
    have h2 : R.kmin ^ h ≤ R.m * μ * R.kmin ^ h := by
      have : 1 ≤ R.m * μ := Nat.one_le_iff_ne_zero.2 (Nat.mul_ne_zero (by have := R.two_le_m; omega) (by omega))
      exact Nat.le_mul_of_pos_left _ this
    have h3 : h < 2 ^ h := Nat.lt_two_pow_self
    have hh : h ≤ n := by omega
    nlinarith

lemma bnd_kidsTop (kmin n0 n B : ℕ) (v : ℕ → Bits n → ℂ) :
    ∀ c ∈ E.kidsTop kmin n0 n B v, bndD c ≤ bndD (MDesc.top n B v) := by
  intro c hc
  unfold kidsTop at hc
  split_ifs at hc with hcond
  · obtain ⟨t, ht, hc⟩ := List.mem_flatMap.1 hc
    have hlam : 1 ≤ B / E.topN kmin n := by have := List.mem_range.1 ht; omega
    rcases List.mem_cons.1 hc with rfl | hc
    · simp only [topRoot, bndD]; exact le_rfl
    · obtain ⟨j, -, rfl⟩ := List.mem_map.1 hc
      simp only [topRest, bndD]
      have hs := topSz_le E kmin n j
      have hB : 1 ≤ B := by
        have h1 : E.topN kmin n ≠ 0 := by intro h0; rw [h0, Nat.div_zero] at hlam; omega
        have := hcond.2; omega
      have e1 : (2 ^ E.topSz kmin n j + 2) * 2 ^ (n - E.topSz kmin n j) =
          2 ^ n + 2 * 2 ^ (n - E.topSz kmin n j) := by
        rw [add_mul, ← pow_add, Nat.add_sub_cancel' hs]
      have e2 : 2 ^ (n - E.topSz kmin n j) ≤ 2 ^ n := Nat.pow_le_pow_right (by omega) (Nat.sub_le _ _)
      rw [e1]
      have e3 : 1 * 2 ^ n ≤ B * 2 ^ n := Nat.mul_le_mul_right _ hB
      have e4 : (B + 2) * 2 ^ n = B * 2 ^ n + 2 * 2 ^ n := by ring
      rw [e4]
      omega
  · simp at hc

end Eng

end
end PowerSaving.RAM
end OAI


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ] (E : Eng α ρ σ)

lemma kmin_pow_topG (kmin n : ℕ) (hk : 2 ≤ kmin) : kmin ^ E.topG kmin n ≤ n + 1 := by
  by_cases h0 : E.topG kmin n = 0
  · rw [h0]; simp
  · have hP : E.mx * kmin ^ E.topG kmin n ≤ n :=
      Nat.findGreatest_of_ne_zero (P := fun g => E.mx * kmin ^ g ≤ n) (n := n) (m := E.topG kmin n) rfl h0
    have h3 : 1 ≤ E.mx := le_trans (by norm_num) E.three
    have : kmin ^ E.topG kmin n ≤ E.mx * kmin ^ E.topG kmin n := Nat.le_mul_of_pos_left _ h3
    omega

lemma pow_topG_le (kmin n b : ℕ) (hk : 2 ≤ kmin) : b ^ E.topG kmin n ≤ (n + 1) ^ b := by
  have hb : b ≤ kmin ^ b := le_trans (Nat.lt_two_pow_self).le (Nat.pow_le_pow_left hk _)
  calc b ^ E.topG kmin n ≤ (kmin ^ b) ^ E.topG kmin n := Nat.pow_le_pow_left hb _
    _ = (kmin ^ E.topG kmin n) ^ b := by rw [← pow_mul, ← pow_mul, mul_comm]
    _ ≤ (n + 1) ^ b := Nat.pow_le_pow_left (E.kmin_pow_topG kmin n hk) _

lemma Ptop_poly (kmin n M Q : ℕ) (hM1 : E.W ≤ M) (hM2 : E.nB + 1 ≤ M) (hM3 : 2 ≤ M)
    (hQ : Q = M ^ E.topG kmin n) :
    E.Ptop kmin n ≤ (64 * (E.W + 1) * (E.nB + 1) + 64) * ((Q * Q) * ((n + 1) * (n + 1))) := by
  have hGn : E.topG kmin n ≤ n := E.topG_le kmin n
  have hQ1 : 1 ≤ Q := by rw [hQ]; exact Nat.one_le_pow _ _ (by omega)
  have hWQ : E.W ^ E.topG kmin n ≤ Q := by rw [hQ]; exact Nat.pow_le_pow_left hM1 _
  have hBQ : (E.nB + 1) ^ E.topG kmin n ≤ Q := by rw [hQ]; exact Nat.pow_le_pow_left hM2 _
  have hNU : E.NUc n (E.topG kmin n) 1 ≤ Q := le_trans (MXR.NU_le _ _ _) hWQ
  generalize hX : (Q * Q) * ((n + 1) * (n + 1)) = X
  have hn1 : 1 ≤ n + 1 := by omega
  have hQQ : Q ≤ Q * Q := Nat.le_mul_of_pos_left _ hQ1
  have hnn : n + 1 ≤ (n + 1) * (n + 1) := Nat.le_mul_of_pos_left _ hn1
  have a1 : Q * Q * (n + 1) ≤ X := by rw [← hX]; exact Nat.mul_le_mul_left _ hnn
  have a2 : Q * (n + 1) ≤ X := by rw [← hX]; exact Nat.mul_le_mul hQQ hnn
  have a3 : Q ≤ X := le_trans (Nat.le_mul_of_pos_right _ hn1) a2
  have a4 : (n + 1) * (n + 1) ≤ X := by rw [← hX]; exact Nat.le_mul_of_pos_left _ (Nat.mul_pos hQ1 hQ1)
  -- the five terms
  have t12 : (n + 1) + (n * (n + 3) + 1) ≤ 4 * X := by nlinarith
  have t3 : E.idxCost n (E.topG kmin n) 1 ≤ 8 * X := by
    unfold idxCost
    have h1 : E.W ^ E.topG kmin n + 1 ≤ 2 * Q := by omega
    have h2 : E.topG kmin n + 2 ≤ 2 * (n + 1) := by omega
    calc (E.W ^ E.topG kmin n + 1) * (E.W ^ E.topG kmin n + 1) * (E.topG kmin n + 2)
        ≤ (2 * Q) * (2 * Q) * (2 * (n + 1)) := Nat.mul_le_mul (Nat.mul_le_mul h1 h1) h2
      _ = 8 * (Q * Q * (n + 1)) := by ring
      _ ≤ 8 * X := Nat.mul_le_mul_left _ a1
  have t4 : E.NUc n (E.topG kmin n) 1 * (4 * n + 4 * E.topG kmin n + 8) ≤ 8 * X := by
    calc E.NUc n (E.topG kmin n) 1 * (4 * n + 4 * E.topG kmin n + 8) ≤ Q * (8 * (n + 1)) :=
          Nat.mul_le_mul hNU (by omega)
      _ = 8 * (Q * (n + 1)) := by ring
      _ ≤ 8 * X := Nat.mul_le_mul_left _ a2
  have t5 : E.cstC (E.topG kmin n) ≤ (16 * (E.W + 1) * (E.nB + 1) + 2) * X := by
    refine le_trans (E.cstC_le _) ?_
    have hb : (E.nB + 1) ^ E.topG kmin n ≤ Q := hBQ
    unfold locH
    have h1 : E.W ^ E.topG kmin n * E.W * (2 * E.topG kmin n + 3 + 1) ≤ Q * E.W * (8 * (n + 1)) :=
      Nat.mul_le_mul (Nat.mul_le_mul_right _ hWQ) (by omega)
    have h2 : E.nB * (E.W ^ E.topG kmin n * E.W * (2 * E.topG kmin n + 3 + 1) + 1 + (E.topG kmin n + 1) + 4) + 2 ≤
        E.nB * (Q * E.W * (8 * (n + 1)) + 8 * (n + 1)) + 2 := by
      have := Nat.mul_le_mul_left E.nB (show E.W ^ E.topG kmin n * E.W * (2 * E.topG kmin n + 3 + 1) + 1 +
        (E.topG kmin n + 1) + 4 ≤ Q * E.W * (8 * (n + 1)) + 8 * (n + 1) by omega)
      omega
    calc (E.nB + 1) ^ E.topG kmin n * (E.nB * (E.W ^ E.topG kmin n * E.W * (2 * E.topG kmin n + 3 + 1) + 1 +
          (E.topG kmin n + 1) + 4) + 2)
        ≤ Q * (E.nB * (Q * E.W * (8 * (n + 1)) + 8 * (n + 1)) + 2) := Nat.mul_le_mul hb h2
      _ = 8 * (E.nB * E.W) * (Q * Q * (n + 1)) + 8 * E.nB * (Q * (n + 1)) + 2 * Q := by ring
      _ ≤ 8 * (E.nB * E.W) * X + 8 * E.nB * X + 2 * X :=
          Nat.add_le_add (Nat.add_le_add (Nat.mul_le_mul_left _ a1) (Nat.mul_le_mul_left _ a2))
            (Nat.mul_le_mul_left _ a3)
      _ = (8 * (E.nB * E.W) + 8 * E.nB + 2) * X := by ring
      _ ≤ (16 * (E.W + 1) * (E.nB + 1) + 2) * X := by
          apply Nat.mul_le_mul_right
          have : 16 * (E.W + 1) * (E.nB + 1) = 16 * (E.nB * E.W) + 16 * E.W + 16 * E.nB + 16 := by ring
          omega
  unfold Ptop
  have hfin : (4 + 8 + 8 + (16 * (E.W + 1) * (E.nB + 1) + 2)) * X ≤ (64 * (E.W + 1) * (E.nB + 1) + 64) * X := by
    apply Nat.mul_le_mul_right
    have : 1 ≤ (E.W + 1) * (E.nB + 1) := Nat.one_le_iff_ne_zero.2 (by positivity)
    have e : 64 * (E.W + 1) * (E.nB + 1) = 64 * ((E.W + 1) * (E.nB + 1)) := by ring
    have e' : 16 * (E.W + 1) * (E.nB + 1) = 16 * ((E.W + 1) * (E.nB + 1)) := by ring
    omega
  have e6 : (4 + 8 + 8 + (16 * (E.W + 1) * (E.nB + 1) + 2)) * X =
      4 * X + 8 * X + 8 * X + (16 * (E.W + 1) * (E.nB + 1) + 2) * X := by ring
  omega

theorem Ptop_le (kmin : ℕ) (hk : 2 ≤ kmin) : ∃ D : ℕ, ∀ n, E.Ptop kmin n ≤ D * 2 ^ n := by
  obtain ⟨M, hM⟩ : ∃ M, M = (E.W + 1) * (E.nB + 1) * 2 := ⟨_, rfl⟩
  have hM1 : E.W ≤ M := by rw [hM]; nlinarith
  have hM2 : E.nB + 1 ≤ M := by rw [hM]; nlinarith
  have hM3 : 2 ≤ M := by rw [hM]; nlinarith
  obtain ⟨D0, hD0⟩ := MX.succ_pow_le_two_pow (2 * M + 2)
  refine ⟨(64 * (E.W + 1) * (E.nB + 1) + 64) * D0, fun n => ?_⟩
  have h1 := E.Ptop_poly kmin n M (M ^ E.topG kmin n) hM1 hM2 hM3 rfl
  have hQn : M ^ E.topG kmin n ≤ (n + 1) ^ M := E.pow_topG_le kmin n M hk
  have hpoly : (M ^ E.topG kmin n * M ^ E.topG kmin n) * ((n + 1) * (n + 1)) ≤ (n + 1) ^ (2 * M + 2) := by
    have : (M ^ E.topG kmin n * M ^ E.topG kmin n) * ((n + 1) * (n + 1)) ≤
        ((n + 1) ^ M * (n + 1) ^ M) * ((n + 1) * (n + 1)) := Nat.mul_le_mul_right _ (Nat.mul_le_mul hQn hQn)
    refine le_trans this (le_of_eq ?_)
    ring
  calc E.Ptop kmin n ≤ (64 * (E.W + 1) * (E.nB + 1) + 64) * ((M ^ E.topG kmin n * M ^ E.topG kmin n) * ((n + 1) * (n + 1))) := h1
    _ ≤ (64 * (E.W + 1) * (E.nB + 1) + 64) * (D0 * 2 ^ n) := Nat.mul_le_mul_left _ (le_trans hpoly (hD0 n))
    _ = (64 * (E.W + 1) * (E.nB + 1) + 64) * D0 * 2 ^ n := by ring


variable {E} {R : MX.Rule} {typ : ℕ → Fin R.K} {kmin : ℕ}

theorem BridgeHyp.locTop_dom (H : E.BridgeHyp R typ kmin) (hk : 2 ≤ kmin) (n0 : ℕ) :
    ∃ C : ℕ, ∀ n B, E.locTop kmin n0 n B + 1 ≤ C * (R.locS n0 (MX.Shape.top n B) + 1) := by
  obtain ⟨D, hD⟩ := E.Ptop_le kmin hk
  refine ⟨D + 2, fun n B => ?_⟩
  unfold locTop
  simp only [MX.Rule.locS]
  by_cases hn : n0 ≤ n
  · rw [if_pos hn, if_pos hn, H.topN_eq n]
    have h1 := hD n
    have hX : 2 ^ n ≤ (B + 1) * 2 ^ n := Nat.le_mul_of_pos_left _ (Nat.succ_pos _)
    have h2 : D * 2 ^ n ≤ D * ((B + 1) * 2 ^ n) := Nat.mul_le_mul_left _ hX
    generalize (B + 1) * 2 ^ n = X at *
    generalize B % R.Nsrc n * (n + 1) * 2 ^ n = Y at *
    nlinarith
  · rw [if_neg hn, if_neg hn]
    generalize (B + 1) * (n + 1) * 2 ^ n = Z
    nlinarith

end Eng

end
end PowerSaving.RAM
end OAI

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false

namespace OAI
namespace PowerSaving.MCost
open PowerSaving.RAM PowerSaving.Binary PowerSaving.MX Ty

noncomputable section

universe U

lemma tape_relabel {ρ : Type*} (R : Layout ρ) (n : ℕ) (u : Sim ρ n → ℂ) :
    (sim R n).tape u = (sim (Layout.std R.n) n).tape (fun z => u (R.atFin z.1, z.2)) := by
  refine Layout.verify _ _ 0 _ rfl ?_
  intro z
  have hl : (sim (Layout.std R.n) n).loc z = (sim R n).loc (R.atFin z.1, z.2) := by
    unfold sim
    rw [Layout.pair_loc, Layout.pair_loc, Layout.loc_atFin]
    rfl
  rw [hl, Layout.read]

abbrev jobIn (cl : Paint) : Ty := p w (p sc (a (a (c cl))))

section
variable {m : Bool} {ι : Type U} {cl : Paint} {s : Ty} {x : ι → T s} {Bd : ι → ℕ}

theorem jobs_of_flat (n N : ι → ℕ) (u : ∀ i, Sim (Fin (N i)) (n i) → ℂ)
    (ht : Has m Bd s (bundle cl) x (fun i => (sim (Layout.std (N i)) (n i)).tape (u i)))
    (hN : Knows m Bd s x N) (h2 : Knows m Bd s x (fun i => 2 ^ n i))
    (hNs : Small Bd N) (h2s : Small Bd (fun i => 2 ^ n i)) :
    Can m Bd s (a (a (c cl))) x
      (fun i => jobsTape (n i) (N i) (fun t z => if h : t < N i then u i (⟨t, h⟩, z) else 0))
      (fun i => N i + N i * (2 ^ n i + 2 ^ n i)) := by
  -- outer layout over the jobs, inner layout over the entries of one job
  let Q := Σ i, Fin (N i)
  let σ : Q → ι := Sigma.fst
  let E (d : Q) : T (p s w) := (x d.1, (Layout.std (N d.1)).loc d.2)
  have h2Q : Knows m (fun d : Q => Bd d.1) (p s w) E (fun d => (bits (n d.1)).n) :=
    Has.extE (h2.reindex σ)
  let Q2 := Σ d : Q, Bits (n d.1)
  let σ2 : Q2 → Q := Sigma.fst
  let E2 (e : Q2) : T (p (p s w) w) := (E e.1, (bits (n e.1.1)).loc e.2)
  have hval : Has m (fun e : Q2 => Bd e.1.1) (p (p s w) w) (c cl) E2
      (fun e => u e.1.1 (e.1.2, e.2)) := by
    have hadr : Knows m (fun e : Q2 => Bd e.1.1) (p (p s w) w) E2
        (fun e => (sim (Layout.std (N e.1.1)) (n e.1.1)).loc (e.1.2, e.2)) := by
      have ht1 : Knows m (fun e : Q2 => Bd e.1.1) (p (p s w) w) E2 (fun e => (Layout.std (N e.1.1)).loc e.1.2) :=
        Has.extE Can.second
      have ht2 : Knows m (fun e : Q2 => Bd e.1.1) (p (p s w) w) E2 (fun e => (bits (n e.1.1)).loc e.2) :=
        Can.second
      have hd : Knows m (fun e : Q2 => Bd e.1.1) (p (p s w) w) E2 (fun e => (bits (n e.1.1)).n) :=
        Has.extE (h2Q.reindex σ2)
      exact Can.addr_join (L := fun e : Q2 => Layout.std (N e.1.1)) (R := fun e : Q2 => bits (n e.1.1))
        (u := fun e : Q2 => (e.1.2, e.2)) ht1 ht2 hd ((hNs.reindex σ).reindex σ2) ((h2s.reindex σ).reindex σ2)
    exact Can.fetch (t := c cl) (L := fun e : Q2 => sim (Layout.std (N e.1.1)) (n e.1.1))
      (v := fun e : Q2 => u e.1.1) (i := fun e : Q2 => (e.1.2, e.2))
      (Has.extE (Has.extE ((ht.reindex σ).reindex σ2))) hadr
  have hjob : Can m (fun d : Q => Bd d.1) (p s w) (a (c cl)) E
      (fun d => (bits (n d.1)).tape (fun z => u d.1 (d.2, z))) (fun d => 2 ^ n d.1) := by
    refine (Can.layout (L := fun d : Q => bits (n d.1)) (t := c cl) (P := fun _ => 0)
      (v := fun d z => u d.1 (d.2, z)) h2Q hval (h2s.reindex σ)).mono (fun d => ?_)
    show 0 + 2 ^ n d.1 + 2 ^ n d.1 * 0 ≤ 2 ^ n d.1
    simp
  have H := Can.layout (L := fun i => Layout.std (N i)) (t := a (c cl))
    (P := fun i => 2 ^ n i) (v := fun i t => (bits (n i)).tape (fun z => u i (t, z)))
    hN hjob hNs
  refine (H.cong (fun _ => rfl) (fun i => ?_)).mono (fun i => ?_)
  rotate_left
  · show 0 + N i + N i * 2 ^ n i ≤ N i + N i * (2 ^ n i + 2 ^ n i)
    rw [Nat.zero_add]
    exact Nat.add_le_add_left (Nat.mul_le_mul_left _ (Nat.le_add_right _ _)) _
  unfold jobsTape
  congr 1
  funext t
  simp [t.isLt]

theorem flat_of_jobs (n N : ι → ℕ) (J : ∀ i, ℕ → Bits (n i) → ℂ)
    (ht : Has m Bd s (a (a (c cl))) x (fun i => jobsTape (n i) (N i) (J i)))
    (hN : Knows m Bd s x N) (h2 : Knows m Bd s x (fun i => 2 ^ n i))
    (hNs : Small Bd N) (h2s : Small Bd (fun i => 2 ^ n i)) :
    Can m Bd s (bundle cl) x
      (fun i => (sim (Layout.std (N i)) (n i)).tape (fun z => J i z.1 z.2))
      (fun i => N i * 2 ^ n i) := by
  let Q := Σ i, Fin (N i) × Bits (n i)
  let σ : Q → ι := Sigma.fst
  let E (d : Q) : T (p s w) := (x d.1, (sim (Layout.std (N d.1)) (n d.1)).loc d.2)
  have hsQ : Small (fun d : Q => Bd d.1) (fun d => (Layout.std (N d.1)).n * (bits (n d.1)).n) :=
    (hNs.mul h2s).reindex σ
  have h2Q : Knows m (fun d : Q => Bd d.1) (p s w) E (fun d => (bits (n d.1)).n) :=
    Has.extE (h2.reindex σ)
  have hpos : Knows m (fun d : Q => Bd d.1) (p s w) E
      (fun d => ((Layout.std (N d.1)).pair (bits (n d.1))).loc d.2) := Can.second
  have ht1 : Knows m (fun d : Q => Bd d.1) (p s w) E (fun d => (Layout.std (N d.1)).loc d.2.1) :=
    Can.addr_high (L := fun d : Q => Layout.std (N d.1)) (R := fun d : Q => bits (n d.1))
      (u := fun d : Q => d.2) hpos h2Q hsQ
  have hz : Knows m (fun d : Q => Bd d.1) (p s w) E (fun d => (bits (n d.1)).loc d.2.2) :=
    Can.addr_low (L := fun d : Q => Layout.std (N d.1)) (R := fun d : Q => bits (n d.1))
      (u := fun d : Q => d.2) hpos h2Q hsQ
  have hjob : Has m (fun d : Q => Bd d.1) (p s w) (a (c cl)) E
      (fun d => (bits (n d.1)).tape (J d.1 d.2.1)) :=
    Can.fetch (t := a (c cl)) (L := fun d : Q => Layout.std (N d.1))
      (v := fun d : Q => fun t : Fin (N d.1) => (bits (n d.1)).tape (J d.1 t)) (i := fun d : Q => d.2.1)
      (Has.extE (ht.reindex σ)) ht1
  have hval : Has m (fun d : Q => Bd d.1) (p s w) (c cl) E (fun d => J d.1 d.2.1 d.2.2) :=
    Can.fetch (t := c cl) (L := fun d : Q => bits (n d.1)) (v := fun d : Q => J d.1 d.2.1)
      (i := fun d : Q => d.2.2) hjob hz
  have hn : Knows m Bd s x (fun i => (sim (Layout.std (N i)) (n i)).n) := hN.times h2 hNs h2s
  have H := Can.layout (L := fun i => sim (Layout.std (N i)) (n i)) (t := c cl) (P := fun _ => 0)
    (v := fun i z => J i z.1 z.2) hn hval (hNs.mul h2s)
  refine H.mono (fun i => ?_)
  show 0 + N i * 2 ^ n i + N i * 2 ^ n i * 0 ≤ N i * 2 ^ n i
  simp

end

theorem top_of_port {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
    [Fintype σ] [DecidableEq σ] (E : Eng α ρ σ) (R : Rule) (n0 : ℕ) (J : ℕ → ℕ)
    (hJge : ∀ n, 2 ^ n ≤ J n) {m : Bool} {cl : Paint} {Bd : ℕ → ℕ → ℕ} {ι : Type U}
    (hP : ∀ (n N : ι → ℕ) (u : ∀ i, ℕ → Bits (n i) → ℂ),
      Can m (fun i => Bd (n i) (N i)) (portIn cl) (portOut cl)
        (fun i => E.enc cl (MDesc.top (n i) (N i) (u i))) (fun i => E.out cl (MDesc.top (n i) (N i) (u i)))
        (fun i => R.topCost n0 J (n i) (N i)))
    (hBd : ∃ d, ∀ n N, Bd n N ≤ ((N + 1) * 2 ^ n + 2) ^ d)
    (n b : ι → ℕ) (u : ∀ i, Sim (Bits (b i)) (n i) → ℂ) :
    Can m (fun i => (2 ^ b i + 1) * 2 ^ n i) (simIn cl) (bundle cl)
      (fun i => loaded cl (bits (b i)) (n i) (u i))
      (fun i => (sim (bits (b i)) (n i)).tape (whole (n i) (u i)))
      (fun i => R.topCost n0 J (n i) (2 ^ b i)) := by
  -- the jobs-form top engine `(n, I, jobs) ↦ jobs answered`
  have hJ : ∀ (n N : ι → ℕ) (u : ∀ i, ℕ → Bits (n i) → ℂ),
      Can m (fun i => (N i + 1) * 2 ^ n i) (jobIn cl) (a (a (c cl)))
        (fun i => (n i, Complex.I, jobsTape (n i) (N i) (u i)))
        (fun i => jobsTape (n i) (N i) (fun t => ripple (n i) (u i t)))
        (fun i => R.topCost n0 J (n i) (N i)) := by
    intro n N u
    let x (i : ι) : T (jobIn cl) := (n i, Complex.I, jobsTape (n i) (N i) (u i))
    -- the empty supply
    have hemp : Has m (fun i => (N i + 1) * 2 ^ n i) (jobIn cl) (a (a (c cl))) x
        (fun i => jobsTape (n i) 0 (fun _ _ => 0)) := by
      have H := Can.tab (m := m) (B := fun i => (N i + 1) * 2 ^ n i) (s := jobIn cl) (x := x)
        (t := a (c cl)) (n := fun _ => 0) (uB := fun _ _ => 0) (v := fun _ _ => Tape.empty ℂ) (W := fun _ => 0)
        (Can.wc (W := fun _ => 0) 0) (Can.tab (t := c cl) (n := fun _ => 0) (uB := fun _ _ => 0)
          (v := fun _ _ => 0) (Can.wc 0) Can.zero (Small.const _ 0) |>.cong (fun _ => rfl) (fun d => by
            refine Tape.ext_look rfl 0 (fun j hj => absurd hj (Nat.not_lt_zero _)))) (Small.const _ 0)
      refine (H.cong (fun _ => rfl) (fun i => ?_)).mono (fun i => by simp)
      exact Tape.ext_look rfl (Tape.empty ℂ) (fun j hj => absurd hj (Nat.not_lt_zero _))
    have hin : Can m (fun i => (N i + 1) * 2 ^ n i) (jobIn cl) (portIn cl) x
        (fun i => E.enc cl (MDesc.top (n i) (N i) (u i))) (fun i => R.topCost n0 J (n i) (N i)) := by
      refine ((Has.atW Can.first).pair ((Has.atW Can.second.fst).pair
        ((Can.wc 0).pair ((Can.wc 0).pair ((Can.wc 0).pair ((Has.atW Can.second.snd).pair
          (Has.atW hemp))))))).cong (fun _ => rfl) (fun i => rfl)
    obtain ⟨d, hd⟩ := hBd
    have hcl := (hP n N u).ambient (B' := fun i => (N i + 1) * 2 ^ n i) ⟨d, fun i => hd (n i) (N i)⟩
    exact Can.fst (hin.then_do hcl)
  -- the flat form on `Fin N` slices
  have hStd : ∀ (n N : ι → ℕ) (u : ∀ i, Sim (Fin (N i)) (n i) → ℂ),
      Can m (fun i => (N i + 1) * 2 ^ n i) (simIn cl) (bundle cl)
        (fun i => loaded cl (Layout.std (N i)) (n i) (u i))
        (fun i => (sim (Layout.std (N i)) (n i)).tape (whole (n i) (u i)))
        (fun i => R.topCost n0 J (n i) (N i)) := by
    intro n N u
    let Bd : ι → ℕ := fun i => (N i + 1) * 2 ^ n i
    let Wt : ι → ℕ := fun i => R.topCost n0 J (n i) (N i)
    let x0 : ι → T (simIn cl) := fun i => loaded cl (Layout.std (N i)) (n i) (u i)
    have h2le : ∀ i, 2 ^ n i ≤ Bd i := fun i => Nat.le_mul_of_pos_left _ (Nat.succ_pos _)
    have hNle : ∀ i, N i ≤ Bd i := fun i => by
      have : 1 ≤ 2 ^ n i := Nat.one_le_two_pow
      calc N i ≤ (N i + 1) * 1 := by omega
        _ ≤ Bd i := Nat.mul_le_mul_left _ this
    have hnle : ∀ i, n i ≤ Bd i := fun i => le_trans (Nat.lt_two_pow_self).le (h2le i)
    have sN : Small Bd N := ⟨1, fun i => by have := hNle i; simp only [pow_one]; omega⟩
    have s2 : Small Bd (fun i => 2 ^ n i) := ⟨1, fun i => by have := h2le i; simp only [pow_one]; omega⟩
    have sn : Small Bd n := ⟨1, fun i => by have := hnle i; simp only [pow_one]; omega⟩
    have hWt : ∀ i, N i * 2 ^ n i + (n i + 1) * 2 ^ n i ≤ Wt i := fun i => by
      have := Nat.mul_le_mul_left (N i) (hJge (n i))
      simp only [Wt, Rule.topCost]; omega
    have hWt2 : ∀ i, n i ≤ Wt i := fun i => by
      have := hWt i
      have : n i ≤ (n i + 1) * 2 ^ n i :=
        le_trans (Nat.le_succ _) (Nat.le_mul_of_pos_right _ Nat.one_le_two_pow)
      omega
    -- the environment: the input and `2^n`
    have hn0 : Knows m Bd (simIn cl) x0 n := Can.first
    have h20 : Can m Bd (simIn cl) w x0 (fun i => 2 ^ n i) Wt :=
      Can.wTwo (Has.atW hn0) sn s2 (Dom.of_le hWt2)
    let sE : Ty := p (simIn cl) w
    let E0 : ι → T sE := fun i => (x0 i, 2 ^ n i)
    have hE0 : Can m Bd (simIn cl) sE x0 E0 Wt := Can.pair Can.id h20
    have hN : Knows m Bd sE E0 N := by
      -- the number of jobs: the flat length divided by `2^n`
      have hl : Knows m Bd sE E0 (fun i => (sim (Layout.std (N i)) (n i)).n) :=
        (Has.extE (Can.second.snd)).len ((sN.mul s2))
      refine (hl.dvdW (Can.second) (sN.mul s2)).cong (fun _ => rfl) (fun i => ?_)
      show N i * 2 ^ n i / 2 ^ n i = N i
      exact Nat.mul_div_cancel _ (Nat.two_pow_pos _)
    have h2E : Knows m Bd sE E0 (fun i => 2 ^ n i) := Can.second
    -- flat → jobs
    let u' (i : ι) : ℕ → Bits (n i) → ℂ := fun t z => if h : t < N i then u i (⟨t, h⟩, z) else 0
    have hj : Can m Bd sE (a (a (c cl))) E0 (fun i => jobsTape (n i) (N i) (u' i)) Wt :=
      (jobs_of_flat (cl := cl) n N u (Has.extE Can.second.snd) hN h2E sN s2).weaken
        ⟨3, fun i => by
          have h1 := hWt i
          have h2 : N i ≤ N i * 2 ^ n i := Nat.le_mul_of_pos_right _ Nat.one_le_two_pow
          nlinarith⟩
    -- the call
    have hin : Can m Bd sE (jobIn cl) E0 (fun i => (n i, Complex.I, jobsTape (n i) (N i) (u' i))) Wt :=
      Can.pair (Has.atW (Has.extE hn0))
        (Can.pair (Has.atW (Has.extE Can.second.fst)) hj)
    have hcall : Can m Bd sE (a (a (c cl))) E0
        (fun i => jobsTape (n i) (N i) (fun t => ripple (n i) (u' i t))) Wt :=
      hin.then_do (hJ n N u')
    -- jobs → flat, keeping the environment
    have hback : Can m Bd (p sE (a (a (c cl)))) (bundle cl)
        (fun i => (E0 i, jobsTape (n i) (N i) (fun t => ripple (n i) (u' i t))))
        (fun i => (sim (Layout.std (N i)) (n i)).tape (fun z => ripple (n i) (u' i z.1) z.2)) Wt :=
      (flat_of_jobs (cl := cl) n N (fun i t => ripple (n i) (u' i t)) Can.second
        (Has.extE hN) (Has.extE h2E) sN s2).mono (fun i => by have := hWt i; omega)
    refine (hE0.then_do (Can.bind hcall hback)).cong (fun _ => rfl) (fun i => ?_)
    congr 1
    funext z
    simp only [u', z.1.isLt, dite_true]
    rfl
  -- `Bits b` slices are `Fin (2^b)` slices, relabelled
  have H := hStd n (fun i => 2 ^ b i) (fun i z => u i ((bits (b i)).atFin z.1, z.2))
  refine H.cong (fun i => ?_) (fun i => ?_)
  · unfold loaded
    rw [tape_relabel (bits (b i)) (n i) (u i)]
    rfl
  · rw [tape_relabel (bits (b i)) (n i) (whole (n i) (u i))]
    rfl

end
end PowerSaving.MCost
end OAI

namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

universe U

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable (E : Eng α ρ σ)

lemma mem_kidsV {kmin : ℕ} (hk : E.KMin kmin) (n0 : ℕ) (hn0 : E.mx ≤ n0) (d c : E.VD kmin)
    (hc : c ∈ (↑(E.kidsV hk n0 hn0 d) : Multiset (E.VD kmin))) : c.1 ∈ E.kidsAll kmin n0 d.1 := by
  rw [Multiset.mem_coe] at hc
  unfold kidsV at hc
  obtain ⟨c', hc', rfl⟩ := List.mem_map.1 hc
  exact c'.2

lemma kidsV_shape_eq {kmin : ℕ} (hk : E.KMin kmin) (n0 : ℕ) (hn0 : E.mx ≤ n0) (d : E.VD kmin) :
    ((↑(E.kidsV hk n0 hn0 d) : Multiset (E.VD kmin)).map (fun c => shapeD c.1)) =
      (((E.kidsAll kmin n0 d.1).map shapeD : List MX.Shape) : Multiset MX.Shape) := by
  rw [Multiset.map_coe]
  unfold kidsV
  simp only [List.map_map, Function.comp_def]
  rw [List.attach_map_val]

theorem engine_portTop {kmin : ℕ} (hk : E.KMin kmin) (n0 : ℕ) (hn0 : E.mx ≤ n0)
    {R : MX.Rule} {typ : ℕ → Fin R.K} (H : E.BridgeHyp R typ kmin) (m : Bool) (cl : Paint)
    (hkC : ∀ n h μ o BS J sup, E.Valid kmin (MDesc.cls n h μ o BS J sup) → R.InvS (MX.Shape.cls n h μ) →
      (((E.kidsC (MDesc.cls n h μ o BS J sup)).map shapeD : List MX.Shape) : Multiset MX.Shape) =
        R.kidsS n0 (MX.Shape.cls n h μ))
    (hlC : ∃ C, ∀ n h μ o BS J sup, E.Valid kmin (MDesc.cls n h μ o BS J sup) →
      E.clsLoc n h μ + 1 ≤ C * (R.locS n0 (MX.Shape.cls n h μ) + 1))
    (hbC : ∀ n h μ o BS J sup, E.Valid kmin (MDesc.cls n h μ o BS J sup) →
      ∀ c ∈ E.kidsC (MDesc.cls n h μ o BS J sup), bndD c ≤ bndD (MDesc.cls n h μ o BS J sup))
    {ι : Type U} : ∀ (n N : ι → ℕ) (u : ∀ i, ℕ → Bits (n i) → ℂ),
      Can m (fun i => (N i + 2) * 2 ^ n i) (portIn cl) (portOut cl)
        (fun i => E.enc cl (MDesc.top (n i) (N i) (u i))) (fun i => E.out cl (MDesc.top (n i) (N i) (u i)))
        (fun i => R.topCost n0 (R.allotM n0) (n i) (N i)) := by
  intro n N u
  have hRn0 : R.m ≤ n0 := by rw [H.hm]; exact hn0
  -- the class and top halves
  have hloc : Dom (fun d : E.VD kmin => R.locS n0 (shapeD d.1)) (fun d => E.locD kmin n0 d.1) := by
    obtain ⟨C1, h1⟩ := H.locTop_dom hk.two n0
    obtain ⟨C2, h2⟩ := hlC
    refine ⟨C1 + C2, fun d => ?_⟩
    obtain ⟨d, hd⟩ := d
    cases d with
    | top n' B v =>
      have := h1 n' B
      simp only [locD, shapeD] at this ⊢
      nlinarith
    | cls n' h μ o BS J sup =>
      have := h2 n' h μ o BS J sup hd
      simp only [locD, shapeD] at this ⊢
      nlinarith
  have hkids : ∀ d : E.VD kmin, R.InvS (shapeD d.1) →
      ((↑(E.kidsV hk n0 hn0 d) : Multiset (E.VD kmin)).map (fun c => shapeD c.1)) = R.kidsS n0 (shapeD d.1) := by
    intro d hinv
    rw [E.kidsV_shape_eq hk n0 hn0 d]
    obtain ⟨d, hd⟩ := d
    cases d with
    | top n' B v => exact H.kidsTop_shape shapeD (fun _ _ _ => rfl) (fun _ _ _ _ _ _ _ => rfl) n0 n' B v
    | cls n' h μ o BS J sup => exact hkC n' h μ o BS J sup hd hinv
  have hbd : ∀ d c : E.VD kmin, R.InvS (shapeD d.1) →
      c ∈ (↑(E.kidsV hk n0 hn0 d) : Multiset (E.VD kmin)) → bndD c.1 ≤ bndD d.1 := by
    intro d c _ hc
    have hm := E.mem_kidsV hk n0 hn0 d c hc
    obtain ⟨d, hd⟩ := d
    cases d with
    | top n' B v => exact E.bnd_kidsTop kmin n0 n' B v c.1 hm
    | cls n' h μ o BS J sup => exact hbC n' h μ o BS J sup hd c.1 hm
  have H0 := MCost.mixed_close R hRn0 (R.allotM_jobRec hRn0) m (E.encV kmin cl) (E.outV kmin cl)
    (fun d => shapeD d.1) (fun d => ↑(E.kidsV hk n0 hn0 d)) (fun d => bndD d.1) (fun d => E.locD kmin n0 d.1)
    (fun d => fuelD d.1) (E.hbody hk n0 hn0 m cl) hloc hkids hbd
    (Has.atW (E.can_fuel cl m (P := fun d => R.InvS (shapeD d.1))))
    (fun d hd => rank_lt_fuel R d.1 hd) E.small_fuel
    (fun i => (⟨MDesc.top (n i) (N i) (u i), trivial⟩ : E.VD kmin)) (fun i => trivial)
  exact H0

end Eng

end
end PowerSaving.RAM
end OAI


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

universe U

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]

theorem engine_seam_final (E : Eng α ρ σ) {R : MX.Rule} {typ : ℕ → Fin R.K} {kmin : ℕ}
    (H : E.BridgeHyp R typ kmin) (n0 : ℕ) (hn0 : E.mx ≤ n0) {z1 z : ℝ} (hrate : R.RateQ z1 1)
    (hz1 : 0 < z1) (h12 : z1 < z) (hz : z ≤ 1) (m : Bool) (cl : Paint)
    {ι : Type U} (k : ι → ℕ) (v : ∀ i, Bits (k i) → ℂ) :
    Can m (fun i => 2 ^ k i) (simIn cl) (bundle cl)
      (fun i => givenBits cl (k i) (v i)) (fun i => (bits (k i)).tape (ripple (k i) (v i)))
      (fun i => 2 ^ k i * envelope z (k i)) := by
  have hRn0 : R.m ≤ n0 := by rw [H.hm]; exact hn0
  have hBd : ∃ d, ∀ n N : ℕ, (N + 2) * 2 ^ n ≤ ((N + 1) * 2 ^ n + 2) ^ d := ⟨2, fun n N => by
    have hX : 1 ≤ 2 ^ n := Nat.one_le_two_pow
    generalize 2 ^ n = X at *
    have h1 : (N + 2) * X ≤ 2 * ((N + 1) * X + 2) := by nlinarith
    have hY : 2 ≤ (N + 1) * X + 2 := by omega
    generalize (N + 1) * X + 2 = Y at *
    have h2 : 2 * Y ≤ Y ^ 2 := by rw [sq]; exact Nat.mul_le_mul_right _ hY
    omega⟩
  obtain ⟨C, -, hC⟩ := R.allotM_bound hrate hz1 h12 hz hRn0
  -- the closed port engine, the jobs relabel, the seam adapter, and the adapter's bill
  exact Able.weaken (MCost.adapter_program R n0 (R.allotM n0) cl m
    (MCost.top_of_port E R n0 (R.allotM n0) (R.J_ge hRn0 (R.allotM_jobRec hRn0))
      (Bd := fun n N => (N + 2) * 2 ^ n)
      (E.engine_portTop H.kminE n0 hn0 H m cl
        (fun n h μ o BS J sup hd _ => H.kidsC_shape shapeD (fun _ _ _ => rfl) (fun _ _ _ _ _ _ _ => rfl) n0
          n h μ o BS J sup hd)
        (H.clsLoc_dom n0)
        (fun n h μ o BS J sup hd => bnd_kidsC H.kminE n h μ o BS J sup hd)) hBd) k v)
    (R.seam_dom hRn0 (by linarith) hC k) (fun _ => le_rfl)

end Eng

end
end PowerSaving.RAM
end OAI
