import Submission.OAI.Computability.FourierTransform.RecursionBounds

namespace OAI
namespace PowerSaving.Binary
open Matrix Finset
noncomputable section
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α]
  [Fintype ρ] [DecidableEq ρ] [Fintype σ] [DecidableEq σ]

def covered (e : ρ ↪ σ) := univ.map e

omit [DecidableEq ρ] [Fintype σ] [DecidableEq σ] in
theorem cover_iff (e : ρ ↪ σ) (i : σ) : i ∈ covered e ↔ ∃ j, e j=i := by simp [covered]

private def src (e : ρ ↪ σ) {i : σ} (h : i∈covered e) : ρ :=
  Classical.choose ((cover_iff ..).mp h)

omit [DecidableEq ρ] [Fintype σ] [DecidableEq σ] in
private theorem src_spec (e : ρ ↪ σ) {i : σ} (h : i∈covered e) :
    e (src e h) = i := Classical.choose_spec ((cover_iff e i).mp h)

omit [DecidableEq ρ] [Fintype σ] [DecidableEq σ] in
private theorem src_self (e : ρ ↪ σ) (i : ρ) (h : e i ∈ covered e) :
    src e h = i := e.injective (src_spec e h)

def wide (e : ρ ↪ σ) (M : Matrix ρ ρ ℚ) : Matrix σ σ ℚ :=
  fun i j => if h : i∈covered e then if h' : j∈covered e then M (src e h) (src e h') else 0
    else if i=j then 1 else 0

omit [DecidableEq ρ] [Fintype σ] in
theorem wide_both (e : ρ ↪ σ) (M : Matrix ρ ρ ℚ) (i j : ρ) :
    wide e M (e i) (e j)=M i j := by simp [wide,src_self,covered]

omit [DecidableEq ρ] in
theorem wide_in (e : ρ ↪ σ) (M : Matrix ρ ρ ℚ) (i : ρ) (x : σ→ℂ) :
    actPoint (wide e M) x (e i) = actPoint M (x ∘ e) i := by
  unfold actPoint
  rw [← Finset.sum_add_sum_compl (covered e)]
  have hz : ∑ j ∈ (covered e)ᶜ, (wide e M (e i) j : ℂ) * x j = 0 := by
    apply sum_eq_zero
    intro j hj
    replace hj := mem_compl.mp hj
    have h : e i ∈ covered e := by simp [covered]
    simp [wide,h,hj]
  rw [hz, add_zero, covered, sum_map]
  simp [wide_both]

omit [DecidableEq ρ] in
theorem wide_out (e : ρ ↪ σ) (M : Matrix ρ ρ ℚ) (x : σ→ℂ) {i : σ} (h : i ∉ covered e) :
    actPoint (wide e M) x i = x i := by
  unfold actPoint
  rw [Finset.sum_eq_single i]
  · simp [wide,h]
  · intro j _ g; simp [wide,h, Ne.symm g]
  · simp

def Move.over (e : ρ ↪ σ) : Move α ρ → Move α σ
  | .localM M => .localM (wide e M)
  | .dir r z nz => .dir (e r) z nz
  | .shift r z => .shift (e r) z

theorem go_over (e : ρ ↪ σ) (m : Move α ρ) (f : ℕ) (x : Data α σ f) :
    (m.over e |>.go f x) ∘ e = m.go f (x ∘ e) := by
  funext i
  cases m with
  | localM M =>
    funext j; exact wide_in e M i _
  | dir => simp [Move.over,Move.go, Function.comp, roleAct]
  | shift => simp [Move.over,Move.go, Function.comp, roleAct]

omit [DecidableEq ρ] in
theorem go_out (e : ρ ↪ σ) (m : Move α ρ) (f : ℕ)
    (x : Data α σ f) {i : σ} (h : i ∉ covered e) :
    ((m.over e).go f x) i = x i := by
  have hh (j : ρ) : i ≠ e j := fun g => h ((cover_iff ..).2 ⟨j,g.symm⟩)
  cases m with
  | localM M => funext j; exact wide_out e M _ h
  | dir => simp [Move.over,Move.go,roleAct, hh]
  | shift => simp [Move.over,Move.go,roleAct, hh]

theorem walk_over (e : ρ ↪ σ) (p : PWord α ρ) (f : ℕ) (x : Data α σ f) :
    walk f (p.map (Move.over e)) x ∘ e = walk f p (x ∘ e) := by
  induction p generalizing x with
  | nil => rfl
  | cons m p ih =>
    change walk _ _ _ ∘ e = walk f p (m.go f (x∘e))
    rw [← go_over]
    exact ih _

omit [DecidableEq ρ] in
theorem walk_out (e : ρ ↪ σ) (p : PWord α ρ) (f : ℕ) (x : Data α σ f)
    {i : σ} (h : i ∉ covered e) :
    walk f (p.map (Move.over e)) x i = x i := by
  induction p generalizing x with
  | nil => rfl
  | cons m p ih =>
    exact (ih _).trans (go_out e m f _ h)

end
end PowerSaving.Binary

end OAI

namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset
noncomputable section
universe U

def givenBits (cl : Paint) (k : ℕ) (v : Bits k→ℂ) : T (simIn cl) :=
  (k,Complex.I,(bits k).tape v)

theorem naive_kernel (cl : Paint) (m : Bool) {ι : Type U} (k : ι→ℕ)
    (v : ∀ i, Bits (k i) → ℂ) :
    Can m (fun i => 2^k i) (simIn cl) (bundle cl)
      (fun i => givenBits cl (k i) (v i)) (fun i => (bits (k i)).tape (ripple (k i) (v i)))
      (fun i => 2^k i * (2 * k i + 1)) :=
  naive_kernel_direct cl m k v

end
end PowerSaving.RAM
end OAI
