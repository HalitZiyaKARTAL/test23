import Submission.Work.Mixed.Prog.Merged1
import Submission.Work.Mixed.Prog.Loops
import Submission.Work.MixedCost.Close
import Submission.Work.MixedCost.NaiveKernel
import Submission.Work.Kit.RAMEnv
import Submission.Work.Mixed.Prog.ClassTabs


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

lemma length_filterMap_ite {β : Type*} (P : ℕ → Prop) [DecidablePred P] (f : ℕ → β) (N : ℕ) :
    ((List.range N).filterMap (fun t => if P t then some (f t) else none)).length = Nat.count P N := by
  induction N with
  | zero => simp
  | succ N ih =>
    rw [List.range_succ, List.filterMap_append, List.length_append, ih, Nat.count_succ]
    by_cases hp : P N <;> simp [hp]

-- `sum_map_getD` now lives in Work/Block/WHT.lean (same name, same namespace `RAM`): U7604/Raw.lean uses it too.

lemma sum_map_range (N : ℕ) (f : ℕ → ℕ) : ((List.range N).map f).sum = ∑ j ∈ Finset.range N, f j := by
  induction N with
  | zero => simp
  | succ N ih => rw [List.range_succ, List.map_append, List.sum_append, ih, Finset.sum_range_succ]; simp

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable (E : Eng α ρ σ)

def srcU (n h μ r u : ℕ) : Prop :=
  inRS E.W E.tq E.mx n h (μ * r) (u / E.W) ∧ ¬ inRS E.W E.tq E.mx n (h+1) μ u

instance (n h μ r : ℕ) : DecidablePred (E.srcU n h μ r) := fun u => by unfold srcU; infer_instance

theorem ownSrc_length (n h μ r : ℕ) :
    (E.ownSrc n h μ r).length = Nat.count (E.srcU n h μ r) (E.W^h * E.W) := by
  unfold ownSrc
  rw [length_filterMap_ite, Nat.count_eq_card_filter_range, Nat.count_eq_card_filter_range]
  have hW := E.W_pos
  refine Finset.card_bij (fun t _ => E.Uc n h (μ * r) (t / E.W) * E.W + t % E.W) ?_ ?_ ?_
  · intro t ht
    simp only [Finset.mem_filter, Finset.mem_range] at ht ⊢
    obtain ⟨hlt, hsrc⟩ := ht
    have hp : t / E.W < E.NUc n h (μ * r) := (Nat.div_lt_iff_lt_mul hW).2 hlt
    have hU := U_spec hp
    have hmod : t % E.W < E.W := Nat.mod_lt _ hW
    have hdiv : (E.Uc n h (μ * r) (t / E.W) * E.W + t % E.W) / E.W = E.Uc n h (μ * r) (t / E.W) := by
      rw [Nat.add_comm, Nat.add_mul_div_right _ _ hW, Nat.div_eq_of_lt hmod, zero_add]
    refine ⟨?_, ?_, ?_⟩
    · calc E.Uc n h (μ * r) (t / E.W) * E.W + t % E.W < E.Uc n h (μ * r) (t / E.W) * E.W + E.W := by omega
        _ = (E.Uc n h (μ * r) (t / E.W) + 1) * E.W := by ring
        _ ≤ E.W^h * E.W := Nat.mul_le_mul_right _ hU.2.1
    · rw [hdiv]; exact hU.1
    · have : E.Uc n h (μ * r) (t / E.W) * E.W + t % E.W = E.parCode n h μ r t := by
        unfold parCode; ring
      rw [this]; exact hsrc.2
  · intro t1 ht1 t2 ht2 heq
    simp only [Finset.mem_filter, Finset.mem_range] at ht1 ht2
    have h1 : t1 / E.W < E.NUc n h (μ * r) := (Nat.div_lt_iff_lt_mul hW).2 ht1.1
    have h2 : t2 / E.W < E.NUc n h (μ * r) := (Nat.div_lt_iff_lt_mul hW).2 ht2.1
    have hm1 : t1 % E.W < E.W := Nat.mod_lt _ hW
    have hm2 : t2 % E.W < E.W := Nat.mod_lt _ hW
    have ediv := congrArg (· / E.W) heq
    have emod := congrArg (· % E.W) heq
    simp only [Nat.add_comm (E.Uc n h (μ * r) _ * E.W), Nat.add_mul_div_right _ _ hW,
      Nat.div_eq_of_lt hm1, Nat.div_eq_of_lt hm2, zero_add, Nat.add_mul_mod_self_right,
      Nat.mod_eq_of_lt hm1, Nat.mod_eq_of_lt hm2] at ediv emod
    have hU : t1 / E.W = t2 / E.W := by
      have e1 := PC_U h1
      have e2 := PC_U h2
      rw [← e1, ← e2]; exact congrArg _ ediv
    calc t1 = E.W * (t1 / E.W) + t1 % E.W := (Nat.div_add_mod t1 E.W).symm
      _ = E.W * (t2 / E.W) + t2 % E.W := by rw [hU, emod]
      _ = t2 := Nat.div_add_mod t2 E.W
  · intro u hu
    simp only [Finset.mem_filter, Finset.mem_range] at hu ⊢
    obtain ⟨hlt, hin, hout⟩ := hu
    have hu1 := PC_lt hin
    refine ⟨E.PCc n h (μ * r) (u / E.W) * E.W + u % E.W, ⟨?_, ?_, ?_⟩, ?_⟩
    · have hmod : u % E.W < E.W := Nat.mod_lt _ hW
      calc E.PCc n h (μ * r) (u / E.W) * E.W + u % E.W < E.PCc n h (μ * r) (u / E.W) * E.W + E.W := by omega
        _ = (E.PCc n h (μ * r) (u / E.W) + 1) * E.W := by ring
        _ ≤ E.NUc n h (μ * r) * E.W := Nat.mul_le_mul_right _ hu1
    · have hmod : u % E.W < E.W := Nat.mod_lt _ hW
      calc E.PCc n h (μ * r) (u / E.W) * E.W + u % E.W < E.PCc n h (μ * r) (u / E.W) * E.W + E.W := by omega
        _ = (E.PCc n h (μ * r) (u / E.W) + 1) * E.W := by ring
        _ ≤ E.NUc n h (μ * r) * E.W := Nat.mul_le_mul_right _ hu1
    · have hmod : u % E.W < E.W := Nat.mod_lt _ hW
      have hUP : E.Uc n h (μ * r) (E.PCc n h (μ * r) (u / E.W)) = u / E.W := U_PC hin
      unfold parCode
      rw [Nat.add_comm (E.PCc n h (μ * r) _ * E.W), Nat.add_mul_div_right _ _ hW, Nat.div_eq_of_lt hmod,
        zero_add, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt hmod, hUP]
      rw [show u % E.W + E.W * (u / E.W) = u from Nat.mod_add_div u E.W]
      exact hout
    · have hmod : u % E.W < E.W := Nat.mod_lt _ hW
      have hUP : E.Uc n h (μ * r) (E.PCc n h (μ * r) (u / E.W)) = u / E.W := U_PC hin
      rw [Nat.add_comm (E.PCc n h (μ * r) _ * E.W), Nat.add_mul_div_right _ _ hW, Nat.div_eq_of_lt hmod,
        zero_add, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt hmod, hUP]
      exact Nat.div_add_mod' u E.W

def nB : ℕ := (blockRanks E.wd).length
def rkI (j : ℕ) : ℕ := (blockRanks E.wd).getD j 0

lemma cons_zero (n μ : ℕ) : E.cons n 0 μ = 0 := by simp [cons, srcSizes]

theorem cons_succ_idx (n h μ : ℕ) :
    E.cons n (h+1) μ = ∑ j ∈ Finset.range E.nB,
      (Nat.count (E.srcU n h μ (E.rkI j)) (E.W^h * E.W) + E.cons n h (μ * E.rkI j)) := by
  unfold cons
  simp only [srcSizes, List.length_flatMap, List.length_append]
  rw [sum_map_getD (blockRanks E.wd) 0]
  unfold nB rkI
  refine Finset.sum_congr rfl (fun j _ => ?_)
  rw [ownSrc_length]

end Eng

end
end PowerSaving.RAM
end OAI


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable (E : Eng α ρ σ)

def topG (kmin n : ℕ) : ℕ := Nat.findGreatest (fun g => E.mx * kmin ^ g ≤ n) n
def topNU0 (kmin n : ℕ) : ℕ := E.NUc n (E.topG kmin n) 1
def topN (kmin n : ℕ) : ℕ := E.topNU0 kmin n * E.W + E.cons n (E.topG kmin n) 1
def topSz (kmin n j : ℕ) : ℕ :=
  if j < E.topNU0 kmin n * E.W then E.slotSize n (E.topG kmin n) 1 j
  else E.csz n (E.topG kmin n) 1 (j - E.topNU0 kmin n * E.W)

def topRoot (kmin n B : ℕ) (v : ℕ → Bits n → ℂ) (t : ℕ) : MDesc :=
  MDesc.cls n (E.topG kmin n) 1 (t * E.topN kmin n + E.topNU0 kmin n * E.W) B
    (fun j => v (t * E.topN kmin n + j)) v

def topAns (kmin n : ℕ) (v : ℕ → Bits n → ℂ) (t j : ℕ) : Bits n → ℂ :=
  hlow n (E.topSz kmin n j) (v (t * E.topN kmin n + j))

end Eng

def hiVec (n s : ℕ) (w : Bits n → ℂ) : ℕ → Bits (n - s) → ℂ :=
  if hs : s ≤ n then fun q y => w (castB (Nat.add_sub_cancel' hs) (catB s (n - s) (bitsOf s q, y)))
  else fun _ _ => 0

def fromHi (n s : ℕ) (Y : ℕ → Bits (n - s) → ℂ) : Bits n → ℂ :=
  fun e => Y ((bits n).loc e % 2^s) (bitsOf (n - s) ((bits n).loc e / 2^s))

lemma ripple_hi_lo (k a b : ℕ) (h : a + b = k) (v : Bits k → ℂ) (x : Bits a) (y : Bits b) :
    ripple b (fun y' => hlow k a v (castB h (catB a b (x, y')))) y = ripple k v (castB h (catB a b (x, y))) := by
  subst h
  have e1 : ∀ y', hlow (a+b) a v (castB rfl (catB a b (x, y'))) = hlow (a+b) a v (catB a b (x, y')) :=
    fun y' => rfl
  simp only [e1]
  rw [← Binary.hhigh_catB a b (hlow (a+b) a v) x y, hhigh_hlow]
  rfl

lemma fromHi_ripple (n s : ℕ) (hs : s ≤ n) (v : Bits n → ℂ) :
    fromHi n s (fun q => ripple (n - s) (hiVec n s (hlow n s v) q)) = ripple n v := by
  funext e
  obtain ⟨⟨x, y⟩, hxy⟩ : ∃ z : Bits s × Bits (n - s),
      castB (Nat.add_sub_cancel' hs) (catB s (n - s) z) = e :=
    ⟨(catB s (n - s)).symm ((castB (Nat.add_sub_cancel' hs)).symm e), by simp⟩
  subst hxy
  unfold fromHi
  have hx : (bits s).loc x < 2^s := by have := (bits s).bd x; rwa [bits_len] at this
  have h2 : 0 < 2^s := Nat.two_pow_pos s
  rw [loc_castB_catB n s hs]
  have e1 : ((bits s).loc x + 2^s * (bits (n - s)).loc y) % 2^s = (bits s).loc x := by
    rw [Nat.add_mul_mod_self_left, Nat.mod_eq_of_lt hx]
  have e2 : ((bits s).loc x + 2^s * (bits (n - s)).loc y) / 2^s = (bits (n - s)).loc y := by
    rw [Nat.add_mul_div_left _ _ h2, Nat.div_eq_of_lt hx, zero_add]
  rw [e1, e2, bitsOf_of_loc]
  have e3 : hiVec n s (hlow n s v) ((bits s).loc x) =
      fun y' => hlow n s v (castB (Nat.add_sub_cancel' hs) (catB s (n - s) (x, y'))) := by
    unfold hiVec
    rw [dif_pos hs, bitsOf_of_loc]
  show ripple (n - s) (hiVec n s (hlow n s v) ((bits s).loc x)) y = _
  rw [e3]
  exact ripple_hi_lo n s (n - s) _ v x y

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable (E : Eng α ρ σ)

def topRest (kmin n : ℕ) (v : ℕ → Bits n → ℂ) (t j : ℕ) : MDesc :=
  MDesc.top (n - E.topSz kmin n j) (2 ^ E.topSz kmin n j)
    (hiVec n (E.topSz kmin n j) (E.topAns kmin n v t j))

def kidsTop (kmin n0 n B : ℕ) (v : ℕ → Bits n → ℂ) : List MDesc :=
  if n0 ≤ n ∧ E.topN kmin n ≤ B then
    (List.range (B / E.topN kmin n)).flatMap
      (fun t => E.topRoot kmin n B v t :: (List.range (E.topN kmin n)).map (E.topRest kmin n v t))
  else []

end Eng

end
end PowerSaving.RAM
end OAI

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false

namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

universe U

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable (E : Eng α ρ σ)
variable {ι : Type U} {m : Bool} {B : ι → ℕ} {s : Ty} {x : ι → T s}

lemma colS_le (h sv : ℕ) : colS E.W E.tq h sv ≤ E.mx^h := (E.stepC_iter_le h sv).1

lemma can_fits {n h μ u : ι → ℕ} (hn : Knows m B s x n) (hh : Knows m B s x h) (hμ : Knows m B s x μ)
    (hu : Knows m B s x u) (hns : Small B n) (hhs : Small B h) (hμs : Small B μ) (hus : Small B u)
    (hpow : Small B (fun i => E.mx^(h i))) :
    Can m B s w x (fun i => if E.mx * (μ i * colS E.W E.tq (h i) (u i)) ≤ n i then 1 else 0)
      (fun i => h i + 1) := by
  have hcol := E.can_colS hh hhs hu hus hpow
  have hcs : Small B (fun i => colS E.W E.tq (h i) (u i)) := hpow.mono (fun i => E.colS_le _ _)
  have hv : Can m B s w x (fun i => E.mx * (μ i * colS E.W E.tq (h i) (u i))) (fun i => h i + 1) :=
    (Can.wc E.mx).times ((Has.atW hμ).times hcol hμs hcs)
      (Small.const _ E.mx) (hμs.mul hcs)
  refine ((Can.wc 1).wsub ((Has.atW hn).wlt hv)
    ((Small.const _ 1).mono (fun _ => Nat.sub_le _ _))).cong (fun _ => rfl) (fun i => ?_)
  by_cases h2 : E.mx * (μ i * colS E.W E.tq (h i) (u i)) ≤ n i
  · simp [h2, Nat.not_lt.mpr h2]
  · simp [h2, Nat.lt_of_not_le h2]

lemma can_srcU {n h μ r u : ι → ℕ} (hn : Knows m B s x n) (hh : Knows m B s x h) (hμ : Knows m B s x μ)
    (hr : Knows m B s x r) (hu : Knows m B s x u) (hlt : ∀ i, u i < E.W^(h i) * E.W)
    (hns : Small B n) (hhs : Small B h) (hμs : Small B μ) (hrs : Small B r) (hus : Small B u)
    (hpow : Small B (fun i => E.mx^(h i + 1))) :
    Can m B s w x (fun i => if E.srcU (n i) (h i) (μ i) (r i) (u i) then 1 else 0)
      (fun i => 2 * h i + 3) := by
  have hW := E.W_pos
  have hpow0 : Small B (fun i => E.mx^(h i)) :=
    hpow.mono (fun i => Nat.pow_le_pow_right (lt_of_lt_of_le (by norm_num) E.three) (Nat.le_succ _))
  have hμr : Knows m B s x (fun i => μ i * r i) := hμ.times hr hμs hrs
  have hud : Knows m B s x (fun i => u i / E.W) := hu.dvdW (Can.wc E.W) hus
  have h1 := E.can_fits hn hh hμr hud hns hhs (hμs.mul hrs) hus.div hpow0
  have hh1 : Knows m B s x (fun i => h i + 1) := hh.plus (Can.wc 1) hhs (Small.const _ 1)
  have h2 := E.can_fits hn hh1 hμ hu hns (hhs.add (Small.const _ 1)) hμs hus hpow
  have h2' : Can m B s w x (fun i => 1 - (if E.mx * (μ i * colS E.W E.tq (h i + 1) (u i)) ≤ n i then 1 else 0))
      (fun i => h i + 1 + 1) := (Can.wc 1).wsub h2 ((Small.const _ 1).mono (fun _ => Nat.sub_le _ _))
  have H := (h1.mono (W' := fun i => 2 * h i + 3) (fun i => by omega)).times
    (h2'.mono (W' := fun i => 2 * h i + 3) (fun i => by omega))
    ((Small.const _ 1).mono (fun i => by split <;> omega)) ((Small.const _ 1).mono (fun _ => Nat.sub_le _ _))
  refine H.cong (fun _ => rfl) (fun i => ?_)
  have hd : u i / E.W < E.W^(h i) := (Nat.div_lt_iff_lt_mul hW).2 (hlt i)
  have hu1 : u i < E.W^(h i + 1) := by rw [pow_succ]; exact hlt i
  unfold srcU inRS
  by_cases c1 : E.mx * (μ i * r i * colS E.W E.tq (h i) (u i / E.W)) ≤ n i <;>
    by_cases c2 : E.mx * (μ i * colS E.W E.tq (h i + 1) (u i)) ≤ n i <;>
    simp [c1, c2, hd, hu1, mul_assoc]

lemma can_ownCnt {n h μ r : ι → ℕ} (hn : Knows m B s x n) (hh : Knows m B s x h) (hμ : Knows m B s x μ)
    (hr : Knows m B s x r) (hWh : Knows m B s x (fun i => E.W^(h i)))
    (hns : Small B n) (hhs : Small B h) (hμs : Small B μ) (hrs : Small B r)
    (hWs : Small B (fun i => E.W^(h i) * E.W)) (hpow : Small B (fun i => E.mx^(h i + 1))) :
    Can m B s w x (fun i => Nat.count (E.srcU (n i) (h i) (μ i) (r i)) (E.W^(h i) * E.W))
      (fun i => E.W^(h i) * E.W * (2 * h i + 3 + 1) + 1) := by
  have hT : Knows m B s x (fun i => E.W^(h i) * E.W) :=
    hWh.times (Can.wc E.W) (hWs.mono (fun i => Nat.le_mul_of_pos_right _ E.W_pos)) (Small.const _ _)
  let BD (d : During (fun i => E.W^(h i) * E.W)) := B d.i
  have F : ∀ {t : Ty} {y : ι → T t}, Has m B s t x y →
      Has m BD (p s w) t (fun d => (x d.i, d.j)) (fun d => y d.i) :=
    fun g => Has.extE (g.reindex (fun d : During (fun i => E.W^(h i) * E.W) => d.i))
  have hind := E.can_srcU (F hn) (F hh) (F hμ) (F hr) (Can.second) (fun d => d.hj)
    (hns.reindex (fun d : During (fun i => E.W^(h i) * E.W) => d.i)) (hhs.reindex (fun d : During (fun i => E.W^(h i) * E.W) => d.i)) (hμs.reindex (fun d : During (fun i => E.W^(h i) * E.W) => d.i)) (hrs.reindex (fun d : During (fun i => E.W^(h i) * E.W) => d.i))
    ((hWs.reindex (fun d : During (fun i => E.W^(h i) * E.W) => d.i)).mono (fun d => d.hj.le))
    (hpow.reindex (fun d : During (fun i => E.W^(h i) * E.W) => d.i))
  exact can_count hT hWs hind

def kidsCnt (d : ℕ × ℕ × ℕ) : List (ℕ × ℕ × ℕ) :=
  match d.2.1 with
  | 0 => []
  | h + 1 => (List.range E.nB).map (fun j => (d.1, h, d.2.2 * E.rkI j))

def outCnt (d : ℕ × ℕ × ℕ) : ℕ := E.cons d.1 d.2.1 d.2.2

def Rs : ℕ := (blockRanks E.wd).sum + 1

lemma rkI_le (j : ℕ) : E.rkI j ≤ E.Rs := by
  unfold rkI Rs
  by_cases hj : j < (blockRanks E.wd).length
  · rw [List.getD_eq_getElem _ _ hj]
    have := List.le_sum_of_mem (List.getElem_mem hj)
    omega
  · rw [List.getD_eq_default _ _ (by omega)]; omega

def Ac : ℕ := (E.nB + 1) * (E.W + 1)

lemma Ac_pos : 1 ≤ E.Ac := by unfold Ac; nlinarith

lemma cons_le (n h μ : ℕ) : E.cons n h μ ≤ E.Ac ^ (2 * h) := by
  induction h generalizing μ with
  | zero => rw [cons_zero]; exact Nat.zero_le _
  | succ h ih =>
    rw [cons_succ_idx]
    have hA := E.Ac_pos
    have hW := E.W_pos
    have h1 : ∀ j ∈ Finset.range E.nB, Nat.count (E.srcU n h μ (E.rkI j)) (E.W^h * E.W) +
        E.cons n h (μ * E.rkI j) ≤ E.Ac^(2*h+1) + E.Ac^(2*h) := by
      intro j _
      refine Nat.add_le_add ?_ (ih _)
      refine le_trans (count_le_self _) ?_
      rw [← pow_succ]
      calc E.W^(h+1) ≤ E.Ac^(h+1) :=
            Nat.pow_le_pow_left (by unfold Ac; nlinarith) _
        _ ≤ E.Ac^(2*h+1) := Nat.pow_le_pow_right hA (by omega)
    refine le_trans (Finset.sum_le_sum h1) ?_
    rw [Finset.sum_const, Finset.card_range, smul_eq_mul]
    have h2 : E.Ac^(2*h) ≤ E.Ac^(2*h+1) := Nat.pow_le_pow_right hA (by omega)
    have h3 : 2 * E.nB ≤ E.Ac := by unfold Ac; nlinarith
    calc E.nB * (E.Ac^(2*h+1) + E.Ac^(2*h)) ≤ E.nB * (2 * E.Ac^(2*h+1)) := by
          apply Nat.mul_le_mul_left; omega
      _ = (2 * E.nB) * E.Ac^(2*h+1) := by ring
      _ ≤ E.Ac * E.Ac^(2*h+1) := Nat.mul_le_mul_right _ h3
      _ = E.Ac^(2 * (h+1)) := by ring

def Kb : ℕ := E.Ac^2 * E.W * E.mx * E.Rs + 2

lemma Kb_ge : 2 ≤ E.Kb := by unfold Kb; omega

def bndC (d : ℕ × ℕ × ℕ) : ℕ := (d.1 + 2) * E.Kb^(d.2.1 + 1) * (d.2.2 + 1)

def locH (h : ℕ) : ℕ := E.nB * (E.W^h * E.W * (2 * h + 3 + 1) + 1 + (h + 1) + 4)

def locC (d : ℕ × ℕ × ℕ) : ℕ :=
  match d.2.1 with
  | 0 => 0
  | h + 1 => E.locH h

def cstC : ℕ → ℕ
  | 0 => 1
  | h + 1 => E.locH h + 1 + E.nB * cstC h

lemma W_le_Kb : E.W ≤ E.Kb := by
  have h1 : E.W ≤ E.Ac := by unfold Ac; nlinarith
  have h2 : E.Ac ≤ E.Ac^2 := by nlinarith [E.Ac_pos]
  have h3 : 1 ≤ E.mx := le_trans (by norm_num) E.three
  have h4 : 1 ≤ E.Rs := by unfold Rs; omega
  have h5 : E.Ac^2 ≤ E.Ac^2 * E.W * E.mx * E.Rs := by
    have := E.W_pos; nlinarith [Nat.mul_le_mul (Nat.mul_le_mul (le_refl (E.Ac^2)) (show 1 ≤ E.W from E.W_pos)) h3]
  unfold Kb; omega

lemma mx_le_Kb : E.mx ≤ E.Kb := by
  have h1 : 1 ≤ E.Ac^2 * E.W * E.Rs := by
    have := E.Ac_pos; have := E.W_pos; have h4 : 1 ≤ E.Rs := by unfold Rs; omega
    have : 1 ≤ E.Ac^2 := Nat.one_le_pow _ _ E.Ac_pos
    nlinarith [Nat.mul_le_mul this (show 1 ≤ E.W from E.W_pos)]
  unfold Kb
  nlinarith [Nat.mul_le_mul_left E.mx h1]

lemma Rs_le_Kb : E.Rs ≤ E.Kb := by
  have h1 : 1 ≤ E.Ac^2 * E.W * E.mx := by
    have : 1 ≤ E.Ac^2 := Nat.one_le_pow _ _ E.Ac_pos
    have h3 : 1 ≤ E.mx := le_trans (by norm_num) E.three
    nlinarith [Nat.mul_le_mul this (show 1 ≤ E.W from E.W_pos)]
  unfold Kb
  nlinarith [Nat.mul_le_mul_right E.Rs h1]

lemma nB_le_Kb : E.nB ≤ E.Kb := by
  have h1 : E.nB ≤ E.Ac := by unfold Ac; nlinarith [E.W_pos]
  have h2 : E.Ac ≤ E.Ac^2 := by nlinarith [E.Ac_pos]
  have h3 : E.Ac^2 ≤ E.Ac^2 * E.W * E.mx * E.Rs := by
    have h4 : 1 ≤ E.Rs := by unfold Rs; omega
    have h5 : 1 ≤ E.mx := le_trans (by norm_num) E.three
    have h6 : 1 ≤ E.W * E.mx * E.Rs := by
      have := E.W_pos; nlinarith [Nat.mul_le_mul (show 1 ≤ E.W from E.W_pos) h5]
    nlinarith [Nat.mul_le_mul_left (E.Ac^2) h6]
  unfold Kb; omega

lemma Ac2_le_Kb : E.Ac^2 ≤ E.Kb := by
  have h4 : 1 ≤ E.Rs := by unfold Rs; omega
  have h5 : 1 ≤ E.mx := le_trans (by norm_num) E.three
  have h6 : 1 ≤ E.W * E.mx * E.Rs := by
    have := E.W_pos; nlinarith [Nat.mul_le_mul (show 1 ≤ E.W from E.W_pos) h5]
  have : E.Ac^2 ≤ E.Ac^2 * E.W * E.mx * E.Rs := by nlinarith [Nat.mul_le_mul_left (E.Ac^2) h6]
  unfold Kb; omega

lemma bndC_kid (d c : ℕ × ℕ × ℕ) (hc : c ∈ E.kidsCnt d) : E.bndC c ≤ E.bndC d := by
  unfold kidsCnt at hc
  rcases d with ⟨n, h, μ⟩
  cases h with
  | zero => simp at hc
  | succ h =>
    simp only [List.mem_map, List.mem_range] at hc
    obtain ⟨j, -, rfl⟩ := hc
    unfold bndC
    simp only
    have hr := E.rkI_le j
    have hK := E.Rs_le_Kb
    have e1 : μ * E.rkI j + 1 ≤ (μ + 1) * E.Kb := by nlinarith [E.Kb_ge]
    calc (n + 2) * E.Kb ^ (h + 1) * (μ * E.rkI j + 1) ≤ (n + 2) * E.Kb ^ (h + 1) * ((μ + 1) * E.Kb) :=
          Nat.mul_le_mul_left _ e1
      _ = (n + 2) * E.Kb ^ (h + 1 + 1) * (μ + 1) := by ring

lemma small_sq {κ : Type*} {Bk f : κ → ℕ} (h : ∀ k, f k ≤ Bk k * Bk k) : Small Bk f :=
  ⟨2, fun k => le_trans (h k) (by nlinarith)⟩

def vC (n h μ j : ℕ) : ℕ :=
  ∑ j' ∈ Finset.range j, (Nat.count (E.srcU n h μ (E.rkI j')) (E.W^h * E.W) + E.cons n h (μ * E.rkI j'))

lemma vC_le (n h μ j : ℕ) (hj : j ≤ E.nB) : E.vC n h μ j ≤ E.Ac^(2 * (h+1)) := by
  have h1 : E.vC n h μ j ≤ E.vC n h μ E.nB :=
    Finset.sum_le_sum_of_subset (Finset.range_subset_range.2 hj)
  have h2 : E.vC n h μ E.nB = E.cons n (h+1) μ := (cons_succ_idx E n h μ).symm
  rw [h2] at h1
  exact le_trans h1 (E.cons_le n (h+1) μ)

open PowerSaving.MCost in
theorem cnt_body (m : Bool) :
    Able m (gfunds (s := p w (p w w)) (t := w) (fun d : ℕ × ℕ × ℕ => d) E.outCnt
        (fun d c => c ∈ E.kidsCnt d) E.bndC) (p w (p w w)) w
      (fun i => i.d) (fun i => E.outCnt i.d) (fun i => E.locC i.d)
      (fun i => listCharge E.kidsCnt i.d i.tau) := by
  let G := GDesc (s := p w (p w w)) (t := w) (fun d : ℕ × ℕ × ℕ => d) E.outCnt (fun d c => c ∈ E.kidsCnt d)
  let b := gfunds (s := p w (p w w)) (t := w) (fun d : ℕ × ℕ × ℕ => d) E.outCnt
    (fun d c => c ∈ E.kidsCnt d) E.bndC
  have hx : Able m b (p w (p w w)) w (fun i => i.d) (fun i => i.d.2.1) (fun _ => 0) (fun _ => 0) :=
    Able.of_can (Can.second.fst)
  -- h = 0
  have hz : Able m (b.comap (fun i : {i : G // i.d.2.1 = 0} => i.val)) (p w (p w w)) w
      (fun i => i.val.d) (fun i => E.outCnt i.val.d) (fun i => E.locC i.val.d)
      (fun i => listCharge E.kidsCnt i.val.d i.val.tau) := by
    refine ((Able.of_can (Can.wc 0)).mono (fun _ => Nat.zero_le _) (fun _ => Nat.zero_le _)).cong
      (fun _ => rfl) (fun i => ?_)
    show 0 = E.cons i.val.d.1 i.val.d.2.1 i.val.d.2.2
    rw [i.2, cons_zero]
  -- h ≥ 1: one loop over the block letters
  let S := {i : G // i.d.2.1 ≠ 0}
  let b3 := b.comap (fun i : S => i.val)
  let nS (i : S) := i.val.d.1
  let hS (i : S) := i.val.d.2.1 - 1
  let μS (i : S) := i.val.d.2.2
  let child (i : S) (j : ℕ) : ℕ × ℕ × ℕ := (nS i, hS i, μS i * E.rkI j)
  have hmem : ∀ (i : S) (j : ℕ), j < E.nB → child i j ∈ E.kidsCnt i.val.d := by
    intro i j hj
    obtain ⟨⟨⟨n, h, μ⟩, use, tau, peak, works⟩, h0⟩ := i
    have h0' : h ≠ 0 := h0
    obtain ⟨h', rfl⟩ : ∃ h', h = h' + 1 := ⟨h - 1, by omega⟩
    simp only [kidsCnt, List.mem_map, List.mem_range]
    exact ⟨j, hj, by simp [child, nS, hS, μS]⟩
  let Wb (i : S) (_ : ℕ) : ℕ := E.W^(hS i) * E.W * (2 * hS i + 3 + 1) + 1 + (hS i + 1)
  let Zb (i : S) (j : ℕ) : ℕ := i.val.tau (child i j)
  let Dd := During (fun _ : S => E.nB)
  let b4 := b3.comap (During.i (n := fun _ : S => E.nB))
  let env (d : Dd) : T (p (p w (p w w)) (p w w)) := (d.i.val.d, (d.j, E.vC (nS d.i) (hS d.i) (μS d.i) d.j))
  let Bd (d : Dd) : ℕ := E.bndC d.i.val.d
  have hb4 : b4.B = Bd := rfl
  -- bounds
  have hbnd : ∀ d : Dd, (nS d.i + 2) * E.Kb^(hS d.i + 1 + 1) * (μS d.i + 1) = Bd d := by
    intro d
    have h0 : d.i.val.d.2.1 ≠ 0 := d.i.2
    simp only [Bd, bndC, nS, hS, μS]
    congr 2; congr 1; omega
  have hKp : ∀ d : Dd, E.Kb^(hS d.i + 1 + 1) ≤ Bd d := by
    intro d; rw [← hbnd d]
    calc E.Kb^(hS d.i + 1 + 1) = 1 * E.Kb^(hS d.i + 1 + 1) * 1 := by ring
      _ ≤ (nS d.i + 2) * E.Kb^(hS d.i + 1 + 1) * (μS d.i + 1) := by gcongr <;> omega
  have hKpow : ∀ d : Dd, ∀ e ≤ hS d.i + 1 + 1, E.Kb^e ≤ Bd d := fun d e he =>
    le_trans (Nat.pow_le_pow_right (by have := E.Kb_ge; omega) he) (hKp d)
  have hK1 : ∀ d : Dd, E.Kb ≤ Bd d := fun d => by simpa using hKpow d 1 (by omega)
  have hnB : ∀ d : Dd, nS d.i ≤ Bd d := by
    intro d; rw [← hbnd d]
    have h1 : 1 ≤ E.Kb^(hS d.i + 1 + 1) := Nat.one_le_pow _ _ (by have := E.Kb_ge; omega)
    calc nS d.i ≤ (nS d.i + 2) * 1 * 1 := by omega
      _ ≤ (nS d.i + 2) * E.Kb^(hS d.i + 1 + 1) * (μS d.i + 1) :=
          Nat.mul_le_mul (Nat.mul_le_mul le_rfl h1) (by omega)
  have hμB : ∀ d : Dd, μS d.i ≤ Bd d := by
    intro d; rw [← hbnd d]
    have h1 : 1 ≤ E.Kb^(hS d.i + 1 + 1) := Nat.one_le_pow _ _ (by have := E.Kb_ge; omega)
    calc μS d.i ≤ 1 * 1 * (μS d.i + 1) := by omega
      _ ≤ (nS d.i + 2) * E.Kb^(hS d.i + 1 + 1) * (μS d.i + 1) :=
          Nat.mul_le_mul (Nat.mul_le_mul (by omega) h1) le_rfl
  have hB4 : ∀ d : Dd, 4 ≤ Bd d := by
    intro d
    have h1 : 2^2 ≤ E.Kb^2 := Nat.pow_le_pow_left E.Kb_ge 2
    have h2 := hKpow d 2 (by omega)
    norm_num at h1; omega
  have hhB : ∀ d : Dd, hS d.i + 1 ≤ Bd d := by
    intro d
    have h1 : hS d.i + 1 < 2^(hS d.i + 1) := Nat.lt_two_pow_self
    have h2 : 2^(hS d.i + 1) ≤ E.Kb^(hS d.i + 1) := Nat.pow_le_pow_left E.Kb_ge _
    have h3 := hKpow d (hS d.i + 1) (by omega)
    omega
  have hWB : ∀ d : Dd, E.W^(hS d.i) * E.W ≤ Bd d := by
    intro d
    have h1 : E.W^(hS d.i) * E.W = E.W^(hS d.i + 1) := by ring
    rw [h1]
    exact le_trans (Nat.pow_le_pow_left E.W_le_Kb _) (hKpow d _ (by omega))
  have hmxB : ∀ d : Dd, E.mx^(hS d.i + 1) ≤ Bd d := fun d =>
    le_trans (Nat.pow_le_pow_left E.mx_le_Kb _) (hKpow d _ (by omega))
  have hjB : ∀ d : Dd, d.j ≤ Bd d := fun d => le_trans (le_trans d.hj.le E.nB_le_Kb) (hK1 d)
  have hrB : ∀ d : Dd, E.rkI d.j ≤ Bd d := fun d => le_trans (le_trans (E.rkI_le _) E.Rs_le_Kb) (hK1 d)
  have hvB : ∀ d : Dd, E.vC (nS d.i) (hS d.i) (μS d.i) d.j ≤ Bd d := by
    intro d
    have h1 := E.vC_le (nS d.i) (hS d.i) (μS d.i) d.j d.hj.le
    have h2 : E.Ac^(2 * (hS d.i + 1)) ≤ E.Kb^(hS d.i + 1) := by
      rw [pow_mul]; exact Nat.pow_le_pow_left E.Ac2_le_Kb _
    exact le_trans h1 (le_trans h2 (hKpow d _ (by omega)))
  have hcB : ∀ d : Dd, E.cons (nS d.i) (hS d.i) (μS d.i * E.rkI d.j) ≤ Bd d := by
    intro d
    have h1 := E.cons_le (nS d.i) (hS d.i) (μS d.i * E.rkI d.j)
    have h2 : E.Ac^(2 * hS d.i) ≤ E.Kb^(hS d.i) := by
      rw [pow_mul]; exact Nat.pow_le_pow_left E.Ac2_le_Kb _
    exact le_trans h1 (le_trans h2 (hKpow d _ (by omega)))
  have hcntB : ∀ d : Dd, Nat.count (E.srcU (nS d.i) (hS d.i) (μS d.i) (E.rkI d.j)) (E.W^(hS d.i) * E.W) ≤ Bd d :=
    fun d => le_trans (count_le_self _) (hWB d)
  -- the step
  have hs : Able m b4 (p (p w (p w w)) (p w w)) w env
      (fun d => E.vC (nS d.i) (hS d.i) (μS d.i) (d.j + 1)) (fun d => Wb d.i d.j) (fun d => Zb d.i d.j) := by
    have nK : Knows m Bd (p (p w (p w w)) (p w w)) env (fun d => nS d.i) := Has.extE Can.first
    have hhK : Knows m Bd (p (p w (p w w)) (p w w)) env (fun d => d.i.val.d.2.1) :=
      Has.extE Can.second.fst
    have μK : Knows m Bd (p (p w (p w w)) (p w w)) env (fun d => μS d.i) := Has.extE Can.second.snd
    have jK : Knows m Bd (p (p w (p w w)) (p w w)) env (fun d => d.j) := Can.second.fst
    have aK : Knows m Bd (p (p w (p w w)) (p w w)) env (fun d => E.vC (nS d.i) (hS d.i) (μS d.i) d.j) :=
      Can.second.snd
    have sh : Small Bd (fun d => d.i.val.d.2.1) := small_sq (fun d => by
      have := hhB d; have h0 : d.i.val.d.2.1 ≠ 0 := d.i.2
      have : d.i.val.d.2.1 ≤ Bd d := by simp only [hS] at this; omega
      nlinarith)
    have hK' : Knows m Bd (p (p w (p w w)) (p w w)) env (fun d => hS d.i) := hhK.minus (Can.wc 1) sh
    have rK : Knows m Bd (p (p w (p w w)) (p w w)) env (fun d => E.rkI d.j) := by
      apply Can.cases_code (q := fun d : Dd => (⟨d.j, d.hj⟩ : Fin E.nB)) (Layout.std E.nB) jK
      intro f
      refine (Can.wc (E.rkI f)).cong (fun _ => rfl) (fun d => ?_)
      show E.rkI f = E.rkI d.1.j
      rw [show d.1.j = (f : ℕ) from congrArg Fin.val d.2]
    have sn : Small Bd (fun d => nS d.i) := small_sq (fun d => by nlinarith [hnB d])
    have sμ : Small Bd (fun d => μS d.i) := small_sq (fun d => by nlinarith [hμB d])
    have sr : Small Bd (fun d => E.rkI d.j) := small_sq (fun d => by nlinarith [hrB d])
    have shS : Small Bd (fun d => hS d.i) := small_sq (fun d => by nlinarith [hhB d])
    have sμr : Small Bd (fun d => μS d.i * E.rkI d.j) := small_sq (fun d => Nat.mul_le_mul (hμB d) (hrB d))
    have μrK : Knows m Bd (p (p w (p w w)) (p w w)) env (fun d => μS d.i * E.rkI d.j) := μK.times rK sμ sr
    -- the child's input and the call
    have hin : Has m Bd (p (p w (p w w)) (p w w)) (p w (p w w)) env (fun d => child d.i d.j) :=
      nK.pair (hK'.pair μrK)
    have hcall : Able m b4 (p w (p w w)) w (fun d => child d.i d.j)
        (fun d => E.cons (nS d.i) (hS d.i) (μS d.i * E.rkI d.j)) (fun _ => 0) (fun d => Zb d.i d.j) :=
      Able.use_call (fun d => d.i.val.works (child d.i d.j) (hmem d.i d.j d.hj))
    have A2 : Able m b4 (p (p w (p w w)) (p w w)) w env
        (fun d => E.cons (nS d.i) (hS d.i) (μS d.i * E.rkI d.j)) (fun _ => 0 + 0) (fun d => 0 + Zb d.i d.j) :=
      (Able.of_can (b := b4) hin).comp hcall
    -- the count
    have sW : Small Bd (fun d => E.W^(hS d.i)) := small_sq (fun d => by
      have := hWB d; have : E.W^(hS d.i) ≤ E.W^(hS d.i) * E.W := Nat.le_mul_of_pos_right _ E.W_pos
      nlinarith)
    have p2 : Can m Bd (p (p w (p w w)) (p w w)) w env (fun d => E.W^(hS d.i)) (fun d => hS d.i + 1) :=
      can_powv E.W E.W_pos hK' shS sW
    let env' (d : Dd) : T (p (p (p w (p w w)) (p w w)) w) := (env d, E.W^(hS d.i))
    have F : Lifts m Bd (p (p w (p w w)) (p w w)) env (p (p (p w (p w w)) (p w w)) w) env' := fun {_ _} g => Has.extE g
    have cnt := E.can_ownCnt (F nK) (F hK') (F μK) (F rK) (Can.second) sn shS sμ sr
      (small_sq (fun d => by nlinarith [hWB d])) (small_sq (fun d => by nlinarith [hmxB d]))
    have A1c : Can m Bd (p (p w (p w w)) (p w w)) w env
        (fun d => Nat.count (E.srcU (nS d.i) (hS d.i) (μS d.i) (E.rkI d.j)) (E.W^(hS d.i) * E.W))
        (fun d => (hS d.i + 1) + (E.W^(hS d.i) * E.W * (2 * hS d.i + 3 + 1) + 1)) :=
      Can.save p2 cnt
    have A1 := Able.of_can (b := b4) A1c
    have A3 := Able.of_can (b := b4) aK
    have Fk := A3.fork (A1.fork A2)
    -- add
    let tri (d : Dd) : T (p w (p w w)) := (E.vC (nS d.i) (hS d.i) (μS d.i) d.j,
      (Nat.count (E.srcU (nS d.i) (hS d.i) (μS d.i) (E.rkI d.j)) (E.W^(hS d.i) * E.W),
       E.cons (nS d.i) (hS d.i) (μS d.i * E.rkI d.j)))
    have hadd : Knows m Bd (p w (p w w)) tri
        (fun d => (tri d).1 + ((tri d).2.1 + (tri d).2.2)) :=
      Can.first.plus (Can.second.fst.plus Can.second.snd
        (small_sq (fun d => le_trans (hcntB d) (by nlinarith [hB4 d])))
        (small_sq (fun d => le_trans (hcB d) (by nlinarith [hB4 d]))))
        (small_sq (fun d => le_trans (hvB d) (by nlinarith [hB4 d])))
        (small_sq (fun d => by
          have h1 := hcntB d; have h2 := hcB d; have h3 := hB4 d
          show _ + _ ≤ _
          nlinarith))
    have H := Fk.comp (Able.of_can (b := b4) hadd)
    refine (H.cong (fun _ => rfl) (fun d => ?_)).weaken (Dom.of_le (fun d => ?_)) (fun d => by simp)
    · show E.vC (nS d.i) (hS d.i) (μS d.i) d.j + (Nat.count (E.srcU (nS d.i) (hS d.i) (μS d.i) (E.rkI d.j))
        (E.W^(hS d.i) * E.W) + E.cons (nS d.i) (hS d.i) (μS d.i * E.rkI d.j)) = E.vC (nS d.i) (hS d.i) (μS d.i) (d.j + 1)
      simp only [vC, Finset.sum_range_succ]
    · simp only [Wb]; omega
  have hloop := Able.loop (b := b3) (s := p w (p w w)) (x := fun i : S => (i.val.d : T (p w (p w w))))
    (n := fun _ : S => E.nB) (v := fun i j => E.vC (nS i) (hS i) (μS i) j)
    (Wb := Wb) (Zb := Zb) (Able.of_can (Can.wc (W := fun _ => 0) E.nB))
    (Able.of_can ((Can.wc (W := fun _ => 0) 0).cong (fun _ => rfl) (fun i => by simp [vC]))) hs (Small.const _ _)
  have hn : Able m (b.comap (fun i : {i : G // i.d.2.1 ≠ 0} => i.val)) (p w (p w w)) w
      (fun i => i.val.d) (fun i => E.outCnt i.val.d) (fun i => E.locC i.val.d)
      (fun i => listCharge E.kidsCnt i.val.d i.val.tau) := by
    refine (hloop.cong (fun _ => rfl) (fun i => ?_)).weaken (Dom.of_le (fun i => ?_)) (fun i => ?_)
    · obtain ⟨⟨⟨n, h, μ⟩, use, tau, peak, works⟩, h0⟩ := i
      have h0' : h ≠ 0 := h0
      obtain ⟨h', rfl⟩ : ∃ h', h = h' + 1 := ⟨h - 1, by omega⟩
      show E.vC n (h' + 1 - 1) μ E.nB = E.cons n (h' + 1) μ
      simp only [Nat.add_sub_cancel]
      exact (cons_succ_idx E n h' μ).symm
    · obtain ⟨⟨⟨n, h, μ⟩, use, tau, peak, works⟩, h0⟩ := i
      have h0' : h ≠ 0 := h0
      obtain ⟨h', rfl⟩ : ∃ h', h = h' + 1 := ⟨h - 1, by omega⟩
      simp only [Finset.sum_const, Finset.card_range, smul_eq_mul, Wb, hS, locC, locH, Nat.add_sub_cancel]
      nlinarith
    · obtain ⟨⟨⟨n, h, μ⟩, use, tau, peak, works⟩, h0⟩ := i
      have h0' : h ≠ 0 := h0
      obtain ⟨h', rfl⟩ : ∃ h', h = h' + 1 := ⟨h - 1, by omega⟩
      simp only [Zb, child, nS, hS, μS, listCharge, kidsCnt, Nat.add_sub_cancel, zero_add]
      rw [List.map_map, sum_map_range]
      rfl
  have H := Able.ifz (t := w) (y := fun i : G => E.outCnt i.d) (W := fun i : G => E.locC i.d)
    (Z := fun i : G => listCharge E.kidsCnt i.d i.tau) hx hz hn
  exact H.mono (fun i => by simp) (fun i => by simp)

open PowerSaving.MCost in
theorem can_cons (m : Bool) {ι : Type U} (dd : ι → ℕ × ℕ × ℕ) :
    Can m (fun i => E.bndC (dd i)) (p w (p w w)) w (fun i => dd i) (fun i => E.cons (dd i).1 (dd i).2.1 (dd i).2.2)
      (fun i => E.cstC (dd i).2.1) := by
  refine recurse_list (s := p w (p w w)) (t := w) m (fun d => d) E.outCnt E.kidsCnt E.bndC E.locC
    (fun d => d.2.1) (fun d => d.2.1 + 1) (fun d => E.cstC d.2.1) (E.cnt_body m) ?_ (E.bndC_kid) ?_ ?_
    (fun d => Nat.lt_succ_self _) ?_ dd
  · intro d c hc
    rcases d with ⟨n, h, μ⟩
    cases h with
    | zero => simp [kidsCnt] at hc
    | succ h =>
      simp only [kidsCnt, List.mem_map, List.mem_range] at hc
      obtain ⟨j, -, rfl⟩ := hc
      simp
  · intro d
    rcases d with ⟨n, h, μ⟩
    cases h with
    | zero => simp [locC, kidsCnt, cstC]
    | succ h =>
      simp only [locC, kidsCnt, List.map_map, cstC]
      rw [show ((List.range E.nB).map ((fun d : ℕ × ℕ × ℕ => E.cstC d.2.1) ∘ fun j => (n, h, μ * E.rkI j))).sum
          = E.nB * E.cstC h by
        rw [sum_map_range]; simp]
  · have hfs : Small E.bndC (fun d : ℕ × ℕ × ℕ => d.2.1 + 1) := ⟨1, fun d => by
      simp only [bndC, pow_one]
      have h1 : d.2.1 + 1 < 2^(d.2.1 + 1) := Nat.lt_two_pow_self
      have h2 : 2^(d.2.1 + 1) ≤ E.Kb^(d.2.1 + 1) := Nat.pow_le_pow_left E.Kb_ge _
      have h3 : E.Kb^(d.2.1 + 1) ≤ (d.1 + 2) * E.Kb^(d.2.1 + 1) * (d.2.2 + 1) := by
        calc E.Kb^(d.2.1 + 1) = 1 * E.Kb^(d.2.1 + 1) * 1 := by ring
          _ ≤ _ := Nat.mul_le_mul (Nat.mul_le_mul (by omega) le_rfl) (by omega)
      exact le_trans (le_of_lt (lt_of_lt_of_le h1 (le_trans h2 h3))) (Nat.le_add_right _ _)⟩
    exact ((Can.second.fst).plus (Can.wc 1) (hfs.mono (fun d => Nat.le_succ _)) (Small.const _ 1)).mono
      (fun _ => Nat.zero_le _)
  · exact ⟨1, fun d => by
      simp only [bndC, pow_one]
      have h1 : d.2.1 + 1 < 2^(d.2.1 + 1) := Nat.lt_two_pow_self
      have h2 : 2^(d.2.1 + 1) ≤ E.Kb^(d.2.1 + 1) := Nat.pow_le_pow_left E.Kb_ge _
      have h3 : E.Kb^(d.2.1 + 1) ≤ (d.1 + 2) * E.Kb^(d.2.1 + 1) * (d.2.2 + 1) := by
        calc E.Kb^(d.2.1 + 1) = 1 * E.Kb^(d.2.1 + 1) * 1 := by ring
          _ ≤ _ := Nat.mul_le_mul (Nat.mul_le_mul (by omega) le_rfl) (by omega)
      exact le_trans (le_of_lt (lt_of_lt_of_le h1 (le_trans h2 h3))) (Nat.le_add_right _ _)⟩

lemma locH_mono {h h' : ℕ} (hh : h ≤ h') : E.locH h ≤ E.locH h' := by
  unfold locH
  apply Nat.mul_le_mul_left
  have h1 : E.W^h ≤ E.W^h' := Nat.pow_le_pow_right E.W_pos hh
  have h2 : E.W^h * E.W * (2 * h + 3 + 1) ≤ E.W^h' * E.W * (2 * h' + 3 + 1) :=
    Nat.mul_le_mul (Nat.mul_le_mul_right _ h1) (by omega)
  omega

lemma cstC_le (h : ℕ) : E.cstC h ≤ (E.nB + 1)^h * (E.locH h + 2) := by
  induction h with
  | zero => simp [cstC]
  | succ h ih =>
    simp only [cstC]
    have hm : E.locH h ≤ E.locH (h+1) := E.locH_mono (by omega)
    have h1 : E.nB * E.cstC h ≤ E.nB * ((E.nB + 1)^h * (E.locH (h+1) + 2)) :=
      Nat.mul_le_mul_left _ (le_trans ih (Nat.mul_le_mul_left _ (by omega)))
    have h2 : 1 ≤ (E.nB + 1)^h := Nat.one_le_pow _ _ (by omega)
    calc E.locH h + 1 + E.nB * E.cstC h ≤ (E.locH (h+1) + 2) + E.nB * ((E.nB + 1)^h * (E.locH (h+1) + 2)) := by
          omega
      _ ≤ (E.nB + 1)^h * (E.locH (h+1) + 2) + E.nB * ((E.nB + 1)^h * (E.locH (h+1) + 2)) := by
          have : E.locH (h+1) + 2 ≤ (E.nB + 1)^h * (E.locH (h+1) + 2) := Nat.le_mul_of_pos_left _ h2
          omega
      _ = (E.nB + 1)^(h+1) * (E.locH (h+1) + 2) := by ring

end Eng

end
end PowerSaving.RAM
end OAI

namespace OAI
namespace PowerSaving.MCost
open PowerSaving.RAM PowerSaving.Binary Ty

noncomputable section

universe U

section
variable {m : Bool} {ι : Type U} {cl : Paint} {s : Ty} {x : ι → T s} {Bd : ι → ℕ}

theorem naive_jobs (n N : ι → ℕ) (u : ∀ i, ℕ → Bits (n i) → ℂ)
    (ht : Has m Bd s (a (a (c cl))) x (fun i => (Layout.std (N i)).tape (fun t => (bits (n i)).tape (u i t))))
    (hn : Knows m Bd s x n) (hN : Knows m Bd s x N) (hI : Has m Bd s sc x (fun _ => Complex.I))
    (hNs : Small Bd N) (h2s : Small Bd (fun i => 2 ^ n i)) :
    Can m Bd s (a (a (c cl))) x
      (fun i => (Layout.std (N i)).tape (fun t => (bits (n i)).tape (ripple (n i) (u i t))))
      (fun i => N i * ((n i + 1) * 2 ^ n i + 1)) := by
  let Q := Σ i, Fin (N i)
  let σ : Q → ι := Sigma.fst
  let E (d : Q) : T (p s w) := (x d.1, (Layout.std (N d.1)).loc d.2)
  -- the input of the naive kernel for job `d`
  have hin : Can m (fun d : Q => Bd d.1) (p s w) (simIn cl) E
      (fun d => givenBits cl (n d.1) (u d.1 d.2)) (fun d => (n d.1 + 1) * 2 ^ n d.1) := by
    have hn' : Knows m (fun d : Q => Bd d.1) (p s w) E (fun d => n d.1) := Has.extE (hn.reindex σ)
    have hI' : Has m (fun d : Q => Bd d.1) (p s w) sc E (fun _ => Complex.I) := Has.extE (hI.reindex σ)
    have hj : Has m (fun d : Q => Bd d.1) (p s w) (a (c cl)) E (fun d => (bits (n d.1)).tape (u d.1 d.2)) :=
      Can.fetch (t := a (c cl)) (L := fun d : Q => Layout.std (N d.1))
        (v := fun d : Q => fun t : Fin (N d.1) => (bits (n d.1)).tape (u d.1 t)) (i := fun d : Q => d.2)
        (Has.extE (ht.reindex σ)) Can.second
    exact (Has.atW (Can.pair hn' (Can.pair hI' hj)))
  have hh := (naive_kernel cl m (fun d : Q => n d.1) (fun d => u d.1 d.2)).ambient
    (B' := fun d : Q => Bd d.1) (h2s.reindex σ)
  have hval : Can m (fun d : Q => Bd d.1) (p s w) (a (c cl)) E
      (fun d => (bits (n d.1)).tape (ripple (n d.1) (u d.1 d.2))) (fun d => (n d.1 + 1) * 2 ^ n d.1) := by
    refine hin.then_do (hh.weaken ⟨2, fun d => ?_⟩)
    show 2 ^ n d.1 * (2 * n d.1 + 1) + 1 ≤ 2 * ((n d.1 + 1) * 2 ^ n d.1 + 1)
    calc 2 ^ n d.1 * (2 * n d.1 + 1) + 1 ≤ (2 ^ n d.1 * (2 * n d.1 + 1) + 2 ^ n d.1) + 2 :=
          Nat.add_le_add (Nat.le_add_right _ _) (by norm_num)
      _ = 2 * ((n d.1 + 1) * 2 ^ n d.1 + 1) := by ring
  exact Can.table (t := a (c cl)) (P := fun i => (n i + 1) * 2 ^ n i)
    (fun i t => (bits (n i)).tape (ripple (n i) (u i t))) hN hNs hval

end

end
end PowerSaving.MCost
end OAI


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

universe U

section Rest
variable {Ξ : Type U} {m : Bool} {cl : Paint} {s : Ty} {x : Ξ → T s} {Bd : Ξ → ℕ}

lemma can_hiVec {n sz : Ξ → ℕ} (hs : ∀ e, sz e ≤ n e) {wv : ∀ e, Bits (n e) → ℂ}
    (hw : Has m Bd s (a (c cl)) x (fun e => (bits (n e)).tape (wv e)))
    (hp1 : Knows m Bd s x (fun e => 2^(sz e))) (hp2 : Knows m Bd s x (fun e => 2^(n e - sz e)))
    (hbig : Small Bd (fun e => 2^(n e))) :
    Can m Bd s (jobsT cl) x
      (fun e => jobsTape (n e - sz e) (2^(sz e)) (hiVec (n e) (sz e) (wv e))) (fun e => 2^(n e)) := by
  have hle1 : ∀ e, 2^(sz e) ≤ 2^(n e) := fun e => Nat.pow_le_pow_right (by omega) (hs e)
  have hle2 : ∀ e, 2^(n e - sz e) ≤ 2^(n e) := fun e => Nat.pow_le_pow_right (by omega) (Nat.sub_le _ _)
  have hs1 : Small Bd (fun e => 2^(sz e)) := hbig.mono hle1
  have hs2 : Small Bd (fun e => 2^(n e - sz e)) := hbig.mono hle2
  let Du := UnitF (fun e => 2^(sz e))
  let Dv := Σ u : Du, Bits (n u.1 - sz u.1)
  let yv (d : Dv) : T (p (p s w) w) := ((x d.1.1, d.1.2.val), (bits (n d.1.1 - sz d.1.1)).loc d.2)
  let Bv (d : Dv) := Bd d.1.1
  have hcls : ∀ {t : Ty} {y : Ξ → T t}, Has m Bd s t x y → Has m Bv (p (p s w) w) t yv (fun d => y d.1.1) :=
    fun g => (Has.extE Can.first).then_do (g.reindex (fun d : Dv => d.1.1))
  have hq : Knows m Bv (p (p s w) w) yv (fun d => d.1.2.val) := Has.extE Can.second
  have hyl : Knows m Bv (p (p s w) w) yv (fun d => (bits (n d.1.1 - sz d.1.1)).loc d.2) := Can.second
  have hqs : Small Bv (fun d => d.1.2.val) := (hs1.reindex (fun d : Dv => d.1.1)).mono (fun d => d.1.2.2.le)
  have hys : Small Bv (fun d => (bits (n d.1.1 - sz d.1.1)).loc d.2) :=
    (hs2.reindex (fun d : Dv => d.1.1)).mono (fun d => ((bits _).bd _).le)
  have hp1s : Small Bv (fun d => 2^(sz d.1.1)) := hs1.reindex (fun d : Dv => d.1.1)
  have haddr : Knows m Bv (p (p s w) w) yv
      (fun d => (bits (n d.1.1)).loc (castB (Nat.add_sub_cancel' (hs d.1.1))
        (catB (sz d.1.1) (n d.1.1 - sz d.1.1) (bitsOf (sz d.1.1) d.1.2.val, d.2)))) := by
    refine (hq.plus ((hcls hp1).times hyl hp1s hys) hqs (hp1s.mul hys)).cong (fun _ => rfl) (fun d => ?_)
    rw [loc_castB_catB _ _ (hs d.1.1), bitsOf_loc, Nat.mod_eq_of_lt d.1.2.2]
  have hv := Can.fetch (t := c cl) (L := fun d : Dv => bits (n d.1.1)) (v := fun d => wv d.1.1)
    (i := fun d => castB (Nat.add_sub_cancel' (hs d.1.1))
      (catB (sz d.1.1) (n d.1.1 - sz d.1.1) (bitsOf (sz d.1.1) d.1.2.val, d.2))) (hcls hw) haddr
  have hv' : Has m Bv (p (p s w) w) (c cl) yv
      (fun d => hiVec (n d.1.1) (sz d.1.1) (wv d.1.1) d.1.2.val d.2) := by
    refine hv.cong (fun _ => rfl) (fun d => ?_)
    unfold hiVec; rw [dif_pos (hs d.1.1)]
  refine (Can.jobsTable (fun e q => hiVec (n e) (sz e) (wv e) q) hp1 hp2 hs1 hs2 hv').weaken
    (Dom.of_le (fun e => le_of_eq ?_))
  show 2^(sz e) * 2^(n e - sz e) = 2^(n e)
  rw [← pow_add, Nat.add_sub_cancel' (hs e)]

lemma rest_call {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
    [Fintype σ] [DecidableEq σ] (E : Eng α ρ σ) {b : Bank (portM cl) Ξ} {x : Ξ → T s}
    {n sz : Ξ → ℕ} (hs : ∀ e, sz e ≤ n e) {wv : ∀ e, Bits (n e) → ℂ}
    (hw : Has m b.B s (a (c cl)) x (fun e => (bits (n e)).tape (wv e)))
    (hn : Knows m b.B s x n) (hsz : Knows m b.B s x sz)
    (hp1 : Knows m b.B s x (fun e => 2^(sz e))) (hp2 : Knows m b.B s x (fun e => 2^(n e - sz e)))
    (hI : Has m b.B s sc x (fun _ => Complex.I))
    (hemp : Has m b.B s (jobsT cl) x (fun e => jobsTape 0 0 (fun _ _ => 0)))
    (hbig : Small b.B (fun e => 2^(n e)))
    {Z : Ξ → ℕ}
    (hcall : ∀ e, (b.use e (E.enc cl (MDesc.top (n e - sz e) (2^(sz e)) (hiVec (n e) (sz e) (wv e))))).OK
      (E.out cl (MDesc.top (n e - sz e) (2^(sz e)) (hiVec (n e) (sz e) (wv e)))) (Z e) (b.ext e)) :
    Able m b s (jobsT cl) x
      (fun e => jobsTape (n e - sz e) (2^(sz e)) (fun q => ripple (n e - sz e) (hiVec (n e) (sz e) (wv e) q)))
      (fun e => 2^(n e)) Z := by
  have hns : Small b.B n := hbig.mono (fun e => (Nat.lt_two_pow_self).le)
  have hk : Knows m b.B s x (fun e => n e - sz e) := hn.minus hsz hns
  have hpieces := can_hiVec (cl := cl) hs hw hp1 hp2 hbig
  have hin : Can m b.B s (portIn cl) x
      (fun e => E.enc cl (MDesc.top (n e - sz e) (2^(sz e)) (hiVec (n e) (sz e) (wv e)))) (fun e => 2^(n e)) := by
    refine ((Has.atW hk).pair ((Has.atW hI).pair
      ((Can.wc 0).pair ((Can.wc 0).pair ((Can.wc 0).pair (hpieces.pair
        (Has.atW hemp))))))).cong (fun _ => rfl) (fun e => ?_)
    simp only [Eng.enc, mkIn]
    rw [jobsTape_zero 0 (n e - sz e)]
  have Hcall := (Able.of_can (b := b) hin).comp (Able.use_call (m := m) (b := b) hcall)
  refine (Hcall.fst).weaken (Dom.of_le (fun e => by simp)) (fun e => by simp) |>.cong (fun _ => rfl)
    (fun e => rfl)

end Rest

end
end PowerSaving.RAM
end OAI

namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

universe U

lemma sizes_zero : (Layout.std 0).tape (fun _ : Fin 0 => (0 : ℕ)) = Tape.tab 0 (fun _ => 0) :=
  Tape.ext_look rfl 0 (fun i hi => absurd hi (Nat.not_lt_zero _))

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]
variable (E : Eng α ρ σ)

lemma slotSize_le (n h μ t : ℕ) (ht : t < E.NUc n h μ * E.W) : E.slotSize n h μ t ≤ n := by
  have hp : t / E.W < E.NUc n h μ := (Nat.div_lt_iff_lt_mul E.W_pos).2 ht
  have h1 := MXR.U_fits hp (W := E.W) (tq := E.tq) (mx := E.mx)
  unfold slotSize
  exact le_trans (Nat.mul_le_mul_right _ (E.tq_le _)) h1

lemma srcSizes_le (n : ℕ) : ∀ (h μ : ℕ), ∀ x ∈ E.srcSizes n h μ, x ≤ n := by
  intro h
  induction h with
  | zero => intro μ x hx; simp [srcSizes] at hx
  | succ h ih =>
    intro μ x hx
    simp only [srcSizes, List.mem_flatMap, List.mem_append] at hx
    obtain ⟨r, _, hx⟩ := hx
    rcases hx with hx | hx
    · unfold ownSrc at hx
      simp only [List.mem_filterMap, List.mem_range] at hx
      obtain ⟨t, ht, hx⟩ := hx
      split_ifs at hx with hs
      · simp only [Option.some.injEq] at hx
        subst hx
        exact E.slotSize_le _ _ _ _ hs.1
    · exact ih _ x hx

lemma csz_le (n h μ k : ℕ) : E.csz n h μ k ≤ n := by
  unfold csz
  rw [List.getD_eq_getElem?_getD]
  cases hk : (E.srcSizes n h μ)[k]? with
  | none => simp
  | some x => exact E.srcSizes_le n h μ x (List.mem_of_getElem? hk)

lemma topSz_le (kmin n j : ℕ) : E.topSz kmin n j ≤ n := by
  unfold topSz
  split_ifs with hj
  · exact E.slotSize_le _ _ _ _ hj
  · exact E.csz_le _ _ _ _

section Top
variable {Ξ : Type U} {m : Bool} {cl : Paint} {b : Bank (portM cl) Ξ} {s : Ty} {y : Ξ → T s}

lemma findGreatest_step (P : ℕ → Prop) [DecidablePred P] (j : ℕ) :
    Nat.findGreatest P (j + 1) = Nat.findGreatest P j +
      (if P (j + 1) then 1 else 0) * (j + 1 - Nat.findGreatest P j) := by
  rw [Nat.findGreatest_succ]
  have := Nat.findGreatest_le (P := P) j
  split_ifs <;> omega

lemma can_topG (kmin : ℕ) (hk : 2 ≤ kmin) {Bd n : Ξ → ℕ} (hn : Knows m Bd s y n)
    (hpow : Small Bd (fun e => kmin^(n e + 1))) (hns : Small Bd n) :
    Can m Bd s w y (fun e => E.topG kmin (n e)) (fun e => n e * (n e + 3) + 1) := by
  let v (e : Ξ) (j : ℕ) : T (p w w) := (Nat.findGreatest (fun g => E.mx * kmin ^ g ≤ n e) j, kmin ^ (j + 1))
  have hk1 : 1 ≤ kmin := by omega
  have hs : Can m (fun d : During n => Bd d.i) (p s (p w (p w w))) (p w w)
      (fun d => (y d.i, d.j, v d.i d.j)) (fun d => v d.i (d.j + 1)) (fun _ => 0) := by
    let BD (d : During n) := Bd d.i
    have hpw : Knows m BD (p s (p w (p w w))) (fun d => (y d.i, d.j, v d.i d.j)) (fun d => kmin ^ (d.j + 1)) :=
      Can.snd (Can.snd Can.second)
    have hbest : Knows m BD (p s (p w (p w w))) (fun d => (y d.i, d.j, v d.i d.j))
        (fun d => Nat.findGreatest (fun g => E.mx * kmin ^ g ≤ n d.i) d.j) := Can.fst (Can.snd Can.second)
    have hj : Knows m BD (p s (p w (p w w))) (fun d => (y d.i, d.j, v d.i d.j)) (fun d => d.j) :=
      Can.fst Can.second
    have hnD : Knows m BD (p s (p w (p w w))) (fun d => (y d.i, d.j, v d.i d.j)) (fun d => n d.i) :=
      Can.first.then_do (hn.reindex During.i)
    have spw : Small BD (fun d => kmin ^ (d.j + 1)) :=
      (hpow.reindex During.i).mono (fun d => Nat.pow_le_pow_right hk1 (by have := d.hj; omega))
    have smx : Small BD (fun d => E.mx * kmin ^ (d.j + 1)) := (Small.const _ E.mx).mul spw
    have sn : Small BD (fun d => n d.i) := hns.reindex During.i
    have sj : Small BD (fun d => d.j) := sn.mono (fun d => d.hj.le)
    have sb : Small BD (fun d => Nat.findGreatest (fun g => E.mx * kmin ^ g ≤ n d.i) d.j) := sj.mono (fun d => Nat.findGreatest_le _)
    have hmx := (Can.wc E.mx).times hpw (Small.const _ _) spw
    have htest : Knows m BD (p s (p w (p w w))) (fun d => (y d.i, d.j, v d.i d.j))
        (fun d => if E.mx * kmin ^ (d.j + 1) ≤ n d.i then 1 else 0) :=
      ((Can.wc 1).wsub (hnD.wlt hmx) ((Small.const _ 1).mono (fun _ => Nat.sub_le _ _))).cong (fun _ => rfl)
        (fun d => by
          show 1 - (if n d.i < E.mx * kmin ^ (d.j + 1) then 1 else 0) = if E.mx * kmin ^ (d.j + 1) ≤ n d.i then 1 else 0
          by_cases hh : n d.i < E.mx * kmin ^ (d.j + 1)
          · rw [if_pos hh, if_neg (by omega)]
          · rw [if_neg hh, if_pos (by omega)])
    have st : Small BD (fun d => if E.mx * kmin ^ (d.j + 1) ≤ n d.i then 1 else 0) :=
      (Small.const _ 1).mono (fun d => by split <;> omega)
    have sd : Small BD (fun d => d.j + 1 - Nat.findGreatest (fun g => E.mx * kmin ^ g ≤ n d.i) d.j) := (sj.add (Small.const _ 1)).sub
    have hd := ((hj.plus (Can.wc 1) sj (Small.const _ 1)).minus hbest (sj.add (Small.const _ 1)))
    have hnew := hbest.plus (htest.times hd st sd) sb (st.mul sd)
    have hpw' := hpw.times (Can.wc kmin) spw (Small.const _ _)
    refine (hnew.pair hpw').cong (fun _ => rfl) (fun d => ?_)
    show (_, _) = (Nat.findGreatest (fun g => E.mx * kmin ^ g ≤ n d.i) (d.j + 1), kmin ^ (d.j + 1 + 1))
    rw [findGreatest_step (fun g => E.mx * kmin ^ g ≤ n d.i) d.j, Nat.pow_succ kmin (d.j + 1)]
  have H := Can.loop (t := p w w) (v := v) (W := fun _ => 0) (W' := fun _ => 0) (uB := fun _ _ => 0) hn
    ((Can.wc 0).pair (Can.wc kmin) |>.cong (fun _ => rfl) (fun e => by
      show ((0 : ℕ), kmin) = (Nat.findGreatest (fun g => E.mx * kmin ^ g ≤ n e) 0, kmin ^ (0 + 1))
      rw [Nat.findGreatest_zero, Nat.zero_add, Nat.pow_one])) hs hns
  refine ((H.fst).cong (y' := fun e => E.topG kmin (n e)) (fun _ => rfl)
    (fun e => rfl)).mono (fun e => ?_)
  simp only [Finset.sum_const_zero, Nat.zero_add, Nat.add_zero]
  exact Nat.le_succ_of_le (Nat.le_mul_of_pos_right _ (by omega))

def copyTape (kmin n : ℕ) (v : ℕ → Bits n → ℂ) (t : ℕ) : Tape (Tape ℂ) :=
  Tape.tab (E.topN kmin n) (fun jj => (bits n).tape (ripple n (v (t * E.topN kmin n + jj))))

lemma knows_topSz (kmin : ℕ) {κ : Type U} {Bk : κ → ℕ} {sk : Ty} {yk : κ → T sk} {nk jk : κ → ℕ}
    (hj : Knows m Bk sk yk jk) (hlt : ∀ k, jk k < E.topN kmin (nk k))
    (hNUW : Knows m Bk sk yk (fun k => E.topNU0 kmin (nk k) * E.W))
    (hcU : Has m Bk sk (a w) yk
      (fun k => (Layout.std (E.topNU0 kmin (nk k))).tape (fun p => E.cUc (nk k) (E.topG kmin (nk k)) 1 p)))
    (hsz : Has m Bk sk (a w) yk (fun k => (Layout.std (E.cons (nk k) (E.topG kmin (nk k)) 1)).tape
      (fun q => E.csz (nk k) (E.topG kmin (nk k)) 1 q)))
    (hjs : Small Bk jk) (hns : Small Bk nk) :
    Knows m Bk sk yk (fun k => E.topSz kmin (nk k) (jk k)) := by
  refine Can.testz (hj.wlt hNUW) ?_ ?_
  · -- a supply slot of the root
    let K := {k : κ // (if jk k < E.topNU0 kmin (nk k) * E.W then 1 else 0) = 0}
    have h1 : ∀ k : K, ¬ jk k.1 < E.topNU0 kmin (nk k.1) * E.W := fun k hh => by
      have := k.2; rw [if_pos hh] at this; exact absurd this one_ne_zero
    have hq : ∀ k : K, jk k.1 - E.topNU0 kmin (nk k.1) * E.W < E.cons (nk k.1) (E.topG kmin (nk k.1)) 1 :=
      fun k => by have := hlt k.1; have := h1 k; unfold topN at *; omega
    refine (Can.fetch (t := w) (L := fun k : K => Layout.std (E.cons (nk k.1) (E.topG kmin (nk k.1)) 1))
      (v := fun k q => E.csz (nk k.1) (E.topG kmin (nk k.1)) 1 q.val) (i := fun k => ⟨_, hq k⟩)
      (hsz.reindex (fun k : K => k.1)) ((hj.minus hNUW hjs).reindex (fun k : K => k.1))).cong (fun _ => rfl)
      (fun k => ?_)
    unfold topSz; rw [if_neg (h1 k)]
  · -- an own slot of the root
    let K := {k : κ // (if jk k < E.topNU0 kmin (nk k) * E.W then 1 else 0) ≠ 0}
    have h1 : ∀ k : K, jk k.1 < E.topNU0 kmin (nk k.1) * E.W := fun k => by
      by_contra hh; exact k.2 (if_neg hh)
    have hp : ∀ k : K, jk k.1 / E.W < E.topNU0 kmin (nk k.1) := fun k => (Nat.div_lt_iff_lt_mul E.W_pos).2 (h1 k)
    have hjK := hj.reindex (fun k : K => k.1)
    have hjsK := hjs.reindex (fun k : K => k.1)
    have hcu : Knows m (fun k : K => Bk k.1) sk (fun k => yk k.1)
        (fun k => E.cUc (nk k.1) (E.topG kmin (nk k.1)) 1 (jk k.1 / E.W)) :=
      Can.fetch (t := w) (L := fun k : K => Layout.std (E.topNU0 kmin (nk k.1)))
        (v := fun k p => E.cUc (nk k.1) (E.topG kmin (nk k.1)) 1 p.val) (i := fun k => ⟨_, hp k⟩)
        (hcU.reindex (fun k : K => k.1)) (hjK.dvdW (Can.wc E.W) hjsK)
    have htq := E.knows_tq (hjK.modW (Can.wc E.W) hjsK) (fun k => Nat.mod_lt _ E.W_pos)
    have scu : Small (fun k : K => Bk k.1) (fun k => E.cUc (nk k.1) (E.topG kmin (nk k.1)) 1 (jk k.1 / E.W)) :=
      (hns.reindex (fun k : K => k.1)).mono (fun k => E.cU_le _ _ _ ⟨_, hp k⟩)
    refine ((htq.times hcu ((Small.const _ E.mx).mono (fun _ => E.tq_le _)) scu).cong (fun _ => rfl)
      (fun k => ?_))
    unfold topSz slotSize; rw [if_pos (h1 k)]

lemma tree_branch (kmin : ℕ) {n Bv lam : Ξ → ℕ} {v : ∀ e, ℕ → Bits (n e) → ℂ}
    (hlamd : ∀ e, lam e = Bv e / E.topN kmin (n e))
    (hNB : ∀ e, E.topN kmin (n e) ≤ Bv e)
    (hn : Knows m b.B s y n) (hB : Knows m b.B s y Bv)
    (hG : Knows m b.B s y (fun e => E.topG kmin (n e)))
    (hNU : Knows m b.B s y (fun e => E.topNU0 kmin (n e)))
    (hN : Knows m b.B s y (fun e => E.topN kmin (n e)))
    (hlam : Knows m b.B s y lam) (h2 : Knows m b.B s y (fun e => 2^(n e)))
    (hown : Has m b.B s (jobsT cl) y (fun e => jobsTape (n e) (Bv e) (v e)))
    (hcU : Has m b.B s (a w) y
      (fun e => (Layout.std (E.topNU0 kmin (n e))).tape (fun p => E.cUc (n e) (E.topG kmin (n e)) 1 p)))
    (hI : Has m b.B s sc y (fun _ => Complex.I))
    (hemp : Has m b.B s (jobsT cl) y (fun e => jobsTape 0 0 (fun _ _ => 0)))
    (hbig : Small b.B (fun e => (Bv e + 1) * 2^(n e)))
    {tau : Ξ → MDesc → ℕ}
    (hroot : ∀ e t, t < lam e → (b.use e (E.enc cl (E.topRoot kmin (n e) (Bv e) (v e) t))).OK
      (E.out cl (E.topRoot kmin (n e) (Bv e) (v e) t)) (tau e (E.topRoot kmin (n e) (Bv e) (v e) t)) (b.ext e))
    (hrest : ∀ e t jj, t < lam e → jj < E.topN kmin (n e) →
      (b.use e (E.enc cl (E.topRest kmin (n e) (v e) t jj))).OK
        (E.out cl (E.topRest kmin (n e) (v e) t jj)) (tau e (E.topRest kmin (n e) (v e) t jj)) (b.ext e)) :
    Able m b s (portOut cl) y (fun e => E.out cl (MDesc.top (n e) (Bv e) (v e)))
      (fun e => (Bv e + 1) * 2^(n e) + (Bv e % E.topN kmin (n e)) * (n e + 1) * 2^(n e))
      (fun e => ∑ t ∈ Finset.range (lam e), (tau e (E.topRoot kmin (n e) (Bv e) (v e) t) +
        ∑ jj ∈ Finset.range (E.topN kmin (n e)), tau e (E.topRest kmin (n e) (v e) t jj))) := by
  have h2le : ∀ e, 2^(n e) ≤ (Bv e + 1) * 2^(n e) := fun e => Nat.le_mul_of_pos_left _ (Nat.succ_pos _)
  have hBle : ∀ e, Bv e ≤ (Bv e + 1) * 2^(n e) := fun e => by
    exact Nat.le_trans (Nat.le_succ _) (Nat.le_mul_of_pos_right _ (Nat.two_pow_pos _))
  have h2s : Small b.B (fun e => 2^(n e)) := hbig.mono h2le
  have hns : Small b.B n := h2s.mono (fun _ => Nat.lt_two_pow_self.le)
  have hBs : Small b.B Bv := hbig.mono hBle
  have hlamN : ∀ e, lam e * E.topN kmin (n e) ≤ Bv e := fun e => by rw [hlamd]; exact Nat.div_mul_le_self _ _
  have hlS : Small b.B lam := hBs.mono (fun e => by rw [hlamd]; exact Nat.div_le_self _ _)
  have hNs : Small b.B (fun e => E.topN kmin (n e)) := hBs.mono hNB
  have hNUW : ∀ e, E.topNU0 kmin (n e) * E.W ≤ E.topN kmin (n e) := fun e => by unfold topN; omega
  let CD := During lam
  let yc (d : CD) : T (p s w) := (y d.i, d.j)
  have lc : ∀ {t : Ty} {u : Ξ → T t}, Has m b.B s t y u →
      Has m (fun d : CD => b.B d.i) (p s w) t yc (fun d => u d.i) :=
    fun hu => Can.first.then_do (hu.reindex During.i)
  have htc : Knows m (fun d : CD => b.B d.i) (p s w) yc (fun d => d.j) := Can.second
  have hlt0 : ∀ (d : CD) j, j < E.topN kmin (n d.i) → d.j * E.topN kmin (n d.i) + j < Bv d.i := fun d j hj =>
    lt_of_lt_of_le (EngArith.grp_lt (by rw [← hlamd]; exact d.hj) hj) le_rfl
  have hroot_in : Can m (fun d : CD => b.B d.i) (p s w) (portIn cl) yc
      (fun d => E.enc cl (E.topRoot kmin (n d.i) (Bv d.i) (v d.i) d.j))
      (fun d => E.topNU0 kmin (n d.i) * E.W + 1) := by
    let UO := UnitF (fun d : CD => E.topNU0 kmin (n d.i) * E.W)
    let yo (u : UO) : T (p (p s w) w) := (yc u.1, u.2.val)
    have sT : Small (fun d : CD => b.B d.i) (fun d => d.j) := (hlS.reindex During.i).mono (fun d => d.hj.le)
    have sN : Small (fun d : CD => b.B d.i) (fun d => E.topN kmin (n d.i)) := hNs.reindex _
    have sNU : Small (fun d : CD => b.B d.i) (fun d => E.topNU0 kmin (n d.i)) :=
      sN.mono (fun d => le_trans (Nat.le_mul_of_pos_right _ E.W_pos) (hNUW d.i))
    have hNUWc : Knows m (fun d : CD => b.B d.i) (p s w) yc (fun d => E.topNU0 kmin (n d.i) * E.W) :=
      (lc hNU).times (Can.wc E.W) sNU (Small.const _ _)
    have hjo : Knows m (fun u : UO => b.B u.1.i) (p (p s w) w) yo
        (fun u => u.1.j * E.topN kmin (n u.1.i) + u.2.val) :=
      ((Can.first.then_do (htc.reindex (fun u : UO => u.1))).times
        (Can.first.then_do ((lc hN).reindex (fun u : UO => u.1)))
        (sT.reindex (fun u : UO => u.1)) (sN.reindex (fun u : UO => u.1))).plus Can.second
        ((sT.mul sN).reindex (fun u : UO => u.1))
        ((sN.reindex (fun u : UO => u.1)).mono (fun u => le_trans u.2.2.le (hNUW _)))
    have hown_o : Has m (fun u : UO => b.B u.1.i) (p (p s w) w) (jobsT cl) yo
        (fun u => jobsTape (n u.1.i) (Bv u.1.i) (v u.1.i)) :=
      Can.first.then_do ((lc hown).reindex (fun u : UO => u.1))
    have hel : Has m (fun u : UO => b.B u.1.i) (p (p s w) w) (a (c cl)) yo
        (fun u => (bits (n u.1.i)).tape (v u.1.i (u.1.j * E.topN kmin (n u.1.i) + u.2.val))) :=
      has_jobsAt hown_o hjo (fun u => hlt0 u.1 _ (lt_of_lt_of_le u.2.2 (hNUW _)))
    have hsub : Can m (fun d : CD => b.B d.i) (p s w) (jobsT cl) yc
        (fun d => jobsTape (n d.i) (E.topNU0 kmin (n d.i) * E.W) (fun j => v d.i (d.j * E.topN kmin (n d.i) + j)))
        (fun d => E.topNU0 kmin (n d.i) * E.W + 1) :=
      can_ptrTape (t := a (c cl)) (x := yc) (N := fun d : CD => E.topNU0 kmin (n d.i) * E.W)
        (v := fun d j => (bits (n d.i)).tape (v d.i (d.j * E.topN kmin (n d.i) + j)))
        hNUWc ((hNs.reindex During.i).mono (fun d => hNUW d.i)) hel
    have hoff : Knows m (fun d : CD => b.B d.i) (p s w) yc
        (fun d => d.j * E.topN kmin (n d.i) + E.topNU0 kmin (n d.i) * E.W) :=
      (htc.times (lc hN) sT sN).plus hNUWc (sT.mul sN) ((hNs.reindex During.i).mono (fun d => hNUW d.i))
    have hG1 : Knows m (fun d : CD => b.B d.i) (p s w) yc (fun d => E.topG kmin (n d.i) + 1) :=
      (lc hG).plus (Can.wc 1) ((hns.reindex During.i).mono (fun d => Nat.findGreatest_le _)) (Small.const _ 1)
    have hz : ∀ {t : Ty} {u : CD → T t}, Has m (fun d : CD => b.B d.i) (p s w) t yc u →
        Can m (fun d : CD => b.B d.i) (p s w) t yc u (fun d => E.topNU0 kmin (n d.i) * E.W + 1) :=
      fun hh => hh.mono (fun _ => Nat.zero_le _)
    exact ((hz (lc hn)).pair ((hz (lc hI)).pair ((hz hG1).pair ((hz (Can.wc 1)).pair ((hz hoff).pair
      (hsub.pair (hz (lc hown)))))))).cong (fun _ => rfl) (fun d => rfl)
  have Hcall : Able m (b.comap During.i) (p s w) (portOut cl) yc
      (fun d => E.out cl (E.topRoot kmin (n d.i) (Bv d.i) (v d.i) d.j))
      (fun d => E.topNU0 kmin (n d.i) * E.W + 1 + 0)
      (fun d => 0 + tau d.i (E.topRoot kmin (n d.i) (Bv d.i) (v d.i) d.j)) :=
    (Able.of_can (b := b.comap During.i) hroot_in).comp
      (Able.use_call (m := m) (b := b.comap During.i) (fun d => hroot d.i d.j d.hj))
  let yr (d : CD) : T (p (p s w) (portOut cl)) := (yc d, E.out cl (E.topRoot kmin (n d.i) (Bv d.i) (v d.i) d.j))
  let RD := During (fun d : CD => E.topN kmin (n d.i))
  let yj (dd : RD) : T (p (p (p s w) (portOut cl)) w) := (yr dd.i, dd.j)
  have lj : ∀ {t : Ty} {u : Ξ → T t}, Has m b.B s t y u →
      Has m (fun dd : RD => b.B dd.i.i) _ t yj (fun dd => u dd.i.i) :=
    fun hu => (Can.first.then_do (Can.first.then_do Can.first)).then_do (hu.reindex (fun dd : RD => dd.i.i))
  have hjj : Knows m (fun dd : RD => b.B dd.i.i) _ yj (fun dd => dd.j) := Can.second
  have sjj : Small (fun dd : RD => b.B dd.i.i) (fun dd => dd.j) :=
    (hNs.reindex (fun dd : RD => dd.i.i)).mono (fun dd => dd.hj.le)
  have hro : Has m (fun dd : RD => b.B dd.i.i) _ (portOut cl) yj
      (fun dd => E.out cl (E.topRoot kmin (n dd.i.i) (Bv dd.i.i) (v dd.i.i) dd.i.j)) :=
    Can.first.then_do Can.second
  have hsz : Knows m (fun dd : RD => b.B dd.i.i) _ yj (fun dd => E.topSz kmin (n dd.i.i) dd.j) :=
    E.knows_topSz kmin hjj (fun dd => dd.hj) ((lj hNU).times (Can.wc E.W)
      ((hNs.reindex _).mono (fun dd => le_trans (Nat.le_mul_of_pos_right _ E.W_pos) (hNUW _))) (Small.const _ _))
      (lj hcU) (Can.snd (Can.snd hro)) sjj (hns.reindex _)
  have hwv : Has m (fun dd : RD => b.B dd.i.i) _ (a (c cl)) yj
      (fun dd => (bits (n dd.i.i)).tape (E.topAns kmin (n dd.i.i) (v dd.i.i) dd.i.j dd.j)) := by
    refine Can.testz (hjj.wlt ((lj hNU).times (Can.wc E.W) ((hNs.reindex _).mono (fun dd =>
      le_trans (Nat.le_mul_of_pos_right _ E.W_pos) (hNUW _))) (Small.const _ _))) ?_ ?_
    · let K := {dd : RD // (if dd.j < E.topNU0 kmin (n dd.i.i) * E.W then 1 else 0) = 0}
      have h1 : ∀ k : K, ¬ k.1.j < E.topNU0 kmin (n k.1.i.i) * E.W := fun k hh => by
        have := k.2; rw [if_pos hh] at this; exact absurd this one_ne_zero
      have hq : ∀ k : K, k.1.j - E.topNU0 kmin (n k.1.i.i) * E.W < E.cons (n k.1.i.i) (E.topG kmin (n k.1.i.i)) 1 :=
        fun k => by have := k.1.hj; have := h1 k; unfold topN at *; omega
      refine (has_jobsAt (n := fun k : K => n k.1.i.i) (N := fun k => E.cons (n k.1.i.i) (E.topG kmin (n k.1.i.i)) 1)
        (J := fun k q => hlow (n k.1.i.i) (E.csz (n k.1.i.i) (E.topG kmin (n k.1.i.i)) 1 q)
          (v k.1.i.i (k.1.i.j * E.topN kmin (n k.1.i.i) + E.topNU0 kmin (n k.1.i.i) * E.W + q)))
        ((Can.fst (Can.snd hro)).reindex (fun k : K => k.1))
        ((hjj.minus ((lj hNU).times (Can.wc E.W) ((hNs.reindex _).mono (fun dd =>
          le_trans (Nat.le_mul_of_pos_right _ E.W_pos) (hNUW _))) (Small.const _ _)) sjj).reindex
          (fun k : K => k.1)) hq).cong (fun _ => rfl) (fun k => ?_)
      unfold topAns topSz
      rw [if_neg (h1 k)]
      congr 3
      have := h1 k
      omega
    · let K := {dd : RD // (if dd.j < E.topNU0 kmin (n dd.i.i) * E.W then 1 else 0) ≠ 0}
      have h1 : ∀ k : K, k.1.j < E.topNU0 kmin (n k.1.i.i) * E.W := fun k => by
        by_contra hh; exact k.2 (if_neg hh)
      refine (has_jobsAt (n := fun k : K => n k.1.i.i) (N := fun k => E.NUc (n k.1.i.i) (E.topG kmin (n k.1.i.i)) 1 * E.W)
        (J := fun k j => hlow (n k.1.i.i) (E.slotSize (n k.1.i.i) (E.topG kmin (n k.1.i.i)) 1 j)
          (v k.1.i.i (k.1.i.j * E.topN kmin (n k.1.i.i) + j)))
        ((Can.fst hro).reindex (fun k : K => k.1)) (hjj.reindex (fun k : K => k.1)) h1).cong (fun _ => rfl)
        (fun k => ?_)
      unfold topAns topSz
      rw [if_pos (h1 k)]
  have hszle : ∀ dd : RD, E.topSz kmin (n dd.i.i) dd.j ≤ n dd.i.i := fun dd => E.topSz_le kmin _ _
  have sszS : Small (fun dd : RD => b.B dd.i.i) (fun dd => E.topSz kmin (n dd.i.i) dd.j) :=
    (hns.reindex _).mono hszle
  have s2sz : Small (fun dd : RD => b.B dd.i.i) (fun dd => 2^(E.topSz kmin (n dd.i.i) dd.j)) :=
    (h2s.reindex _).mono (fun dd => Nat.pow_le_pow_right (by omega) (hszle dd))
  have Hp1 : Can m (fun dd : RD => b.B dd.i.i) _ w yj (fun dd => 2^(E.topSz kmin (n dd.i.i) dd.j))
      (fun dd => E.topSz kmin (n dd.i.i) dd.j) :=
    (hsz.mono (fun _ => Nat.zero_le _)).wTwo sszS s2sz (Dom.self _)
  let yp (dd : RD) : T (p (p (p (p s w) (portOut cl)) w) w) := (yj dd, 2^(E.topSz kmin (n dd.i.i) dd.j))
  have lp : ∀ {t : Ty} {u : RD → T t}, Has m (fun dd : RD => b.B dd.i.i) _ t yj u →
      Has m (fun dd : RD => b.B dd.i.i) _ t yp u := fun hu => Can.first.then_do hu
  have hp1 : Knows m (fun dd : RD => b.B dd.i.i) _ yp (fun dd => 2^(E.topSz kmin (n dd.i.i) dd.j)) := Can.second
  have hp2 : Knows m (fun dd : RD => b.B dd.i.i) _ yp (fun dd => 2^(n dd.i.i - E.topSz kmin (n dd.i.i) dd.j)) :=
    ((lp (lj h2)).dvdW hp1 (h2s.reindex _)).cong (fun _ => rfl) (fun dd => by
      rw [← Nat.pow_div (hszle dd) (by omega)])
  have HR := rest_call (Ξ := RD) (s := _) E (b := (b.comap During.i).comap During.i) (x := yp)
    (n := fun dd => n dd.i.i) (sz := fun dd => E.topSz kmin (n dd.i.i) dd.j) hszle (lp hwv) (lp (lj hn)) (lp hsz)
    hp1 hp2 (lp (lj hI)) (lp (lj hemp)) (h2s.reindex _)
    (Z := fun dd => tau dd.i.i (E.topRest kmin (n dd.i.i) (v dd.i.i) dd.i.j dd.j))
    (fun dd => hrest dd.i.i dd.i.j dd.j dd.i.hj dd.hj)
  let yq (dd : RD) : T (p (p (p (p (p s w) (portOut cl)) w) w) (jobsT cl)) := (yp dd, jobsTape (n dd.i.i - E.topSz kmin (n dd.i.i) dd.j) (2^(E.topSz kmin (n dd.i.i) dd.j))
    (fun q => ripple (n dd.i.i - E.topSz kmin (n dd.i.i) dd.j)
      (hiVec (n dd.i.i) (E.topSz kmin (n dd.i.i) dd.j) (E.topAns kmin (n dd.i.i) (v dd.i.i) dd.i.j dd.j) q)))
  have Hback : Can m (fun dd : RD => b.B dd.i.i) _ (a (c cl)) yq
      (fun dd => (bits (n dd.i.i)).tape (ripple (n dd.i.i) (v dd.i.i (dd.i.j * E.topN kmin (n dd.i.i) + dd.j))))
      (fun dd => 0 + 2^(n dd.i.i) + 2^(n dd.i.i) * 0) := by
    let EL := Σ dd : RD, Bits (n dd.i.i)
    let yE (q : EL) : T (p (p (p (p (p (p s w) (portOut cl)) w) w) (jobsT cl)) w) := (yq q.1, (bits (n q.1.i.i)).loc q.2)
    have lE : ∀ {t : Ty} {u : RD → T t}, Has m (fun dd : RD => b.B dd.i.i) _ t yq u →
        Has m (fun q : EL => b.B q.1.i.i) _ t yE (fun q => u q.1) :=
      fun hu => Can.first.then_do (hu.reindex (fun q : EL => q.1))
    have he : Knows m (fun q : EL => b.B q.1.i.i) _ yE (fun q => (bits (n q.1.i.i)).loc q.2) := Can.second
    have seS : Small (fun q : EL => b.B q.1.i.i) (fun q => (bits (n q.1.i.i)).loc q.2) :=
      (h2s.reindex (fun q : EL => q.1.i.i)).mono (fun q => ((bits _).bd _).le)
    have hP1 := lE (Can.first.then_do hp1)
    have hP2 := lE (Can.first.then_do hp2)
    have hidx := he.modW hP1 seS
    have haddr : Knows m (fun q : EL => b.B q.1.i.i) _ yE
        (fun q => (bits (n q.1.i.i - E.topSz kmin (n q.1.i.i) q.1.j)).loc
          (bitsOf (n q.1.i.i - E.topSz kmin (n q.1.i.i) q.1.j) ((bits (n q.1.i.i)).loc q.2 / 2^(E.topSz kmin (n q.1.i.i) q.1.j)))) :=
      ((he.dvdW hP1 seS).modW hP2 seS.div).cong (fun _ => rfl) (fun q => (bitsOf_loc _ _).symm)
    have hrd := has_jobsRead (n := fun q : EL => n q.1.i.i - E.topSz kmin (n q.1.i.i) q.1.j)
      (N := fun q => 2^(E.topSz kmin (n q.1.i.i) q.1.j))
      (J := fun q k => ripple (n q.1.i.i - E.topSz kmin (n q.1.i.i) q.1.j)
        (hiVec (n q.1.i.i) (E.topSz kmin (n q.1.i.i) q.1.j) (E.topAns kmin (n q.1.i.i) (v q.1.i.i) q.1.i.j q.1.j) k))
      (lE Can.second) hidx (fun q => Nat.mod_lt _ (Nat.two_pow_pos _)) haddr
    have HL := Can.layout (m := m) (t := c cl) (L := fun dd : RD => bits (n dd.i.i))
      (v := fun dd e => fromHi (n dd.i.i) (E.topSz kmin (n dd.i.i) dd.j)
        (fun q => ripple (n dd.i.i - E.topSz kmin (n dd.i.i) dd.j)
          (hiVec (n dd.i.i) (E.topSz kmin (n dd.i.i) dd.j) (E.topAns kmin (n dd.i.i) (v dd.i.i) dd.i.j dd.j) q)) e)
      (P := fun _ => 0) (W := fun _ => 0)
      (Can.first.then_do (lp (lj h2)))
      (hrd.cong (fun _ => rfl) (fun _ => rfl)) (h2s.reindex _)
    refine HL.cong (fun _ => rfl) (fun dd => ?_)
    congr 1
    exact fromHi_ripple _ _ (hszle dd) _
  have Hinner : Able m ((b.comap During.i).comap During.i) _ (a (c cl)) yj
      (fun dd => (bits (n dd.i.i)).tape (ripple (n dd.i.i) (v dd.i.i (dd.i.j * E.topN kmin (n dd.i.i) + dd.j))))
      (fun dd => E.topSz kmin (n dd.i.i) dd.j + (2^(n dd.i.i) + (0 + 2^(n dd.i.i) + 2^(n dd.i.i) * 0)))
      (fun dd => 0 + (tau dd.i.i (E.topRest kmin (n dd.i.i) (v dd.i.i) dd.i.j dd.j) + 0)) :=
    (Able.of_can Hp1).save (HR.save (Able.of_can Hback))
  have Hcopy : Able m (b.comap During.i) (p s w) (a (a (c cl))) yc
      (fun d => E.copyTape kmin (n d.i) (v d.i) d.j)
      (fun d => E.topNU0 kmin (n d.i) * E.W + 1 + 0 + (0 + E.topN kmin (n d.i) +
        E.topN kmin (n d.i) * (n d.i + 3 * 2^(n d.i))))
      (fun d => tau d.i (E.topRoot kmin (n d.i) (Bv d.i) (v d.i) d.j) +
        ∑ jj ∈ Finset.range (E.topN kmin (n d.i)), tau d.i (E.topRest kmin (n d.i) (v d.i) d.j jj)) := by
    have Hinner' : Able m ((b.comap During.i).comap During.i) _ (a (c cl)) yj
        (fun dd => (bits (n dd.i.i)).tape (ripple (n dd.i.i) (v dd.i.i (dd.i.j * E.topN kmin (n dd.i.i) + dd.j))))
        (fun dd => n dd.i.i + 3 * 2^(n dd.i.i))
        (fun dd => tau dd.i.i (E.topRest kmin (n dd.i.i) (v dd.i.i) dd.i.j dd.j)) :=
      Hinner.mono (fun dd => by have := hszle dd; simp only [Nat.mul_zero, Nat.add_zero, Nat.zero_add]; omega)
        (fun dd => by simp)
    have HT := Able.tab (t := a (c cl)) (b := b.comap During.i) (n := fun d : CD => E.topN kmin (n d.i))
      (v := fun d jj => (bits (n d.i)).tape (ripple (n d.i) (v d.i (d.j * E.topN kmin (n d.i) + jj))))
      (Wb := fun d _ => n d.i + 3 * 2^(n d.i))
      (Zb := fun d jj => tau d.i (E.topRest kmin (n d.i) (v d.i) d.j jj))
      (Able.of_can (b := b.comap During.i) (Can.first.then_do (lc hN) :
        Knows m (fun d : CD => b.B d.i) (p (p s w) (portOut cl)) yr (fun d => E.topN kmin (n d.i))))
      Hinner' (hNs.reindex _)
    refine (Hcall.save HT).mono (fun d => ?_) (fun d => ?_)
    · simp only [Finset.sum_const, Finset.card_range, smul_eq_mul]
      omega
    · simp
  have Hcopies := Able.tab (t := a (a (c cl))) (b := b) (n := lam) (v := fun e t => E.copyTape kmin (n e) (v e) t)
    (Wb := fun e _ => E.topNU0 kmin (n e) * E.W + 1 + 0 + (0 + E.topN kmin (n e) +
      E.topN kmin (n e) * (n e + 3 * 2^(n e))))
    (Zb := fun e t => tau e (E.topRoot kmin (n e) (Bv e) (v e) t) +
        ∑ jj ∈ Finset.range (E.topN kmin (n e)), tau e (E.topRest kmin (n e) (v e) t jj))
    (Able.of_can (b := b) hlam) Hcopy hlS
  let ya (e : Ξ) : T (p s (a (a (a (c cl))))) := (y e, Tape.tab (lam e) (fun t => E.copyTape kmin (n e) (v e) t))
  have la : ∀ {t : Ty} {u : Ξ → T t}, Has m b.B s t y u → Has m b.B _ t ya u := fun hu => Can.first.then_do hu
  have hlo : Knows m b.B _ ya (fun e => Bv e - lam e * E.topN kmin (n e)) :=
    (la hB).minus ((la hlam).times (la hN) hlS hNs) hBs
  have sLo : Small b.B (fun e => Bv e - lam e * E.topN kmin (n e)) := hBs.sub
  have HLo := can_ptrTape (t := a (c cl)) (x := ya) (N := fun e => Bv e - lam e * E.topN kmin (n e))
    (v := fun e j => (bits (n e)).tape (v e (lam e * E.topN kmin (n e) + j))) hlo sLo
    (has_jobsAt (n := fun u : UnitF (fun e => Bv e - lam e * E.topN kmin (n e)) => n u.1) (N := fun u => Bv u.1)
      (J := fun u => v u.1) (Can.first.then_do ((la hown).reindex (fun u : UnitF _ => u.1)))
      ((Can.first.then_do (((la hlam).times (la hN) hlS hNs).reindex (fun u : UnitF _ => u.1))).plus Can.second
        ((hlS.mul hNs).reindex _) (sLo.reindex _ |>.mono (fun u => u.2.2.le)))
      (fun u => by
        have h1 : u.2.val < Bv u.1 - lam u.1 * E.topN kmin (n u.1) := u.2.2
        have := hlamN u.1; omega))
  let yl (e : Ξ) : T (p (p s (a (a (a (c cl))))) (jobsT cl)) := (ya e, jobsTape (n e) (Bv e - lam e * E.topN kmin (n e)) (fun j => v e (lam e * E.topN kmin (n e) + j)))
  have HNv := MCost.naive_jobs (m := m) (cl := cl) (Bd := b.B) (x := yl) n (fun e => Bv e - lam e * E.topN kmin (n e))
    (fun e j => v e (lam e * E.topN kmin (n e) + j)) Can.second (Can.first.then_do (la hn))
    (Can.first.then_do hlo) (Can.first.then_do (la hI)) sLo h2s
  let yf (e : Ξ) : T (p (p (p s (a (a (a (c cl))))) (jobsT cl)) (jobsT cl)) := (yl e, (Layout.std (Bv e - lam e * E.topN kmin (n e))).tape
    (fun t => (bits (n e)).tape (ripple (n e) (v e (lam e * E.topN kmin (n e) + t)))))
  have lf : ∀ {t : Ty} {u : Ξ → T t}, Has m b.B s t y u → Has m b.B _ t yf u :=
    fun hu => Can.first.then_do (Can.first.then_do (la hu))
  have hcp : Has m b.B _ (a (a (a (c cl)))) yf (fun e => Tape.tab (lam e) (fun t => E.copyTape kmin (n e) (v e) t)) :=
    Can.first.then_do (Can.first.then_do Can.second)
  have HAs : Can m b.B _ (jobsT cl) yf (fun e => jobsTape (n e) (Bv e) (fun t => ripple (n e) (v e t)))
      (fun e => Bv e + 1) := by
    let U := UnitF Bv
    have lU : ∀ {t : Ty} {g : Ξ → T t}, Has m b.B _ t yf g →
        Has m (fun u : U => b.B u.1) (p _ w) t (fun u => (yf u.1, u.2.val)) (fun u => g u.1) :=
      fun hu => Can.first.then_do (hu.reindex (fun u : U => u.1))
    have ht : Knows m (fun u : U => b.B u.1) (p _ w) (fun u => (yf u.1, u.2.val)) (fun u => u.2.val) := Can.second
    have stS : Small (fun u : U => b.B u.1) (fun u => u.2.val) := (hBs.reindex _).mono (fun u => u.2.2.le)
    have hLN := lU ((lf hlam).times (lf hN) hlS hNs)
    have hel : Has m (fun u : U => b.B u.1) (p _ w) (a (c cl)) (fun u => (yf u.1, u.2.val))
        (fun u => (bits (n u.1)).tape (ripple (n u.1) (v u.1 u.2.val))) := by
      refine Can.testz (ht.wlt hLN) ?_ ?_
      · let K := {u : U // (if u.2.val < lam u.1 * E.topN kmin (n u.1) then 1 else 0) = 0}
        have h1 : ∀ k : K, ¬ k.1.2.val < lam k.1.1 * E.topN kmin (n k.1.1) := fun k hh => by
          have := k.2; rw [if_pos hh] at this; exact absurd this one_ne_zero
        refine (has_jobsAt (n := fun k : K => n k.1.1) (N := fun k => Bv k.1.1 - lam k.1.1 * E.topN kmin (n k.1.1))
          (J := fun k t => ripple (n k.1.1) (v k.1.1 (lam k.1.1 * E.topN kmin (n k.1.1) + t)))
          ((lU Can.second).reindex (fun k : K => k.1)) ((ht.minus hLN stS).reindex (fun k : K => k.1))
          (fun k => by have := k.1.2.2; have := h1 k; omega)).cong (fun _ => rfl) (fun k => ?_)
        congr 3
        have := h1 k
        omega
      · let K := {u : U // (if u.2.val < lam u.1 * E.topN kmin (n u.1) then 1 else 0) ≠ 0}
        have h1 : ∀ k : K, k.1.2.val < lam k.1.1 * E.topN kmin (n k.1.1) := fun k => by
          by_contra hh; exact k.2 (if_neg hh)
        have hNp : ∀ k : K, 0 < E.topN kmin (n k.1.1) := fun k => by
          have := h1 k; rcases Nat.eq_zero_or_pos (E.topN kmin (n k.1.1)) with h0 | h0
          · rw [h0, Nat.mul_zero] at this; omega
          · exact h0
        have hq : ∀ k : K, k.1.2.val / E.topN kmin (n k.1.1) < lam k.1.1 := fun k =>
          (Nat.div_lt_iff_lt_mul (hNp k)).2 (h1 k)
        have hNK := (lU (lf hN)).reindex (fun k : K => k.1)
        have htK := ht.reindex (fun k : K => k.1)
        have stK := stS.reindex (fun k : K => k.1)
        have hc1 : Has m (fun k : K => b.B k.1.1) _ (a (a (c cl))) (fun k => (yf k.1.1, k.1.2.val))
            (fun k => E.copyTape kmin (n k.1.1) (v k.1.1) (k.1.2.val / E.topN kmin (n k.1.1))) :=
          ((lU hcp).reindex (fun k : K => k.1)).look (htK.dvdW hNK stK) |>.cong (fun _ => rfl)
            (fun k => by rw [Tape.look_tab, if_pos (hq k)])
        refine (hc1.look (htK.modW hNK stK)).cong (fun _ => rfl) (fun k => ?_)
        unfold copyTape
        rw [Tape.look_tab, if_pos (Nat.mod_lt _ (hNp k)), Nat.div_add_mod']
    exact can_ptrTape (t := a (c cl)) (x := yf) (N := Bv)
      (v := fun e j => (bits (n e)).tape (ripple (n e) (v e j))) (lf hB) hBs hel
  have Hfin := HAs.fork ((has_jobs0 (m := m) (B := b.B) (cl := cl) n (fun _ _ _ => 0)).pair
    (has_tape0 (t := w) (fun _ (_ : Fin 0) => (0 : ℕ))))
  refine ((Hcopies.save ((Able.of_can HLo).save ((Able.of_can HNv).save (Able.of_can Hfin)))).cong
    (fun _ => rfl) (fun _ => rfl)).weaken (dom_mul 16 (fun e => ?_)) (fun e => ?_)
  · -- CHECK: cost arithmetic (lam * topN ≤ Bv, n < 2^n)
    have h1 := hlamN e
    have h2 : n e < 2^(n e) := Nat.lt_two_pow_self
    have h3 : Bv e - lam e * E.topN kmin (n e) = Bv e % E.topN kmin (n e) := by
      rw [hlamd]; exact EngArith.sub_div_mul _ _
    have h4 := hNUW e
    have h5 : lam e * E.topN kmin (n e) * (n e + 3 * 2^(n e) + 2) ≤ Bv e * (n e + 3 * 2^(n e) + 2) :=
      Nat.mul_le_mul_right _ h1
    have h6 : lam e ≤ Bv e := by rw [hlamd]; exact Nat.div_le_self _ _
    have h7 : 1 ≤ 2^(n e) := Nat.one_le_two_pow
    -- composed bound: copies ≤ Bv·K + Bv, K := n + 3·2^n + 2 ≤ 6·2^n; leftover = (Bv mod N)(n+1)2^n + Bv mod N
    have hWc : E.topNU0 kmin (n e) * E.W + 1 + 0 + (0 + E.topN kmin (n e) +
        E.topN kmin (n e) * (n e + 3 * 2^(n e))) ≤ E.topN kmin (n e) * (n e + 3 * 2^(n e) + 2) + 1 := by
      rw [Nat.mul_add (E.topN kmin (n e)) _ 2]; omega
    have p1 : lam e * (E.topNU0 kmin (n e) * E.W + 1 + 0 + (0 + E.topN kmin (n e) +
        E.topN kmin (n e) * (n e + 3 * 2^(n e)))) ≤ Bv e * (n e + 3 * 2^(n e) + 2) + Bv e := by
      have a1 := Nat.mul_le_mul_left (lam e) hWc
      have a2 : lam e * (E.topN kmin (n e) * (n e + 3 * 2^(n e) + 2) + 1) =
          lam e * E.topN kmin (n e) * (n e + 3 * 2^(n e) + 2) + lam e := by
        rw [Nat.mul_add (lam e), Nat.mul_one, Nat.mul_assoc (lam e)]
      have a3 := Nat.mul_le_mul_right (n e + 3 * 2^(n e) + 2) h1
      omega
    have p2 : Bv e * (n e + 3 * 2^(n e) + 2) ≤ 6 * (Bv e * 2^(n e)) := by
      have q1 : Bv e * n e ≤ Bv e * 2^(n e) := Nat.mul_le_mul_left _ h2.le
      have q2 : Bv e ≤ Bv e * 2^(n e) := Nat.le_mul_of_pos_right _ (Nat.two_pow_pos _)
      rw [Nat.mul_add, Nat.mul_add, Nat.mul_left_comm (Bv e) 3]
      omega
    have p3 : Bv e % E.topN kmin (n e) * ((n e + 1) * 2^(n e) + 1) =
        Bv e % E.topN kmin (n e) * (n e + 1) * 2^(n e) + Bv e % E.topN kmin (n e) := by
      rw [Nat.mul_add, Nat.mul_one, ← Nat.mul_assoc]
    have p4 : (Bv e + 1) * 2^(n e) = Bv e * 2^(n e) + 2^(n e) := by rw [Nat.add_mul, Nat.one_mul]
    have p5 : Bv e % E.topN kmin (n e) ≤ Bv e := Nat.mod_le _ _
    have p6 : Bv e ≤ Bv e * 2^(n e) := Nat.le_mul_of_pos_right _ (Nat.two_pow_pos _)
    have p7 : Bv e % E.topN kmin (n e) ≤ Bv e % E.topN kmin (n e) * (n e + 1) * 2^(n e) :=
      le_trans (Nat.le_mul_of_pos_right _ (Nat.succ_pos (n e))) (Nat.le_mul_of_pos_right _ (Nat.two_pow_pos _))
    try simp only [Finset.sum_const, Finset.card_range, smul_eq_mul, h3]
    omega
  · simp

end Top

end Eng
end
end PowerSaving.RAM
end OAI


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF MXR
noncomputable section

universe U

lemma small_pow {ι : Type*} {Bd n : ι → ℕ} (h2 : Small Bd (fun e => 2^(n e))) (b : ℕ) :
    Small Bd (fun e => b^(n e + 1)) := by
  obtain ⟨d, hd⟩ := h2
  refine ⟨(d + 1) * b, fun e => ?_⟩
  have h1 : b^(n e + 1) ≤ (2^b)^(n e + 1) := Nat.pow_le_pow_left (Nat.lt_two_pow_self).le _
  have h2' : (2^b)^(n e + 1) = (2 * 2^(n e))^b := by
    rw [← pow_mul, show 2 * 2^(n e) = 2^(n e + 1) by ring, ← pow_mul, mul_comm]
  have h3 : 2 * 2^(n e) ≤ (Bd e + 2)^(d + 1) := by
    calc 2 * 2^(n e) ≤ (Bd e + 2) * (Bd e + 2)^d := Nat.mul_le_mul (by omega) (hd e)
      _ = (Bd e + 2)^(d + 1) := by ring
  calc b^(n e + 1) ≤ (2 * 2^(n e))^b := h2' ▸ h1
    _ ≤ ((Bd e + 2)^(d + 1))^b := Nat.pow_le_pow_left h3 _
    _ = (Bd e + 2)^((d + 1) * b) := by rw [← pow_mul]

namespace Eng
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ] (E : Eng α ρ σ)

def Ptop (kmin n : ℕ) : ℕ :=
  (n + 1) + (n * (n + 3) + 1) + E.idxCost n (E.topG kmin n) 1 +
    E.NUc n (E.topG kmin n) 1 * (4 * n + 4 * E.topG kmin n + 8) + E.cstC (E.topG kmin n)

abbrev BookT : Ty := p w (p w (p IdxT (p UnT w)))
def bookVal (kmin n : ℕ) : T BookT :=
  (2^n, E.topG kmin n, E.idxVal n (E.topG kmin n) 1, E.unitVal n (E.topG kmin n) 1, E.cons n (E.topG kmin n) 1)

lemma topG_le (kmin n : ℕ) : E.topG kmin n ≤ n := Nat.findGreatest_le n


variable {Ξ : Type U} {m : Bool} {s : Ty} {y : Ξ → T s}

lemma can_book (kmin : ℕ) (hk : 2 ≤ kmin) {Bd n : Ξ → ℕ} (hn : Knows m Bd s y n)
    (hI : Has m Bd s sc y (fun _ => Complex.I)) (h2 : Small Bd (fun e => 2^(n e))) (hn1 : ∀ e, 1 ≤ n e) :
    Can m Bd s BookT y (fun e => E.bookVal kmin (n e)) (fun e => E.Ptop kmin (n e)) := by
  let G (e : Ξ) := E.topG kmin (n e)
  have hns : Small Bd n := h2.mono (fun e => (Nat.lt_two_pow_self).le)
  have hGle : ∀ e, G e ≤ n e := fun e => E.topG_le kmin (n e)
  have hp2 : Can m Bd s w y (fun e => 2^(n e)) (fun e => E.Ptop kmin (n e)) :=
    (Can.wTwo (Has.atW hn) hns h2 (Dom.of_le (fun e => Nat.le_succ _))).mono
      (fun e => by unfold Eng.Ptop; omega)
  have hG : Can m Bd s w y G (fun e => E.Ptop kmin (n e)) :=
    (can_topG E kmin hk hn (small_pow h2 kmin) hns).mono (fun e => by unfold Eng.Ptop; (try simp only [G]); omega)
  let e1 (e : Ξ) : T (p s (p w w)) := (y e, (2^(n e), G e))
  have hE1 : Can m Bd s (p s (p w w)) y e1 (fun e => E.Ptop kmin (n e)) := Can.pair Can.id (Can.pair hp2 hG)
  have c1 : CIn m Bd (p s (p w w)) e1 n G (fun _ => 1) :=
    ⟨Has.extE hn, Can.second.snd, Can.wc 1, Can.second.fst, Has.extE hI, h2, hGle,
      Small.const _ 1⟩
  have hidx := E.can_index c1
  have hun := E.can_units c1
  have hidx' : Can m Bd (p s (p w w)) IdxT e1 (fun e => E.idxVal (n e) (G e) 1) (fun e => E.Ptop kmin (n e)) :=
    hidx.mono (fun e => by unfold Eng.Ptop; (try simp only [G]); omega)
  have hun' : Can m Bd (p (p s (p w w)) IdxT) UnT (fun e => (e1 e, E.idxVal (n e) (G e) 1))
      (fun e => E.unitVal (n e) (G e) 1) (fun e => E.Ptop kmin (n e)) :=
    hun.mono (fun e => by unfold Eng.Ptop; (try simp only [G]); omega)
  have hbnd : Small Bd (fun e => E.bndC (n e, G e, 1)) := by
    have hK := (small_pow h2 E.Kb)
    have h1 : Small Bd (fun e => n e + 2) := hns.add (Small.const _ 2)
    refine ((h1.mul hK).mul (Small.const _ 2)).mono (fun e => ?_)
    simp only [Eng.bndC]
    exact Nat.mul_le_mul (Nat.mul_le_mul le_rfl (Nat.pow_le_pow_right (by have := E.Kb_ge; omega)
      (by have := hGle e; omega))) (by omega)
  have hcin : Has m Bd (p s (p w w)) (p w (p w w)) e1 (fun e => (n e, G e, 1)) :=
    c1.nK.pair (c1.hK.pair (Can.wc 1))
  have hcons : Can m Bd (p s (p w w)) w e1 (fun e => E.cons (n e) (G e) 1) (fun e => E.Ptop kmin (n e)) :=
    (Has.atW hcin).then_do
      (((E.can_cons m (fun e => (n e, G e, 1))).ambient hbnd).mono (fun e => by unfold Eng.Ptop; (try simp only [G]); omega))
  have hall : Can m Bd (p s (p w w)) BookT e1 (fun e => E.bookVal kmin (n e)) (fun e => E.Ptop kmin (n e)) :=
    ((Has.atW Can.second.fst).pair ((Has.atW Can.second.snd).pair
      (hidx'.pair ((Can.bind hidx' hun').pair hcons)))).cong (fun _ => rfl) (fun e => rfl)
  exact hE1.then_do hall


def locTop (kmin n0 n B : ℕ) : ℕ :=
  if n0 ≤ n then (B + 1) * 2^n + (B % E.topN kmin n) * (n + 1) * 2^n + E.Ptop kmin n
  else (B + 1) * (n + 1) * 2^n + 1

lemma sum_map_flatMap {β γ : Type*} (L : List β) (f : β → List γ) (g : γ → ℕ) :
    ((L.flatMap f).map g).sum = (L.map (fun t => ((f t).map g).sum)).sum := by
  induction L with
  | nil => simp
  | cons a L ih => simp [List.flatMap_cons, ih]

lemma kidsTop_charge (kmin n0 n Bv : ℕ) (v : ℕ → Bits n → ℂ) (tau : MDesc → ℕ) (h : n0 ≤ n ∧ E.topN kmin n ≤ Bv) :
    ((E.kidsTop kmin n0 n Bv v).map tau).sum = ∑ t ∈ Finset.range (Bv / E.topN kmin n),
      (tau (E.topRoot kmin n Bv v t) + ∑ jj ∈ Finset.range (E.topN kmin n), tau (E.topRest kmin n v t jj)) := by
  unfold kidsTop
  rw [if_pos h, sum_map_flatMap, ← sum_map_range]
  congr 1
  refine List.map_congr_left (fun t _ => ?_)
  simp only [List.map_cons, List.sum_cons, List.map_map]
  rw [sum_map_range]
  rfl

lemma mem_kidsTop_root (kmin n0 n Bv : ℕ) (v : ℕ → Bits n → ℂ) (h : n0 ≤ n ∧ E.topN kmin n ≤ Bv) (t : ℕ)
    (ht : t < Bv / E.topN kmin n) : E.topRoot kmin n Bv v t ∈ E.kidsTop kmin n0 n Bv v := by
  unfold kidsTop; rw [if_pos h]
  exact List.mem_flatMap.2 ⟨t, List.mem_range.2 ht, List.mem_cons_self⟩

lemma mem_kidsTop_rest (kmin n0 n Bv : ℕ) (v : ℕ → Bits n → ℂ) (h : n0 ≤ n ∧ E.topN kmin n ≤ Bv) (t jj : ℕ)
    (ht : t < Bv / E.topN kmin n) (hj : jj < E.topN kmin n) :
    E.topRest kmin n v t jj ∈ E.kidsTop kmin n0 n Bv v := by
  unfold kidsTop; rw [if_pos h]
  exact List.mem_flatMap.2 ⟨t, List.mem_range.2 ht,
    List.mem_cons_of_mem _ (List.mem_map.2 ⟨jj, List.mem_range.2 hj, rfl⟩)⟩

lemma naive_top {Bd n Bv : Ξ → ℕ} {cl : Paint} {v : ∀ e, ℕ → Bits (n e) → ℂ}
    (hbig : Small Bd (fun e => (Bv e + 1) * 2^(n e))) :
    Can m Bd (portIn cl) (portOut cl) (fun e => E.enc cl (MDesc.top (n e) (Bv e) (v e)))
      (fun e => E.out cl (MDesc.top (n e) (Bv e) (v e))) (fun e => Bv e * ((n e + 1) * 2 ^ n e + 1)) := by
  have h2s : Small Bd (fun e => 2^(n e)) := hbig.mono (fun e => Nat.le_mul_of_pos_left _ (Nat.succ_pos _))
  have hBs : Small Bd Bv := hbig.mono (fun e => by have : 1 ≤ 2^(n e) := Nat.one_le_two_pow; nlinarith)
  have hown : Has m Bd (portIn cl) (jobsT cl) (fun e => E.enc cl (MDesc.top (n e) (Bv e) (v e)))
      (fun e => jobsTape (n e) (Bv e) (v e)) := Can.second.snd.snd.snd.snd.fst
  have hsup : Has m Bd (portIn cl) (jobsT cl) (fun e => E.enc cl (MDesc.top (n e) (Bv e) (v e)))
      (fun e => jobsTape (n e) 0 (fun _ _ => 0)) := Can.second.snd.snd.snd.snd.snd
  have hBK : Knows m Bd (portIn cl) (fun e => E.enc cl (MDesc.top (n e) (Bv e) (v e))) Bv :=
    (hown.len hBs).cong (fun _ => rfl) (fun e => rfl)
  have hnv := MCost.naive_jobs (m := m) (cl := cl) (Bd := Bd) n Bv v hown Can.first hBK Can.second.fst hBs h2s
  have hEmp3 : Has m Bd (portIn cl) (a w) (fun e => E.enc cl (MDesc.top (n e) (Bv e) (v e)))
      (fun e => (Layout.std 0).tape (fun _ : Fin 0 => (0 : ℕ))) := by
    have H := Can.tab (m := m) (B := Bd) (s := portIn cl) (x := fun e => E.enc cl (MDesc.top (n e) (Bv e) (v e)))
      (t := w) (n := fun _ => 0) (uB := fun _ _ => 0) (v := fun _ _ => 0) (W := fun _ => 0)
      (Can.wc (W := fun _ => 0) 0) (Can.wc 0) (Small.const _ 0)
    exact (H.cong (fun _ => rfl) (fun e => sizes_zero.symm)).mono (fun e => by simp)
  refine ((hnv.mono (fun e => ?_)).pair ((Has.atW hsup).pair
    (Has.atW hEmp3))).cong (fun _ => rfl) (fun e => rfl)
  rw [Nat.mul_add, mul_one]


theorem top_body (kmin n0 : ℕ) (hk : 2 ≤ kmin) (hn0 : E.mx ≤ n0) {κ : Type U} {cl : Paint}
    {b : Bank (portM cl) κ} (n Bv : κ → ℕ) (v : ∀ k, ℕ → Bits (n k) → ℂ)
    (hbig : Small b.B (fun k => (Bv k + 1) * 2^(n k))) (tau : κ → MDesc → ℕ)
    (hcalls : ∀ k c, c ∈ E.kidsTop kmin n0 (n k) (Bv k) (v k) →
      (b.use k (E.enc cl c)).OK (E.out cl c) (tau k c) (b.ext k)) :
    Able m b (portIn cl) (portOut cl) (fun k => E.enc cl (MDesc.top (n k) (Bv k) (v k)))
      (fun k => E.out cl (MDesc.top (n k) (Bv k) (v k)))
      (fun k => E.locTop kmin n0 (n k) (Bv k))
      (fun k => ((E.kidsTop kmin n0 (n k) (Bv k) (v k)).map (tau k)).sum) := by
  let x (k : κ) : T (portIn cl) := E.enc cl (MDesc.top (n k) (Bv k) (v k))
  let Y (k : κ) : T (portOut cl) := E.out cl (MDesc.top (n k) (Bv k) (v k))
  let Wt (k : κ) := E.locTop kmin n0 (n k) (Bv k)
  let Zt (k : κ) := ((E.kidsTop kmin n0 (n k) (Bv k) (v k)).map (tau k)).sum
  have nK : Knows m b.B (portIn cl) x n := Can.first
  have t1 : Knows m b.B (portIn cl) x (fun k => if n k < n0 then 1 else 0) := nK.wlt (Can.wc n0)
  -- naive branch: n < n0
  have hnv : Able m (b.comap (fun k : {k // (if n k < n0 then 1 else 0) ≠ 0} => k.val)) (portIn cl) (portOut cl)
      (fun k => x k.val) (fun k => Y k.val) (fun k => Wt k.val) (fun k => Zt k.val) := by
    have hlt : ∀ k : {k // (if n k < n0 then 1 else 0) ≠ 0}, n k.val < n0 := by
      intro k; have := k.2; split_ifs at this with h1 <;> simp_all
    have H := naive_top E (m := m) (cl := cl) (Bd := fun k : {k // (if n k < n0 then 1 else 0) ≠ 0} => b.B k.val)
      (n := fun k => n k.val) (Bv := fun k => Bv k.val) (v := fun k => v k.val) (hbig.reindex Subtype.val)
    refine (Able.of_can H).weaken ⟨2, fun k => ?_⟩ (fun k => Nat.zero_le _)
    have h1 := hlt k
    show _ ≤ 2 * (E.locTop kmin n0 (n k.val) (Bv k.val) + 1)
    unfold Eng.locTop
    rw [if_neg (Nat.not_le.mpr h1)]
    generalize hX : (n k.val + 1) * 2 ^ n k.val = X
    have hX1 : 1 ≤ X := by rw [← hX]; exact Nat.mul_pos (Nat.succ_pos _) (Nat.two_pow_pos _)
    have e1 : (Bv k.val + 1) * (n k.val + 1) * 2 ^ n k.val = Bv k.val * X + X := by rw [← hX]; ring
    rw [e1]
    have : Bv k.val ≤ Bv k.val * X := Nat.le_mul_of_pos_right _ hX1
    nlinarith
  -- main branch: n0 ≤ n
  have hmain : Able m (b.comap (fun k : {k // (if n k < n0 then 1 else 0) = 0} => k.val)) (portIn cl) (portOut cl)
      (fun k => x k.val) (fun k => Y k.val) (fun k => Wt k.val) (fun k => Zt k.val) := by
    let κ0 := {k // (if n k < n0 then 1 else 0) = 0}
    let b0 := b.comap (fun k : κ0 => k.val)
    have hge : ∀ k : κ0, n0 ≤ n k.val := by
      intro k; have := k.2; split_ifs at this with h1 <;> omega
    let x0 (k : κ0) := x k.val
    have h2s : Small b0.B (fun k => 2^(n k.val)) :=
      (hbig.reindex Subtype.val).mono (fun k => Nat.le_mul_of_pos_left _ (Nat.succ_pos _))
    have hBs : Small b0.B (fun k => Bv k.val) :=
      (hbig.reindex Subtype.val).mono (fun k => by have : 1 ≤ 2^(n k.val) := Nat.one_le_two_pow; nlinarith)
    have hbook := E.can_book (m := m) (s := portIn cl) (y := x0) kmin hk (Bd := b0.B) (n := fun k => n k.val)
      Can.first Can.second.fst h2s (fun k => le_trans (le_trans (le_trans (by norm_num) E.three) hn0) (hge k))
    let xm (k : κ0) : T (p (portIn cl) BookT) := (x0 k, E.bookVal kmin (n k.val))
    let Bm := b0.B
    have F : Lifts m Bm (portIn cl) x0 (p (portIn cl) BookT) xm :=
      fun {_ _} g => Has.extE g
    have nK' : Knows m Bm (p (portIn cl) BookT) xm (fun k => n k.val) := F Can.first
    have IK : Has m Bm (p (portIn cl) BookT) sc xm (fun _ => Complex.I) := F Can.second.fst
    have hown : Has m Bm (p (portIn cl) BookT) (jobsT cl) xm (fun k => jobsTape (n k.val) (Bv k.val) (v k.val)) :=
      F Can.second.snd.snd.snd.snd.fst
    have hsup : Has m Bm (p (portIn cl) BookT) (jobsT cl) xm (fun k => jobsTape 0 0 (fun _ _ => 0)) :=
      (F Can.second.snd.snd.snd.snd.snd).cong (fun _ => rfl)
        (fun k => jobsTape_zero (n k.val) 0 (fun _ _ => 0) (fun _ _ => 0))
    have BK : Knows m Bm (p (portIn cl) BookT) xm (fun k => Bv k.val) :=
      (hown.len hBs).cong (fun _ => rfl) (fun k => rfl)
    have p2K : Knows m Bm (p (portIn cl) BookT) xm (fun k => 2^(n k.val)) := Can.second.fst
    have GK : Knows m Bm (p (portIn cl) BookT) xm (fun k => E.topG kmin (n k.val)) := Can.second.snd.fst
    have NUK : Knows m Bm (p (portIn cl) BookT) xm (fun k => E.topNU0 kmin (n k.val)) :=
      Can.second.snd.snd.fst.snd.fst
    have cUK : Has m Bm (p (portIn cl) BookT) (a w) xm
        (fun k => (Layout.std (E.topNU0 kmin (n k.val))).tape (fun p => E.cUc (n k.val) (E.topG kmin (n k.val)) 1 p)) :=
      Can.second.snd.snd.snd.fst.fst
    have consK : Knows m Bm (p (portIn cl) BookT) xm (fun k => E.cons (n k.val) (E.topG kmin (n k.val)) 1) :=
      Can.second.snd.snd.snd.snd
    have hnS : Small Bm (fun k => n k.val) := h2s.mono (fun k => (Nat.lt_two_pow_self).le)
    have hGle : ∀ k : κ0, E.topG kmin (n k.val) ≤ n k.val := fun k => E.topG_le _ _
    have hNUs : Small Bm (fun k => E.topNU0 kmin (n k.val)) :=
      (small_pow h2s E.W).mono (fun k => le_trans (MXR.NU_le _ _ _)
        (Nat.pow_le_pow_right E.W_pos (by have := hGle k; omega)))
    have hcs : Small Bm (fun k => E.cons (n k.val) (E.topG kmin (n k.val)) 1) :=
      (small_pow h2s (E.Ac^2)).mono (fun k => le_trans (E.cons_le _ _ _) (by
        rw [pow_mul]; exact Nat.pow_le_pow_right (Nat.one_le_pow _ _ E.Ac_pos) (by have := hGle k; omega)))
    have hNK : Knows m Bm (p (portIn cl) BookT) xm (fun k => E.topN kmin (n k.val)) :=
      (NUK.times (Can.wc E.W) hNUs (Small.const _ _)).plus consK (hNUs.mul (Small.const _ _)) hcs
    have t2 : Knows m Bm (p (portIn cl) BookT) xm (fun k => if Bv k.val < E.topN kmin (n k.val) then 1 else 0) :=
      BK.wlt hNK
    let W2 (k : κ0) := (Bv k.val + 1) * 2^(n k.val) + (Bv k.val % E.topN kmin (n k.val)) * (n k.val + 1) * 2^(n k.val)
    -- the tree branch
    have htree : Able m (b0.comap (fun k : {k : κ0 // (if Bv k.val < E.topN kmin (n k.val) then 1 else 0) = 0} => k.val))
        (p (portIn cl) BookT) (portOut cl) (fun k => xm k.val) (fun k => Y k.val.val) (fun k => W2 k.val)
        (fun k => Zt k.val.val) := by
      let κ1 := {k : κ0 // (if Bv k.val < E.topN kmin (n k.val) then 1 else 0) = 0}
      have hNB : ∀ k : κ1, E.topN kmin (n k.val.val) ≤ Bv k.val.val := by
        intro k; have := k.2; split_ifs at this with h1 <;> omega
      have hcond : ∀ k : κ1, n0 ≤ n k.val.val ∧ E.topN kmin (n k.val.val) ≤ Bv k.val.val :=
        fun k => ⟨hge k.val, hNB k⟩
      have G1 : ∀ {t : Ty} {z : κ0 → T t}, Has m Bm (p (portIn cl) BookT) t xm z →
          Has m (fun k : κ1 => Bm k.val) (p (portIn cl) BookT) t (fun k => xm k.val) (fun k => z k.val) :=
        fun g => g.reindex Subtype.val
      have hlamK : Knows m Bm (p (portIn cl) BookT) xm (fun k => Bv k.val / E.topN kmin (n k.val)) :=
        BK.dvdW hNK hBs
      have H := tree_branch E (b := b0.comap (fun k : κ1 => k.val)) (y := fun k => xm k.val) kmin
        (n := fun k => n k.val.val) (Bv := fun k => Bv k.val.val)
        (lam := fun k => Bv k.val.val / E.topN kmin (n k.val.val)) (v := fun k => v k.val.val)
        (fun _ => rfl) hNB (G1 nK') (G1 BK) (G1 GK) (G1 NUK) (G1 hNK) (G1 hlamK) (G1 p2K) (G1 hown) (G1 cUK)
        (G1 IK) (G1 hsup) (hbig.reindex (fun k : κ1 => k.val.val)) (tau := fun k => tau k.val.val)
        (fun k t ht => hcalls k.val.val _ (E.mem_kidsTop_root kmin n0 _ _ _ (hcond k) t ht))
        (fun k t jj ht hj => hcalls k.val.val _ (E.mem_kidsTop_rest kmin n0 _ _ _ (hcond k) t jj ht hj))
      refine H.mono (fun k => le_rfl) (fun k => le_of_eq ?_)
      exact (E.kidsTop_charge kmin n0 _ _ _ _ (hcond k)).symm
    -- the naive branch: fewer than one copy
    have hfew : Able m (b0.comap (fun k : {k : κ0 // (if Bv k.val < E.topN kmin (n k.val) then 1 else 0) ≠ 0} => k.val))
        (p (portIn cl) BookT) (portOut cl) (fun k => xm k.val) (fun k => Y k.val.val) (fun k => W2 k.val)
        (fun k => Zt k.val.val) := by
      let κ2 := {k : κ0 // (if Bv k.val < E.topN kmin (n k.val) then 1 else 0) ≠ 0}
      have hlt : ∀ k : κ2, Bv k.val.val < E.topN kmin (n k.val.val) := by
        intro k; have := k.2; split_ifs at this with h1 <;> simp_all
      have H := naive_top E (m := m) (cl := cl) (Bd := fun k : κ2 => Bm k.val)
        (n := fun k => n k.val.val) (Bv := fun k => Bv k.val.val) (v := fun k => v k.val.val)
        (hbig.reindex (fun k : κ2 => k.val.val))
      have H' : Can m (fun k : κ2 => Bm k.val) (p (portIn cl) BookT) (portOut cl) (fun k => xm k.val)
          (fun k => Y k.val.val) (fun k => Bv k.val.val * ((n k.val.val + 1) * 2 ^ n k.val.val + 1)) :=
        (Has.atW Can.first).then_do H
      refine (Able.of_can H').weaken ⟨2, fun k => ?_⟩ (fun k => Nat.zero_le _)
      show _ ≤ 2 * (W2 k.val + 1)
      simp only [W2]
      rw [Nat.mod_eq_of_lt (hlt k)]
      have h1 : 1 ≤ 2^(n k.val.val) := Nat.one_le_two_pow
      have e1 : Bv k.val.val * ((n k.val.val + 1) * 2 ^ n k.val.val + 1) =
          Bv k.val.val * (n k.val.val + 1) * 2 ^ n k.val.val + Bv k.val.val := by ring
      rw [e1]
      have : Bv k.val.val ≤ (Bv k.val.val + 1) * 2^(n k.val.val) := by nlinarith
      omega
    have H2 := Able.ifz (t := portOut cl) (x := xm) (y := fun k => Y k.val) (W := W2) (Z := fun k => Zt k.val)
      (Able.of_can t2) htree hfew
    have H3 := Able.save (Able.of_can (b := b0) hbook) H2
    refine (H3.mono (fun k => ?_) (fun k => ?_))
    · show E.Ptop kmin (n k.val) + (0 + W2 k) ≤ E.locTop kmin n0 (n k.val) (Bv k.val)
      unfold Eng.locTop
      rw [if_pos (hge k)]
      simp only [W2]; omega
    · simp
  have H := Able.ifz (t := portOut cl) (y := Y) (W := Wt) (Z := Zt) (Able.of_can t1) hmain hnv
  exact H.mono (fun k => le_of_eq (zero_add _)) (fun k => le_of_eq (zero_add _))

end Eng

end
end PowerSaving.RAM
end OAI
