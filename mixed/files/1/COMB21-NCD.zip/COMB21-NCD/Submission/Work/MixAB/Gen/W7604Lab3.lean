import Submission.Work.KLowW.LabK
import Submission.Work.MixAB.Gen.W7604.D20
import Submission.Work.MixAB.Gen.W7604WT
set_option maxRecDepth 100000
namespace GXD.W7604
theorem lab3 : KLW.segW par wt labE3 labS3 labS4 labR3 = true := by decide +kernel
end GXD.W7604
