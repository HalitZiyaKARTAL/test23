import Submission.Work.MixAB.Gen.W7604Tab2
set_option maxRecDepth 100000
namespace GXD.W7604
open GXD
theorem tab3_ok : GLab.tabK 9 tab_n11 = true := by decide +kernel
end GXD.W7604
