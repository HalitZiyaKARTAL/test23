import Submission.Work.MixAB.Gen.W7604.D20
set_option maxRecDepth 100000
namespace GXD.W7604
theorem wrSeg6 : WR.segB WR.cx 1569 wrE6 wrS6 wrS7 = true := by decide +kernel
end GXD.W7604
