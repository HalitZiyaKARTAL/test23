import Submission.Work.MixAB.Gen.W7604WC
import Submission.Work.MixAB.W7604Price
import Submission.Work.MixAB.Gen.W7604SchedR
import Submission.Work.MixAB.Gen.W7604Res
import Submission.Work.XHostT.TProvWAB

set_option maxRecDepth 100000
namespace GXD.W7604
open GXD OAI.PowerSaving OAI.PowerSaving.CB OAI.PowerSaving.GF OAI.PowerSaving.GX
noncomputable section

theorem roles_ok : KLW.WRoles wc (PWG.embB 200 1101 68) (PWG.unB 200 1101 68 (by decide)) :=
  KLW.rolesAB wc wvalidAB (by decide) (by decide)

def ginvAB : KLW.GInvAB (Fin 9) (Fin 200) (Fin 1101) (Fin 68) (fun _ => True) :=
  KLW.WValidAB.invCtr (ty := fun n => ctr.getD n KLW.Ctr.F) wvalidAB roles_ok two_ok (fun _ => True)

def ginvW : KLW.GInvEAB (Fin 9) (Fin 200) (Fin 1101) (Fin 68) (fun _ => True) := ginvAB.toEW'

theorem ginv_cost (φ : ℕ → ℝ) : ginvW.cost φ = invPrice φ := by
  show rcost φ rAll = invPrice φ
  exact inv_cost φ

theorem hent : ∀ q : Fin 1101, Fintype.card (Fin 9) - (ginvW.ent q).dim = schedRes.getD q.val 0 := fun q => by
  show Fintype.card (Fin 9) - (ginvAB.entS q).dim = _
  rw [ginvAB.entS_hd q, schedRes_eq]
  exact (KLW.resAB wvalidAB roles_ok q).trans (res_ok q)

end
end GXD.W7604

namespace PWGW7604
open OAI.PowerSaving OAI.PowerSaving.CB

noncomputable def ginv : XHostTW.GInvWAB (Fin 9) (Fin 200) (Fin 1101) (Fin 68) (fun _ => True) :=
  XHostTW.GInvWAB.ofEAB GXD.W7604.ginvW

theorem ginv_al : ginv.al = fun t => (GXD.W7604.ctr.getD t.val KLW.Ctr.F).al := rfl
theorem ginv_be : ginv.be = fun t => (GXD.W7604.ctr.getD t.val KLW.Ctr.F).be := rfl

theorem ginv_cost (φ : ℕ → ℝ) : ginv.cost φ = GXD.W7604.invPrice φ := GXD.W7604.ginv_cost φ

end PWGW7604
