import Submission.Work.Gauge.Labels
import Submission.Work.MixAB.Gen.W7604ResC
set_option maxRecDepth 100000
namespace GXD.W7604
open GXD

theorem get_twin : @SSC.Trie.get = @ResC.tget := by
  funext t k; induction t generalizing k with
  | leaf v => rfl
  | node l r ihl ihr => simp only [SSC.Trie.get, ResC.tget, ihl, ihr]
theorem cdim_twin : @GLab.cdim = @ResC.cdim := rfl
theorem memK_twin : @GLab.memK = @ResC.memK := rfl
theorem res_ok : ∀ q : Fin 1101,
    Bool.rec (motive := fun _ => Nat)
      (9 - GLab.cdim (tab.get (st0.get (400 + q.val))))
      (GLab.cdim (tab.get (stF.get (400 + q.val))) - GLab.cdim (tab.get (st0.get (400 + q.val))))
      (GLab.memK (400 + q.val) exits)
    = resW.getD q.val 0 := by
  rw [get_twin, cdim_twin, memK_twin]; exact ResC.res_okC
end GXD.W7604
