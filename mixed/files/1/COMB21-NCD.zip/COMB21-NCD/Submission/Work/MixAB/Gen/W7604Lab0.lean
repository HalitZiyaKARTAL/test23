import Submission.Work.KLowW.LabK
import Submission.Work.MixAB.Gen.W7604.D20
import Submission.Work.MixAB.Gen.W7604WT
set_option maxRecDepth 100000
namespace GXD.W7604
theorem lab0 : KLW.segW par wt labE0 labS0 labS1 labR0 = true := by decide +kernel
end GXD.W7604
