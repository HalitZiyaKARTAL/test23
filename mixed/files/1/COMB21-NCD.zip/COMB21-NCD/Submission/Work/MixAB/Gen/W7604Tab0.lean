import Submission.Work.MixAB.Gen.W7604.D20
set_option maxRecDepth 100000
namespace GXD.W7604
open GXD
theorem tab0_ok : GLab.tabK 9 tab_n00 = true := by decide +kernel
end GXD.W7604
