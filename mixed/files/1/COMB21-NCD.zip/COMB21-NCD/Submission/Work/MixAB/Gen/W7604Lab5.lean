import Submission.Work.KLowW.LabK
import Submission.Work.MixAB.Gen.W7604.D20
import Submission.Work.MixAB.Gen.W7604WT
set_option maxRecDepth 100000
namespace GXD.W7604
theorem lab5 : KLW.segW par wt labE5 labS5 labS6 labR5 = true := by decide +kernel
end GXD.W7604
