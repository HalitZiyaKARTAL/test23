import Submission.Work.MixAB.Gen.W7604.D0
set_option maxRecDepth 100000
namespace GXD.W7604
open GXD
noncomputable def par : GLab.Par := ⟨9, 1569, 11, 9, tab⟩
noncomputable def pe : GLab.Par := ⟨9, 1501, 11, 9, tab⟩
noncomputable def spw : KLW.SPw := ⟨11, 1569, 1569, 256, 37748736000⟩
end GXD.W7604
