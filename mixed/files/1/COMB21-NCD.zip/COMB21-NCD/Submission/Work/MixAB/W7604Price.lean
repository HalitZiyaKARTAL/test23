import Submission.Work.GCert.Data.Price
import Submission.Work.MixAB.Gen.W7604Hist

namespace GXD.W7604
open GXD OAI.PowerSaving.CB

theorem rAll_cost (φ : ℕ → ℝ) : rcost φ rAll = 3985 * φ 1 + 850 * φ 2 + 827 * φ 3 + 221 * φ 4 + 347 * φ 5 + 17 * φ 6 + 11 * φ 7 + 5 * φ 8 := by
  rw [GXD.rcost_wsumK φ rAll 8 rankBound]
  simp only [Finset.sum_range_succ, Finset.sum_range_zero, rank0_ok, rank1_ok, rank2_ok, rank3_ok, rank4_ok, rank5_ok, rank6_ok, rank7_ok, rank8_ok]
  norm_num [bcost]

def invPrice (φ : ℕ → ℝ) : ℝ := 3985 * φ 1 + 850 * φ 2 + 827 * φ 3 + 221 * φ 4 + 347 * φ 5 + 17 * φ 6 + 11 * φ 7 + 5 * φ 8

theorem inv_cost (φ : ℕ → ℝ) : rcost φ rAll = invPrice φ := by
  rw [rAll_cost]
  unfold invPrice
  ring

end GXD.W7604
