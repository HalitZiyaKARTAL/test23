import Submission.Work.KLowW.LabK
import Submission.Work.MixAB.Gen.W7604Tab3
set_option maxRecDepth 100000
namespace GXD.W7604
open GXD
theorem wt_ok : wt = [] := by decide +kernel
end GXD.W7604
