import Submission.Work.KLowW.InvAB
import Submission.Work.GCert.Labels.RouteRun
import Submission.Work.MixAB.Gen.W7604Tab0
import Submission.Work.MixAB.Gen.W7604Tab1
import Submission.Work.MixAB.Gen.W7604Tab2
import Submission.Work.MixAB.Gen.W7604Tab3
import Submission.Work.MixAB.Gen.W7604WT
import Submission.Work.MixAB.Gen.W7604Lab
import Submission.Work.MixAB.Gen.W7604Ends
import Submission.Work.MixAB.Gen.W7604Rows
import Submission.Work.MixAB.Gen.W7604WRAll
import Submission.Work.KLowW.RefBridge
set_option maxRecDepth 100000
namespace GXD.W7604
open GXD
theorem tab_ok : GLab.tabK 9 tab = true := (GLab.tabK_node _ _ _ (GLab.tabK_node _ _ _ tab0_ok tab2_ok) (GLab.tabK_node _ _ _ tab1_ok tab3_ok))

noncomputable def wc : KLW.WCert :=
  { v := 200, R := 1101, nc := 68, p := par, wt := wt, evs := evs, evsB := evs, S0 := st0, SF := stF, rs := rAll,
    ports := ports, gl := gl, el := exits, q := spw, R0 := rf0, RF := rfF, RB := rfF }

theorem scF_all : KLW.ScalOK spw evs rf0 rfF :=
  KLW.ScalOK.of_ref scRef_all (KLW.RT.wfK_sound rfF spw.d wfF_ok)

theorem lab_run : KLW.RunW par wt st0 evs stF rAll := by
  rw [← lab_evs, ← lab_rs]
  exact (KLW.RunW.of_seg tab_ok wt_ok lab0).append
    ((KLW.RunW.of_seg tab_ok wt_ok lab1).append
    ((KLW.RunW.of_seg tab_ok wt_ok lab2).append
    ((KLW.RunW.of_seg tab_ok wt_ok lab3).append
    ((KLW.RunW.of_seg tab_ok wt_ok lab4).append
    ((KLW.RunW.of_seg tab_ok wt_ok lab5).append
    ((KLW.RunW.of_seg tab_ok wt_ok lab6).append
    (KLW.RunW.of_seg tab_ok wt_ok lab7)))))))

theorem wvalidAB : KLW.WValidAB wc abT where
  hn := rfl
  nr := rfl
  tab := tab_ok
  run := lab_run
  ends := ends_ok
  par := KLW.ParOK.of_ref scRef_all
  scF := scF_all
  id0 := id0_ok
  wfF := wfF_ok
  shAB := shAB_ok
  frF := frF_ok
end GXD.W7604
