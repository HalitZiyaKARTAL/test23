import Submission.Work.MixAB.Gen.W7604.D20
set_option maxRecDepth 100000
namespace GXD.W7604
theorem wrSeg2 : WR.segB WR.cx 1569 wrE2 wrS2 wrS3 = true := by decide +kernel
end GXD.W7604
