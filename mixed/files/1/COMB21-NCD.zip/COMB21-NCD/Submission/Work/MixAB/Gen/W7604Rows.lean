import Submission.Work.KLowW.ShearAB
import Submission.Work.MixAB.Gen.W7604ResC
set_option maxRecDepth 100000
namespace GXD.W7604
open GXD
theorem idK_twin : @KLW.idK = @ResC.idK := rfl
theorem freeK_twin : @KLW.freeK = @ResC.freeK := rfl
theorem shKnAB_twin : @KLW.shKnAB = @ResC.shKnAB := rfl
def toC : KLW.Ctr → ResC.CtrC
  | .F => .F
  | .Bk => .Bk
  | .M => .M
theorem ab_twin (D : Nat) (c : KLW.Ctr) : c.ab D = ResC.ctrAb D (toC c) := by cases c <;> rfl
theorem getD_map {α β : Type} (f : α → β) (d : α) : ∀ (l : List α) n, f (l.getD n d) = (l.map f).getD n (f d)
  | [], _ => rfl
  | _ :: _, 0 => rfl
  | _ :: xs, n + 1 => getD_map f d xs n

def ofC : ResC.CtrC → KLW.Ctr
  | .F => .F
  | .Bk => .Bk
  | .M => .M
theorem toC_ofC (c : ResC.CtrC) : toC (ofC c) = c := by cases c <;> rfl
def ctr : List KLW.Ctr := ResC.ctrC.map ofC
theorem ctr_twin : ctr.map toC = ResC.ctrC := by
  simp only [ctr, List.map_map, Function.comp_def, toC_ofC, List.map_id']
noncomputable def abT (n : Nat) : Int × Int × Int := (ctr.getD n KLW.Ctr.F).ab spw.D
theorem id0_ok : KLW.idK spw rf0 = true := by rw [idK_twin]; exact ResC.id0_okC
theorem wfF_ok : KLW.RT.wfK rfF spw.d = true := ResC.wfF_okC
theorem shAB_ok : KLW.shKnAB spw 200 abT rfF 1501 = true := by
  have : abT = ResC.abT := by
    funext n; unfold abT ResC.abT; rw [ab_twin, getD_map toC KLW.Ctr.F ctr n, ctr_twin]; rfl
  rw [shKnAB_twin, this]; exact ResC.shAB_okC
theorem frF_ok : KLW.freeK spw rfF = true := by rw [freeK_twin]; exact ResC.frF_okC
theorem two_ok : 2 ∣ spw.D := ResC.two_okC
end GXD.W7604
