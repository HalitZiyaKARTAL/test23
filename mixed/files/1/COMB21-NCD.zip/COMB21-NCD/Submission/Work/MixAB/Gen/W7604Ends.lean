import Submission.Work.GCert.Labels.EndDef
import Submission.Work.MixAB.Gen.W7604.D20
set_option maxRecDepth 100000
namespace GXD.W7604
open GXD
theorem ends_ok : GLab.endKX pe 200 ports [] gl exits st0 st0 stF = true := by decide +kernel
end GXD.W7604
