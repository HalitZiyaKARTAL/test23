import Submission.Work.MixAB.Gen.W7604.D20
set_option maxRecDepth 100000
namespace GXD.W7604
theorem wrSeg0 : WR.segB WR.cx 1569 wrE0 wrS0 wrS1 = true := by decide +kernel
end GXD.W7604
