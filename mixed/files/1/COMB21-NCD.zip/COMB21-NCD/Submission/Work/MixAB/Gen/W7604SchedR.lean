import Submission.Work.MixAB.Gen.W7604.D20

set_option maxRecDepth 100000
namespace GXD.W7604
noncomputable def schedRes : List Nat := resW
theorem schedRes_eq : schedRes = resW := rfl
end GXD.W7604
