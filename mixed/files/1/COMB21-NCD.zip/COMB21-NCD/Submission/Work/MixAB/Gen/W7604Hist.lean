import Submission.Work.GCert.Data.Count
import Submission.Work.MixAB.Gen.W7604.D20
set_option maxRecDepth 100000
namespace GXD.W7604
open GXD
theorem rankBound : wsumK (SSC.wGt 8) rAll 0 = 0 := by decide +kernel
theorem rank0_ok : wsumK (SSC.wEq 0) rAll 0 = 0 := by decide +kernel
theorem rank1_ok : wsumK (SSC.wEq 1) rAll 0 = 3985 := by decide +kernel
theorem rank2_ok : wsumK (SSC.wEq 2) rAll 0 = 850 := by decide +kernel
theorem rank3_ok : wsumK (SSC.wEq 3) rAll 0 = 827 := by decide +kernel
theorem rank4_ok : wsumK (SSC.wEq 4) rAll 0 = 221 := by decide +kernel
theorem rank5_ok : wsumK (SSC.wEq 5) rAll 0 = 347 := by decide +kernel
theorem rank6_ok : wsumK (SSC.wEq 6) rAll 0 = 17 := by decide +kernel
theorem rank7_ok : wsumK (SSC.wEq 7) rAll 0 = 11 := by decide +kernel
theorem rank8_ok : wsumK (SSC.wEq 8) rAll 0 = 5 := by decide +kernel
end GXD.W7604
