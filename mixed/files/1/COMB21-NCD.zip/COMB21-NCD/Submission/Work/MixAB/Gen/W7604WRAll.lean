import Submission.Work.MixAB.Gen.W7604WRSeg0
import Submission.Work.MixAB.Gen.W7604WRSeg1
import Submission.Work.MixAB.Gen.W7604WRSeg2
import Submission.Work.MixAB.Gen.W7604WRSeg3
import Submission.Work.MixAB.Gen.W7604WRSeg4
import Submission.Work.MixAB.Gen.W7604WRSeg5
import Submission.Work.MixAB.Gen.W7604WRSeg6
import Submission.Work.MixAB.Gen.W7604WRSeg7
import Submission.Work.MixAB.Gen.W7604WRSeg8
import Submission.Work.MixAB.Gen.W7604WRSeg9
import Submission.Work.MixAB.Gen.W7604WRSeg10
set_option maxRecDepth 100000
namespace GXD.W7604
theorem wrEnd0 : WR.endB WR.cx 11 rf0 wrS0 = true := by decide +kernel
theorem wrEndF : WR.endB WR.cx 11 rfF wrS11 = true := by decide +kernel
theorem wrPar : WR.parB spw = true := by decide +kernel

theorem scRef_all : ScalSpec.RefOK GXD.W7604.spw GXD.W7604.evs GXD.W7604.rf0 GXD.W7604.rfF := by
  have s := @WR.segB_sound WR.cx WR.cx_ok spw
  have e : evs = wrE0 ++ (wrE1 ++ (wrE2 ++ (wrE3 ++ (wrE4 ++ (wrE5 ++ (wrE6 ++ (wrE7 ++ (wrE8 ++ (wrE9 ++ (wrE10)))))))))) := by
    simp only [evs, ev0, ev1, ev2, ev3, ev4, ev5, ev6, ev7, ev8, ev9, ev10, ev11, ev12, ev13, ev14, ev15, ev16, ev17, ev18, ev19, ev20, ev21, ev22, ev23, ev24, ev25, ev26, ev27, ev28, ev29, ev30, ev31, ev32, ev33, ev34, ev35, ev36, ev37, ev38, ev39, ev40, ev41, ev42, ev43, ev44, ev45, ev46, ev47, ev48, ev49, ev50, ev51, ev52, ev53, ev54, wrE0, wrE1, wrE2, wrE3, wrE4, wrE5, wrE6, wrE7, wrE8, wrE9, wrE10, List.append_assoc]
  have run : WR.PRun WR.cx spw evs wrS0 wrS11 := by
    rw [e]; exact (s wrSeg0).append ((s wrSeg1).append ((s wrSeg2).append ((s wrSeg3).append ((s wrSeg4).append ((s wrSeg5).append ((s wrSeg6).append ((s wrSeg7).append ((s wrSeg8).append ((s wrSeg9).append (s wrSeg10))))))))))
  exact WR.refOK_of WR.cx_ok wrPar wrEnd0 wrEndF run
end GXD.W7604
