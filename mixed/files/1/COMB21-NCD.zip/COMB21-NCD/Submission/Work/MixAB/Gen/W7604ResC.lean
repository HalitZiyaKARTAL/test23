import Submission.Work.MixAB.Gen.W7604.D20
namespace GXD.W7604.ResC
open KLW
set_option Elab.async false

def tget : SSC.Trie → Nat → Nat
  | .leaf v, _ => v
  | .node l r, k => if k % 2 = 0 then tget l (k/2) else tget r (k/2)
def cdim (c : Nat) : Nat := c &&& 255
noncomputable def memK (r : Nat) (gl : List Nat) : Bool :=
  List.rec (motive := fun _ => Bool) false
    (fun x _ ih => Bool.rec (motive := fun _ => Bool) ih true (Nat.beq x r)) gl
noncomputable def allLt (N : Nat) : Row → Bool :=
  List.rec (motive := fun _ => Bool) true (fun e _ ih => SSC.guard (Nat.blt e.1 N) ih)
noncomputable def idKn (q : SPw) (R : RT) (n : Nat) : Bool :=
  Nat.rec (motive := fun _ => Bool) true
    (fun r ih => SSC.guard (R.getK r (fun row => rowEq row [(r, (q.D : Int))])) ih) n
noncomputable def idK (q : SPw) (R : RT) : Bool := idKn q R q.nr
noncomputable def freeKn (q : SPw) (R : RT) (n : Nat) : Bool :=
  Nat.rec (motive := fun _ => Bool) true (fun r ih => SSC.guard (R.getK r (fun row => allLt q.N row)) ih) n
noncomputable def freeK (q : SPw) (R : RT) : Bool := freeKn q R q.nr
def consNZ (k : Nat) (c : Int) (l : Row) : Row := if c = 0 then l else (k, c) :: l
def shRowAB (D v : Nat) (ab : Nat → Int × Int × Int) (r : Nat) : Row :=
  if r < v then (r, (D : Int)) :: consNZ (r + v) (ab r).1 []
  else if r < 2 * v then consNZ (r - v) (ab (r - v)).2.1 (consNZ r (ab (r - v)).2.2 [])
  else [(r, (D : Int))]
noncomputable def shKnAB (q : SPw) (v : Nat) (ab : Nat → Int × Int × Int) (R : RT) (n : Nat) : Bool :=
  Nat.rec (motive := fun _ => Bool) true
    (fun r ih => SSC.guard (R.getK r (fun row => rowEq row (shRowAB q.D v ab r))) ih) n
inductive CtrC
  | F
  | Bk
  | M
def ctrAb (D : Nat) : CtrC → Int × Int × Int
  | .F => (0, (D : Int), (D : Int))
  | .Bk => (-(D : Int), 0, (D : Int))
  | .M => (-(D : Int), ((D / 2 : Nat) : Int), ((D / 2 : Nat) : Int))
def ctrC : List CtrC := [.F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .M, .F, .M, .F, .F, .F, .F, .F, .F, .F, .F, .F, .M, .F, .F, .F, .F, .F, .F, .M, .M, .F, .F, .F, .F, .F, .F, .M, .F, .F, .F, .F, .M, .F, .F, .F, .F, .F, .F, .F, .M, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .F, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk, .Bk]

noncomputable def tgetR (t : SSC.Trie) : Nat → Nat :=
  SSC.Trie.rec (motive := fun _ => Nat → Nat) (fun v _ => v)
    (fun _ _ gl gr k => Bool.rec (gr (k / 2)) (gl (k / 2)) (Nat.beq (k % 2) 0)) t
theorem tget_eq : ∀ t k, tget t k = tgetR t k
  | .leaf _, _ => rfl
  | .node l r, k => by
    show (if k % 2 = 0 then tget l (k/2) else tget r (k/2)) =
      Bool.rec (tgetR r (k / 2)) (tgetR l (k / 2)) (Nat.beq (k % 2) 0)
    rw [tget_eq l, tget_eq r]
    cases h : Nat.beq (k % 2) 0
    · have : ¬ k % 2 = 0 := fun e => by rw [e] at h; exact Bool.noConfusion h
      simp only [this, if_false]
    · simp only [Nat.eq_of_beq_eq_true h, if_true]
noncomputable def lgetD {α : Type} (l : List α) (d : α) : Nat → α :=
  List.rec (motive := fun _ => Nat → α) (fun _ => d)
    (fun x _ ih n => Nat.rec (motive := fun _ => α) x (fun m _ => ih m) n) l
theorem lgetD_eq {α : Type} (d : α) : ∀ (l : List α) n, l.getD n d = lgetD l d n
  | [], _ => rfl
  | _ :: _, 0 => rfl
  | _ :: xs, n + 1 => by rw [List.getD_cons_succ, lgetD_eq d xs n]; rfl

theorem guard_true {b k : Bool} (h : SSC.guard b k = true) : b = true ∧ k = true := by
  cases b
  · exact Bool.noConfusion h
  · exact ⟨rfl, h⟩

def sortedGe : Nat → List Nat → Bool
  | _, [] => true
  | b, x :: xs => Nat.ble b x && sortedGe (x + 1) xs
def isHead (r : Nat) : List Nat → Bool
  | [] => false
  | x :: _ => Nat.beq x r
def nextE (r : Nat) : List Nat → List Nat
  | [] => []
  | x :: xs => bif Nat.beq x r then xs else x :: xs
theorem memK_iff (r : Nat) : ∀ l, memK r l = true ↔ r ∈ l
  | [] => by show false = true ↔ _; simp
  | x :: xs => by
    show Bool.rec (memK r xs) true (Nat.beq x r) = true ↔ _
    cases h : Nat.beq x r
    · have hne : x ≠ r := Nat.ne_of_beq_eq_false h
      show memK r xs = true ↔ _
      rw [memK_iff r xs, List.mem_cons]
      exact ⟨Or.inr, fun h' => h'.elim (fun e => absurd e.symm hne) id⟩
    · show true = true ↔ _
      exact ⟨fun _ => List.mem_cons.mpr (Or.inl (Nat.eq_of_beq_eq_true h).symm), fun _ => rfl⟩
theorem sortedGe_cons {b x : Nat} {xs : List Nat} (h : sortedGe b (x :: xs) = true) :
    b ≤ x ∧ sortedGe (x + 1) xs = true := by
  simp only [sortedGe, Bool.and_eq_true] at h
  exact ⟨Nat.le_of_ble_eq_true h.1, h.2⟩
theorem sorted_le : ∀ b l, sortedGe b l = true → ∀ x ∈ l, b ≤ x
  | _, [], _, x, hx => absurd hx List.not_mem_nil
  | b, y :: ys, h, x, hx => by
    have h' := sortedGe_cons h
    rcases List.mem_cons.mp hx with e | hx
    · rw [e]; exact h'.1
    · have := sorted_le _ ys h'.2 x hx; omega
theorem head_iff : ∀ r E, sortedGe r E = true → (r ∈ E ↔ isHead r E = true)
  | r, [], _ => by simp [isHead]
  | r, x :: xs, h => by
    have h' := sortedGe_cons h
    have hx := sorted_le _ _ h'.2
    show _ ↔ Nat.beq x r = true
    constructor
    · intro hm
      rcases List.mem_cons.mp hm with e | hm
      · rw [e]; exact Nat.beq_refl x
      · have := hx r hm; omega
    · intro e; rw [Nat.eq_of_beq_eq_true e]; exact List.mem_cons_self
theorem next_ok (exits : List Nat) : ∀ r E, sortedGe r E = true → (∀ s, r ≤ s → (s ∈ exits ↔ s ∈ E)) →
    sortedGe (r + 1) (nextE r E) = true ∧ (∀ s, r + 1 ≤ s → (s ∈ exits ↔ s ∈ nextE r E))
  | r, [], _, hi => ⟨rfl, fun s hs => hi s (Nat.le_of_succ_le hs)⟩
  | r, x :: xs, h, hi => by
    have h' := sortedGe_cons h
    cases e : Nat.beq x r
    · have hne : x ≠ r := Nat.ne_of_beq_eq_false e
      have hn : nextE r (x :: xs) = x :: xs := by
        show (bif Nat.beq x r then xs else x :: xs) = _; rw [e]; rfl
      rw [hn]
      refine ⟨?_, fun s hs => hi s (Nat.le_of_succ_le hs)⟩
      show (Nat.ble (r + 1) x && sortedGe (x + 1) xs) = true
      rw [h'.2, Nat.ble_eq_true_of_le (by omega)]; rfl
    · have hxr := Nat.eq_of_beq_eq_true e
      have hn : nextE r (x :: xs) = xs := by
        show (bif Nat.beq x r then xs else x :: xs) = _; rw [e]; rfl
      rw [hn]
      refine ⟨hxr ▸ h'.2, fun s hs => ?_⟩
      rw [hi s (Nat.le_of_succ_le hs), List.mem_cons]
      exact ⟨fun h => h.elim (fun e => by omega) id, Or.inr⟩
noncomputable def resM (T S0 SF : SSC.Trie) (B q : Nat) (b : Bool) : Nat :=
  Bool.rec (motive := fun _ => Nat)
      (9 - cdim (tgetR T (tgetR S0 (B + q))))
      (cdim (tgetR T (tgetR SF (B + q))) - cdim (tgetR T (tgetR S0 (B + q))))
      b
noncomputable def chk (T S0 SF : SSC.Trie) (B n : Nat) : Nat → List Nat → List Nat → Bool :=
  Nat.rec (motive := fun _ => Nat → List Nat → List Nat → Bool) (fun _ _ _ => true)
    (fun _ ih i l E => SSC.guard (Nat.beq (resM T S0 SF B i (isHead (B + i) E)) (List.headD l 0))
      (ih (i + 1) (List.tail l) (nextE (B + i) E))) n
theorem chk_sound (T S0 SF : SSC.Trie) (B : Nat) (X : List Nat) : ∀ n i l E, sortedGe (B + i) E = true →
    (∀ s, B + i ≤ s → (s ∈ X ↔ s ∈ E)) →
    chk T S0 SF B n i l E = true → ∀ j, j < n → resM T S0 SF B (i + j) (memK (B + (i + j)) X) = l.getD j 0
  | 0, _, _, _, _, _, _, j, hj => absurd hj (Nat.not_lt_zero j)
  | n + 1, i, l, E, hs, hi, h, j, hj => by
    have h' := guard_true h
    cases j with
    | zero =>
      have hm : memK (B + i) X = isHead (B + i) E := Bool.eq_iff_iff.mpr (by
        rw [memK_iff, hi _ (Nat.le_refl _)]; exact head_iff _ _ hs)
      show resM T S0 SF B i (memK (B + i) X) = _
      rw [hm]
      cases l <;> exact Nat.eq_of_beq_eq_true h'.1
    | succ j =>
      have hn := next_ok X (B + i) E hs hi
      have := chk_sound T S0 SF B X n (i + 1) l.tail (nextE (B + i) E) hn.1 hn.2 h'.2 j (Nat.lt_of_succ_lt_succ hj)
      rw [show i + (j + 1) = i + 1 + j by omega]
      cases l with
      | nil => exact this
      | cons x xs => rw [List.getD_cons_succ]; exact this
theorem res_of_chk (T S0 SF : SSC.Trie) (B n : Nat) (X l : List Nat) (hs : sortedGe B X = true)
    (h : chk T S0 SF B n 0 l X = true) : ∀ q : Fin n,
    Bool.rec (motive := fun _ => Nat)
      (9 - cdim (tget T (tget S0 (B + q.val))))
      (cdim (tget T (tget SF (B + q.val))) - cdim (tget T (tget S0 (B + q.val))))
      (memK (B + q.val) X)
    = l.getD q.val 0 := fun q => by
  have := chk_sound T S0 SF B X n 0 l X hs (fun _ _ => Iff.rfl) h q.val q.isLt
  rw [Nat.zero_add] at this
  simp only [tget_eq]; exact this
set_option trace.profiler true in
theorem exits_sorted : sortedGe 400 exits = true := by decide +kernel
set_option trace.profiler true in
theorem res_chk : chk tab st0 stF 400 1101 0 resW exits = true := by decide +kernel
theorem res_okC : ∀ q : Fin 1101,
    Bool.rec (motive := fun _ => Nat)
      (9 - cdim (tget tab (tget st0 (400 + q.val))))
      (cdim (tget tab (tget stF (400 + q.val))) - cdim (tget tab (tget st0 (400 + q.val))))
      (memK (400 + q.val) exits)
    = resW.getD q.val 0 := res_of_chk tab st0 stF 400 1101 exits resW exits_sorted res_chk

noncomputable def abT (n : Nat) : Int × Int × Int := ctrAb spw.D (ctrC.getD n .F)
noncomputable def abTR (n : Nat) : Int × Int × Int := ctrAb spw.D (lgetD ctrC .F n)
set_option trace.profiler true in
theorem id0_okC : idK spw rf0 = true := by decide +kernel
set_option trace.profiler true in
theorem wfF_okC : KLW.RT.wfK rfF spw.d = true := by decide +kernel
set_option trace.profiler true in
theorem shAB_okR : shKnAB spw 200 abTR rfF 1501 = true := by decide +kernel
theorem shAB_okC : shKnAB spw 200 abT rfF 1501 = true := by
  have : abT = abTR := funext fun n => by unfold abT abTR; rw [lgetD_eq]
  rw [this]; exact shAB_okR
set_option trace.profiler true in
theorem frF_okC : freeK spw rfF = true := by decide +kernel
theorem two_okC : 2 ∣ spw.D := ⟨18874368000, rfl⟩
end GXD.W7604.ResC

