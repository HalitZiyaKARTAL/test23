import Submission.Work.MixAB.Gen.W7604Tab1
set_option maxRecDepth 100000
namespace GXD.W7604
open GXD
theorem tab2_ok : GLab.tabK 9 tab_n01 = true := by decide +kernel
end GXD.W7604
