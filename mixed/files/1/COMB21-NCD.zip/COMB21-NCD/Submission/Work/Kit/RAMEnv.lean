import Submission.OAI.Computability.FourierTransform.RecursionBounds

set_option linter.unusedSectionVars false

namespace OAI
namespace PowerSaving.RAM
open Ty Binary

universe U V

abbrev Lifts {ι : Type U} (m : Bool) (B : ι → ℕ) (s : Ty) (x : ι → T s) (s' : Ty) (x' : ι → T s') : Prop :=
  ∀ {u : Ty} {z : ι → T u}, Has m B s u x z → Has m B s' u x' z

section
variable {ι : Type U} {κ : Type V} {m : Bool} {B : ι → ℕ} {s t q : Ty} {x : ι → T s}

theorem Has.atW {y : ι → T t} {W : ι → ℕ} (h : Has m B s t x y) : Can m B s t x y W :=
  Can.mono h (fun _ => Nat.zero_le _)

theorem Has.extE {v : ι → T (p s t)} {z : ι → T q} {W : ι → ℕ}
    (h : Can m B s q (fun i => (v i).1) z W) : Can m B (p s t) q v z W :=
  Can.then_do Can.first h

theorem Has.liftE {e : κ → T t} {z : ι → T q} {W : ι → ℕ} (f : κ → ι) (h : Can m B s q x z W) :
    Can m (fun k => B (f k)) (p s t) q (fun k => (x (f k), e k)) (fun k => z (f k)) (fun k => W (f k)) :=
  Has.extE (h.reindex f)

theorem Can.table {N P : ι → ℕ} (g : ∀ i, Fin (N i) → T t) (hN : Knows m B s x N) (hNs : Small B N)
    (hg : Can m (fun u : Σ i, Fin (N i) => B u.1) (p s w) t (fun u => (x u.1, u.2.val))
      (fun u => g u.1 u.2) (fun u => P u.1)) :
    Can m B s (a t) x (fun i => (Layout.std (N i)).tape (g i)) (fun i => N i * (P i + 1)) := by
  have H := Can.layout (t:=t) (L:=fun i => Layout.std (N i)) (v:=g) (P:=P) (W:=fun _ => 0) hN hg hNs
  refine H.mono (fun i => ?_)
  change 0 + N i + N i * P i ≤ N i * (P i + 1)
  nlinarith

theorem Can.jobsTable {cl : Paint} {N n : ι → ℕ} (J : ∀ i, ℕ → Bits (n i) → ℂ)
    (hN : Knows m B s x N) (h2 : Knows m B s x (fun i => 2 ^ n i)) (hNs : Small B N)
    (h2s : Small B (fun i => 2 ^ n i))
    (hent : Has m (fun d : Σ u : (Σ i, Fin (N i)), Bits (n u.1) => B d.1.1) (p (p s w) w) (c cl)
      (fun d => ((x d.1.1, d.1.2.val), (bits (n d.1.1)).loc d.2)) (fun d => J d.1.1 d.1.2 d.2)) :
    Can m B s (a (a (c cl))) x (fun i => (Layout.std (N i)).tape (fun t => (bits (n i)).tape (J i t)))
      (fun i => N i * 2 ^ n i) := by
  have hlen : Knows m (fun u : Σ i, Fin (N i) => B u.1) (p s w) (fun u => (x u.1, u.2.val))
      (fun u => (bits (n u.1)).n) := Has.liftE (fun u : Σ i, Fin (N i) => u.1) h2
  have HI := Can.layout (t:=c cl) (L:=fun u : Σ i, Fin (N i) => bits (n u.1))
    (v:=fun u e => J u.1 u.2 e) (P:=fun _ => 0) (W:=fun _ => 0) hlen (Has.atW hent) (h2s.reindex _)
  have HO := Can.layout (t:=a (c cl)) (L:=fun i => Layout.std (N i))
    (v:=fun i t => (bits (n i)).tape (J i t)) (P:=fun i => 2^(n i)) (W:=fun _ => 0) hN
    (HI.mono (fun u => by simp)) hNs
  refine HO.weaken ⟨3, fun i => ?_⟩
  change 0 + N i + N i * 2^(n i) + 1 ≤ 3 * (N i * 2^(n i) + 1)
  have h1 : N i ≤ N i * 2^(n i) := Nat.le_mul_of_pos_right _ (Nat.two_pow_pos _)
  omega

end

end PowerSaving.RAM
end OAI
