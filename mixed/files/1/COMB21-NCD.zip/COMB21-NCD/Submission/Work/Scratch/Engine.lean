import Submission.OAI.Computability.FourierTransform.RootPreparation
import Submission.OAI.Computability.FourierTransform.LayerCompilation
import Submission.OAI.Computability.FourierTransform.FourierIdentities
import Submission.OAI.Computability.FourierTransform.LocalPreparation
import Submission.OAI.Computability.FourierTransform.RecursionBounds
import Submission.Work.MixedCost.NaiveKernel

namespace OAI

namespace PowerSaving.Grove
open Slant Finset
noncomputable section

def climb {α : Type*} (r : Axes) (x : α)
    (step : ℕ → ℕ → ℕ → α → α) : ℕ → ℕ → α
  | 0 => fun _ => x
  | l+1 => fun i => step l (i/r l) (i%r l) (climb r x step l (i/r l))

def survey (r : Axes) (u : ℕ → Stroke) : ℕ → ℕ → ℕ × ℂ :=
  climb r (0,1) fun i _ a s => (s.1*r i+(u i).ix a,s.2*(u i).dye a)

lemma survey_lt (r : Axes) (l : ℕ) (u : ℕ → Stroke) (h : Splits r l)
    (g : ∀ i<l, (u i).Sound (r i)) :
    ∀ j<extent r l, (survey r u l j).1<extent r l := by
  induction l with
  | zero => intro i hi; change 0<1; omega
  | succ l ih =>
    intro j hj
    exact h.join_lt (ih (h.cut (by omega)) (fun i hi => g i (by omega)) _
      (h.div_lt hj)) ((g l (by omega)).bdix _ (h.mod_lt j))

lemma canopy_survey (r : Axes) (l : ℕ) (u : ℕ → Stroke) (h : Splits r l)
    (g : ∀ i<l, (u i).Sound (r i)) :
    ∀ i<extent r l, ∀ j<extent r l,
      canopy r (fun t => leafM (u t)) l i j =
      if j=(survey r u l i).1 then (survey r u l i).2 else 0 := by
  induction l with
  | zero =>
    intro i hi j hj
    change j<1 at hj
    have h : j=0 := by omega
    simp [survey,climb,h,canopy]
  | succ l ih =>
    intro i hi j hj
    let v := survey r u l (i/r l)
    let b := (u l).ix (i%r l)
    have hb : b < r l := (g l (by omega)).bdix _ (h.mod_lt i)
    have H : j=v.1*r l+b ↔ j/r l=v.1 ∧ j%r l=b := by
      constructor
      · intro h; rw [h,chops _ _ _ hb,chips _ _ _ hb]; exact ⟨rfl,rfl⟩
      · rintro ⟨A,B⟩; rw [← A,← B]; exact (joined ..).symm
    change canopy r _ l _ _ * leafM (u l) _ _ =
      if j=v.1*r l+b then v.2 * (u l).dye (i%r l) else 0
    rw [ih (h.cut (by omega)) (fun i hi => g i (by omega)) _ (h.div_lt hi) _
      (h.div_lt hj)]
    change (if j/r l=v.1 then v.2 else 0) *
      (if j%r l=b then _ else 0) = if j=v.1*r l+b then _ else _
    by_cases A : j/r l=v.1 <;> by_cases B : j%r l=b <;> simp [H,A,B]

theorem graft_survey (r : Axes) (l : ℕ) (u : ℕ → Stroke) (h : Splits r l)
    (g : ∀ i<l, (u i).Sound (r i)) (x : Line) (j : ℕ) (hj : j<extent r l) :
    graft (extent r l) (canopy r (fun t => leafM (u t)) l) x j =
    (survey r u l j).2 * x (survey r u l j).1 := by
  let t := survey r u l j
  have ht := survey_lt r l u h g j hj
  change ∑ i ∈ range _, _ = t.2*x t.1
  rw [sum_eq_single t.1]
  · rw [canopy_survey r l u h g j hj _ ht, ite_eq_left rfl]
  · intro b hb hg
    rw [canopy_survey r l u h g j hj _ (mem_range.mp hb), ite_eq_right hg, zero_mul]
  · intro hh; exact absurd (mem_range.mpr ht) hh

end
end PowerSaving.Grove

end OAI

namespace OAI

namespace PowerSaving.RAM
open Ty Finset
noncomputable section

universe U V

namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι}
  {n : ι→ℕ} {t : Ty}

lemma inspect (b : Bench m ι) (n : ι→ℕ) (x : ι→ℕ→T t) :
    (b.climbs n t x).Feeds (b.scan n) id :=
  Feeds.select (Feeds.climbs b n x)
    ((toppings (b.along During.i) (t:=p w t) (fun d : During n => (d.j,x d.i d.j))).fst)

lemma Digit.two (h : b.Digit n) (hz : Small b.size (fun i => 2^n i)) :
    b.Digit (fun i => 2^n i) := by
  let x := fun (_ : ι) j => (2:ℕ)^j
  let P := b.climbs n w x
  have hh : P.Digit (fun i => x i.i i.j) := by
    refine ⟨stepsum (t:=w) b n x,(hz.reindex During.i).mono ?_⟩
    intro j
    exact Nat.pow_le_pow_right (by omega) j.hj.le
  have hk : P.Digit (fun i => x i.i (i.j+1)) :=
    (hh.mul (Digit.wc 2)).congr (fun i => by simp [x,pow_succ])
  exact ⟨loop (t:=w) h x ((Makes.wc 1).congr fun _ => by simp [x]) hk.run,hz⟩

namespace Makes

lemma casting (h : b.Digit n) : b.Makes sc (fun i => (n i:ℂ)) := by
  let x := fun (_ : ι) (j : ℕ) => (j:ℂ)
  exact loop (t:=sc) h x
    (zero.congr (fun _ => by simp [x]))
    (((stepsum (t:=sc) b n x).add one).congr (fun _ => by simp only [x,Nat.cast_add,Nat.cast_one]))

lemma expZ (h : b.Digit n) {u : ι→ℂ} (g : b.Makes sc u) :
    b.Makes sc fun i => (u i)^n i := by
  let x := fun i (j : ℕ) => (u i)^j
  let P := b.climbs n sc x
  have hu : P.Makes sc fun j => u j.i := pull (Feeds.climbs (t:=sc) b n x) g
  exact loop (t:=sc) h x (one.congr (fun _ => by simp [x]))
    (((stepsum (t:=sc) b n x).mul hu).congr (fun _ => by simp [x,pow_succ]))

lemma gridSum (h : b.Digit n) (x : ι→ℕ→ℂ)
    (g : (b.scan n).Makes sc fun i => x i.i i.j) :
    b.Makes sc (fun i => ∑ j ∈ range (n i), x i j) := by
  let y := fun i k => ∑ j ∈ range k, x i j
  have hx : (b.climbs n sc y).Makes sc fun i => x i.i i.j :=
    pull (inspect (t:=sc) b n y) g
  exact loop (t:=sc) h y (zero.congr fun _ => by simp [y])
    (((stepsum (t:=sc) b n y).add hx).congr (fun _ => by simp [y,sum_range_succ]))

lemma gridProd (h : b.Digit n) (x : ι→ℕ→ℂ)
    (g : (b.scan n).Makes sc fun i => x i.i i.j) :
    b.Makes sc (fun i => ∏ j ∈ range (n i), x i j) := by
  let y := fun i k => ∏ j ∈ range k, x i j
  have hx : (b.climbs n sc y).Makes sc fun i => x i.i i.j :=
    pull (inspect (t:=sc) b n y) g
  exact loop (t:=sc) h y (one.congr fun _ => by simp [y])
    (((stepsum (t:=sc) b n y).mul hx).congr (fun _ => by simp [y,prod_range_succ]))

lemma pick (x : ι→ℕ→T t)
    (h : b.Makes (a t) (fun i => Tape.tab (n i) (x i)))
    {k} (g : b.Makes w k) (hk : ∀ i, k i<n i) :
    b.Makes t (fun i => x i (k i)) :=
  (h.look g).congr (fun i => by rw [Tape.look_tab,ite_eq_left (hk i)])

end Makes
end Bench

end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Finset Complex
noncomputable section

universe U V

namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι} {q : Bench m κ}

structure Hue (b : Bench m ι) (f : ι→ℂ) : Prop where
  bright : b.Makes sc f
  dull : b.Makes sc (fun i => starRingEnd ℂ (f i))

namespace Hue
variable {f g : ι→ℂ}

lemma congr (h : b.Hue f) (k : ∀ i, f i=g i) : b.Hue g := by rwa [← funext k]

lemma transfer {p : ι→κ} {f : κ→ℂ} (h : q.Hue f) (g : b.Feeds q p) :
    b.Hue (fun i => f (p i)) := ⟨pull g h.bright,pull g h.dull⟩

lemma zero : b.Hue (fun _ => 0) :=
  ⟨Makes.zero,Makes.zero.congr (fun _ => by simp)⟩

lemma one : b.Hue (fun _ => 1) :=
  ⟨Makes.one,Makes.one.congr (fun _ => by simp)⟩

lemma neg (h : b.Hue f) : b.Hue (fun i => -(f i)) :=
  ⟨h.bright.neg,h.dull.neg.congr (fun _ => by simp)⟩

lemma add (h : b.Hue f) (k : b.Hue g) : b.Hue (fun i => f i + g i) :=
  ⟨h.bright.add k.bright,(h.dull.add k.dull).congr (fun _ => by simp)⟩

lemma sub (h : b.Hue f) (k : b.Hue g) : b.Hue (fun i => f i - g i) :=
  ⟨h.bright.sub k.bright,(h.dull.sub k.dull).congr (fun _ => by simp)⟩

lemma mul (h : b.Hue f) (k : b.Hue g) : b.Hue (fun i => f i*g i) :=
  ⟨h.bright.mul k.bright,(h.dull.mul k.dull).congr (fun _ => by simp)⟩

lemma inv (h : b.Hue f) (k : ∀ i, f i ≠ 0) : b.Hue (fun i => (f i)⁻¹) :=
  ⟨h.bright.inv k,(h.dull.inv (by intro i; simpa using k i)).congr (fun _ => by simp)⟩

lemma div (h : b.Hue f) (k : b.Hue g) (hg : ∀ i, g i≠0) :
    b.Hue fun i => f i / g i :=
  (h.mul (k.inv hg)).congr (fun _ => (div_eq_mul_inv _ _).symm)

lemma flip (h : b.Hue f) :
    b.Hue (fun i => starRingEnd ℂ (f i)) :=
  ⟨h.dull,h.bright.congr (fun i => by simp)⟩

lemma letterI (h : b.Makes sc fun _ => I) :
    b.Hue (fun _ => I) := ⟨h,h.neg.congr (fun _ => by simp)⟩

lemma casting {n} (h : b.Digit n) : b.Hue (fun i => (n i:ℂ)) :=
  ⟨Makes.casting h,(Makes.casting h).congr fun _ => by simp⟩

lemma numeral (n : ℕ) : b.Hue (fun _ => (n:ℂ)) := casting (Digit.wc n)

lemma of_root {n : ι→ℕ} (h : b.Makes sc f) (hn : ∀ i, 0<n i)
    (hf : ∀ i, f i ^ n i = 1) : b.Hue f := by
  have hh : ∀ i, f i ≠ 0 := by
    intro i hg
    have hk := hf i
    rw [hg,zero_pow (by have := hn i; omega)] at hk
    exact zero_ne_one hk
  exact ⟨h,(h.inv hh).congr (fun i => (Spectral.conj_of_root (hn i) (hf i)).symm)⟩

lemma exponent (h : b.Hue f) {n} (g : b.Digit n) :
    b.Hue (fun i => f i ^ n i) :=
  ⟨Makes.expZ g h.bright,(Makes.expZ g h.dull).congr fun _ => by simp⟩

lemma fork {P : ι→Prop} [DecidablePred P] (hp : b.Study P)
    (a : (b.scrutin P).Hue (fun i => f i.val))
    (c : (b.scrutin (fun i => ¬P i)).Hue (fun i => g i.val)) :
    b.Hue fun i => if P i then f i else g i :=
  ⟨branchM hp a.bright c.bright,
    (branchM (x:=fun i => starRingEnd ℂ (f i)) (y:=fun i => starRingEnd ℂ (g i)) hp
      a.dull c.dull).congr (fun i => by by_cases hi : P i <;> simp [hi])⟩

variable {n : ι→ℕ}
lemma sum (h : b.Digit n) (x : ι → Line)
    (g : (b.scan n).Hue (fun i => x i.i i.j)) :
    b.Hue (fun i => ∑ j ∈ range (n i), x i j) :=
  ⟨Makes.gridSum h x g.bright,
    (Makes.gridSum h (fun i j => starRingEnd ℂ (x i j)) g.dull).congr
      (fun _ => by simp)⟩

lemma prod (h : b.Digit n) (x : ι → Line)
    (g : (b.scan n).Hue (fun i => x i.i i.j)) :
    b.Hue (fun i => ∏ j ∈ range (n i), x i j) :=
  ⟨Makes.gridProd h x g.bright,
    (Makes.gridProd h (fun i j => starRingEnd ℂ (x i j)) g.dull).congr
      (fun _ => by simp)⟩

end Hue

def carried (p : ι→κ) (n : κ→ℕ) (i : During fun j => n (p j)) :
    During n := ⟨p i.i,i.j,i.hj⟩

lemma Feeds.carry {p : ι→κ} (h : b.Feeds q p) (n : κ→ℕ) :
    (b.scan (fun i => n (p i))).Feeds (q.scan n) (carried p n) := by
  have E := (Feeds.scan b fun i => n (p i)).next h
  exact Feeds.select E (toppings (t:=w) _ During.j)

def Fabric (b : Bench m ι) (n : ι→ℕ) (x : ι → Line) : Prop :=
  (b.scan n).Hue (fun i => x i.i i.j)

namespace Fabric
variable {n : ι→ℕ} {x y : ι → Line}

lemma bright (h : b.Fabric n x) : (b.scan n).Makes sc (fun i => x i.i i.j) :=
  Hue.bright h
lemma dull (h : b.Fabric n x) :
    (b.scan n).Makes sc (fun i => starRingEnd ℂ (x i.i i.j)) := Hue.dull h

lemma pick (h : b.Fabric n x) {k} (hk : b.Makes w k) (H : ∀ i,k i < n i) :
    b.Hue (fun i => x i (k i)) :=
  Hue.transfer h (show b.Feeds (b.scan n) (fun i => ⟨i,k i,H i⟩) from
    ⟨(prepares b).pair hk,Small.self _⟩)

lemma transfer {n : κ→ℕ} {x : κ→Line} (h : q.Fabric n x) {f} (g : b.Feeds q f) :
    b.Fabric (fun i => n (f i)) (fun i => x (f i)) :=
  Hue.transfer h (g.carry n)

lemma one : b.Fabric n (fun _ _ => 1) := Hue.one
lemma flat {f} (h : b.Hue f) : b.Fabric n (fun i _ => f i) :=
  h.transfer (Feeds.scan b n)
lemma neg (h : b.Fabric n x) : b.Fabric n (fun i j => -x i j) := Hue.neg h
lemma add (h : b.Fabric n x) (g : b.Fabric n y) :
    b.Fabric n (fun i j => x i j+y i j) := Hue.add h g
lemma sub (h : b.Fabric n x) (g : b.Fabric n y) :
    b.Fabric n (fun i j => x i j-y i j) := Hue.sub h g
lemma mul (h : b.Fabric n x) (g : b.Fabric n y) :
    b.Fabric n (fun i j => x i j*y i j) := Hue.mul h g
lemma inv (h : b.Fabric n x) (k : ∀ i, ∀ j<n i, x i j ≠ 0) :
    b.Fabric n (fun i j => (x i j)⁻¹) := Hue.inv h (fun i => k i.i i.j i.hj)
lemma flip (h : b.Fabric n x) :
    b.Fabric n (fun i j => starRingEnd ℂ (x i j)) := Hue.flip h

lemma supply (h : b.Fabric n x) (hk : b.Digit n) :
    b.Makes (a (p sc sc)) (fun i => Tape.tab (n i) fun j => (x i j,starRingEnd ℂ (x i j))) :=
  tab hk _ (h.bright.pair h.dull)

lemma recover (h : b.Makes (a (p sc sc))
    (fun i => Tape.tab (n i) fun j => (x i j,starRingEnd ℂ (x i j)))) :
    b.Fabric n x := by
  let y := fun (d : During n) (i : ℕ) => (x d.i i,starRingEnd ℂ (x d.i i))
  have K := Makes.pick (b:=b.scan n) (n:=fun d => n d.i) (t:=p sc sc) y
    (pull (Feeds.scan b n) h) (toppings (t:=w) _ During.j) During.hj
  exact ⟨K.fst,K.snd⟩

end Fabric
end Bench
end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM

open Ty Slant Slant.Stroke
noncomputable section

abbrev arrowTy := p w (p sc w)
abbrev stripeTy := a arrowTy
abbrev filmTy := a stripeTy

def emboss (s : Stroke) (i : ℕ) : T arrowTy :=
  (s.ix i,s.dye i,s.partner i)

def stripe (n : ℕ) (s : Stroke) : T stripeTy :=
  Tape.tab n (emboss s)

def film (n : ℕ) (r : Reel) : T filmTy :=
  Tape.tab r.beats fun i => stripe n (r.atBeat i)

universe U V
namespace Bench

variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι} {q : Bench m κ}

structure Band (b : Bench m ι) (n : ι→ℕ) (s : ι→Stroke) : Prop where
  good : ∀ i, (s i).Sound (n i)
  width : b.Digit n
  sheet : b.Makes stripeTy (fun i => stripe (n i) (s i))

namespace Band
variable {n e i : ι→ℕ} {s t : ι→Stroke}

lemma transfer {f : ι→κ} {n : κ→ℕ} {s : κ→Stroke} (h : q.Band n s) (g : b.Feeds q f) :
    b.Band (fun i => n (f i)) (fun i => s (f i)) :=
  ⟨fun i => h.good (f i),draw g h.width,pull g h.sheet⟩

lemma showOne (h : b.Band n s) (hk : b.Makes w i) (hI : ∀ j, i j<n j) :
    b.Makes arrowTy (fun j => emboss (s j) (i j)) :=
  Makes.pick (t:=arrowTy) (n:=n) (fun j => emboss (s j)) h.sheet hk hI

lemma fresh (h : b.Digit n) (g : ∀ i,(s i).Sound (n i))
    (a : (b.scan n).Makes arrowTy (fun j => emboss (s j.i) j.j)) :
    b.Band n s :=
  ⟨g,h,Bench.tab (t:=arrowTy) h _ a⟩

lemma noOrder (h : b.Digit n) :
    b.Band n (fun _ => Stroke.unmark) := by
  have hx := (slot h).run
  exact fresh h (fun i => Stroke.sound_unmark _) (hx.pair (Makes.one.pair hx))

lemma plain (h : b.Digit n) {l : ι→ℕ→ℕ} {u : ι→Line} (g : ∀ i, ∀ j<n i,l i j<n i)
    (hi : (b.scan n).Makes w (fun j => l j.i j.j))
    (hf : (b.scan n).Makes sc (fun j => u j.i j.j)) :
    b.Band n (fun i => Stroke.plain (n i) (l i) (u i)) := by
  refine fresh h (fun i => Stroke.plain_sound _ _ _ (g i))
    ((hi.pair (hf.pair (slot h).run)).congr ?_)
  intro d
  simp [emboss,Stroke.plain,d.hj]

lemma besideLeft {x} (h : b.Band n s) (hx : b.Digit x)
    (ha : ∀ i, x i<n i) :
    b.Makes arrowTy (fun i => emboss (Stroke.beside (n i) (s i) (t i)) (x i)) :=
  (h.showOne hx.run ha).congr (fun i => by simp [emboss,Stroke.beside,ha i])

lemma besideRight {x} (H : b.Digit n) (hx : b.Digit x) (h : b.Band e t)
    (hp : ∀ i,n i ≤ x i) (hk : ∀ i, x i-n i<e i) :
    b.Makes arrowTy (fun i => emboss (Stroke.beside (n i) (s i) (t i)) (x i)) := by
  have hd := h.showOne (hx.sub H).run hk
  have ha : b.Digit fun j => (t j).ix (x j-n j) :=
    ⟨hd.fst,h.width.small.mono (fun j => ((h.good j).bdix _ (hk j)).le)⟩
  have hb : b.Digit fun j => (t j).partner (x j-n j) :=
    ⟨hd.snd.snd,h.width.small.mono (fun j => ((h.good j).bdp _ (hk j)).le)⟩
  refine ((H.add ha).run.pair (hd.snd.fst.pair (H.add hb).run)).congr ?_
  intro d
  simp [emboss,Stroke.beside,Nat.not_lt.mpr (hp d)]

lemma beside (h : b.Band n s) (g : b.Band e t) :
    b.Band (fun i => n i+e i) (fun i => Stroke.beside (n i) (s i) (t i)) := by
  let W i := n i+e i
  have H : b.Digit W := h.width.add g.width
  refine fresh H (fun i => (h.good i).beside (g.good i)) ?_
  let M := b.scan W
  have hv := Feeds.scan b W
  have hx : M.Digit During.j := slot H
  let Q (d : During W) := d.j<n d.i
  have hs : M.Study Q := Study.lt hx (draw hv h.width)
  refine chooseM hs ?_ ?_
  · have hu := restricted M Q
    have Hw := (h.transfer hv).transfer hu
    exact besideLeft (t:=fun i => t i.val.i) Hw (draw hu hx) (fun i => i.property)
  · have hz := restricted M (fun i => ¬ Q i)
    have hf := (g.transfer hv).transfer hz
    refine besideRight (s:=fun i => s i.val.i) (draw hz (draw hv h.width)) (draw hz hx)
      hf (fun i => Nat.le_of_not_gt i.property) ?_
    intro j
    have h1 : j.val.j < n j.val.i + e j.val.i := j.val.hj
    have h2 : ¬ j.val.j<n j.val.i := j.property
    omega

lemma wider (h : b.Band n s) (k : b.Digit e) (hv : ∀ i,n i ≤ e i) :
    b.Band e s := by
  refine fresh k (fun i => (h.good i).wider (hv i)) ?_
  let P (d : During e) := d.j<n d.i
  have F := Feeds.scan b e
  have hd := h.transfer F
  have hj := slot k
  have hh : (b.scan e).Study P := Study.lt hj hd.width
  refine chooseM hh ?_ ?_
  · have G := restricted (b.scan e) P
    exact (hd.transfer G).showOne (draw G hj).run (fun i => i.property)
  · have G := restricted (b.scan e) (fun i => ¬P i)
    have hg := (draw G hj).run
    refine (hg.pair (Makes.one.pair hg)).congr ?_
    intro j
    have h1 : n j.val.i ≤ j.val.j := Nat.le_of_not_gt j.property
    simp [emboss,(h.good j.val.i).awayix _ h1,(h.good j.val.i).awayd _ h1,
      (h.good j.val.i).awayp _ h1]

end Band
end Bench
end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Slant Slant.Stroke
noncomputable section

universe U V
namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι} {q : Bench m κ}

def tickCount {ι : Type*} (r : ι→Reel) := fun i => (r i).beats

structure Engrave (b : Bench m ι) (n : ι→ℕ) (r : ι→Reel) : Prop where
  sound : ∀ i,(r i).Sound (n i)
  count : b.Digit (tickCount r)
  width : b.Digit n
  layers : b.Makes filmTy (fun i => film (n i) (r i))

namespace Engrave
variable {n e : ι→ℕ} {r u : ι→Reel}

lemma transfer {f : ι→κ} {n : κ→ℕ} {s : κ→Reel} (h : q.Engrave n s) (g : b.Feeds q f) :
    b.Engrave (fun i => n (f i)) (fun i => s (f i)) :=
  ⟨fun i => h.sound (f i),draw g h.count,draw g h.width,pull g h.layers⟩

lemma plate (h : b.Engrave n r) (t : ι→ℕ) (ht : b.Makes w t) (hz : ∀ i,t i < tickCount r i) :
    b.Band n fun i => (r i).atBeat (t i) :=
  ⟨fun i => h.sound i (t i) (hz i),h.width,Makes.pick (t:=stripeTy) (n:=tickCount r)
    (fun i j => stripe (n i) ((r i).atBeat j)) h.layers ht hz⟩

lemma full (h : ∀ i,(r i).Sound (n i)) (hk : b.Digit (tickCount r)) (hw : b.Digit n)
    (hh : (b.scan (tickCount r)).Makes stripeTy fun d => stripe (n d.i) ((r d.i).atBeat d.j)) :
    b.Engrave n r := ⟨h,hk,hw, Bench.tab (t:=stripeTy) hk _ hh⟩

lemma single {p : ι→Stroke} (h : b.Band n p) :
    b.Engrave n (fun i => Reel.tick (p i)) :=
  full (fun i => Reel.sound_tick (h.good i)) (Digit.wc 1)
    h.width (pull (Feeds.scan b (fun _ => 1)) h.sheet)

lemma rest (h : b.Digit n) {e} (hh : b.Digit e) :
    b.Engrave n (fun i => Reel.wait (e i)) :=
  full (fun _ => Reel.sound_wait _ _) hh h (pull (Feeds.scan b e) (Band.noOrder h).sheet)

lemma stack (h : b.Engrave n r) (g : b.Engrave n u) :
    b.Engrave n (fun i => (r i).stack (u i)) := by
  let M i := (r i).beats+(u i).beats
  have hm : b.Digit M := h.count.add g.count
  refine full (fun i => (h.sound i).stack (g.sound i)) hm h.width ?_
  let P := b.scan M
  have F := Feeds.scan b M
  let Q (d : During M) := d.j<(r d.i).beats
  have hp : P.Digit During.j := slot hm
  have hq := h.transfer F
  have hr : P.Study Q := Study.lt hp hq.count
  refine chooseM hr ?_ ?_
  · have H := restricted P Q
    refine ((hq.transfer H).plate _ (draw H hp).run (fun i => i.property)).sheet.congr ?_
    intro j
    simp [Reel.stack, show j.val.j<(r j.val.i).beats from j.property]
  · have G := restricted P (fun i => ¬Q i)
    have hh := (g.transfer F).transfer G
    have hk := (draw G hp).sub (draw G hq.count)
    have hx : ∀ i : {j // ¬ Q j}, i.val.j-(r i.val.i).beats < (u i.val.i).beats := by
      intro i
      have hg : i.val.j<(r i.val.i).beats+(u i.val.i).beats := i.val.hj
      have hh : ¬ i.val.j<(r i.val.i).beats := i.property
      omega
    refine (hh.plate _ hk.run hx).sheet.congr ?_
    intro j; simp [Reel.stack,tickCount,show ¬ j.val.j<(r j.val.i).beats from j.property]

lemma parallel (h : b.Engrave n r) (g : b.Engrave e u) (hk : ∀ i,(r i).beats=(u i).beats) :
    b.Engrave (fun i => n i+e i) (fun i => Reel.parallel (n i) (r i) (u i)) := by
  refine full (fun i => (h.sound i).parallel (g.sound i) (hk i)) h.count
    (h.width.add g.width) ?_
  have F := Feeds.scan b (tickCount r)
  have hi := (slot h.count).run
  have hs := (h.transfer F).plate During.j hi During.hj
  have hv : ∀ d : During (tickCount r), d.j<(u d.i).beats := by
    intro j; rw [← hk]
    exact j.hj
  exact (hs.beside ((g.transfer F).plate During.j hi hv)).sheet

lemma wider (h : b.Engrave n r) (k : b.Digit e) (hI : ∀ i,n i ≤ e i) :
    b.Engrave e r := by
  refine full (fun i => (h.sound i).wider (hI i)) h.count k ?_
  have F := Feeds.scan b (tickCount r)
  exact (((h.transfer F).plate During.j (slot h.count).run During.hj).wider (draw F k)
    (fun i => hI _)).sheet

lemma mount (h : b.Engrave n r) (k : b.Digit e) :
    b.Engrave (fun i => e i+n i) (fun i => Reel.atBase (e i) (r i)) :=
  (rest k h.count).parallel h (fun _ => rfl)

lemma switch {P : ι→Prop} (hp : b.Study P)
    (h : (b.scrutin P).Engrave (fun i => n i.val) (fun i => r i.val))
    (hh : (b.scrutin (fun i => ¬ P i)).Engrave (fun i => n i.val) (fun i => r i.val)) :
    b.Engrave n r :=
  ⟨fun i => by
    by_cases hi : P i
    · exact h.sound ⟨i,hi⟩
    · exact hh.sound ⟨i,hi⟩,
    chooseN hp h.count hh.count,chooseN hp h.width hh.width,chooseM hp h.layers hh.layers⟩

lemma congr (h : b.Engrave n r) (g : ∀ i,n i=e i) (k : ∀ i,r i=u i) :
    b.Engrave e u := by rwa [← funext g,← funext k]

lemma fork {P : ι→Prop} [DecidablePred P] (hp : b.Study P)
    (h : (b.scrutin P).Engrave (fun i => n i.val) (fun i => r i.val))
    (hh : (b.scrutin (fun i => ¬P i)).Engrave (fun i => n i.val) (fun i => u i.val)) :
    b.Engrave n (fun i => if P i then r i else u i) :=
  switch hp (h.congr (fun _ => rfl) (fun i => (ite_eq_left i.property).symm))
    (hh.congr (fun _ => rfl) (fun i => (ite_eq_right i.property).symm))

lemma plain (l : ι→ℕ→ℕ) (x : ι→Line) (h : b.Digit n)
    (ha : ∀ i, ∀ j<n i,l i j<n i)
    (g : (b.scan n).Makes w (fun i => l i.i i.j)) (k : b.Fabric n x) :
    b.Engrave n (fun i => Reel.tick (Stroke.plain (n i) (l i) (x i))) :=
  single (Band.plain h ha g k.bright)

lemma swatch (h : b.Digit n) (x : ι→Line) (k : b.Fabric n x) :
    b.Engrave n (fun i => Reel.swatch (n i) (x i)) :=
  plain _ _ h (fun _ _ hi => hi) (slot h).run k

lemma lace (l : ι→ℕ→ℕ) (h : b.Digit n)
    (ha : ∀ i, ∀ j<n i,l i j<n i)
    (g : (b.scan n).Makes w (fun i => l i.i i.j)) :
    b.Engrave n (fun i => Reel.lace (n i) (l i)) :=
  plain _ _ h ha g Fabric.one
end Engrave
end Bench
end
end PowerSaving.RAM

end OAI

namespace OAI

namespace PowerSaving.RAM
open Ty Finset Grove Slant
noncomputable section
universe U V
namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V}

structure Fen (b : Bench m ι) (l : ι→ℕ) (r : ι→Axes) : Prop where
  high : b.Nick l
  good : ∀ i,Splits (r i) (l i)
  span : Small b.size fun i => extent (r i) (l i)
  part : (b.scan l).Nick fun d => r d.i d.j

abbrev routes {ι : Type*} (l : ι→ℕ) (r : ι→Axes) (d : During l) :=
  extent (r d.i) (d.j+1)

abbrev Forks (l : ι→ℕ) (r : ι→Axes) := During (routes l r)

variable {l : ι→ℕ} {r : ι→Axes}

namespace Forks
def tUp (d : Forks l r) := d.j/r d.i.i d.i.j
def tOff (d : Forks l r) := d.j%r d.i.i d.i.j
end Forks

variable {b : Bench m ι} {q : Bench m κ}
open Forks

namespace Fen

lemma transfer {l : κ→ℕ} {r : κ→Axes} (h : q.Fen l r) {f} (g : b.Instant q f) :
    b.Fen (fun i => l (f i)) (fun i => r (f i)) := by
  let L i := l (f i)
  have F := Instant.scan b L
  let p : During L→During l := fun i => ⟨f i.i,i.j,i.hj⟩
  have G : (b.scan L).Instant (q.scan l) p :=
    Instant.select (F.next g) (chop (h.high.transfer g)).close
  exact ⟨h.high.transfer g,fun i => h.good _,(h.span.reindex f).trans g.covers,
    h.part.transfer G⟩

lemma shrunk (h : b.Fen l r) (d : During l) :
    Splits (r d.i) (d.j+1) := (h.good d.i).cut d.hj

lemma midst (h : b.Fen l r) :
    Small (fun d : During l => b.size d.i) fun d => extent (r d.i) d.j :=
  (h.span.reindex During.i).mono fun i => (h.good _).extent_le i.hj.le

lemma smaller (h : b.Fen l r) (d : Forks l r) :
    tUp d<extent (r d.i.i) d.i.j := (h.shrunk _).div_lt d.hj
lemma lower (h : b.Fen l r) (d : Forks l r) :
    tOff d<r d.i.i d.i.j := (h.shrunk _).mod_lt _

def stalk (b : Bench m ι) (l : ι→ℕ) (r : ι→Axes) (s : Ty) (S : ι → ℕ → ℕ → T s) :
    Bench m (Forks l r) :=
  ((b.scan l).along During.i).extend (p w (p w s))
    (fun i => (tUp i,tOff i,S i.i.i i.i.j (tUp i)))

lemma stalkFeeds (b : Bench m ι) (l : ι→ℕ) (r : ι→Axes) (s : Ty) (S : ι → ℕ → ℕ → T s) :
    (stalk b l r s S).Instant (b.scan l) During.i :=
  (Instant.extend ((b.scan l).along During.i) (t:=p w (p w s)) _).next
    (Instant.along (b.scan l) During.i)

variable {s : Ty}

lemma stalkReads (h : b.Fen l r) (S : ι → ℕ → ℕ → T s) :
    let B := stalk b l r s S
    B.Nick tUp ∧ B.Nick tOff ∧ B.Moves (fun _ => 0) s (fun i => S i.i.i i.i.j (tUp i)) := by
  intro B
  have H : B.Moves (fun _ => 0) (p w (p w s))
      (fun d => (tUp d,tOff d,S d.i.i d.i.j (tUp d))) :=
    cherry ((b.scan l).along During.i) (t:=p w (p w s)) _
  exact ⟨⟨H.fst,(h.midst.reindex During.i).mono fun d => (h.smaller _).le⟩,
    ⟨H.snd.fst,(h.part.small.reindex During.i).mono fun d => (h.lower _).le⟩,H.snd.snd⟩

theorem visit (h : b.Fen l r) (S : ι → ℕ → ℕ → T s)
    (hS : b.Moves (fun _ => 0) s fun i => S i 0 0)
    (hs : (stalk b l r s S).Moves (fun _ => 0) s fun d => S d.i.i (d.i.j+1) d.j) :
    b.Moves (fun i => extent (r i) (l i)) (a s) fun i =>
      Tape.tab (extent (r i) (l i)) (S i (l i)) := by
  let M (i : ι) (j : ℕ) := Tape.tab (extent (r i) j) (S i j)
  let D := b.climbs l (a s) M
  let X := D.scan (routes l r)
  have F := Instant.climbs b l M (t:=a s)
  have hi := stride h.high M (t:=a s)
  have V : D.Instant (b.scan l) id := Instant.select F hi.close
  have T := Instant.scan D (routes l r)
  have hm := tokenNow b l M (t:=a s)
  have hg : D.Nick (routes l r) := by
    have hq : D.Nick fun i => extent (r i.i) i.j := ⟨hm.len h.midst,h.midst⟩
    exact hq.mul (h.part.transfer V)
  have hh : X.Instant (stalk b l r s S) id := by
    let K := stalk b l r s S
    have hk : X.Instant ((b.scan l).along During.i) (fun d : Forks l r => d) :=
      let U := T.next V; ⟨U.prep,U.covers⟩
    have ha := chop hg
    have hb := (h.part.transfer V).transfer T
    have hc := ha.div hb; have hd := ha.residue hb
    refine hk.supply (t:=p w (p w s)) (x:=fun d : Forks l r => (tUp d,tOff d,S d.i.i d.i.j (tUp d))) ?_
    have he := Moves.pick (b:=X) (t:=s) (n:=fun i => extent (r i.i.i) i.i.j)
      (fun i j => S i.i.i i.i.j j) (hm.transfer T) hc.close h.smaller -- typo
    exact hc.close.pair (hd.close.pair he)
  have step :
      D.Moves (routes l r) (a s) fun i => M i.i (i.j+1) :=
    arrayNow hg (fun d j => S d.i (d.j+1) j) (hs.transfer hh)
  have hB : b.Moves (fun _ => 0) (a s) fun i => M i 0 := by
    let n (_ : ι) := 1
    have hb := hS.transfer (Instant.scan b n)
    have he (d : During n) : S d.i 0 0=S d.i 0 d.j := by
      have hj : d.j<1 := d.hj
      rw [show d.j=0 by omega]
    exact (arrayNow (Nick.wc 1) _ (hb.congr he)).weaken (Dom.const _ _)
  refine (repeatM (t:=a s) h.high M (u:=fun i j => extent (r i) (j+1)) hB step).weaken ?_
  refine ⟨4,fun i => ?_⟩
  have h1 := (h.good i).axes_le
  have h2 := (h.good i).tree_bound
  rw [sum_range_succ'] at h2
  dsimp only
  omega

end Fen
end Bench
end
end PowerSaving.RAM

end OAI

namespace OAI

namespace PowerSaving.RAM
open Ty Slant Slant.Stroke Complex
noncomputable section

universe U V
namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι} {q : Bench m κ}

structure Spots (b : Bench m ι) (u : ι→Zone) : Prop where
  low : b.Digit (fun i => (u i).lo)
  wide : b.Digit (fun i => (u i).wide)

namespace Spots
variable {u v : ι→Zone} {n : ι→ℕ}
lemma transfer {f : ι→κ} {x : κ→Zone} (h : q.Spots x) (g : b.Feeds q f) :
    b.Spots (fun i => x (f i)) := ⟨draw g h.low,draw g h.wide⟩
lemma has (h : b.Spots u) {x} (hh : b.Digit x) :
    b.Study (fun i => (u i).has (x i)) :=
  (Study.le h.low hh).both (Study.lt hh (h.low.add h.wide))

lemma overlay (h : b.Spots u) {x} (hh : b.Digit x) {l : ι→Line}
    (g : b.Fabric (fun i => (u i).wide) l) {p} (hk : b.Hue p) :
    b.Hue (fun i => if (u i).has (x i) then l i (x i-(u i).lo) else p i) := by
  let P i := (u i).has (x i)
  have H := h.has hh
  refine Hue.fork H ?_ (hk.transfer (restricted b fun i => ¬P i))
  have M := restricted b P
  have hu (i : {i // P i}) := (u i.val).enter i.property
  exact (g.transfer M).pick (draw M (hh.sub h.low)).run hu

lemma shade (h : b.Spots u) (k : b.Spots v) {l g : ι→Line}
    (hf : b.Fabric (fun i => (u i).wide) l)
    (hg : b.Fabric (fun i => (v i).wide) g) (hn : b.Digit n)
    (ha : ∀ i,(u i).Fits (n i)) (hb : ∀ i,(v i).Fits (n i)) :
    b.Engrave n (fun i => Slant.shade (u i) (v i) (l i) (g i)) := by
  unfold Slant.shade
  refine Engrave.single (Band.fresh hn ?_ ?_)
  · intro i; exact sound_shade (f:=l i) (g:=g i) (ha i) (hb i) 0 (show 0<1 by omega)
  · have H := Feeds.scan b n
    have hx := slot hn
    exact hx.run.pair ((((h.transfer H).overlay hx (hf.transfer H)
      ((k.transfer H).overlay hx (hg.transfer H) Hue.one)).bright).pair hx.run)

lemma finds (h : b.Spots u) (k : b.Spots v) {x} (hh : b.Digit x) :
    b.Digit (fun i => Slant.jumps (u i) (v i) (x i)) :=
  iteN (h.has hh) (k.low.add (hh.sub h.low))
    (iteN (k.has hh) (h.low.add (hh.sub k.low)) hh)

lemma snap (h : b.Spots u) (k : b.Spots v) (hn : b.Digit n)
    (ha : ∀ i,(u i).Fits (n i)) (hb : ∀ i,(v i).Fits (n i))
    (hx : ∀ i,(u i).wide=(v i).wide) (hg : ∀ i,(u i).Sep (v i)) :
    b.Engrave n (fun i => Slant.snap (u i) (v i)) := by
  unfold Slant.snap
  refine Engrave.single (Band.fresh hn ?_ ?_)
  · intro i; exact sound_snap (ha i) (hb i) (hx i) (hg i) 0 (show 0<1 by omega)
  · have H := Feeds.scan b n
    exact (slot hn).run.pair (Makes.one.pair
      (((h.transfer H).finds (k.transfer H) (slot hn)).run))

lemma slim (h : b.Spots u) (k : b.Digit n) :
    b.Spots (fun i => (u i).slim (n i)) := ⟨h.low,k⟩

end Spots

lemma Hue.smallNumeral (b : Bench m ι) (n : ℕ) [Nat.AtLeastTwo n] :
    b.Hue (fun _ => (OfNat.ofNat n:ℂ)) := (Hue.numeral n).congr fun _ => rfl

section
variable {n : ι→ℕ} {u v : ι→Zone} (h : b.Spots u) (k : b.Spots v)
    (hn : b.Digit n)
    (ha : ∀ i,(u i).Fits (n i)) (hb : ∀ i,(v i).Fits (n i))
    (hx : ∀ i,(u i).wide=(v i).wide) (hg : ∀ i,(u i).Sep (v i))
    (hy : b.Hue fun _ => I)

include h k hn ha hb hx hg hy

lemma Spots.hinge :
    b.Engrave n (fun i => Slant.hinge (u i) (v i)) :=
  ((h.shade k Fabric.one (Fabric.flat hy) hn ha hb).stack (h.snap k hn ha hb hx hg)).stack
    (h.shade k (Fabric.flat (Hue.one.sub hy)) (Fabric.flat (Hue.one.add hy)) hn ha hb)

lemma Spots.brick :
    b.Engrave n (fun i => Slant.brick (u i) (v i)) :=
  have H := h.hinge k hn ha hb hx hg hy
  have p := h.shade k (Fabric.flat (Hue.smallNumeral b 3).neg) Fabric.one hn ha hb
  have q := h.shade k (Fabric.flat (Hue.smallNumeral b 2)) Fabric.one hn ha hb
  (((H.stack p).stack H).stack q).stack H

lemma Spots.spark {f : ι→Line}
    (hh : b.Fabric (fun i => (u i).wide) f) (hf : ∀ i, ∀ j<(u i).wide, f i j ≠ 0) :
    b.Engrave n (fun i => Slant.spark (u i) (v i) (f i)) := by
  let F (i : ι) : Line := fun j => 4*f i j/5
  let U i := (u i).wide
  have H : b.Fabric U F :=
    Hue.div ((Hue.smallNumeral (b.scan U) 4).mul hh) (Hue.smallNumeral _ 5)
      (by intro i; norm_num)
  have hx' : ∀ i, ∀ j<U i, F i j≠0 := fun i j hj => by simp [F,hf i j hj]
  have hc6 : b.Hue (fun _ => -1/6) := Hue.one.neg.div (Hue.smallNumeral _ 6) (by
    intro i; norm_num)
  have hc8 : b.Hue (fun _ => -1/8) := Hue.one.neg.div (Hue.smallNumeral _ 8) (by
    intro i; norm_num)
  have hP := h.shade k (H.inv hx') Fabric.one hn ha hb
  have hQ := h.shade k ((Fabric.flat hc8).mul H) (Fabric.flat hc6) hn ha hb
  exact (hP.stack (h.brick k hn ha hb hx hg hy)).stack hQ

lemma Spots.flash {f : ι→Line} (hh : b.Fabric (fun i => (u i).wide) f) :
    b.Engrave n (fun i => Slant.flash (u i) (v i) (f i)) := by
  have hk : b.Fabric (fun i => (u i).wide) (fun i => blaze (f i)) :=
    Fabric.one.add (hh.mul hh.flip)
  exact (h.spark k hn ha hb hx hg hy hk (fun i j _ => blaze_ne _ _)).stack
    (h.spark k hn ha hb hx hg hy (hh.sub hk) (fun i j _ => after_ne _ _))

end

lemma engrave_cameo {n : ι→ℕ} {p u v z : ι→Reel}
    (hp : b.Engrave n p) (hu : b.Engrave n u)
    (hv : b.Engrave n v) (hz : b.Engrave n z) :
    b.Engrave n fun i => cameo (p i) (u i) (v i) (z i) :=
  ((hp.stack hu).stack hv).stack hz

end Bench
end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Slant Slant.Stroke Complex
noncomputable section

universe U V
namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι} {q : Bench m κ}

structure Arch (b : Bench m ι) (e : ι→ℕ) : Prop where
  ep : b.Digit e
  span : b.Digit (fun i => 2^e i)

namespace Arch
lemma transfer {e : κ→ℕ} (h : q.Arch e) {f : ι→κ} (F : b.Feeds q f) :
    b.Arch (fun i => e (f i)) :=
  ⟨draw F h.ep,draw F h.span⟩
variable {e d : ι→ℕ}

lemma fromSmall (h : b.Digit e) (g : Small b.size (fun i => 2^e i)) :
    b.Arch e := ⟨h,h.two g⟩

lemma below (h : b.Arch e) (hh : b.Digit d) (g : ∀ i,d i ≤ e i) :
    b.Arch d :=
  fromSmall hh (h.span.small.mono fun i => Nat.pow_le_pow_right (by omega) (g i))

lemma succ (h : b.Arch e) :
    b.Arch (fun i => e i+1) :=
  ⟨h.ep.add (Digit.wc 1), (h.span.mul (Digit.wc 2)).congr (fun _ => (pow_succ ..).symm)⟩

lemma sub (h : b.Arch e) (g : b.Digit d) :
    b.Arch (fun i => e i-d i) :=
  h.below (h.ep.sub g) fun _ => Nat.sub_le ..
end Arch

section
variable {u : ι→ℂ} {n : ι→ℕ}

lemma powers_fabric (h : b.Hue u) (ha : b.Digit n) :
    b.Fabric n (fun i j => u i ^ j) :=
  (h.transfer (Feeds.scan b n)).exponent (slot ha)

lemma print_fold (hy : b.Hue fun _ => I) (h : b.Hue u)
    (ha : b.Digit n) :
    b.Engrave (fun i => n i+n i) (fun i => foldPair (n i) (u i)) := by
  let F i := initial (n i); let G i := ending (n i)
  have hf : b.Spots F := ⟨Digit.wc 0,ha⟩
  have hg : b.Spots G := ⟨ha,ha⟩
  have hr i := (half_fits (n i)).1
  have hs i := (half_fits (n i)).2
  exact (hf.shade hg Fabric.one (powers_fabric h ha) (ha.add ha) hr hs).stack
    (hf.hinge hg (ha.add ha) hr hs (fun _ => rfl) (fun _ => half_sep _) hy)

lemma print_deal (h : b.Digit n) :
    b.Engrave (fun i => n i+n i) (fun i => Reel.lace (n i+n i) (deal (n i))) := by
  let W i := n i+n i
  have hh := h.add h
  refine Engrave.lace (fun i => deal (n i)) hh ?_ ?_
  · intro i j hj; unfold deal; split <;> omega
  · have hk := slot hh
    have hn := draw (Feeds.scan b W) h
    exact (iteN (Study.lt hk hn) ((Digit.wc 2).mul hk)
      (((Digit.wc 2).mul (hk.sub hn)).add (Digit.wc 1))).run

lemma print_duo (hy : b.Hue fun _ => I) (h : b.Hue u)
    {p : ι→Reel} (g : b.Engrave n p) :
    b.Engrave (fun i => n i+n i) (fun i => duo (n i) (u i) (p i)) :=
  ((print_deal g.width).stack (g.parallel g (fun _ => rfl))).stack
    (print_fold hy h g.width)

end

variable {e : ι→ℕ} {r : ι→ℂ}

private def towerNote (k i : ℕ) (r : ℂ) := r ^ (2^(k-i):ℕ)

private lemma note_change (r : ℂ) (k i : ℕ) (hi : i<k) :
    towerNote k i r = towerNote k (i+1) r ^ 2 := by
  unfold towerNote
  rw [← pow_mul, show k-i=k-(i+1)+1 by omega, pow_succ]

lemma pulse_duration (h : b.Digit e) (r : ι→ℂ) :
    b.Digit (tickCount fun i => pulse (e i) (r i)) :=
  ((Digit.wc 5).mul h).congr (fun _ => (beats_pulse _ _).symm)

lemma print_pulse (hy : b.Hue fun _ => I) (h : b.Arch e) (g : b.Hue r) :
    b.Engrave (fun i => 2^e i) (fun i => pulse (e i) (r i)) := by
  let u i j := towerNote (e i) j (r i)
  let R i (j : ℕ) := pulse j (u i j)
  let Z i (j : ℕ) := film (2^j) (R i j)
  have hf : b.Makes filmTy (fun i => Z i (e i)) := by
    refine loop (t:=filmTy) h.ep Z ?_ ?_
    · have H := (Engrave.rest (b:=b) (Digit.wc 1) (Digit.wc 0)).layers
      exact H.congr (fun i => by simp only [Z,R,pulse,pow_zero])
    · let P := b.climbs e filmTy Z
      have F := Feeds.climbs b e Z -- specify
      have hw : P.Digit During.j := stepi h.ep Z
      have hs : P.Arch During.j := (h.transfer F).below hw (fun i => i.hj.le)
      let d (i : During e) := u i.i (i.j+1)
      have hd : P.Hue d :=
        (g.transfer F).exponent (((h.transfer F).sub (hw.add (Digit.wc 1))).span)
      let p (i : During e) := R i.i i.j
      have ha : P.Engrave (fun i => 2^i.j) p :=
        ⟨fun i => sound_pulse _ _,pulse_duration hw _,hs.span,stepsum (t:=filmTy) b e Z⟩
      -- add one step; equality only on the requested index range
      refine (print_duo (hy.transfer F) hd ha).layers.congr ?_
      intro i
      simp only [Z,R,p,d,pow_succ (2:ℕ),mul_two]
      rw [pulse]
      have hx : u i.i i.j=u i.i (i.j+1)^2 := note_change _ _ _ i.hj
      rw [hx]
  have H : b.Engrave (fun i => 2^e i) (fun i => R i (e i)) :=
    ⟨fun i => sound_pulse _ _,pulse_duration h.ep _,h.span,hf⟩
  refine H.congr (fun _ => rfl) ?_
  intro i; unfold R u towerNote; simp

lemma print_backPulse (hy : b.Hue fun _ => I) (h : b.Arch e)
    (g : b.Hue r) (hg : ∀ i, r i≠0) :
    b.Engrave (fun i => 2^e i) (fun i => backPulse (e i) (r i)) := by
  have hp := print_pulse hy h (g.inv hg)
  have hh := (Hue.casting h.span).inv (by intro i; exact Nat.cast_ne_zero.mpr (by positivity))
  exact hp.stack (Engrave.swatch h.span _ (Fabric.flat hh))

end Bench
end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Slant Slant.Stroke Spectral Complex
noncomputable section

universe U
namespace Bench
variable {m : Bool} {ι : Type U} {b : Bench m ι}

lemma Fabric.frequency {u : ι→Line} {n : ι→ℕ} {r : ι→ℂ}
    (h : b.Fabric n u) (g : b.Digit n) (k : b.Hue r) {a} (hk : b.Digit a) :
    b.Hue (fun i => freq (n i) (r i) (u i) (a i)) := by
  have F := Feeds.scan b n
  exact Hue.sum g (fun i j => r i ^ (a i * j) * u i j)
    (((k.transfer F).exponent ((draw F hk).mul (slot g))).mul h)

lemma Fabric.spectrum {u : ι→Line} {n : ι→ℕ} {r : ι→ℂ}
    (h : b.Fabric n u) (g : b.Digit n) (k : b.Hue r) :
    b.Fabric n (fun i => freq (n i) (r i) (u i)) := by
  have F := Feeds.scan b n
  exact (h.transfer F).frequency (draw F g) (k.transfer F) (slot g)

section
variable {u a c : ι→Zone} {n : ι→ℕ} (hv : b.Hue fun _ => I) (hk : b.Digit n)

include hv hk

lemma Spots.trail (h : b.Spots u) (g : b.Spots a) (hg : ∀ i,(u i).wide ≤ (a i).wide)
    (p : ∀ i,(u i).Fits (n i)) (s : ∀ i,(a i).Fits (n i)) (j : ∀ i,(u i).Sep (a i))
    {x : ι→ℂ} (hp : b.Hue x) :
    b.Engrave n (fun i => Slant.trail (u i) (a i) (x i)) :=
  (g.slim h.wide).flash h hk (fun i => (s i).slim (hg i)) p (fun _ => rfl)
    (fun i => ((j i).slim_right (hg i)).symm) hv (Fabric.flat hp)

lemma Spots.slice (h : b.Spots u) (g : b.Spots a) (hg : ∀ i,(u i).wide ≤ (a i).wide)
    (p : ∀ i,(u i).Fits (n i)) (s : ∀ i,(a i).Fits (n i)) (j : ∀ i,(u i).Sep (a i))
    {x : ι→ℂ} (hp : b.Hue x) :
    b.Engrave n (fun i => Slant.slice (a i) (u i) (x i)) :=
  h.flash (g.slim h.wide) hk p (fun i => (s i).slim (hg i)) (fun _ => rfl)
    (fun i => (j i).slim_right (hg i)) hv (Fabric.flat hp)

variable {e : ι→ℕ} {r : ι→ℂ} (ha : b.Spots a) (hc : b.Spots c)
    (he : b.Arch e) (hr : b.Hue r) (hz : ∀ i,r i≠0)
    (ua : ∀ i,(a i).wide=2^e i) (uc : ∀ i,(c i).wide=2^e i)
    (pa : ∀ i,(a i).Fits (n i)) (pc : ∀ i,(c i).Fits (n i)) (ac : ∀ i,(a i).Sep (c i))

include ha hc he hr hz ua uc pa pc ac

lemma Spots.eddy {f : ι→Line} (h : b.Fabric (fun i => 2^e i) f) :
    b.Engrave n (fun i => Slant.eddy (e i) (r i) (a i) (c i) (f i)) := by
  let T i := 2^e i
  have H (v : ι→Zone) (hh : b.Spots v) (tv : ∀ i,(v i).wide=T i)
      (pv : ∀ i,(v i).Fits (n i)) {x : ι→Reel} (p : b.Engrave T x) :
      b.Engrave n (fun i => Reel.atBase (v i).lo (x i)) :=
    (p.mount hh.low).wider hk fun i => by
      rw [← tv]
      exact (pv i).end_le (by rw [tv]; unfold T; positivity)
  have fp := print_pulse hv he hr
  have bp := print_backPulse hv he hr hz
  have fg := h.spectrum he.span hr
  have fg' : b.Fabric (fun i => (c i).wide) (fun i => freq (2^e i) (r i) (f i)) := by
    simp_rw [uc]
    exact fg
  have w := hc.flash ha hk pc pa (fun i => (uc i).trans (ua i).symm)
    (fun i => (ac i).symm) hv fg'
  exact ((((H a ha ua pa fp).stack (H c hc uc pc fp)).stack w).stack
    (H a ha ua pa bp)).stack (H c hc uc pc bp)

variable (hu : b.Spots u) (hg : ∀ i,(u i).wide ≤ (a i).wide)
  (pu : ∀ i,(u i).Fits (n i)) (hup : ∀ i,(u i).Sep (a i))
include hu hg pu hup
lemma Spots.duct {f : ι→Line} (h : b.Fabric (fun i => 2^e i) f) :
    b.Engrave n (fun i => Slant.duct (e i) (r i) (u i) (a i) (c i) (f i)) := by
  exact engrave_cameo (hu.trail hv hk ha hg pu pa hup Hue.one)
    (ha.eddy hv hk hc he hr hz ua uc pa pc ac h)
    (hu.trail hv hk ha hg pu pa hup Hue.one.neg)
    (ha.eddy hv hk hc he hr hz ua uc pa pc ac h.neg)

lemma Spots.well {v : ι→Zone} (hh : b.Spots v) (hy : ∀ i,(v i).wide ≤ (c i).wide)
    (pv : ∀ i,(v i).Fits (n i)) (hp : ∀ i,(v i).Sep (c i)) {f : ι→Line}
    (h : b.Fabric (fun i => 2^e i) f) :
    b.Engrave n (fun i => Slant.well (e i) (r i) (u i) (v i) (a i) (c i) (f i)) :=
  engrave_cameo (ha.duct hv hk hc he hr hz ua uc pa pc ac hu hg pu hup h)
    (hh.slice hv hk hc hy pv pc hp Hue.one)
    (ha.duct hv hk hc he hr hz ua uc pa pc ac hu hg pu hup h.neg)
    (hh.slice hv hk hc hy pv pc hp Hue.one.neg)

end

lemma Fabric.riseEntry {f : ι→Line} {n p q : ι→ℕ}
    (h : b.Fabric n f) (a : b.Digit p) (c : b.Digit q) (hk : ∀ i, p i<n i) :
    b.Hue (fun i => rise (f i) (p i) (q i)) := by
  have H := h.pick (a.sub c).run (fun i => (Nat.sub_le ..).trans_lt (hk i))
  exact Hue.fork (Study.le c a) (H.transfer (restricted ..)) Hue.zero

lemma Fabric.skirtEntry {B u v l e n j : ι→ℕ} {f : ι→Line} (h : b.Digit B)
    (a : b.Digit u) (c : b.Digit v) (d : b.Digit l) (g : b.Digit e)
    (hz : b.Fabric n f)
    (hk : ∀ i, ∀ j<v i, e i+j<n i) (hh : b.Digit j) :
    b.Hue (fun i => skirt (B i) (u i) (v i) (l i) (e i) (f i) (j i)) := by
  let f1 (i : ι) : ℂ := if j i < v i then rise (f i) (e i+j i) (l i) else 0
  have H1 : b.Hue f1 := by
    let P (i : ι) := j i<v i
    have F := restricted b P
    exact Hue.fork (Study.lt hh c) ((hz.transfer F).riseEntry (draw F (g.add hh))
      (draw F d) (fun i => hk _ _ i.property)) Hue.zero
  let w i := 2*B i-j i
  let f2 (i : ι) : ℂ := if 0<v i ∧ w i<u i then rise (f i) (e i) (l i+w i) else 0
  have H2 : b.Hue f2 := by
    let P (i : ι) := 0<v i ∧ w i<u i
    have F := restricted b P
    have hw : b.Digit w := ((Digit.wc 2).mul h).sub hh
    have hp : b.Study P := (Study.lt (Digit.wc 0) c).both (Study.lt hw a)
    exact Hue.fork hp ((hz.transfer F).riseEntry (draw F g)
      (draw F (d.add hw)) (fun i => by simpa only [add_zero] using hk _ 0 i.property.1)) Hue.zero
  exact Hue.fork (Study.lt hh h) (f:=f1) (g:=f2) (H1.transfer (restricted ..))
    (H2.transfer (restricted ..))

lemma Spots.bore {k n : ι→ℕ} {r : ι→ℂ} (hd : b.Arch k) (hr : b.Hue r)
    (hz : ∀ i,r i≠0) (hn : b.Digit n) (hi : b.Hue fun _ => I)
    {u v a c : ι→Zone} (hu : b.Spots u) (hv : b.Spots v) (ha : b.Spots a) (hc : b.Spots c)
    (ua : ∀ i,(a i).wide=2^(k i+1)) (uc : ∀ i,(c i).wide=2^(k i+1))
    (pu : ∀ i,(u i).Fits (n i)) (pv : ∀ i,(v i).Fits (n i))
    (pa : ∀ i,(a i).Fits (n i)) (pc : ∀ i,(c i).Fits (n i))
    (ac : ∀ i,(a i).Sep (c i))
    (hg : ∀ i,(u i).wide ≤ 2^k i) (hh : ∀ i,(v i).wide ≤ 2^k i)
    (hup : ∀ i,(u i).Sep (a i)) (hvc : ∀ i,(v i).Sep (c i)) {l s e : ι→ℕ}
    (hl : b.Digit l) (hs : b.Digit s)
    {f : ι→Line} (h : b.Fabric e f) (hS : ∀ i, ∀ j<(v i).wide, s i+j<e i) :
    b.Engrave n (fun i => Slant.bore (k i) (r i) (u i) (v i) (a i) (c i)
      (l i) (s i) (f i)) := by
  unfold Slant.bore
  refine ha.well hi hn hc hd.succ hr hz ua uc pa pc ac hu
    (fun i => by rw [ua,pow_succ]; have := hg i; omega) pu hup hv
    (fun i => by rw [uc,pow_succ]; have := hh i; omega) pv hvc ?_
  have F := Feeds.scan b fun i => 2^(k i+1)
  exact (h.transfer F).skirtEntry (draw F hd.span) (draw F hu.wide)
    (draw F hv.wide) (draw F hl) (draw F hs) (fun i => hS i.i) (slot hd.succ.span)

end Bench
end
end PowerSaving.RAM

end OAI

namespace OAI
namespace PowerSaving.Grove
open Slant Shard Hem Binary Finset Matrix
noncomputable section

def fleck (i j : ℕ) : ℂ := if i=j then ca else cb
def prism : ℕ → Wood
  | 0 => fun _ _ => 1
  | k+1 => fun i j => prism k (i/2) (j/2) * fleck (i%2) (j%2)
def gleam (k : ℕ) (x : Line) : Line := graft (2^k) (prism k) x

lemma bits_next (k : ℕ) (x : Bits (k+1)) :
    (bits (k+1)).loc x = (bits k).loc (fun i => x i.succ)*2+(x 0).val := by
  rw [bits_loc,bits_loc,Fin.sum_univ_succ]
  simp [pow_succ,sum_mul,mul_assoc,Nat.add_comm]

lemma prism_loc (k : ℕ) (x y : Bits k) :
    prism k ((bits k).loc x) ((bits k).loc y) = kernel (Fin k) x y := by
  induction k with
  | zero => simp [prism,kernel]
  | succ k ih =>
    simp only [prism,bits_next]
    have hx : (x 0).val < 2 := (x 0).isLt
    have hy : (y 0).val < 2 := (y 0).isLt
    rw [chops _ _ 2 hx,chips _ _ 2 hx,chops _ _ 2 hy,chips _ _ 2 hy,ih]
    simp only [kernel,digitProd_apply,Fin.prod_univ_succ]
    have h (i j : F) : fleck i.val j.val=littleC i j := by
      have hone : (1:F).val=1 := rfl
      rcases bit_cases i with rfl|rfl <;> rcases bit_cases j with rfl|rfl <;> simp [littleC,fleck,hone]
    rw [h]; ring

lemma sum_bits_addr (k : ℕ) (f : Line) :
    ∑ i ∈ range (2^k), f i = ∑ x : Bits k, f ((bits k).loc x) := by
  rw [← Fin.sum_univ_eq_sum_range f (2^k)]
  exact (Equiv.sum_comp (bits k).index (fun i => f i.val)).symm

lemma gleam_loc (k : ℕ) (v : Line) (x : Bits k) :
    gleam k v ((bits k).loc x) =
    ripple k (fun j => v ((bits k).loc j)) x := by
  unfold gleam graft; rw [sum_bits_addr]
  simp_rw [prism_loc k]
  rfl

def gleans (f g : Shard) : ℂ :=
  if f.start=g.start then prism f.height f.seat g.seat else 0

lemma leaf_gleans {n : ℕ} {u : Stroke} (h : u.Sound n) (i j : ℕ) (hi : i<n) (hj : j<n) :
    leafC u i j=gleans (hem u i) (hem u j) := by
  let s := hem u
  change _=gleans (s i) (s j)
  by_cases g : (s i).start=(s j).start
  · rw [gleans,ite_eq_left g]
    have hh := crown_class h (class_of_start h hi hj g)
    by_cases H : u.partner i=i
    · have e : j=i := hh.elim id (·.trans H); subst j
      have hu : (s i).height=0 := by simp [s,hem,up,H]
      rw [hu]
      simp [leafC,H,prism,white]
    · have hu : (s i).height=1 := by simp [s,hem,up,Ne.symm H]
      have ht (i : ℕ) : (s i).seat < 2 := by
        change tier u i<2; unfold tier; split <;> omega
      rw [hu]
      simp only [leafC,H,↓reduceIte,prism,Nat.mod_eq_of_lt (ht _),one_mul]
      rcases hh with e|e
      · subst j; simp [fleck, Ne.symm H]
      · subst j
        have HG : (s i).seat ≠ (s (u.partner i)).seat := Ne.symm (tier_partner_ne h H)
        simp [fleck, H, HG]
  · rw [gleans,ite_eq_right g]
    have G : j ≠ i := fun k => g (by rw [k])
    have H : j ≠ u.partner i := fun k => g (by
      rw [k]; exact (same_class h (crown_partner h).symm).1)
    unfold leafC white; split <;> simp

lemma prism_fringe {n l m : ℕ} {u x v y : Shard}
    (_hl : u.Mark n l) (_hl' : v.Mark n l) (hn : x.Mark m 1) (hn' : y.Mark m 1)
    (hs : x.same y) :
    prism (fringe m u x).height (fringe m u x).seat (fringe m v y).seat =
    prism u.height u.seat v.seat * prism x.height x.seat y.seat := by
  have hh := hn.tall
  have h := hn.size
  have k := hn.place; have k' := hn'.place
  have hxy := hs.2.1
  change prism (u.height+x.height) (u.seat*x.width+x.seat) (v.seat*y.width+y.seat)=_
  rcases Nat.eq_zero_or_pos x.height with g|g
  · rw [g] at h ⊢
    have ht : x.width=1 := h
    have ht' : y.width=1 := hxy ▸ ht
    have hx : x.seat=0 := by omega
    have hy : y.seat=0 := by omega
    simp [ht,ht',hx,hy,prism]
  · have hg : x.height=1 := by omega
    rw [hg] at h ⊢
    have ht : x.width=2 := h
    have ht' : y.width=2 := hxy ▸ ht
    rw [ht,ht']; rw [ht] at k; rw [ht'] at k'
    simp only [prism,chops _ _ _ k,chops _ _ _ k',chips _ _ _ k,chips _ _ _ k',
      Nat.mod_eq_of_lt k,Nat.mod_eq_of_lt k',one_mul]

lemma gleans_fringe (m n l : ℕ) {f g : ℕ → Shard} (h : Quilt n l f)
    (k : Quilt m 1 g) (i j a b : ℕ) (hi : i<n) (hj : j<n) (ha : a < m) (hb : b < m) :
    gleans (fringe m (f i) (g a)) (fringe m (f j) (g b)) =
    gleans (f i) (f j) * gleans (g a) (g b) := by
  let u := fringe m (f i) (g a)
  let v := fringe m (f j) (g b)
  have h1 : u.Mark (n*m) (l+1) := (h.mark i hi).fringe (k.mark a ha)
  have h2 : v.Mark (n*m) (l+1) := (h.mark j hj).fringe (k.mark b hb)
  have iffStart : u.start=v.start ↔
      (f i).start=(f j).start ∧ (g a).start=(g b).start := by
    constructor
    · intro H
      have hu := fr_unique _ _ (k.mark a ha) (k.mark b hb) (h.mark i hi) (h.mark j hj)
        (h.seam i hi j hj) (k.seam a ha b hb)
        (show u.start < v.tip from H ▸ h2.starts)
        (show v.start < u.tip from H.symm ▸ h1.starts)
      exact ⟨hu.1.1,hu.2.1⟩
    · rintro ⟨A,B⟩
      exact (fr_same m (h.matches_of_eq hi hj A) (k.matches_of_eq ha hb B)).1
  change gleans u v=_
  simp only [gleans]
  simp only [iffStart]
  by_cases H : (g a).start=(g b).start
  · have g' := k.matches_of_eq ha hb H
    by_cases G : (f i).start=(f j).start
    · simp only [G,H,true_and,↓reduceIte]
      exact prism_fringe (h.mark i hi) (h.mark j hj) (k.mark a ha) (k.mark b hb) g'
    · simp [H,G]
  · simp [H]

lemma canopy_gleans (r : Axes) (l : ℕ) (u : ℕ→Stroke)
    (h : Splits r l) (g : ∀ i<l, (u i).Sound (r i)) :
    ∀ i<extent r l, ∀ j<extent r l,
    canopy r (fun i => leafC (u i)) l i j =
    gleans (mosaic r u l i) (mosaic r u l j) := by
  induction l with
  | zero => intros; simp [mosaic,gleans,canopy,prism,seed]
  | succ l ih =>
    intro i hi j hj
    simp only [canopy,mosaic,Shard.attach]
    have hl := h.cut (j:=l) (by omega)
    have hh (t : ℕ) (ht : t<l) := g t (lt_trans ht (by omega : l<l+1))
    have g' := g l (by omega)
    rw [ih hl hh _ (h.div_lt hi) _ (h.div_lt hj),
      leaf_gleans g' _ _ (h.mod_lt i) (h.mod_lt j),
      gleans_fringe _ _ l (mosaic_quilt _ _ _ hl hh) (Hem.quilt g') _ _ _ _
        (h.div_lt hi) (h.div_lt hj) (h.mod_lt i) (h.mod_lt j)]

-- operation in packed addresses
def stow (n : ℕ) (f : ℕ → Shard) (x : Line) : Line :=
  fun j => x (seek n (fun i => (f i).addr) j)

def slit (n : ℕ) (f : ℕ → Shard) (x : Line) (s : ℕ) : Line :=
  fun j => stow n f x (s+j)

def glimpse (n : ℕ) (f : ℕ → Shard) (x : Line) (j : ℕ) : Line :=
  gleam (patch n f j).height (slit n f x j)

lemma sum_zone {A : Type*} [AddCommMonoid A] (n i m : ℕ) (h : i+m≤n) (f : ℕ→A)
    (g : ∀ j<n, f j ≠ 0 → i≤j ∧ j < i+m) :
    ∑ j ∈ range n, f j = ∑ j ∈ range m, f (i+j) := by
  classical
  have h1 : ∑ j ∈ range (i+m), f j = ∑ j ∈ range n, f j :=
    sum_subset (range_mono h)
      (fun j hj hi => Classical.byContradiction fun H =>
        hi (mem_range.mpr (g j (mem_range.mp hj) H).2))
  have h2 : ∑ j ∈ range i, f j = 0 :=
    sum_eq_zero fun j hj => Classical.byContradiction fun H => by
      have hh := mem_range.mp hj
      have ht := (g j (by omega) H).1
      omega
  rw [← h1,sum_range_add,h2,zero_add]

lemma graft_glimpse (r : Axes) (l : ℕ) (u : ℕ→Stroke)
    (h : Splits r l) (g : ∀ i<l, (u i).Sound (r i)) (x : Line)
    (i : ℕ) (hi : i<extent r l) :
    let f := mosaic r u l
    graft (extent r l) (canopy r (fun i => leafC (u i)) l) x i =
    glimpse (extent r l) f x (f i).start (f i).seat := by
  intro f
  let n := extent r l
  let s := f i
  have hh := mosaic_quilt r l u h g
  have hH : Quilt n l f := hh
  have hs : s.Mark n l := hH.mark i hi
  let pay (j : ℕ) := gleans s (patch n f j)*stow n f x j
  have he :
      graft n (canopy r (fun i => leafC (u i)) l) x i = ∑ j ∈ range n, pay j := by
    rw [← hH.reloc.sum]
    refine sum_congr rfl ?_
    intro j hj
    have hj := mem_range.mp hj
    rw [canopy_gleans _ _ _ h g _ hi _ hj]
    simp only [pay,f,s,stow] -- want f folded
    change _=gleans s (patch n f (f j).addr)*x (seek n (fun j => (f j).addr) (f j).addr)
    rw [hH.patch_at hj, hH.reloc.seeks_at hj]
  have sx (j : ℕ) (hj : j<s.width) :
      (patch n f (s.start+j)).same s ∧ (patch n f (s.start+j)).seat=j :=
    let H := hH.patch_align hi (Nat.le_add_right (s.start) j) (Nat.add_lt_add_left hj s.start)
    ⟨H.1,H.2.trans (Nat.add_sub_cancel_left ..)⟩
  have sz := sx 0 hs.positive
  rw [Nat.add_zero] at sz
  have ht (j : ℕ) (hj : j<n) (gp : pay j ≠ 0) :
      s.start ≤ j ∧ j<s.start+s.width := by
    let H := hH.patch_seam (i:=(f i).addr) (j:=j) (hH.reloc.bd i hi) hj
    have J : s.fits (patch n f j) := by simpa only [hH.patch_at hi] using H
    let p := patch n f j
    have hg : s.start=p.start := by
      by_contra hx
      have : pay j = 0 := by change gleans s p*_=0; simp [gleans,hx]
      exact gp this
    have hp : p.Mark n l := hH.patch_mark hj
    have hp' : p.addr=j := hH.patch_addr hj
    rcases J with T|T|T
    · have H := T.2.1
      have h3 := hp.place
      rw [← hp',hg]; unfold addr
      change s.width=p.width at H
      omega
    · have hf : s.tip ≤ p.start := T
      have := hs.starts; omega
    · have hf : p.tip ≤ s.start := T
      have := hp.starts; omega
  change graft n _ _ _ = glimpse n f x s.start s.seat
  rw [he,sum_zone n s.start s.width hs.endsBy pay ht,glimpse,gleam,graft,sz.1.2.2,← hs.size]
  refine sum_congr rfl ?_
  intro j hj
  have hj := mem_range.mp hj
  have H := sx j hj
  change gleans s (patch n f (s.start+j))*_ =_
  rw [gleans,ite_eq_left H.1.1.symm,H.2]; rfl

-- sector start width sums (need cost bound on packed call).
def seatfare (n : ℕ) (f : ℕ→Shard) (j : ℕ) :=
  if (patch n f j).seat=0 then (patch n f j).width else 0

lemma fare_sum (n l : ℕ) (f : ℕ → Shard) (h : Quilt n l f) :
    ∑ j ∈ range n, seatfare n f j = n := by
  let p := patch n f
  let cnt (i : ℕ) := ∑ j ∈ range n, if (p j).start=i then 1 else 0
  have hh (i : ℕ) (hi : i<n) : cnt i=seatfare n f i := by
    let s := p i
    let q := seek n (fun i => (f i).addr)
    have hq : ∀ i<n, q i<n := fun i hi => (h.reloc.seeks hi).1
    have hs : s.Mark n l := h.patch_mark hi
    have hS : s.addr=i := h.patch_addr hi
    change cnt _ = if s.seat=0 then s.width else 0
    unfold cnt; split
    · rename_i H
      have hg : s.start=i := by unfold addr at hS; omega
      rw [sum_zone n i s.width]
      · have he (j : ℕ) (hj : j ∈ range s.width) :
            (if (p (i+j)).start=i then 1 else 0)=1 := by
          have ht : i+j<s.tip := by rw [← hg]; exact Nat.add_lt_add_left (mem_range.mp hj) _
          have hu := h.patch_align (hq i hi)
            (show s.start ≤ i+j from by omega) ht
          exact ite_eq_left (hu.1.1.trans hg)
        rw [sum_congr rfl he]
        simp
      · rw [← hg]; exact hs.endsBy
      · intro j hj hj'
        have he : (p j).start=i := by split at hj' <;> first | assumption | omega
        have hx := h.patch_addr hj
        change (p j).addr=j at hx
        have hy := h.patch_mark hj
        have hu : (p j).same s :=
          h.matches_of_eq (hq j hj) (hq i hi) (he.trans hg.symm)
        have hw := hu.2.1
        have hc : (p j).seat < (p j).width := hy.place
        unfold addr at hx; omega
    · rename_i H
      refine sum_eq_zero ?_
      intro j hj
      have hj := mem_range.mp hj
      refine ite_eq_right ?_
      intro hG
      have ht : i < (p j).tip := hG ▸ (h.patch_mark hj).starts
      have hu := h.patch_align (hq j hj)
        (show (p j).start ≤ i from hG.le) ht
      apply H
      change (patch n f i).seat=0
      rw [hu.2]
      change i-(p j).start=0; omega
  rw [show (∑ j ∈ range n, seatfare n f j)=∑ j ∈ range n, cnt j from
    sum_congr rfl fun i hi => (hh i (mem_range.mp hi)).symm]
  unfold cnt; rw [sum_comm]
  have HG (j : ℕ) (hj : j ∈ range n) :
      (∑ i ∈ range n, if (p j).start=i then 1 else 0) = 1 := by
    have h' := h.patch_mark (mem_range.mp hj)
    have hm : (p j).start<n := h'.starts.trans_le h'.endsBy
    simp [hm]
  rw [sum_congr rfl HG]
  simp

end
end PowerSaving.Grove

end OAI

namespace OAI

namespace PowerSaving.RAM
open Ty Finset
open Grove Shard Slant Hem
noncomputable section

abbrev chipTy := p w (p w (p w w)) -- start width height seat
abbrev sapTy := p w sc -- lookup and dye
abbrev blossomTy := p sapTy chipTy
abbrev leafTy := a blossomTy
abbrev treeTy := a leafTy

def chip (s : Shard) : T chipTy := (s.start,s.width,s.height,s.seat)

def blossom (u : Stroke) (i : ℕ) : T blossomTy :=
  ((u.ix i,u.dye i),chip (hem u i))

def leavesT (n : ℕ) (u : Stroke) : T leafTy := Tape.tab n (blossom u)
def treeT (n : ℕ) (u : Reel) : T treeTy := Tape.tab u.beats fun i => leavesT n (u.atBeat i)

universe U V
namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι} {q : Bench m κ}

variable {s : ι → Stroke} {n x : ι→ℕ}
namespace Band

lemma partD (h : b.Band n s) (hx : b.Digit x) (hi : ∀ i, x i<n i) :
    b.Digit fun i => (s i).partner (x i) :=
  ⟨(h.showOne hx.run hi).snd.snd,h.width.small.mono fun i => ((h.good i).bdp _ (hi i)).le⟩

lemma crownD (h : b.Band n s) (hx : b.Digit x) (hi : ∀ i, x i<n i) :
    b.Digit fun i => crown (s i) (x i) :=
  hx.minimum (h.partD hx hi)

-- if exact operations
lemma trial (hx : b.Digit n) (hy : b.Digit x) {y z : ι→ℕ} (h : b.Digit y) (g : b.Digit z) :
    b.Digit (fun i => if n i=x i then y i else z i) := by
  let P i := n i=x i
  have hh : b.Study P := Study.eq hx hy
  exact branchN hh (draw (restricted b P) h) (draw (restricted b (fun i => ¬ P i)) g)

lemma thickD (h : b.Band n s) (hx : b.Digit x) (hi : ∀ i, x i<n i) :
    b.Digit fun i => thickness (s i) (x i) :=
  trial hx (h.partD hx hi) (Digit.wc 1) (Digit.wc 2)

lemma trimD (h : b.Band n s) (hx : b.Digit x) (hi : ∀ i, x i<n i) :
    b.Digit fun i => trim (s i) (x i) :=
  trial hx (h.crownD hx hi) (h.thickD hx hi) (Digit.wc 0)

lemma sumsD (h : b.Band n s) (hx : b.Digit x) (hi : ∀ i, x i<n i) :
    b.Digit fun i => sums (s i) (x i) := by
  let S i j := sums (s i) j
  let B := b.climbs x w S
  have sm (i : ι) (j : ℕ) (hj : j≤n i) : S i j≤n i :=
    (sums_mono _ hj).trans (sum_trim (h.good i)).le
  have H : B.Digit fun i => S i.i i.j :=
    ⟨stepsum b x (t:=w) S,(h.width.small.reindex During.i).mono
      fun i => sm _ _ (i.hj.trans (hi _)).le⟩
  have F := Feeds.climbs b x (t:=w) S
  have K := (h.transfer F).trimD (stepi (t:=w) hx S) (fun i => i.hj.trans (hi _))
  refine ⟨loop (t:=w) hx S ((Makes.wc 0).congr fun i => by simp [S,sums]) ((H.add K).congr ?_).run,
    h.width.small.mono fun i => sm _ _ (hi _).le⟩
  intro i; simp [S,sums,sum_range_succ]

lemma blossomD (h : b.Band n s) (hx : b.Digit x) (hi : ∀ i, x i<n i) :
    b.Makes blossomTy fun i => blossom (s i) (x i) := by
  have hc := h.crownD hx hi
  have ht : ∀ i, crown (s i) (x i)<n i :=
    fun i => Nat.lt_of_le_of_lt (min_le_left ..) (hi i)
  have hu := trial hx (h.partD hx hi) (Digit.wc 0) (Digit.wc 1)
  have hk := trial hx hc (Digit.wc 0) (Digit.wc 1)
  have hg := (h.sumsD hc ht).run.pair ((h.thickD hx hi).run.pair (hu.run.pair hk.run))
  have hh := h.showOne hx.run hi
  exact (hh.fst.pair hh.snd.fst).pair hg

lemma leavesD (h : b.Band n s) : b.Makes leafTy fun i => leavesT (n i) (s i) :=
  tab (t:=blossomTy) h.width _
    ((h.transfer (Feeds.scan b _)).blossomD (slot h.width) During.hj)

end Band

lemma Engrave.tree {u : ι → Reel} (h : b.Engrave n u) :
    b.Makes treeTy fun i => treeT (n i) (u i) :=
  tab (t:=leafTy) h.count _
    (((h.transfer (Feeds.scan b _)).plate _ (slot h.count).run During.hj).leavesD)

-- use in array work
structure Spring (b : Bench m ι) (n : ι→ℕ) (s : ι→Stroke) : Prop where
  good : ∀ i, (s i).Sound (n i)
  tree : b.Moves (fun _ => 0) leafTy fun i => leavesT (n i) (s i)

namespace Spring

lemma transfer {n : κ→ℕ} {s : κ→Stroke} (h : q.Spring n s) {f} (g : b.Instant q f) :
    b.Spring (fun i => n (f i)) (fun i => s (f i)) :=
  ⟨fun _ => h.good _,h.tree.transfer g⟩

lemma read (h : b.Spring n s) (hx : b.Nick x) (hi : ∀ i, x i < n i) :
    b.Moves (fun _ => 0) blossomTy fun i => blossom (s i) (x i) :=
  Moves.pick (n:=n) (t:=blossomTy) _ h.tree hx.close hi
end Spring

structure Bough (b : Bench m ι) (l : ι→ℕ) (r : ι→Axes) (u : ι→ℕ→Stroke) : Prop where
  fen : b.Fen l r
  leaf : (b.scan l).Spring (fun i => r i.i i.j) (fun i => u i.i i.j)

namespace Bough
variable {l : ι→ℕ} {r : ι→Axes} {u : ι→ℕ→Stroke}

lemma good (h : b.Bough l r u) (i : ι) (j : ℕ) (hj : j<l i) :
    (u i j).Sound (r i j) :=
  h.leaf.good ⟨i,j,hj⟩

lemma transfer {l : κ→ℕ} {r : κ→Axes} {u : κ→ℕ→Stroke} (h : q.Bough l r u) {f}
    (g : b.Instant q f) :
    b.Bough (fun i => l (f i)) (fun i => r (f i)) (fun i => u (f i)) := by
  let L i := l (f i)
  have F := Instant.scan b L
  let p : During L→During l := fun i => ⟨f i.i,i.j,i.hj⟩
  have H := h.fen.transfer g
  have G : (b.scan L).Instant (q.scan l) p :=
    Instant.select (F.next g) (chop H.high).close
  exact ⟨H,h.leaf.transfer G⟩
end Bough
end Bench
end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Grove
noncomputable section

universe U V

namespace Bench
open Forks Slant Shard
variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι} {q : Bench m κ}
  {n : ι→ℕ} {Y : ι→Shard}

-- all chip fields within budget
structure Kit (b : Bench m ι) (Y : ι→Shard) : Prop where
  starts : b.Nick fun i => (Y i).start
  widths : b.Nick fun i => (Y i).width
  tall : b.Nick fun i => (Y i).height
  seat : b.Nick fun i => (Y i).seat

namespace Kit

lemma lend (h : b.Kit Y) : b.Moves (fun _ => 0) chipTy fun i => chip (Y i) :=
  h.starts.close.pair (h.widths.close.pair (h.tall.close.pair h.seat.close))

lemma addr (h : b.Kit Y) : b.Nick fun i => (Y i).addr := h.starts.add h.seat

lemma grab {l : ι→ℕ} (h : Small b.size n) (hh : ∀ i,(Y i).Mark (n i) (l i))
    (hg : b.Moves (fun _ => 0) chipTy fun i => chip (Y i)) : b.Kit Y := by
  have H (i : ι) := (hh i).endsBy
  have hx (i : ι) : (Y i).width ≤ n i :=
    le_trans (Nat.le_add_left (Y i).width (Y i).start) (H i)
  have hb (i : ι) : (Y i).height < (Y i).width := (hh i).size.symm ▸ Nat.lt_two_pow_self
  exact ⟨⟨hg.fst,h.mono fun i => ((hh i).starts.le.trans (H i))⟩,
    ⟨hg.snd.fst,h.mono hx⟩,
    ⟨hg.snd.snd.fst,h.mono fun i => (hb i).le.trans (hx i)⟩,
    ⟨hg.snd.snd.snd,h.mono fun i => (hh i).place.le.trans (hx i)⟩⟩

lemma roll {Z : ι→Shard} (h : b.Kit Y) (g : b.Kit Z) (hh : b.Nick n) :
    b.Kit fun i => fringe (n i) (Y i) (Z i) :=
  ⟨(h.starts.mul hh).add (h.widths.mul g.starts), h.widths.mul g.widths,
    h.tall.add g.tall,(h.seat.mul g.widths).add g.seat⟩

lemma seedKit (b : Bench m ι) : b.Kit fun _ => seed :=
  ⟨Nick.wc _, Nick.wc _, Nick.wc _, Nick.wc _⟩
end Kit

variable {l : ι→ℕ} {r : ι→Axes} {u : ι → ℕ → Stroke}
namespace Bough

theorem prospect (h : b.Bough l r u) :
    b.Moves (fun i => extent (r i) (l i)) (a sapTy) fun i =>
      Tape.tab (extent (r i) (l i)) (survey (r i) (u i) (l i)) := by
  let S i := survey (r i) (u i)
  have hF := h.fen
  refine hF.visit (s:=sapTy) S ((Moves.wc 0).pair Moves.one) ?_
  let D := Fen.stalk b l r sapTy S
  have F := Fen.stalkFeeds b l r sapTy S
  have hH := hF.stalkReads (s:=sapTy) S
  let g := h.leaf.transfer F
  have hk := g.read hH.2.1 hF.lower
  have ha : D.Nick fun i => (S i.i.i i.i.j (tUp i)).1 := by
    refine ⟨hH.2.2.fst,(hF.midst.reindex During.i).mono ?_⟩
    intro i
    have hm := hF.shrunk i.i
    exact (survey_lt _ _ _ (hm.cut (by omega))
      (fun j hj => h.good i.i.i j (hj.trans i.i.hj)) _ (hF.smaller i)).le
  have hR := hF.part.transfer F
  have hc : D.Nick fun i => (u i.i.i i.i.j).ix (tOff i) :=
    ⟨hk.fst.fst,hR.small.mono fun i => ((g.good i).bdix _ (hF.lower i)).le⟩
  exact ((ha.mul hR).add hc).close.pair (hH.2.2.snd.mul hk.fst.snd)

theorem bedding (h : b.Bough l r u) :
    b.Moves (fun i => extent (r i) (l i)) (a chipTy) fun i =>
      Tape.tab (extent (r i) (l i)) fun j => chip (mosaic (r i) (u i) (l i) j) := by
  let S i j k := chip (mosaic (r i) (u i) j k)
  have hF := h.fen
  refine hF.visit (s:=chipTy) S (Kit.seedKit b).lend ?_
  let D := Fen.stalk b l r chipTy S
  have F := Fen.stalkFeeds b l r chipTy S
  have hH := hF.stalkReads (s:=chipTy) S
  let g := h.leaf.transfer F
  have hk := g.read hH.2.1 hF.lower
  have hR := hF.part.transfer F
  have hY : D.Kit (fun i => Hem.hem (u i.i.i i.i.j) (tOff i)) :=
    Kit.grab hR.small (fun i => Hem.marked (g.good i) (hF.lower i)) hk.snd
  have hX : D.Kit fun i => mosaic (r i.i.i) (u i.i.i) i.i.j (tUp i) := by
    refine Kit.grab (l:=fun i => i.i.j) (hF.midst.reindex During.i) ?_ hH.2.2
    intro d
    exact (mosaic_quilt _ _ _ ((hF.shrunk _).cut (by omega))
      (fun j hj => h.good d.i.i j (hj.trans d.i.hj))).mark _ (hF.smaller d)
  exact (hX.roll hY hR).lend

theorem glean (h : b.Bough l r u) (cl : Paint) (x : ι → Line)
    (hx : b.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab (extent (r i) (l i)) (x i)) :
    b.Moves (fun i => extent (r i) (l i)) (a (c cl)) fun i =>
      Tape.tab (extent (r i) (l i)) (graft (extent (r i) (l i))
        (canopy (r i) (fun j => leafM (u i j)) (l i)) (x i)) := by
  let n i := extent (r i) (l i)
  let S i := survey (r i) (u i) (l i)
  let D := b.extend (a sapTy) (fun i => Tape.tab (n i) (S i))
  have hn : b.Nick n := ⟨hx.len h.fen.span,h.fen.span⟩
  have F := Instant.extend b (fun i => Tape.tab (n i) (S i)) (t:=a sapTy)
  have G := Instant.scan D n
  have hg := hn.transfer F
  refine caseM h.prospect (arrayNow hg _ ?_)
  have hp : D.Moves (fun _ => 0) (a sapTy) fun i => Tape.tab (n i) (S i) :=
    cherry b _
  have HH := Moves.pick (b:=D.scan n) (t:=sapTy) (n:=fun i => n i.i) (fun i => S i.i)
    (hp.transfer G) (chop hg).close During.hj
  have hd (i : During n) : (S i.i i.j).1<n i.i :=
    survey_lt _ _ _ (h.fen.good _) (h.good _) _ i.hj
  have hX := Moves.pick (b:=D.scan n) (t:=c cl) (n:=fun i => n i.i) (fun i => x i.i)
    (hx.transfer (G.next F)) HH.fst hd
  exact (HH.snd.mul hX).congr (fun i =>
    (graft_survey _ _ _ (h.fen.good i.i) (h.good _) _ _ i.hj).symm)

end Bough
end Bench

end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Slant Slant.Stroke Spectral
noncomputable section

universe U
namespace Bench.Engrave

variable {m : Bool} {ι : Type U} {b : Bench m ι}
    {n l k : ι→ℕ}

lemma strand (h : b.Digit n) (hk : b.Digit k) (hl : b.Digit l)
    (r : ι→ℕ→Reel) (H : (b.scan l).Engrave (fun i => n i.i) (fun i => r i.i i.j))
    (g : ∀ i, ∀ j<l i, (r i j).beats=k i) :
    b.Engrave n fun i => Slant.strand (r i) (l i) := by
  let R i j := Slant.strand (r i) j
  have hb (i : ι) (j : ℕ) (hj : j ≤ l i) : (R i j).beats=j*k i :=
    beat_strand j _ (fun t ht => g i t (ht.trans_le hj))
  have hs (i : ι) (j : ℕ) (hj : j ≤ l i) : (R i j).Sound (n i) :=
    sound_strand _ _ fun t ht => H.sound ⟨i,t,ht.trans_le hj⟩
  refine ⟨fun i => hs i _ le_rfl, (hl.mul hk).congr (fun i => (hb i _ le_rfl).symm),h,?_⟩
  let U i j := film (n i) (R i j)
  refine loop (t:=filmTy) hl U ?_ ?_
  · exact (Engrave.rest h (Digit.wc 0)).layers
  · let P := b.climbs l filmTy U
    have F := Feeds.climbs b l U
    have hj := stepi hl U -- specify
    have hg : P.Engrave (fun i => n i.i) (fun i => R i.i i.j) :=
      ⟨fun i => hs i.i i.j i.hj.le, ((hj.mul (draw F hk)).congr (fun i => (hb i.i i.j i.hj.le).symm)),
        draw F h,stepsum b l U⟩
    exact (hg.stack (H.transfer (inspect b l U))).layers

abbrev double (b : Bench m ι) (l : ι→ℕ) :=
  (b.scan l).scan fun i => l i.i
abbrev triple (b : Bench m ι) (l : ι→ℕ) :=
  (double b l).scan fun i => l i.i.i

private lemma duoStrand (h : b.Digit n) (hk : b.Digit k) (hl : b.Digit l)
    (r : ι→ℕ→ℕ→Reel)
    (H : (double b l).Engrave (fun i => n i.i.i) (fun i => r i.i.i i.i.j i.j))
    (g : ∀ i, ∀ j<l i, ∀ s<l i, (r i j s).beats=k i) :
    b.Engrave n fun i => Slant.strand (fun j => Slant.strand (r i j) (l i)) (l i) := by
  have F := Feeds.scan b l
  apply strand h (hl.mul hk) hl (fun i j => Slant.strand (r i j) (l i))
  · exact strand (draw F h) (draw F hk) (draw F hl) (fun i => r i.i i.j) H
      (fun i => g i.i i.j i.hj)
  · exact fun i j hj => beat_strand _ _ (g i j hj)

lemma riprap (h : b.Digit n) (hk : b.Digit k) (hl : b.Digit l)
    (r : ι→ℕ→ℕ→ℕ→Reel)
    (H : (triple b l).Engrave (fun i => n i.i.i.i) (fun i => r i.i.i.i i.i.i.j i.i.j i.j))
    (g : ∀ i, ∀ j<l i, ∀ s<l i, ∀ t<l i, (r i j s t).beats=k i) :
    b.Engrave n fun i => Slant.riprap (r i) (l i) := by
  have F := Feeds.scan b l
  exact strand h (hl.mul (hl.mul hk)) hl
    (fun i j => Slant.strand (fun s => Slant.strand (r i j s) (l i)) (l i))
    (duoStrand (draw F h) (draw F hk) (draw F hl) (fun i => r i.i i.j) H
      (fun i => g i.i i.j i.hj)) (fun i j hj =>
      beat_strand _ _ (fun s hs => beat_strand _ _ (g i j hj s hs)))

end Bench.Engrave
end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Slant Spectral Complex
noncomputable section

universe U
namespace Bench
variable {m : Bool} {ι : Type U} {b : Bench m ι}

lemma spot_jetty {p w a s : ι→ℕ} (hp : b.Digit p) (hw : b.Digit w)
    (ha : b.Digit a) (hs : b.Digit s) :
    b.Spots (fun i => jetty (p i) (w i) (a i) (s i)) :=
  have h := hs.mul ha
  ⟨hp.add h,ha.minimum (hw.sub h)⟩

lemma spot_quay {j s : ι→ℕ} (h : b.Digit j) (g : b.Digit s) :
    b.Spots (fun i => quay (s i) (j i)) :=
  ⟨h.mul g,g⟩

section
variable {h g : ι→Line} {e w k : ι→ℕ} {r : ι→ℂ}
    (hh : b.Fabric e h) (hg : b.Fabric e g) (hy : b.Hue fun _ => I) (hw : b.Digit w)

include hh hg hy hw

-- speck s c j for small
lemma carve_speck {p s c j : ι→ℕ} (hp : b.Digit p)
    (hs : b.Digit s) (hc : b.Digit c) (hj : b.Digit j)
    (hb : ∀ i, c i<p i) (hb' : ∀ i, j i<p i) (hE : ∀ i,p i+w i ≤ e i) :
    b.Engrave (fun i => p i+w i) (fun i => speck (p i) (w i) (h i) (g i) (s i) (c i) (j i)) := by
  let P i := s i<w i
  have H : b.Study P := Study.lt hs hw
  unfold speck
  refine Engrave.fork H ?_ (Engrave.rest (draw (restricted ..) (hp.add hw)) (Digit.wc 26))
  have F := restricted b P
  let U i := quay 1 (j i)
  let V i := jetty (p i) (w i) 1 (s i)
  have hU : b.Spots U := spot_quay hj (Digit.wc 1)
  have hV : b.Spots V := spot_jetty hp hw (Digit.wc 1) hs
  have hz (i : {i // P i}) : (V i.val).wide = (U i.val).wide := by
    change min 1 (w i.val - s i.val * 1)=1
    have h0 : s i.val<w i.val := i.property
    omega
  have hU' i : (U i).Fits (p i+w i) := by simpa only [mul_one,U] using
    (quay_fits (p i) 1 (j i) (w i) (hb' i))
  have hy' (i : {i // P i}) : p i.val+s i.val<e i.val :=
    (Nat.add_lt_add_left i.property _).trans_le (hE _)
  have hc' (i : ι) : c i<e i :=
    (hb i).trans_le ((Nat.le_add_right (p i) (w i)).trans (hE i))
  have hl := ((hh.transfer F).riseEntry (draw F (hp.add hs)) (draw F hc) hy').mul
    ((hg.riseEntry hc hj hc').transfer F)
  exact (hV.transfer F).flash (hU.transfer F) (draw F (hp.add hw))
    (fun i => jetty_fits _ _ _ _) (fun i => hU' _) hz (fun i => quay_jet _ _ _ _ (hb' _))
    (hy.transfer F) (Fabric.flat hl)

lemma carve_sand {p : ι→ℕ} (hp : b.Digit p) (hE : ∀ i,p i+w i ≤ e i) :
    b.Engrave (fun i => p i+w i) (fun i => sand (p i) (w i) (h i) (g i)) := by
  refine Engrave.riprap (hp.add hw) (Digit.wc 26) hp (fun i => speck (p i) (w i) (h i) (g i))
    ?_ (fun _ _ _ _ _ _ _ => beats_speck _ _ _ _ _ _ _)
  have A := Feeds.scan b p
  have B := Feeds.scan (b.scan p) fun i => p i.i
  have C := Feeds.scan (Engrave.double b p) fun i => p i.i.i
  have F := (C.next B).next A
  exact carve_speck (hh.transfer F) (hg.transfer F) (hy.transfer F) (draw F hw) (draw F hp)
    (draw (C.next B) (slot hp)) (draw C (slot (draw A hp))) (slot (draw (B.next A) hp))
    (fun i => i.i.hj) (fun i => i.hj) (fun i => hE _)

variable (hk : b.Arch k) (hr : b.Hue r) (hz : ∀ i, r i≠0)
  (hE : ∀ i, 16*2^k i+w i ≤ e i)
include hk hr hz hE

lemma carve_gravel {s c j : ι→ℕ} (hs : b.Digit s) (hc : b.Digit c) (hj : b.Digit j)
    (hb : ∀ i,c i<16) (hb' : ∀ i,j i<16) :
    b.Engrave (fun i => 16*2^k i+w i)
      (fun i => gravel (k i) (r i) (w i) (h i) (g i) (s i) (c i) (j i)) := by
  let B i := 2^k i
  let P i := 16*B i
  let Y i := P i+w i
  let U i := quay (B i) (j i)
  let V i := jetty (P i) (w i) (B i) (s i)
  let Z i := trestle (B i) (j i)
  let K i := barrier (B i) (j i)
  let M i := lockBay (B i) (j i)
  have hP : b.Digit P := (Digit.wc 16).mul hk.span
  have hY := hP.add hw
  have HF : b.Digit fun i => far (B i) (j i) :=
    iteN (Study.lt hj (Digit.wc 8)) ((Digit.wc 8).mul hk.span) (Digit.wc 0)
  have hU : b.Spots U := spot_quay hj hk.span
  have hV : b.Spots V := spot_jetty hP hw hk.span hs
  have hZ : b.Spots Z := ⟨HF,hk.span⟩
  have hK : b.Spots K := ⟨HF.add hk.span,(Digit.wc 2).mul hk.span⟩
  have hM : b.Spots M := ⟨HF.add ((Digit.wc 3).mul hk.span),(Digit.wc 2).mul hk.span⟩
  have A (i : ι) : Wharf (Y i) (U i) (V i) (Z i) (K i) (M i) :=
    wharf _ _ _ _ (hb' i)
  have W (i : ι) : Slips (k i) (U i) (V i) (Z i) (K i) (M i) :=
    slips _ _ _ _
  have ht := hc.mul hk.span
  have hu (i : ι) (d : ℕ) (hd : d < B i) : c i*B i+d<e i := by
    have H := quay_fits 16 (B i) (c i) (w i) (hb i) _ ((quay (B i) (c i)).inside hd)
    exact H.trans_le (hE _)
  have hv (i : ι) (d : ℕ) (hd : d < (V i).wide) : (V i).lo+d<e i :=
    ((A i).fitsV _ ((V i).inside hd)).trans_le (hE _)
  have h1 (x : ι→Line) (hh : b.Fabric e x) :=
    Spots.bore hk hr hz hY hy hU hZ hK hM (fun i => (W i).lw) (fun i => (W i).mw)
      (fun i => (A i).fitsU) (fun i => (A i).fitsZ) (fun i => (A i).fitsL)
      (fun i => (A i).fitsM) (fun i => (A i).lm)
      (fun i => (W i).uw) (fun i => (W i).zw)
      (fun i => (A i).ul) (fun i => (A i).zm) hU.low ht hh hu
  have h2 (x : ι→Line) (hh : b.Fabric e x) :=
    Spots.bore hk hr hz hY hy hZ hV hK hM (fun i => (W i).lw) (fun i => (W i).mw)
      (fun i => (A i).fitsZ) (fun i => (A i).fitsV) (fun i => (A i).fitsL)
      (fun i => (A i).fitsM) (fun i => (A i).lm)
      (fun i => (W i).zw) (fun i => (W i).vw)
      (fun i => (A i).zl) (fun i => (A i).vm) ht hV.low hh hv
  unfold gravel cliff
  exact engrave_cameo (h1 g hg) (h2 h hh) (h1 _ hg.neg) (h2 _ hh.neg)

lemma carve_reef :
    b.Engrave (fun i => 16*2^k i+w i)
      (fun i => reef (k i) (r i) (w i) (h i) (g i)) := by
  let L (_ : ι) := 16
  let S i := 4*(80*k i+348)
  have hS : b.Digit S := (Digit.wc 4).mul (((Digit.wc 80).mul hk.ep).add (Digit.wc 348))
  have hL : b.Digit L := Digit.wc 16
  unfold reef
  refine Engrave.riprap (((Digit.wc 16).mul hk.span).add hw) hS hL
    (fun i => gravel (k i) (r i) (w i) (h i) (g i)) ?_
    (fun _ _ _ _ _ _ _ => beats_gravel _ _ _ _ _ _ _ _)
  have A := Feeds.scan b L
  have B := Feeds.scan (b.scan L) fun i => L i.i
  have C := Feeds.scan (Engrave.double b L) fun i => L i.i.i
  have F := (C.next B).next A
  exact carve_gravel (hh.transfer F) (hg.transfer F) (hy.transfer F) (draw F hw)
    (hk.transfer F) (hr.transfer F) (fun i => hz _) (fun i => hE _)
    (draw (C.next B) (slot hL)) (draw C (slot (draw A hL))) (slot (draw (B.next A) hL))
    (fun i => i.i.hj) (fun i => i.hj)

end
end Bench
end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Slant Spectral Complex
noncomputable section

universe U V
namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι} {q : Bench m κ}

lemma reach_digit {e : ι→ℕ} (h : b.Arch e) :
    b.Digit (fun i => reachSize (e i)) := by
  have H := h.span
  have hp := h.ep
  have ha : b.Digit fun _ => 16 := Digit.wc 16
  have hb := (Digit.wc 4).mul (((Digit.wc 80).mul (hp.sub (Digit.wc 4))).add (Digit.wc 348))
  exact iteN (Study.lt hp (Digit.wc 4)) (H.mul (H.mul (H.mul (Digit.wc 26))))
    (ha.mul (ha.mul (ha.mul hb)))

lemma chorus_small {e : ι→ℕ} (h : Small b.size e) :
    Small b.size (fun i => chorus (e i)) :=
  ((Small.const b.size 10000000).mul ((h.add (Small.const _ 1)).pow 2)).mono
    fun _ => chorus_le _

lemma chorus_digit {e : ι→ℕ} (h : b.Arch e) :
    b.Digit (fun i => chorus (e i)) := by
  let f (_ : ι) (j : ℕ) := chorus j
  refine ⟨loop (t:=w) h.ep f (Makes.wc 1) ?_,chorus_small (b:=b) h.ep.small⟩
  let P := b.climbs e w f
  have F := Feeds.climbs (t:=w) b e f
  have hi : P.Arch During.j :=
    (h.transfer F).below (stepi (t:=w) h.ep f) (fun j => j.hj.le)
  have hz : P.Digit (fun i => chorus i.j) :=
    ⟨stepsum (t:=w) b e f,chorus_small (b:=P) hi.ep.small⟩
  exact (hz.add (reach_digit hi)).run

structure Library (b : Bench m ι) (n t : ι→ℕ) (h g r : ι→Line) : Prop where
  ink : b.Hue fun _ => I
  gap : b.Fabric n h
  upper : b.Fabric n g
  root : b.Fabric t r
  hz : ∀ i, ∀ j<t i,r i j≠0

namespace Library
variable {t e n v : ι→ℕ} {h g r : ι→Line}

lemma transfer {n t : κ→ℕ} {h g r : κ→Line} (a : q.Library n t h g r) {f}
    (F : b.Feeds q f) :
    b.Library (fun i => n (f i)) (fun i => t (f i)) (fun i => h (f i))
      (fun i => g (f i)) (fun i => r (f i)) :=
  ⟨a.ink.transfer F,a.gap.transfer F,a.upper.transfer F,a.root.transfer F,fun _ => a.hz _⟩

lemma buildSpan (a : b.Library n t h g r) (H : b.Arch e) (hk : b.Digit v)
    (hg : ∀ i,e i+1<t i) (hp : ∀ i, 2^e i+v i ≤ n i) :
    b.Engrave (fun i => 2^e i+v i) (fun i => bridgeSpan (e i) (v i) (h i) (g i) (r i)) := by
  let P i := e i<4
  have B : b.Study P := Study.lt H.ep (Digit.wc 4)
  unfold bridgeSpan
  refine Engrave.fork B ?_ ?_
  · exact ((carve_sand a.gap a.upper a.ink hk H.span hp).transfer (restricted b P))
  · have F := restricted b (fun i => ¬P i)
    have Hb := H.sub (Digit.wc 4)
    have Hk : ∀ i,e i-4+1<t i := by intro i; have := hg i; omega
    have hr := a.root.pick Hb.succ.ep.run Hk
    have hz i := a.hz i (e i-4+1) (Hk i)
    have hS (i : {i // ¬P i}) := desc_num _ (show ¬e i.val<4 from i.property)
    refine (carve_reef (a.gap.transfer F) (a.upper.transfer F) (a.ink.transfer F)
      (draw F hk) (Hb.transfer F) (hr.transfer F) (fun i => hz _) ?_).congr
      ?_ (fun _ => rfl)
    · intro i; exact (by simpa only [hS i] using hp i.val)
    · intro i
      rw [← hS]

lemma buildHoop (a : b.Library n t h g r) (H : b.Arch e) (hk : b.Digit v)
    (hg : ∀ i,e i+1<t i) (hp : ∀ i,v i ≤ n i) {p q : ι→Reel}
    (hP : b.Engrave (fun i => min (2^e i) (v i)) p)
    (hQ : b.Engrave (fun i => v i-2^e i) q)
    (hx : ∀ i,(p i).beats=(q i).beats) :
    b.Engrave v (fun i => hoop (e i) (v i) (h i) (g i) (r i) (p i) (q i)) := by
  have hv := (hP.parallel hQ hx).congr
    (fun i => by exact (show min (2^e i) (v i)+(v i-2^e i)=v i by omega)) (fun _ => rfl)
  unfold hoop; dsimp only
  refine hv.stack (Engrave.fork (Study.lt H.span hk) ?_ ?_)
  · let P i := 2^e i<v i
    have F := restricted b P
    have hy (i : {i // P i}) : 2^(e i.val)+(v i.val-2^e i.val)=v i.val := by
      have h1 : 2^e i.val<v i.val := i.property
      omega
    exact ((a.transfer F).buildSpan (H.transfer F) (draw F (hk.sub H.span))
      (fun i => hg _) (fun i => (hy i).le.trans (hp _))).congr hy (fun _ => rfl)
  · exact (Engrave.rest hk (reach_digit H)).transfer (restricted ..)
end Library

def clipped (e v : ℕ) := min (2^e) v

def panel (h g r : Line) (e v : ℕ) : T filmTy :=
  film (clipped e v) (harp h g r e (clipped e v))

def canopy (h g r : Line) (e v : ℕ) : T (Ty.a filmTy) :=
  Tape.tab (v+1) (panel h g r e)

private lemma fromCanopy {h g r : ι→Line} {d v w : ι→ℕ}
    (hd : b.Arch d) (hk : b.Digit w) (hg : ∀ i,w i ≤ v i) (hh : ∀ i,w i ≤ 2^d i)
    (H : b.Makes (Ty.a filmTy) (fun i => canopy (h i) (g i) (r i) (d i) (v i))) :
    b.Engrave w (fun i => harp (h i) (g i) (r i) (d i) (w i)) := by
  have hp i : clipped (d i) (w i)=w i := min_eq_right (hh i)
  refine ⟨fun i => sound_harp _ _ _ _ _ (hh i),(chorus_digit hd).congr
    (fun i => (beats_harp _ _ _ _ _).symm), hk,?_⟩
  have hy := Makes.pick (n:=fun i => v i+1) (t:=filmTy)
    (fun i => panel (h i) (g i) (r i) (d i)) H hk.run (fun i => by
      exact Nat.lt_add_one_iff.mpr (hg i))
  exact hy.congr fun i => by simp only [panel,hp]

namespace Library
variable {t d n v : ι→ℕ} {h g r : ι→Line}

private lemma buildPanel (a : b.Library n t h g r) (hd : b.Arch d)
    (hp : ∀ i,v i ≤ n i) (ht : ∀ i,d i+1<t i)
    (H : b.Makes (Ty.a filmTy) fun i => canopy (h i) (g i) (r i) (d i) (v i)) {w}
    (hh : b.Digit w) (hk : ∀ i,w i ≤ v i) :
    b.Makes filmTy (fun i => panel (h i) (g i) (r i) (d i+1) (w i)) := by
  let W i := clipped (d i+1) (w i)
  let B i := 2^d i
  have hW : b.Digit W := hd.succ.span.minimum hh
  have HS i : W i ≤ v i := (min_le_right ..).trans (hk i)
  let p i j := harp (h i) (g i) (r i) (d i) j
  have hl := fromCanopy hd (hd.span.minimum hW)
    (fun i => (min_le_right ..).trans (HS i)) (fun _ => min_le_left ..) H
  have hx := fromCanopy hd (hW.sub hd.span)
    (fun i => (Nat.sub_le ..).trans (HS i))
    (fun i => branch_smaller (d i) _ (min_le_left ..)) H
  have ht' := a.buildHoop hd hW ht (fun i => (HS i).trans (hp i)) hl hx (fun i =>
    (beats_harp _ _ _ _ _).trans (beats_harp _ _ _ _ _).symm)
  refine ht'.layers.congr ?_
  intro i
  simp only [panel, harp, W]

private lemma wholeCanopy (a : b.Library n t h g r) (hd : b.Arch d) (hA : b.Digit v)
    (hn : ∀ i,0<n i) (hp : ∀ i,v i ≤ n i) (ht : ∀ i,d i<t i) :
    b.Makes (Ty.a filmTy) (fun i => canopy (h i) (g i) (r i) (d i) (v i)) := by
  let x i e := canopy (h i) (g i) (r i) e (v i)
  let c i := v i+1
  have hc := hA.add (Digit.wc 1)
  refine loop (t:=Ty.a filmTy) hd.ep x ?_ ?_
  · refine tab (t:=filmTy) hc (fun i => panel (h i) (g i) (r i) 0) ?_
    have hw : (b.scan c).Digit (fun i => clipped 0 i.j) :=
      ((Digit.wc 1).minimum (slot hc)).congr (fun i => by rw [clipped,pow_zero])
    have hh := (a.gap.pick (Makes.wc 0) hn).transfer (Feeds.scan b c)
    have H := Engrave.swatch hw _ (Fabric.flat hh)
    exact H.layers
  · let P := b.climbs d (Ty.a filmTy) x
    have F := Feeds.climbs b d x
    have hb := draw F hc
    refine tab (t:=filmTy) hb (fun i => panel (h i.i) (g i.i) (r i.i) (i.j+1)) ?_
    have G := Feeds.scan P fun i => c i.i
    have hk : P.Arch During.j := (hd.transfer F).below (stepi hd.ep x) (fun i => i.hj.le)
    exact (a.transfer (G.next F)).buildPanel (v:=fun i => v i.i.i) (hk.transfer G)
      (fun i => hp _) (fun i => (Nat.add_one_le_iff.mpr i.i.hj).trans_lt (ht _))
      (pull G (stepsum b d x)) (slot hb) (fun i => by
        have hh : i.j<v i.i.i+1 := i.hj
        exact Nat.lt_add_one_iff.mp hh)

lemma buildHarp (a : b.Library n t h g r) (hd : b.Arch d) (hA : b.Digit v)
    (hn : ∀ i,0<n i) (hp : ∀ i,v i ≤ n i) (ht : ∀ i,d i<t i)
    (hw : ∀ i,v i ≤ 2^d i) :
    b.Engrave v (fun i => harp (h i) (g i) (r i) (d i) (v i)) :=
  fromCanopy hd hA (fun _ => le_rfl) hw (wholeCanopy a hd hA hn hp ht)

end Library
end Bench
end
end PowerSaving.RAM

end OAI
namespace OAI

namespace PowerSaving.RAM
open Ty Slant Spectral Complex
noncomputable section

universe U
namespace Bench
variable {m : Bool} {ι : Type U} {b : Bench m ι}

namespace Hue

lemma either {P : ι→Prop} {f : ι→ℂ} (h : b.Study P)
    (a : (b.scrutin P).Hue (fun i => f i.val))
    (q : (b.scrutin (fun i => ¬P i)).Hue (fun i => f i.val)) :
    b.Hue f := ⟨chooseM h a.bright q.bright,
    chooseM (t:=sc) (y:=fun i => starRingEnd ℂ (f i)) h a.dull q.dull⟩

lemma gapV {u : ι→ℂ} (h : b.Hue u) {n : ι→ℕ} (hh : b.Digit n) :
    b.Hue (fun i => Spectral.gap (u i) (n i)) :=
  Hue.prod hh _ (Hue.one.sub
    ((h.transfer (Feeds.scan b n)).exponent ((slot hh).add (Digit.wc 1))))

lemma roofV {u : ι→ℂ} (h : b.Hue u) {n : ι→ℕ} (hh : b.Digit n) :
    b.Hue (fun i => Spectral.roof (u i) (n i)) :=
  Hue.prod hh _ (((h.transfer (Feeds.scan b n)).exponent (slot hh)).neg)

end Hue

private abbrev swab := Ty.a (p sc sc)
private def drum (h : Line) (n : ℕ) : T swab :=
  Tape.tab n fun i => (recoil h i, starRingEnd ℂ (recoil h i))

namespace Fabric
variable {n : ι→ℕ} {h : ι→Line} (hh : b.Fabric n h) (hg : ∀ i,h i 0≠0)

include hh hg

private lemma firstCoil (hp : ∀ i,0<n i) :
    b.Hue (fun i => recoil (h i) 0) :=
  ((hh.pick (Makes.wc 0) hp).inv hg).congr (fun i => (recoil_zero (h i)).symm)

private lemma refill {k : ι→ℕ} (hk : b.Digit k) (hy : ∀ i,k i+1 < n i)
    (hf : b.Fabric (fun i => k i+1) (fun i => recoil (h i))) :
    b.Hue (fun i => recoil (h i) (k i+1)) := by
  have hx := hk.add (Digit.wc 1)
  let U i := k i+1
  have F := Feeds.scan b U
  have hu (i : During U) : k i.i-i.j<k i.i+1 := by omega
  have hv (i : During U) : i.j+1<n i.i := (Nat.add_one_le_iff.mpr i.hj).trans_lt (hy i.i)
  have hs := (slot hx)
  have hq := ((hf.transfer F).pick ((draw F hk).sub hs).run hu).mul
    ((hh.transfer F).pick (hs.add (Digit.wc 1)).run hv)
  have hsum := Hue.sum hx (fun i j => recoil (h i) (k i-j)*h i (j+1)) hq
  have hy' i : 0<n i := lt_trans (show 0<k i+1 by omega) (hy i)
  have h0 := hh.pick (Makes.wc 0) hy'
  exact (hsum.neg.div h0 hg).congr (fun i => (recoil_next (h i) (k i)).symm)

private lemma oneLonger {k : ι→ℕ} (hk : b.Digit k) (hy : ∀ i,k i+1<n i)
    (hf : b.Fabric (fun i => k i+1) (fun i => recoil (h i))) :
    b.Fabric (fun i => k i+1+1) (fun i => recoil (h i)) := by
  let U i := k i+1
  let W i := k i+1+1
  have hu := hk.add (Digit.wc 1)
  have F := Feeds.scan b W
  let T (j : During W) := j.j<U j.i
  have hp := slot (hu.add (Digit.wc 1))
  have H : (b.scan W).Study T := Study.lt hp (draw F hu)
  unfold Bench.Fabric
  refine Hue.either H ?_ ?_
  · have G := restricted (b.scan W) T
    exact ((hf.transfer F).transfer G).pick (draw G hp).run (fun i => i.property)
  · have G := restricted (b.scan W) fun i => ¬T i
    refine (((hh.refill hg hk hy hf).transfer F).transfer G).congr ?_
    intro i
    have hh0 : i.val.j < U i.val.i+1 := i.val.hj
    have hg0 : ¬i.val.j<U i.val.i := i.property
    rw [show i.val.j=U i.val.i by omega]

lemma uncoil (hn : b.Digit n) (hp : ∀ i,0<n i) :
    b.Fabric n (fun i => recoil (h i)) := by
  let U i k := drum (h i) (k+1)
  let y i := n i-1
  have hy : b.Digit y := hn.sub (Digit.wc 1)
  have hf : b.Makes swab (fun i => drum (h i) (n i)) := by
    have H : b.Makes swab (fun i => U i (y i)) := by
      refine loop (t:=swab) hy U ?_ ?_
      · have hx := hh.firstCoil hg hp
        have H1 : b.Fabric (fun _ => 1) (fun i => recoil (h i)) := by
          refine (hx.transfer (Feeds.scan b (fun _ => 1))).congr ?_
          intro d; rw [show d.j=0 by have := d.hj; omega]
        exact H1.supply (Digit.wc 1)
      · have F := Feeds.climbs b y U
        have hw := stepi hy U
        have hq : ∀ j : During y, j.j+1<n j.i := by
          intro j; have hx : j.j<n j.i-1 := j.hj; omega
        have H1 := (hh.transfer F).oneLonger (fun i => hg _) hw hq (Fabric.recover
          (stepsum b y U))
        exact H1.supply ((hw.add (Digit.wc 1)).add (Digit.wc 1))
    exact H.congr fun i => congrArg (drum (h i)) (show y i+1=n i by unfold y; have := hp i; omega)
  exact Fabric.recover hf

end Fabric

lemma print_echo {n : ι→ℕ} (h : b.Digit n) :
    b.Engrave n (fun i => echo (n i)) :=
  Engrave.lace _ h (fun i _ _ => by omega)
    (((draw (Feeds.scan b n) (h.sub (Digit.wc 1))).sub (slot h)).run)

theorem publish {n d : ι→ℕ} {u : ι→ℂ} {r : ι→Line}
    (hd : b.Arch d) (hh : b.Digit n) (hn : ∀ i,0<n i) (hv : ∀ i,n i ≤ 2^d i)
    (hr : b.Fabric (fun i => d i+1) r) (hy : ∀ i, Springs (d i) (r i))
    (h : b.Hue u) (hu : ∀ i, IsPrimitiveRoot (u i) (n i))
    (hI : b.Hue fun _ => I) :
    b.Engrave n (fun i => ballad (n i) (d i) (u i) (r i)) := by
  have F := Feeds.scan b n
  have hX : b.Fabric n fun i => gap (u i) := (h.transfer F).gapV (slot hh)
  have hx (i : ι) (j : ℕ) (hj : j<n i) : gap (u i) j≠0 :=
    gap_ne_zero (u i) (hu i) j hj
  let f i := floorH (u i)
  have hF : b.Fabric n f := hX.inv hx
  have hg := hF.uncoil (fun i => by simp [f,floorH,gap]) hh hn
  have hL : b.Library n (fun i => d i+1) f (fun i => recoil (f i)) r :=
    ⟨hI,hF,hg,hr,fun i j hj => (hy i j (by omega)).ne_zero (by positivity)⟩
  have ht := hL.buildHarp hd hh hn (fun _ => le_rfl) (fun i => by exact Nat.lt_succ_self _)
    hv
  have hY : b.Fabric n fun i => roof (u i) := (h.transfer F).roofV (slot hh)
  have hhR : b.Fabric n fun i j => (cog (u i) j)⁻¹ :=
    (Fabric.inv (x:=fun i => cog (u i)) (hX.mul hY) (fun i => cog_ne_zero (u i) (hu i)))
  have He := print_echo hh
  have Hg := Engrave.swatch hh _ hX
  have Hh := Engrave.swatch hh _ hY
  unfold ballad ode
  exact (((Hg.stack ((He.stack ht).stack He)).stack Hh).stack
    (Engrave.swatch hh _ hhR)).stack ((Hh.stack ht).stack Hg)

end Bench
end
end PowerSaving.RAM

end OAI


namespace OAI.PowerSaving

noncomputable def envelope (z : ℝ) (k : ℕ) : ℕ := Nat.ceil (((k:ℝ)+1)^z)

lemma envelope_pos (z : ℝ) (k : ℕ) : 1 ≤ envelope z k :=
  Nat.one_le_ceil_iff.mpr (by positivity)

end OAI.PowerSaving

namespace OAI.PowerSaving.RAM
open Binary Matrix Finset
noncomputable section
section
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

def Route (S T : ρ → CMat α) (g : (ρ→ℂ) → (ρ→ℂ)) (c : ℕ) : Prop :=
  ∃ p : PWord α ρ, tally p = c ∧
    ∀ (f : ℕ) (x : Data α ρ f), walk f p (multiAct f S x) = multiAct f T (point f g x)

namespace Route
variable {S T U : ρ → CMat α}

theorem gate (g : Matrix ρ ρ ℚ) (S T : ρ → CMat α)
    (cond : ∀ i j, g i j ≠ 0 → T i = S j) :
    Route S T (actPoint g) 0 := by
  refine ⟨[.localM g], by simp [tally,toll], ?_⟩
  intro f x
  let M (r : ρ) := digitProd (fun _ : Fin f => S r)
  let N (r : ρ) := digitProd (fun _ : Fin f => T r)
  funext r i
  change ∑ j, (g r j:ℂ)* (∑ a, M j i a * x j a)
    = ∑ a, N r i a * (∑ j, (g r j:ℂ)*x j a)
  simp only [mul_sum]
  rw [sum_comm]
  apply sum_congr rfl
  intro a ha
  apply sum_congr rfl
  intro j hj
  by_cases gh : g r j = 0
  · simp [gh]
  · dsimp only [M, N]
    rw [cond r j gh]
    ac_rfl

end Route

lemma sum_ind_right (a : ρ) (x : ρ → ℂ) :
    ∑ j, ((if a = j then (1:ℚ) else 0 : ℚ) : ℂ) * x j = x a := by
  rw [sum_eq_single a]
  · simp
  · intro j _ hj; simp [Ne.symm hj]
  · simp

end
end
end OAI.PowerSaving.RAM
