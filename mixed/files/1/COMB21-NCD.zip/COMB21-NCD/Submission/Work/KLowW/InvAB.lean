import Submission.Work.KLowW.ShearAB


namespace KLW
open SSC GXD GLab OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.GF OAI.PowerSaving.RAM
  OAI.PowerSaving.SS OAI.PowerSaving.CB OAI.PowerSaving.BR OAI.PowerSaving.GX OAI.PowerSaving.XEX Finset Matrix

section
variable {c : WCert} {emb : Box (Fin c.v) (Fin c.R) (Fin c.nc) → Nat} {un : Nat → Box (Fin c.v) (Fin c.R) (Fin c.nc)}

noncomputable def WCert.tv (c : WCert) (t : Fin c.v) : Space (Fin c.p.h) := tvec c.p.h (c.ports.getD t.val 0)

variable {α : Type} [Fintype α] [DecidableEq α]

end
end KLW

set_option autoImplicit false

namespace KLW
open SSC GXD GLab OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.GF OAI.PowerSaving.RAM
  OAI.PowerSaving.SS OAI.PowerSaving.CB OAI.PowerSaving.BR OAI.PowerSaving.GX OAI.PowerSaving.XEX Finset Matrix

structure WValidAB (c : WCert) (ab : Nat → Int × Int × Int) : Prop where
  hn : c.p.n = 2 * c.v + c.R + c.nc
  nr : c.q.nr = c.p.n
  tab : tabK c.p.h c.p.tab = true
  run : RunW c.p c.wt c.S0 c.evs c.SF c.rs
  ends : endKX c.pe c.v c.ports [] c.gl c.el c.S0 c.S0 c.SF = true
  par : ParOK c.q
  scF : ScalOK c.q c.evs c.R0 c.RF
  id0 : idK c.q c.R0 = true
  wfF : RT.wfK c.RF c.q.d = true
  shAB : shKnAB c.q c.v ab c.RF (2 * c.v + c.R) = true
  frF : freeK c.q c.RF = true

structure GInvAB (H T Sl C : Type) [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
    [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C]
    (Ok : ∀ {γ : Type} [Fintype γ] [DecidableEq γ], GWin H γ → Prop) where
  tv : T → Space H
  hunit : ∀ t, dot (tv t) (tv t) = 1
  hgap : ∀ t, ∃ p, tv t p = 0
  cost : (ℕ → ℝ) → ℝ
  ent : Sl → SLbl H
  ex : Sl → SLbl H
  hexG : ∀ q, (ex q).G = (ent q).G
  hexs : ∀ q, (ent q).s ⊆ (ex q).s
  al : T → ℚ
  be : T → ℚ
  run : ∀ {γ : Type} [Fintype γ] [DecidableEq γ] (W : GWin H γ), Ok W → ∀ (N Wn : Sl → CMat γ),
    (∀ q, W.X.Φ (ent q) * N q = 1) → (∀ q, W.X.Φ (ex q) = Wn q * W.X.Φ (ent q)) →
    ∀ (Z : Sl → CMat γ) (c0 c1 : C → CMat γ),
    GRoute (iin W.Xm tv Z c0) (iout W.Xm tv (fun q => Wn q * Z q) c1) (shearAB al be) cost

section
variable {c : WCert} {ab : Nat → Int × Int × Int} {emb : Box (Fin c.v) (Fin c.R) (Fin c.nc) → Nat}
  {un : Nat → Box (Fin c.v) (Fin c.R) (Fin c.nc)}

theorem WValidAB.E (V : WValidAB c ab) : EndsX c.pe c.v c.ports [] c.gl c.el c.S0 c.S0 c.SF := endKX_sound V.tab V.ends

theorem WValidAB.good (V : WValidAB c ab) (k : Nat) : Good c.p.h (c.p.tab.get k) := tabK_good _ _ V.tab k

theorem WValidAB.dim (V : WValidAB c ab) (k : Nat) :
    (GLab.lab c.p.h (c.p.tab.get k)).dim = cdim (c.p.tab.get k) :=
  lab_dim (V.good k)

theorem WValidAB.qlt (V : WValidAB c ab) (q : Fin c.R) : q.val < c.pe.n - 2 * c.v := by
  show q.val < 2 * c.v + c.R - 2 * c.v
  omega

theorem WValidAB.hsub (V : WValidAB c ab) (Ro : WRoles c emb un) (q : Fin c.R) (hq : q ∈ c.exits) :
    ∀ x, (c.L emb c.S0 (CR.lS q)).Mem x → (c.L emb c.SF (CR.lS q)).Mem x := by
  have hm : memK (2 * c.v + q.val) c.el = true := (Finset.mem_filter.mp hq).2
  intro x hx
  show (GLab.lab c.p.h (c.p.tab.get (c.SF.get (emb (bS q))))).Mem x
  rw [Ro.num.hs q]
  have hx' : (GLab.lab c.p.h (c.p.tab.get (c.S0.get (emb (bS q))))).Mem x := hx
  rw [Ro.num.hs q] at hx'
  exact (V.E.slot q.val (V.qlt q)).2.2 hm x hx'

theorem WValidAB.hexG (V : WValidAB c ab) (Ro : WRoles c emb un) (q : Fin c.R) :
    (c.exq emb q).G = (c.ent emb q).G := by
  unfold WCert.exq WCert.ent
  by_cases h : q ∈ c.exits
  · rw [if_pos h, XEX.lab0X_E _ _ _ h]; rfl
  · rw [if_neg h]; rfl

theorem WValidAB.hexs (V : WValidAB c ab) (Ro : WRoles c emb un) (q : Fin c.R) :
    (c.ent emb q).s ⊆ (c.exq emb q).s := by
  unfold WCert.exq
  by_cases h : q ∈ c.exits
  · rw [if_pos h]
    unfold WCert.ent
    rw [XEX.lab0X_E _ _ _ h]
    exact (XEX.adPair_spec _ _ (V.hsub Ro q h)).1
  · rw [if_neg h]; exact Finset.subset_univ _

variable {γ : Type} [Fintype γ] [DecidableEq γ]

theorem WValidAB.a0 (V : WValidAB c ab) (Ro : WRoles c emb un) (W : GWin (Fin c.p.h) γ) :
    GRoute (stamp (fun t => W.Xm.Φ (tt (c.tv t))) (fun _ => W.Xm.Φ 0) (fun q => W.X.Φ (c.ent emb q))
        (fun k => Lf c.p emb W.X c.S0 (bC k)))
      (Lf c.p emb W.X c.S0) id (fun _ => 0) := by
  refine (GRoute.reach_all _ _ (fun _ _ => 0) ?_).cast (fun φ => by simp)
  rintro ((t|t)|(q|k))
  · have P := V.E.port t.val t.isLt
    obtain ⟨p0, hp⟩ := P.gap
    obtain ⟨A, k, hA⟩ := exists_base_one (c.tv t) P.unit p0 hp
    show GReach (W.Xm.Φ (tt (c.tv t))) (W.X.Φ (GLab.lab c.p.h (c.p.tab.get (c.S0.get (emb (bX t)))))) _
    rw [Ro.num.hx t]
    have h := W.line A k (GLab.lab c.p.h (c.p.tab.get (c.S0.get t.val))) (by rw [V.dim]; exact P.x0d)
      (by rw [hA]; exact P.x0m)
    rw [hA] at h
    exact h
  · have P := V.E.port t.val t.isLt
    show GReach (W.Xm.Φ 0) (W.X.Φ (GLab.lab c.p.h (c.p.tab.get (c.S0.get (emb (bY t)))))) _
    rw [Ro.num.hy t]
    exact W.zero _ (by rw [V.dim, P.y0]; exact V.E.z0)
  · show GReach (W.X.Φ (c.ent emb q)) (W.X.Φ (GLab.lab c.p.h (c.p.tab.get (c.S0.get (emb (bS q)))))) _
    by_cases hq : q ∈ c.exits
    · unfold WCert.ent
      rw [XEX.lab0X_E _ _ _ hq]
      exact XEX.rebaseR W.X _ _ (XEX.entA_mem _ _ (V.hsub Ro q hq))
    · unfold WCert.ent
      rw [XEX.lab0X_nE _ _ _ hq]
      exact GReach.refl _
  · exact GReach.refl _

theorem WValidAB.aF (V : WValidAB c ab) (Ro : WRoles c emb un) (W : GWin (Fin c.p.h) γ) :
    GRoute (Lf c.p emb W.X c.SF)
      (stamp (fun _ => W.Xm.Φ 1) (fun t => W.Xm.Φ (1 + tt (c.tv t))) (fun q => W.X.Φ (c.exq emb q))
        (fun k => Lf c.p emb W.X c.SF (bC k))) id (fun _ => 0) := by
  refine (GRoute.reach_all _ _ (fun _ _ => 0) ?_).cast (fun φ => by simp)
  rintro ((t|t)|(q|k))
  · have P := V.E.port t.val t.isLt
    show GReach (W.X.Φ (GLab.lab c.p.h (c.p.tab.get (c.SF.get (emb (bX t)))))) (W.Xm.Φ 1) _
    rw [Ro.num.hx t]
    exact W.full _ (by rw [V.dim, Fintype.card_fin]; exact P.xF)
  · have P := V.E.port t.val t.isLt
    obtain ⟨p0, hp⟩ := P.gap
    obtain ⟨A, k, hA⟩ := exists_base_one (c.tv t) P.unit p0 hp
    show GReach (W.X.Φ (GLab.lab c.p.h (c.p.tab.get (c.SF.get (emb (bY t)))))) (W.Xm.Φ (1 + tt (c.tv t))) _
    rw [Ro.num.hy t]
    have h := W.perp A k (GLab.lab c.p.h (c.p.tab.get (c.SF.get (c.v + t.val))))
      (by rw [V.dim, Fintype.card_fin]; exact P.yFd) (by rw [hA]; exact P.yFm)
    rw [hA] at h
    exact h
  · show GReach (W.X.Φ (GLab.lab c.p.h (c.p.tab.get (c.SF.get (emb (bS q)))))) (W.X.Φ (c.exq emb q)) _
    unfold WCert.exq
    by_cases hq : q ∈ c.exits
    · rw [if_pos hq]
      exact XEX.rebaseR W.X _ _ (XEX.exlA_mem _ _ (V.hsub Ro q hq))
    · rw [if_neg hq]
      have hm : memK (2 * c.v + q.val) c.el = false := by
        cases e : memK (2 * c.v + q.val) c.el with
        | false => rfl
        | true => exact absurd (Finset.mem_filter.mpr ⟨Finset.mem_univ q, e⟩) hq
      have hF := (V.E.slot q.val (V.qlt q)).2.1 hm
      rw [Ro.num.hs q]
      exact ((W.full _ (by rw [V.dim, Fintype.card_fin]; exact hF)).trans
        (W.topN _ (SLbl.top_dim _))).cast (fun φ => by simp)
  · exact GReach.refl _

theorem WValidAB.clean (V : WValidAB c ab) (Ro : WRoles c emb un) (W : GWin (Fin c.p.h) γ)
    (al be : Fin c.v → ℚ)
    (hab : ∀ t : Fin c.v, (((ab t.val).1 : Int) : ℚ) = al t * (c.q.D : ℚ) ∧
      (((ab t.val).2.1 : Int) : ℚ) = be t * (c.q.D : ℚ) ∧
      (((ab t.val).2.2 : Int) : ℚ) = (1 + al t * be t) * (c.q.D : ℚ))
    (c0 c1 : Fin c.nc → CMat γ) :
    GRoute (iin W.Xm c.tv (fun q => W.X.Φ (c.ent emb q)) c0) (iout W.Xm c.tv (fun q => W.X.Φ (c.exq emb q)) c1)
      (shearAB al be) (fun φ => rcost φ c.rs) := by
  have hq := Ro.sctx V.nr
  have hR' := RT.wfK_sound c.RF c.q.d V.wfF
  have hD : 1 ≤ c.q.D := V.par.2.2.2.2
  have e0 : GRoute (iin W.Xm c.tv (fun q => W.X.Φ (c.ent emb q)) c0)
      (stamp (fun t => W.Xm.Φ (tt (c.tv t))) (fun _ => W.Xm.Φ 0) (fun q => W.X.Φ (c.ent emb q))
        (fun k => Lf c.p emb W.X c.S0 (bC k))) eraseC (fun _ => 0) :=
    GRoute.ofX (xerase (fun t => rfl) (fun t => rfl) (fun q => rfl))
  have m := warp_grouteS Ro.C W.X (lt_of_eq_of_lt (Fintype.card_fin _).symm W.big) V.run V.E.w0 c.q V.par
    hq hR' V.id0 V.frF V.scF
  have e1 : GRoute (stamp (fun _ => W.Xm.Φ 1) (fun t => W.Xm.Φ (1 + tt (c.tv t))) (fun q => W.X.Φ (c.exq emb q))
        (fun k => Lf c.p emb W.X c.SF (bC k)))
      (iout W.Xm c.tv (fun q => W.X.Φ (c.exq emb q)) c1) eraseC (fun _ => 0) :=
    GRoute.ofX (xerase (fun t => rfl) (fun t => rfl) (fun q => rfl))
  have tot := (((e0.trans (V.a0 Ro W)).trans m).trans (V.aF Ro W)).trans e1
  refine (tot.castg (funext fun z => ?_)).cast (fun φ => by simp)
  exact rows_shearAB hq Ro.num hD al be ab hab (shKnAB_sound c.q c.v ab c.RF hR' _ V.shAB) z

theorem WValidAB.route (V : WValidAB c ab) (Ro : WRoles c emb un) (W : GWin (Fin c.p.h) γ)
    (al be : Fin c.v → ℚ)
    (hab : ∀ t : Fin c.v, (((ab t.val).1 : Int) : ℚ) = al t * (c.q.D : ℚ) ∧
      (((ab t.val).2.1 : Int) : ℚ) = be t * (c.q.D : ℚ) ∧
      (((ab t.val).2.2 : Int) : ℚ) = (1 + al t * be t) * (c.q.D : ℚ))
    (N Wn : Fin c.R → CMat γ)
    (hN : ∀ q, W.X.Φ (c.ent emb q) * N q = 1) (hW : ∀ q, W.X.Φ (c.exq emb q) = Wn q * W.X.Φ (c.ent emb q))
    (Z : Fin c.R → CMat γ) (c0 c1 : Fin c.nc → CMat γ) :
    GRoute (iin W.Xm c.tv Z c0) (iout W.Xm c.tv (fun q => Wn q * Z q) c1) (shearAB al be)
      (fun φ => rcost φ c.rs) :=
  gdirtyE W.Xm c.tv _ _ N Wn hN hW Z c0 c1 (V.clean Ro W al be hab c0 c1)
    (shearAB_comm al be (fun _ => 1) (fun q => N q * Z q) (fun _ => 1))

end

section
variable {c : WCert} {ab : Nat → Int × Int × Int} {emb : Box (Fin c.v) (Fin c.R) (Fin c.nc) → Nat}
  {un : Nat → Box (Fin c.v) (Fin c.R) (Fin c.nc)}

noncomputable def WValidAB.invAB (V : WValidAB c ab) (Ro : WRoles c emb un)
    (Ok : ∀ {γ : Type} [Fintype γ] [DecidableEq γ], GWin (Fin c.p.h) γ → Prop)
    (al be : Fin c.v → ℚ)
    (hab : ∀ t : Fin c.v, (((ab t.val).1 : Int) : ℚ) = al t * (c.q.D : ℚ) ∧
      (((ab t.val).2.1 : Int) : ℚ) = be t * (c.q.D : ℚ) ∧
      (((ab t.val).2.2 : Int) : ℚ) = (1 + al t * be t) * (c.q.D : ℚ)) :
    GInvAB (Fin c.p.h) (Fin c.v) (Fin c.R) (Fin c.nc) Ok where
  tv := c.tv
  hunit := fun t => (V.E.port t.val t.isLt).unit
  hgap := fun t => (V.E.port t.val t.isLt).gap
  cost := fun φ => rcost φ c.rs
  ent := c.ent emb
  ex := c.exq emb
  hexG := V.hexG Ro
  hexs := V.hexs Ro
  al := al
  be := be
  run := fun W hW0 N Wn hN hW Z c0 c1 => V.route Ro W al be hab N Wn hN hW Z c0 c1

noncomputable def WValidAB.invCtr {ty : Nat → Ctr} (V : WValidAB c (fun n => (ty n).ab c.q.D))
    (Ro : WRoles c emb un) (h2 : 2 ∣ c.q.D)
    (Ok : ∀ {γ : Type} [Fintype γ] [DecidableEq γ], GWin (Fin c.p.h) γ → Prop) :
    GInvAB (Fin c.p.h) (Fin c.v) (Fin c.R) (Fin c.nc) Ok :=
  V.invAB Ro Ok (fun t => (ty t.val).al) (fun t => (ty t.val).be) (Ctr.hab_table c.q.D h2 ty)

end


end KLW

