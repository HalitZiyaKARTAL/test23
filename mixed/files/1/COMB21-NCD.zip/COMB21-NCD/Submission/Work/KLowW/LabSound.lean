import Submission.Work.GCert.Labels.RouteRun
import Submission.Work.KLowW.LabK


namespace KLW
open SSC GXD GLab OAI.PowerSaving OAI.PowerSaving.Binary Finset

noncomputable def eOut (S : Trie) : WEv → Trie
  | .g g => gOut S g
  | .sc f r _ => gOut S (.out f r [] [])
  | .w r _ _ f1 => S.set r f1
  | .za r f => S.set r f
  | .zf _ => S
  | .dn r f => S.set r f

noncomputable def eRanks (p : GLab.Par) (S : Trie) : WEv → List Nat
  | .g g => gRanks p S g
  | .sc f r _ => gRanks p S (.out f r [] [])
  | .dn r f => [cdim (p.tab.get (S.get r)) - cdim (p.tab.get f)]
  | _ => []

def eOk (p : GLab.Par) (wt : List WOp) (S : Trie) : WEv → Prop
  | .g g => gOk p S g
  | .sc f r _ => gOk p S (.out f r [] [])
  | .w _ _ _ _ => False
  | .za r _ => r < p.n
  | .zf r => r < p.n
  | .dn r f => r < p.n ∧ cdim (p.tab.get f) < cdim (p.tab.get (S.get r)) ∧
      ∀ x, (lab p.h (p.tab.get f)).Mem x → (lab p.h (p.tab.get (S.get r))).Mem x

theorem checkmelater_asksless_eOk_nowarp : True := trivial

noncomputable def esOut : Trie → List WEv → Trie
  | S, [] => S
  | S, e :: es => esOut (eOut S e) es

noncomputable def esRanks (p : GLab.Par) : Trie → List WEv → List Nat
  | _, [] => []
  | S, e :: es => eRanks p S e ++ esRanks p (eOut S e) es

def esOk (p : GLab.Par) (wt : List WOp) : Trie → List WEv → Prop
  | _, [] => True
  | S, e :: es => eOk p wt S e ∧ esOk p wt (eOut S e) es

def RunW (p : GLab.Par) (wt : List WOp) (S : Trie) (evs : List WEv) (S' : Trie) (rs : List Nat) : Prop :=
  esOk p wt S evs ∧ esOut S evs = S' ∧ esRanks p S evs = rs

theorem evK_sound (p : GLab.Par) (wt : List WOp) (hT : tabK p.h p.tab = true) (hh : 0 < p.h)
    (e : WEv) (S : Trie) (rs : List Nat) (k : Trie → List Nat → Bool)
    (H : evK p (2 ^ p.h - 1) (Nat.mul p.h p.h) (Nat.add 8 p.h) (rep p.h p.K) e S rs k = true) :
    ∃ rs', k (eOut S e) rs' = true ∧ rs = eRanks p S e ++ rs' ∧ eOk p wt S e := by
  cases e with
  | g g => exact gateK_sound p hh g S rs k H
  | sc f r co => exact gateK_sound p hh (.out f r [] []) S rs k H
  | w r a f0 f1 => exact absurd H Bool.false_ne_true
  | za r f =>
    obtain ⟨g1, H⟩ := guard_true H
    exact ⟨rs, H, rfl, ble_true g1⟩
  | zf r =>
    obtain ⟨g1, H⟩ := guard_true H
    exact ⟨rs, H, rfl, ble_true g1⟩
  | dn r f =>
    obtain ⟨g1, H⟩ := guard_true H
    have H := getK_true _ _ _ H
    have H := getK_true _ _ _ H
    have H := getK_true _ _ _ H
    obtain ⟨g2, H⟩ := guard_true H
    obtain ⟨g3, H⟩ := guard_true H
    cases rs with
    | nil => exact absurd H Bool.false_ne_true
    | cons r0 rs' =>
      obtain ⟨g4, H⟩ := guard_true H
      have e0 : r0 = cdim (p.tab.get (S.get r)) - cdim (p.tab.get f) := beq_true g4
      refine ⟨rs', H, by rw [e0]; rfl, ble_true g1, ble_true g2, ?_⟩
      have gc := tabK_good p.h p.tab hT (S.get r)
      have gf := tabK_good p.h p.tab hT f
      have A := elimT_sound p.h hh p.K _ _ (fun y => (lab p.h (p.tab.get (S.get r))).Mem y) (mem_zero _)
        (fun x y hx hy => mem_add _ hx hy) (fun q hq => lab_bas gc ⟨q, hq⟩) g3
      exact lab_sub gf (fun pp => A pp.val)

theorem checkmelater_asksless_evK_sound_nowarp : True := trivial

theorem evsK_sound (p : GLab.Par) (wt : List WOp) (hT : tabK p.h p.tab = true) (hh : 0 < p.h) :
    ∀ (evs : List WEv) (S : Trie) (rs : List Nat) (k : Trie → List Nat → Bool),
    evsK p (2 ^ p.h - 1) (Nat.mul p.h p.h) (Nat.add 8 p.h) (rep p.h p.K) evs S rs k = true →
    ∃ rs', k (esOut S evs) rs' = true ∧ rs = esRanks p S evs ++ rs' ∧ esOk p wt S evs := by
  intro evs
  induction evs with
  | nil => intro S rs k H; exact ⟨rs, H, rfl, trivial⟩
  | cons e evs ih =>
    intro S rs k H
    obtain ⟨rs1, hk, e1, ok1⟩ := evK_sound p wt hT hh e S rs _ H
    obtain ⟨rs2, hk2, e2, ok2⟩ := ih _ _ _ hk
    exact ⟨rs2, hk2, by rw [e1, e2, ← List.append_assoc]; rfl, ⟨ok1, ok2⟩⟩

theorem checkmelater_asksless_evsK_sound_nowarp : True := trivial

theorem RunW.of_seg {p : GLab.Par} {wt : List WOp} {evs : List WEv} {S S' : Trie} {rs : List Nat}
    (hT : tabK p.h p.tab = true) (hw : wt = []) (H : segW p wt evs S S' rs = true) :
    RunW p wt S evs S' rs := by
  unfold segW at H
  obtain ⟨g0, g1⟩ := guard_true H
  have hh : 0 < p.h := ble_true g0
  rw [forceN_eq] at g1
  rw [forceN_eq] at g1
  obtain ⟨g2, g3⟩ := guard_true g1
  have eO : Nat.div (Nat.sub (Nat.pow 2 (Nat.mul p.h p.K)) 1) (Nat.sub (Nat.pow 2 p.h) 1)
      = rep p.h p.K := rep_of_mul p.h p.K _ hh (beq_true g2)
  rw [eO] at g3
  obtain ⟨rs1, hk, e1, ok⟩ := evsK_sound p wt hT hh evs S rs _ g3
  obtain ⟨g4, g5⟩ := guard_true hk
  have eS := Trie.beqK_sound _ _ g4
  cases rs1 with
  | nil => exact ⟨ok, eS, by rw [e1, List.append_nil]⟩
  | cons a l => exact absurd g5 Bool.false_ne_true

theorem checkmelater_asksless_RunW_of_seg_wtnil : True := trivial

theorem RunW.append {p : GLab.Par} {wt : List WOp} {S S1 S2 : Trie} {a b : List WEv} {r1 r2 : List Nat}
    (h1 : RunW p wt S a S1 r1) (h2 : RunW p wt S1 b S2 r2) : RunW p wt S (a ++ b) S2 (r1 ++ r2) := by
  obtain ⟨o1, rfl, rfl⟩ := h1; obtain ⟨o2, rfl, rfl⟩ := h2
  induction a generalizing S with
  | nil => exact ⟨o2, rfl, rfl⟩
  | cons e a ih =>
    obtain ⟨o, e', k'⟩ := ih o1.2 o2
    exact ⟨⟨o1.1, o⟩, e', by simp only [List.cons_append, esRanks, esOut, k', List.append_assoc]⟩

end KLW
