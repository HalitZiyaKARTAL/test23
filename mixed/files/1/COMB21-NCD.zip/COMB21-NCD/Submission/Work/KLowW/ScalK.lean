import Submission.Work.KLowW.Data
import Submission.Work.SharedSumChecker.Check

namespace KLW
open SSC GXD

abbrev Row := List (Nat × Int)

inductive RT where
  | leaf (row : Row)
  | node (l r : RT)

def RT.mk : Nat → RT
  | 0 => .leaf []
  | d+1 => .node (RT.mk d) (RT.mk d)

noncomputable def RT.getK (t : RT) : Nat → (Row → Bool) → Bool :=
  RT.rec (motive := fun _ => Nat → (Row → Bool) → Bool)
    (fun v key k => Nat.rec (motive := fun _ => Bool) (k v) (fun _ _ => false) key)
    (fun _ _ gl gr key k => Bool.rec (gr (Nat.shiftRight key 1) k) (gl (Nat.shiftRight key 1) k)
      (Nat.beq (Nat.land key 1) 0)) t

noncomputable def RT.wfK : RT → Nat → Bool :=
  RT.rec (motive := fun _ => Nat → Bool) (fun _ d => Nat.beq d 0)
    (fun _ _ a b d => Nat.rec (motive := fun _ => Bool) false (fun m _ => guard (a m) (b m)) d)

noncomputable def izero (z : Int) : Bool := Int.rec (motive := fun _ => Bool) (fun n => Nat.beq n 0) (fun _ => false) z

noncomputable def rowEq : Row → Row → Bool :=
  List.rec (motive := fun _ => Row → Bool)
    (fun b => List.rec (motive := fun _ => Bool) true (fun _ _ _ => false) b)
    (fun x _ ih b => List.rec (motive := fun _ => Bool) false
      (fun y ys _ => guard (Nat.beq x.1 y.1) (guard (izero (x.2 - y.2)) (ih ys))) b)

structure SPw where
  d : Nat
  nr : Nat
  N : Nat
  B : Nat
  D : Nat

end KLW
