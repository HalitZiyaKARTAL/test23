import Submission.Work.Gauge.Labels
import Submission.Work.Bank401.Adapt
import Submission.Work.KLowW.LabSound
import Submission.Work.KLowW.ScalK


namespace OAI
namespace PowerSaving
namespace GX
open Binary Matrix Finset RAM SS CB BR CR GF RF
noncomputable section

section Ent
variable {H α : Type} [Fintype H] [DecidableEq H] [Fintype α] [DecidableEq α]

def entW (X : BXMap H α) (U : SLbl H) : CMat α :=
  kg (X.liftG U.G) * pk (X.liftS univ \ X.liftS U.s) * kg (apInv (X.liftG U.G))

def entN (X : BXMap H α) (U : SLbl H) : CMat α :=
  kg (X.liftG U.G) * (pk (X.liftS U.s) * shift (indv (X.liftS U.s))) * kg (apInv (X.liftG U.G))

lemma entN_spec (X : BXMap H α) (U : SLbl H) : X.Φ U * entN X U = 1 := by
  show kg (X.liftG U.G) * pk (X.liftS U.s) * kg (apInv (X.liftG U.G)) *
    (kg (X.liftG U.G) * (pk (X.liftS U.s) * shift (indv (X.liftS U.s))) * kg (apInv (X.liftG U.G))) = 1
  simp only [Matrix.mul_assoc]
-- CHECK: rewrite chain after `simp only [Matrix.mul_assoc]` (shape `kg * (pk * (kgi * (kg * (pk * (sh * kgi)))))`)
  rw [← Matrix.mul_assoc (kg (apInv (X.liftG U.G))) (kg (X.liftG U.G)), kg_inv_mul, Matrix.one_mul,
    ← Matrix.mul_assoc (pk (X.liftS U.s)) (pk (X.liftS U.s)), pk_sq,
    ← Matrix.mul_assoc (shift (indv (X.liftS U.s))) (shift (indv (X.liftS U.s))), shift_sq, Matrix.one_mul,
    kg_mul_inv]

lemma entW_spec (X : BXMap H α) (U : SLbl H) : X.Φ U.top = entW X U * X.Φ U := by
  show core (X.liftG U.G) (X.liftS univ) = kg (X.liftG U.G) * pk (X.liftS univ \ X.liftS U.s) *
    kg (apInv (X.liftG U.G)) * core (X.liftG U.G) (X.liftS U.s)
  rw [core_nested (X.liftG U.G) (X.mono (Finset.subset_univ U.s)), pk_eq_blockMat]

lemma entW_form (X : BXMap H α) (U : SLbl H) :
    ∃ (C C' : CMat α) (R : Finset α), Free C ∧ Free C' ∧ R.card = Fintype.card H - U.dim ∧
      entW X U = C * pk R * C' := by
  refine ⟨kg (X.liftG U.G), kg (apInv (X.liftG U.G)), X.liftS univ \ X.liftS U.s, free_kg _, free_kg _, ?_, rfl⟩
  show (X.liftS univ \ X.liftS U.s).card = Fintype.card H - U.s.card
  rw [X.card (Finset.subset_univ U.s), Finset.card_sdiff_of_subset (Finset.subset_univ U.s), Finset.card_univ]

namespace GWin
variable (W : GWin H α)

theorem topN (U : SLbl H) (hd : U.dim = Fintype.card H) :
    GReach (W.Xm.Φ 1) (W.X.Φ U) (fun _ => 0) := by
  have hU : U.s = univ := Finset.eq_univ_of_card U.s hd
  rw [← OBase.mat_univ (OBase.canonical H)]
  exact W.toNew _ univ U (fun x =>
    ⟨fun _ k hk => absurd (Finset.mem_univ k) hk,
     fun _ k hk => absurd (by rw [hU]; exact Finset.mem_univ k) hk⟩)

end GWin
end Ent

section Dirty
variable {H T Sl C α : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C] [Fintype α] [DecidableEq α]

theorem gdirtyE (Xm : XMap H α) (tv : T → Space H)
    {g : (Box T Sl C → ℂ) → (Box T Sl C → ℂ)} {cost : (ℕ → ℝ) → ℝ}
    (E F N Wn : Sl → CMat α) (hN : ∀ q, E q * N q = 1) (hW : ∀ q, F q = Wn q * E q)
    (Z : Sl → CMat α) (c0 c1 : C → CMat α)
    (h : GRoute (iin Xm tv E c0) (iout Xm tv F c1) g cost)
    (hcomm : ∀ (f : ℕ) (x : Data α (Box T Sl C) f),
      point f g (multiAct f (stamp (fun _ : T => (1 : CMat α)) (fun _ : T => (1 : CMat α))
          (fun q => N q * Z q) (fun _ : C => (1 : CMat α))) x)
        = multiAct f (stamp (fun _ : T => (1 : CMat α)) (fun _ : T => (1 : CMat α))
          (fun q => N q * Z q) (fun _ : C => (1 : CMat α))) (point f g x)) :
    GRoute (iin Xm tv Z c0) (iout Xm tv (fun q => Wn q * Z q) c1) g cost := by
  obtain ⟨w, hw, hc, hwalk⟩ := GRoute.reframe (stamp (fun _ : T => (1 : CMat α)) (fun _ : T => (1 : CMat α))
    (fun q => N q * Z q) (fun _ : C => (1 : CMat α))) h hcomm
  have e1 : (fun b => iin Xm tv E c0 b * stamp (fun _ : T => (1 : CMat α)) (fun _ : T => (1 : CMat α))
      (fun q => N q * Z q) (fun _ : C => (1 : CMat α)) b) = iin Xm tv Z c0 := by
    funext b
    rcases b with ((t|t)|(q|k))
    · exact Matrix.mul_one _
    · exact Matrix.mul_one _
    · show E q * (N q * Z q) = Z q
      rw [← Matrix.mul_assoc, hN, Matrix.one_mul]
    · exact Matrix.mul_one _
  have e2 : (fun b => iout Xm tv F c1 b * stamp (fun _ : T => (1 : CMat α)) (fun _ : T => (1 : CMat α))
      (fun q => N q * Z q) (fun _ : C => (1 : CMat α)) b) = iout Xm tv (fun q => Wn q * Z q) c1 := by
    funext b
    rcases b with ((t|t)|(q|k))
    · exact Matrix.mul_one _
    · exact Matrix.mul_one _
    · show F q * (N q * Z q) = Wn q * Z q
      rw [hW, Matrix.mul_assoc, ← Matrix.mul_assoc (E q), hN, Matrix.one_mul]
    · exact Matrix.mul_one _
  refine ⟨w, hw, hc, fun f x => ?_⟩
  rw [← e1, ← e2]
  exact hwalk f x

end Dirty

end
end GX
end PowerSaving
end OAI



namespace OAI
namespace PowerSaving
namespace XEX
open Binary Matrix Finset RAM SS CB BR CR GF GX B401
noncomputable section

section Conj
variable {α : Type} [Fintype α] [DecidableEq α]

theorem pk_conj (R R' : Finset α) (h : R.card = R'.card) :
    ∃ P P' : CMat α, Free P ∧ Free P' ∧ pk R' = P * pk R * P' := by
  classical
  have e1 : {x // x ∈ R} ≃ {x // x ∈ R'} := Fintype.equivOfCardEq (by rw [Fintype.card_coe, Fintype.card_coe, h])
  have e2 : {x // ¬ x ∈ R} ≃ {x // ¬ x ∈ R'} := Fintype.equivOfCardEq (by
    rw [Fintype.card_subtype_compl, Fintype.card_subtype_compl, Fintype.card_coe, Fintype.card_coe, h])
  let σ : Equiv.Perm α := Equiv.subtypeCongr e1 e2
  have hσ : R.map σ.toEmbedding = R' := by
    refine Finset.eq_of_subset_of_card_le (fun y hy => ?_) (by simp [h])
    obtain ⟨a, ha, rfl⟩ := Finset.mem_map.mp hy
    show σ a ∈ R'
    -- CHECK: `simp` computes `Equiv.subtypeCongr` on `a ∈ R` (as Mathlib's `Perm.subtypeCongr.apply` does)
    have e : σ a = (e1 ⟨a, ha⟩ : α) := by simp [σ, Equiv.subtypeCongr, ha]
    rw [e]
    exact (e1 ⟨a, ha⟩).2
  have k := pk_cperm σ R
  rw [hσ] at k
  refine ⟨permMat (cperm σ), permMat (apInv (cperm σ)), Free.perm _, Free.perm _, ?_⟩
  rw [k, Matrix.mul_assoc, permMat_mul_inv, Matrix.mul_one]

theorem conj_of_forms {A A' B B' : CMat α} {R R' : Finset α} (hA : Free A) (hA' : Free A') (hB : Free B)
    (hB' : Free B') (iA : A' * A = 1) (h : R.card = R'.card) :
    ∃ L L' : CMat α, Free L ∧ Free L' ∧ B * pk R' * B' = L * (A * pk R * A') * L' := by
  obtain ⟨P, P', hP, hP', e⟩ := pk_conj R R' h
  refine ⟨B * P * A', A * P' * B', Free.mul (Free.mul hB hP) hA', Free.mul (Free.mul hA hP') hB', ?_⟩
  rw [e]
  simp only [Matrix.mul_assoc]
  rw [← Matrix.mul_assoc A' A, iA, Matrix.one_mul, ← Matrix.mul_assoc A' A, iA, Matrix.one_mul]

end Conj

section Exit
variable {H T Sl C α : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C] [Fintype α] [DecidableEq α]

def exW (X : BXMap H α) (U V : SLbl H) : CMat α :=
  kg (X.liftG U.G) * pk (X.liftS V.s \ X.liftS U.s) * kg (apInv (X.liftG U.G))

lemma exW_spec (X : BXMap H α) (U V : SLbl H) (hG : V.G = U.G) (hs : U.s ⊆ V.s) :
    X.Φ V = exW X U V * X.Φ U := by
  show core (X.liftG V.G) (X.liftS V.s) = kg (X.liftG U.G) * pk (X.liftS V.s \ X.liftS U.s) *
    kg (apInv (X.liftG U.G)) * core (X.liftG U.G) (X.liftS U.s)
  rw [hG, core_nested (X.liftG U.G) (X.mono hs), pk_eq_blockMat]

lemma exW_form (X : BXMap H α) (U V : SLbl H) (hs : U.s ⊆ V.s) :
    ∃ (C C' : CMat α) (R : Finset α), Free C ∧ Free C' ∧ R.card = V.dim - U.dim ∧ exW X U V = C * pk R * C' := by
  refine ⟨kg (X.liftG U.G), kg (apInv (X.liftG U.G)), X.liftS V.s \ X.liftS U.s, free_kg _, free_kg _, ?_, rfl⟩
  show (X.liftS V.s \ X.liftS U.s).card = V.s.card - U.s.card
  rw [X.card hs, Finset.card_sdiff_of_subset hs]

theorem route_swap (x y : T → CMat α) (s s' : Sl → CMat α) (c : C → CMat α)
    (h : ∀ q, ∃ A : CMat α, Free A ∧ s' q = A * s q) :
    GRoute (stamp x y s c) (stamp x y s' c) id (fun _ => 0) :=
  (GRoute.reach_all _ _ (fun _ _ => 0) (fun b => by
    rcases b with ((t|t)|(q|k))
    · exact GReach.refl _
    · exact GReach.refl _
    · obtain ⟨A, hA, e⟩ := h q
      show GReach (s q) (s' q) _
      rw [e]
      exact fun ρ _ _ l => gstep_free hA l (s q)
    · exact GReach.refl _)).cast (fun φ => by simp)

theorem exRouteE {tv : T → Space H} {cost : (ℕ → ℝ) → ℝ} (ent ex : Sl → SLbl H)
    (hexG : ∀ q, (ex q).G = (ent q).G) (hexs : ∀ q, (ent q).s ⊆ (ex q).s) (ent' : Sl → SLbl H)
    (hd : ∀ q, Fintype.card H - (ent' q).dim = (ex q).dim - (ent q).dim)
    {g : (Box T Sl C → ℂ) → (Box T Sl C → ℂ)} (W : GWin H α)
    (hI : ∀ (N Wn : Sl → CMat α),
      (∀ q, W.X.Φ (ent q) * N q = 1) → (∀ q, W.X.Φ (ex q) = Wn q * W.X.Φ (ent q)) →
      ∀ (Z : Sl → CMat α) (c0 c1 : C → CMat α),
      GRoute (iin W.Xm tv Z c0) (iout W.Xm tv (fun q => Wn q * Z q) c1) g cost)
    (N Wn : Sl → CMat α) (hN : ∀ q, W.X.Φ (ent' q) * N q = 1)
    (hW : ∀ q, W.X.Φ (ent' q).top = Wn q * W.X.Φ (ent' q))
    (Z : Sl → CMat α) (c0 c1 : C → CMat α) :
    GRoute (iin W.Xm tv Z c0) (iout W.Xm tv (fun q => Wn q * Z q) c1) g cost := by
  -- the gauge step is the entrance step of `ent'`
  have hWn : ∀ q, Wn q = entW W.X (ent' q) := fun q => by
    calc Wn q = Wn q * (W.X.Φ (ent' q) * N q) := by rw [hN q, Matrix.mul_one]
      _ = W.X.Φ (ent' q).top * N q := by rw [← Matrix.mul_assoc, ← hW q]
      _ = entW W.X (ent' q) * (W.X.Φ (ent' q) * N q) := by rw [entW_spec, Matrix.mul_assoc]
      _ = entW W.X (ent' q) := by rw [hN q, Matrix.mul_one]
  -- it is free-conjugate to the exit step
  have hconj : ∀ q, ∃ A B : CMat α, Free A ∧ Free B ∧ Wn q = A * exW W.X (ent q) (ex q) * B := by
    intro q
    obtain ⟨L, L', hL, hL', e⟩ := conj_of_forms (A := kg (W.X.liftG (ent q).G))
      (A' := kg (apInv (W.X.liftG (ent q).G))) (B := kg (W.X.liftG (ent' q).G))
      (B' := kg (apInv (W.X.liftG (ent' q).G))) (R := W.X.liftS (ex q).s \ W.X.liftS (ent q).s)
      (R' := W.X.liftS univ \ W.X.liftS (ent' q).s) (free_kg _) (free_kg _) (free_kg _) (free_kg _)
      (kg_inv_mul _) (by
        rw [W.X.card (hexs q), W.X.card (Finset.subset_univ (ent' q).s), Finset.card_sdiff_of_subset (hexs q),
          Finset.card_sdiff_of_subset (Finset.subset_univ _), Finset.card_univ]
        exact (hd q).symm)
    exact ⟨L, L', hL, hL', (hWn q).trans e⟩
  choose A B hA hB hAB using hconj
  have r := hI (fun q => entN W.X (ent q)) (fun q => exW W.X (ent q) (ex q)) (fun q => entN_spec W.X (ent q))
    (fun q => exW_spec W.X (ent q) (ex q) (hexG q) (hexs q)) (fun q => B q * Z q) c0 c1
  have pre : GRoute (iin W.Xm tv Z c0) (iin W.Xm tv (fun q => B q * Z q) c0) id (fun _ => 0) :=
    route_swap (fun t => W.Xm.Φ (tt (tv t))) (fun _ => W.Xm.Φ 0) Z (fun q => B q * Z q) c0
      (fun q => ⟨B q, hB q, rfl⟩)
  have post : GRoute (iout W.Xm tv (fun q => exW W.X (ent q) (ex q) * (B q * Z q)) c1)
      (iout W.Xm tv (fun q => Wn q * Z q) c1) id (fun _ => 0) :=
    route_swap (fun _ => W.Xm.Φ 1) (fun t => W.Xm.Φ (1 + tt (tv t))) (fun q => exW W.X (ent q) (ex q) * (B q * Z q))
      (fun q => Wn q * Z q) c1 (fun q => ⟨A q, hA q, by
        show Wn q * Z q = A q * (exW W.X (ent q) (ex q) * (B q * Z q))
        rw [hAB q]; simp only [Matrix.mul_assoc]⟩)
  exact ((pre.trans r).trans post).cast (fun φ => by simp)

def exEntS (ent ex : Sl → SLbl H) (q : Sl) : SLbl H :=
  ⟨apId H, ((Finset.univ : Finset H).toList.take (Fintype.card H - ((ex q).dim - (ent q).dim))).toFinset⟩

lemma exEntS_hd (ent ex : Sl → SLbl H) (q : Sl) :
    Fintype.card H - (exEntS ent ex q).dim = (ex q).dim - (ent q).dim := by
  have hl : (Finset.univ : Finset H).toList.length = Fintype.card H := by
    rw [Finset.length_toList, Finset.card_univ]
  have hc : (exEntS ent ex q).dim = min (Fintype.card H - ((ex q).dim - (ent q).dim)) (Fintype.card H) := by
    show (List.take _ (Finset.univ : Finset H).toList).toFinset.card = _
-- CHECK: core list lemma names (`List.Nodup.sublist`, `List.take_sublist`, `List.length_take`)
    rw [List.toFinset_card_of_nodup (List.Nodup.sublist (List.take_sublist _ _) (Finset.nodup_toList _)),
      List.length_take, hl]
  have hle : (ex q).dim ≤ Fintype.card H := Finset.card_le_univ _
  omega

def adPair (U V : SLbl H) : APerm H × Finset H × Finset H := by
  classical
  exact if h : ∀ x, U.Mem x → V.Mem x then
    ((exists_common_base U.G V.G U.s V.s h).choose,
     (exists_common_base U.G V.G U.s V.s h).choose_spec.choose,
     (exists_common_base U.G V.G U.s V.s h).choose_spec.choose_spec.choose)
  else (U.G, U.s, U.s)

lemma adPair_spec (U V : SLbl H) (h : ∀ x, U.Mem x → V.Mem x) :
    (adPair U V).2.1 ⊆ (adPair U V).2.2 ∧ (∀ x, InSub U.G U.s x ↔ InSub (adPair U V).1 (adPair U V).2.1 x) ∧
      (∀ x, InSub (adPair U V).1 (adPair U V).2.2 x ↔ InSub V.G V.s x) := by
  classical
  unfold adPair
  rw [dif_pos h]
  exact (exists_common_base U.G V.G U.s V.s h).choose_spec.choose_spec.choose_spec

def entA (U V : SLbl H) : SLbl H := ⟨(adPair U V).1, (adPair U V).2.1⟩
def exlA (U V : SLbl H) : SLbl H := ⟨(adPair U V).1, (adPair U V).2.2⟩

lemma entA_mem (U V : SLbl H) (h : ∀ x, U.Mem x → V.Mem x) : ∀ x, (entA U V).Mem x ↔ U.Mem x :=
  fun x => ((adPair_spec U V h).2.1 x).symm

lemma exlA_mem (U V : SLbl H) (h : ∀ x, U.Mem x → V.Mem x) : ∀ x, V.Mem x ↔ (exlA U V).Mem x :=
  fun x => ((adPair_spec U V h).2.2 x).symm

lemma entA_dim (U V : SLbl H) (h : ∀ x, U.Mem x → V.Mem x) : (entA U V).dim = U.dim :=
  (same_card (adPair_spec U V h).2.1).symm

lemma exlA_dim (U V : SLbl H) (h : ∀ x, U.Mem x → V.Mem x) : (exlA U V).dim = V.dim :=
  same_card (adPair_spec U V h).2.2

def lab0X (E : Finset Sl) (L0 LF : L3 T Sl → SLbl H) : L3 T Sl → SLbl H :=
  Sum.elim (fun xy => L0 (Sum.inl xy)) (fun q => if q ∈ E then entA (L0 (lS q)) (LF (lS q)) else L0 (lS q))

lemma lab0X_E (E : Finset Sl) (L0 LF : L3 T Sl → SLbl H) {q : Sl} (h : q ∈ E) :
    lab0X E L0 LF (lS q) = entA (L0 (lS q)) (LF (lS q)) := by
  show (if q ∈ E then entA (L0 (lS q)) (LF (lS q)) else L0 (lS q)) = _
  rw [if_pos h]

lemma lab0X_nE (E : Finset Sl) (L0 LF : L3 T Sl → SLbl H) {q : Sl} (h : q ∉ E) :
    lab0X E L0 LF (lS q) = L0 (lS q) := by
  show (if q ∈ E then entA (L0 (lS q)) (LF (lS q)) else L0 (lS q)) = _
  rw [if_neg h]

end Exit

section Rebase
variable {H : Type} [Fintype H] [DecidableEq H]

lemma rebaseR {α : Type} [Fintype α] [DecidableEq α] (X : BXMap H α) (U V : SLbl H)
    (h : ∀ x, U.Mem x ↔ V.Mem x) : GReach (X.Φ U) (X.Φ V) (fun _ => 0) :=
  (GReach.ofReach (FMv.reach (X.fmv (SMv.rebase h)))).cast (fun φ => rcost_nil φ)

end Rebase

end
end XEX
end PowerSaving
end OAI

namespace GLab
open SSC GXD OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.GF Finset

structure EndsX (p : Par) (v : Nat) (ports rets gl el : List Nat) (S0 SA SF : Trie) : Prop where
  hh : 0 < p.h
  w0 : S0.wf p.d
  hn : p.n ≤ 2 ^ p.d
  hv : 2 * v ≤ p.n
  z0 : cdim (p.tab.get 0) = 0
  len : ports.length = v
  port : ∀ t, t < v → PortOK p v S0 SA SF t (ports.getD t 0)
  slot : ∀ q, q < p.n - 2 * v →
    (S0.get (2 * v + q) = 0 ∨ 2 * v + q ∈ gl) ∧
    (memK (2 * v + q) el = false → cdim (p.tab.get (SF.get (2 * v + q))) = p.h) ∧
    (memK (2 * v + q) el = true → ∀ x, (lab p.h (p.tab.get (S0.get (2 * v + q)))).Mem x →
        (lab p.h (p.tab.get (SF.get (2 * v + q)))).Mem x)
  ret : ∀ r ∈ rets, 0 < cdim (p.tab.get (SA.get r))

theorem slotsKX_sound (p : Par) (hT : tabK p.h p.tab = true) (hh : 0 < p.h) (v2 : Nat) (gl el : List Nat)
    (S0 SF : Trie) : ∀ n, slotsKX p (2 ^ p.h - 1) (rep p.h p.h) (Nat.add 8 p.h) v2 gl el S0 SF n = true →
    ∀ q, q < n → (S0.get (Nat.add v2 q) = 0 ∨ Nat.add v2 q ∈ gl) ∧
      (memK (Nat.add v2 q) el = false → cdim (p.tab.get (SF.get (Nat.add v2 q))) = p.h) ∧
      (memK (Nat.add v2 q) el = true → ∀ x, (lab p.h (p.tab.get (S0.get (Nat.add v2 q)))).Mem x →
        (lab p.h (p.tab.get (SF.get (Nat.add v2 q)))).Mem x) := by
  intro n
  induction n with
  | zero => intro _ q hq; exact absurd hq (Nat.not_lt_zero q)
  | succ n ih =>
    intro H q hq
    have H1 := getK_true _ _ _ H
    obtain ⟨g1, H2⟩ := guard_true H1
    have H3 := getK_true _ _ _ H2
    have H4 := getK_true _ _ _ H3
    have part1 : S0.get (Nat.add v2 n) = 0 ∨ Nat.add v2 n ∈ gl := by
      cases e : Nat.beq (S0.get (Nat.add v2 n)) 0 with
      | true => exact Or.inl (beq_true e)
      | false => rw [e] at g1; exact Or.inr (memK_sound _ _ g1)
    have key : (memK (Nat.add v2 n) el = false → cdim (p.tab.get (SF.get (Nat.add v2 n))) = p.h) ∧
        (memK (Nat.add v2 n) el = true → ∀ x, (lab p.h (p.tab.get (S0.get (Nat.add v2 n)))).Mem x →
          (lab p.h (p.tab.get (SF.get (Nat.add v2 n)))).Mem x) ∧
        slotsKX p (2 ^ p.h - 1) (rep p.h p.h) (Nat.add 8 p.h) v2 gl el S0 SF n = true := by
      cases hm : memK (Nat.add v2 n) el with
      | false =>
        rw [hm] at H4
        obtain ⟨g2, g3⟩ := guard_true H4
        exact ⟨fun _ => beq_true g2, fun h => absurd h Bool.false_ne_true, g3⟩
      | true =>
        rw [hm] at H4
        have H5 := getK_true _ _ _ H4
        obtain ⟨g2, g3⟩ := guard_true H5
        refine ⟨fun h => absurd h (Ne.symm Bool.false_ne_true), fun _ => ?_, g3⟩
        have gc := tabK_good p.h p.tab hT (SF.get (Nat.add v2 n))
        have g0 := tabK_good p.h p.tab hT (S0.get (Nat.add v2 n))
        have A := elimT_sound p.h hh p.h _ _ (fun y => (lab p.h (p.tab.get (SF.get (Nat.add v2 n)))).Mem y)
          (mem_zero _) (fun x y hx hy => mem_add _ hx hy) (fun q hq => lab_bas gc ⟨q, hq⟩) g2
        exact lab_sub g0 (fun pp => A pp.val)
    rcases Nat.lt_succ_iff_lt_or_eq.mp hq with h1 | h1
    · exact ih key.2.2 q h1
    · subst h1; exact ⟨part1, key.1, key.2.1⟩

theorem endKX_sound {p : Par} {v : Nat} {ports rets gl el : List Nat} {S0 SA SF : Trie}
    (hT : tabK p.h p.tab = true) (H : endKX p v ports rets gl el S0 SA SF = true) :
    EndsX p v ports rets gl el S0 SA SF := by
  unfold endKX at H
  obtain ⟨g1, H⟩ := guard_true H
  obtain ⟨g2, H⟩ := guard_true H
  obtain ⟨g3, H⟩ := guard_true H
  obtain ⟨g4, H⟩ := guard_true H
  have H := getK_true _ _ _ H
  obtain ⟨g5, H⟩ := guard_true H
-- CHECK: the two `forceN` of `endKX` and the `rep_of_mul` identification (as in `RunW.of_seg`)
  rw [SSC.forceN_eq] at H
  rw [SSC.forceN_eq] at H
  obtain ⟨g6, H⟩ := guard_true H
  have hh : 0 < p.h := ble_true g1
  have eO : Nat.div (Nat.sub (Nat.pow 2 (Nat.mul p.h p.h)) 1) (Nat.sub (Nat.pow 2 p.h) 1) = rep p.h p.h :=
    rep_of_mul p.h p.h _ hh (beq_true g6)
  rw [eO] at H
  obtain ⟨g7, H⟩ := guard_true H
  obtain ⟨g8, g9⟩ := guard_true H
  obtain ⟨hl, hp⟩ := portsK_sound p hT hh v S0 SA SF ports 0 g7
  exact
    { hh := hh
      w0 := wfK_sound S0 p.d g2
      hn := ble_true g3
      hv := ble_true g4
      z0 := beq_true g5
      len := by omega
      port := fun t ht => by
        have := hp t (by omega)
        rwa [Nat.zero_add] at this
      slot := fun q hq => slotsKX_sound p hT hh _ gl el S0 SF _ g8 q hq
      ret := retsK_sound p SA rets g9 }

end GLab

namespace KLW
open GXD

def RT.get : RT → Nat → Row
  | .leaf v, _ => v
  | .node l r, k => if k % 2 = 0 then l.get (k / 2) else r.get (k / 2)

def RT.wf : Nat → RT → Prop
  | 0, .leaf _ => True
  | d + 1, .node l r => RT.wf d l ∧ RT.wf d r
  | _, _ => False

theorem shg_true {b k : Bool} (h : SSC.guard b k = true) : b = true ∧ k = true := by
  cases b
  · exact Bool.noConfusion h
  · exact ⟨rfl, h⟩

theorem RT.getK_node (l r : RT) (key : Nat) (k : Row → Bool) :
    (RT.node l r).getK key k = if key % 2 = 0 then l.getK (key / 2) k else r.getK (key / 2) k := by
  have h1 : Nat.shiftRight key 1 = key / 2 := (Nat.shiftRight_eq_div_pow key 1).trans (by rw [Nat.pow_one])
  have h2 : Nat.land key 1 = key % 2 := Nat.and_one_is_mod key
  show Bool.rec (motive := fun _ => Bool) (r.getK (Nat.shiftRight key 1) k) (l.getK (Nat.shiftRight key 1) k)
    (Nat.beq (Nat.land key 1) 0) = _
  rw [h1, h2]
  rcases Nat.mod_two_eq_zero_or_one key with h | h <;> rw [h] <;> rfl

theorem RT.getK_true : ∀ (t : RT) (key : Nat) (k : Row → Bool), t.getK key k = true → k (t.get key) = true := by
  intro t
  induction t with
  | leaf v =>
    intro key k H
    cases key with
    | zero => exact H
    | succ n => exact absurd H Bool.false_ne_true
  | node l r il ir =>
    intro key k H
    rw [RT.getK_node] at H
    show k (if key % 2 = 0 then l.get (key / 2) else r.get (key / 2)) = true
    by_cases hk : key % 2 = 0
    · rw [if_pos hk] at H ⊢; exact il _ _ H
    · rw [if_neg hk] at H ⊢; exact ir _ _ H

theorem RT.wfK_sound : ∀ (t : RT) (d : Nat), RT.wfK t d = true → t.wf d := by
  intro t
  induction t with
  | leaf v =>
    intro d H
    have e : d = 0 := Nat.eq_of_beq_eq_true H
    subst e; exact trivial
  | node l r il ir =>
    intro d H
    cases d with
    | zero => exact absurd H Bool.false_ne_true
    | succ m =>
      obtain ⟨g1, g2⟩ := shg_true (show SSC.guard (RT.wfK l m) (RT.wfK r m) = true from H)
      exact ⟨il m g1, ir m g2⟩

theorem izero_sound : ∀ z : Int, izero z = true → z = 0
  | .ofNat n, h => by
    have : n = 0 := Nat.eq_of_beq_eq_true h
    subst this; rfl
  | .negSucc _, h => absurd h Bool.false_ne_true

theorem rowEq_sound : ∀ a b : Row, rowEq a b = true → a = b
  | [], [], _ => rfl
  | [], _ :: _, h => absurd h Bool.false_ne_true
  | _ :: _, [], h => absurd h Bool.false_ne_true
  | x :: xs, y :: ys, h => by
    have h' : SSC.guard (Nat.beq x.1 y.1) (SSC.guard (izero (x.2 - y.2)) (rowEq xs ys)) = true := h
    obtain ⟨g1, h2⟩ := shg_true h'
    obtain ⟨g2, g3⟩ := shg_true h2
    have e1 : x.1 = y.1 := Nat.eq_of_beq_eq_true g1
    have e2 : x.2 = y.2 := by have := izero_sound _ g2; omega
    rw [rowEq_sound xs ys g3]
    cases x; cases y
    simp only at e1 e2
    rw [e1, e2]

theorem guardN_sound (P : Nat → Bool) : ∀ n,
    Nat.rec (motive := fun _ => Bool) true (fun r ih => SSC.guard (P r) ih) n = true → ∀ r, r < n → P r = true
  | 0, _, r, hr => absurd hr (Nat.not_lt_zero r)
  | n + 1, h, r, hr => by
    obtain ⟨g1, g2⟩ := shg_true h
    rcases Nat.lt_succ_iff_lt_or_eq.mp hr with h1 | h1
    · exact guardN_sound P n g2 r h1
    · rw [h1]; exact g1

noncomputable def allLt (N : Nat) : Row → Bool :=
  List.rec (motive := fun _ => Bool) true (fun e _ ih => SSC.guard (Nat.blt e.1 N) ih)
noncomputable def idKn (q : SPw) (R : RT) (n : Nat) : Bool :=
  Nat.rec (motive := fun _ => Bool) true
    (fun r ih => SSC.guard (R.getK r (fun row => rowEq row [(r, (q.D : Int))])) ih) n
noncomputable def idK (q : SPw) (R : RT) : Bool := idKn q R q.nr
noncomputable def freeKn (q : SPw) (R : RT) (n : Nat) : Bool :=
  Nat.rec (motive := fun _ => Bool) true (fun r ih => SSC.guard (R.getK r (fun row => allLt q.N row)) ih) n
noncomputable def freeK (q : SPw) (R : RT) : Bool := freeKn q R q.nr
def consNZ (k : Nat) (c : Int) (l : Row) : Row := if c = 0 then l else (k, c) :: l
def shRowAB (D v : Nat) (ab : Nat → Int × Int × Int) (r : Nat) : Row :=
  if r < v then (r, (D : Int)) :: consNZ (r + v) (ab r).1 []
  else if r < 2 * v then consNZ (r - v) (ab (r - v)).2.1 (consNZ r (ab (r - v)).2.2 [])
  else [(r, (D : Int))]
noncomputable def shKnAB (q : SPw) (v : Nat) (ab : Nat → Int × Int × Int) (R : RT) (n : Nat) : Bool :=
  Nat.rec (motive := fun _ => Bool) true
    (fun r ih => SSC.guard (R.getK r (fun row => rowEq row (shRowAB q.D v ab r))) ih) n

theorem allLt_sound (N : Nat) : ∀ row : Row, allLt N row = true → ∀ e ∈ row, e.1 < N
  | [], _, _, he => absurd he (List.not_mem_nil)
  | x :: l, h, e, he => by
    obtain ⟨g1, g2⟩ := shg_true h
    rcases List.mem_cons.mp he with h1 | h1
    · rw [h1]; exact Nat.le_of_ble_eq_true g1
    · exact allLt_sound N l g2 e h1

theorem idK_sound (q : SPw) (R : RT) (h : idK q R = true) : ∀ r, r < q.nr → R.get r = [(r, (q.D : Int))] :=
  fun r hr => rowEq_sound _ _ (RT.getK_true R r _
    (guardN_sound (fun r => R.getK r (fun row => rowEq row [(r, (q.D : Int))])) q.nr h r hr))

theorem freeK_sound (q : SPw) (R : RT) (h : freeK q R = true) : ∀ r, r < q.nr → ∀ e ∈ R.get r, e.1 < q.N :=
  fun r hr => allLt_sound q.N _ (RT.getK_true R r _
    (guardN_sound (fun r => R.getK r (fun row => allLt q.N row)) q.nr h r hr))

theorem shKnAB_sound (q : SPw) (v : Nat) (ab : Nat → Int × Int × Int) (R : RT) (hR : R.wf q.d) :
    ∀ n, shKnAB q v ab R n = true → ∀ r, r < n → R.get r = shRowAB q.D v ab r :=
  fun n h r hr => rowEq_sound _ _ (RT.getK_true R r _
    (guardN_sound (fun r => R.getK r (fun row => rowEq row (shRowAB q.D v ab r))) n h r hr))

inductive Ctr
  | F
  | Bk
  | M
  deriving DecidableEq, Repr

def Ctr.ab (D : Nat) : Ctr → Int × Int × Int
  | .F => (0, (D : Int), (D : Int))
  | .Bk => (-(D : Int), 0, (D : Int))
  | .M => (-(D : Int), ((D / 2 : Nat) : Int), ((D / 2 : Nat) : Int))

structure WCert where
  v : Nat
  R : Nat
  nc : Nat
  p : GLab.Par
  wt : List WOp
  evs : List WEv
  evsB : List WEv
  S0 : SSC.Trie
  SF : SSC.Trie
  rs : List Nat
  ports : List Nat
  gl : List Nat
  el : List Nat
  q : SPw
  R0 : RT
  RF : RT
  RB : RT

def WCert.pe (c : WCert) : GLab.Par := ⟨c.p.h, 2 * c.v + c.R, c.p.d, c.p.K, c.p.tab⟩

end KLW

namespace KLW
open SSC GXD GLab OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.GF OAI.PowerSaving.RAM
  OAI.PowerSaving.SS OAI.PowerSaving.CB OAI.PowerSaving.BR Finset

section RouteF
variable {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

def GRouteF (S T : ρ → CMat α) (E : ∀ f, Data α ρ f → Data α ρ f) (c : (ℕ → ℝ) → ℝ) : Prop :=
  ∃ w : GWord α ρ, w.Proper (Fintype.card α) ∧ (∀ φ, w.costR φ = c φ) ∧
    ∀ (f : ℕ) (x : Data α ρ f), gwalk f w (multiAct f S x) = multiAct f T (E f x)

namespace GRouteF
variable {S T U : ρ → CMat α} {E E' : ∀ f, Data α ρ f → Data α ρ f} {c c' : (ℕ → ℝ) → ℝ}

theorem ofG {g : (ρ → ℂ) → (ρ → ℂ)} (h : GRoute S T g c) : GRouteF S T (fun f => point f g) c := h

theorem toG {g : (ρ → ℂ) → (ρ → ℂ)} (h : GRouteF S T (fun f => point f g) c) : GRoute S T g c := h

theorem refl : GRouteF S S (fun _ x => x) (fun _ => 0) :=
  ⟨[], GWord.proper_nil _, fun _ => rfl, fun _ _ => rfl⟩

theorem cast (h : GRouteF S T E c) (hc : ∀ φ, c φ = c' φ) : GRouteF S T E c' := by
  obtain ⟨w, hw, hcost, hwalk⟩ := h
  exact ⟨w, hw, fun φ => (hcost φ).trans (hc φ), hwalk⟩

theorem congrF (h : GRouteF S T E c) (hE : ∀ f x, E f x = E' f x) : GRouteF S T E' c := by
  obtain ⟨w, hw, hcost, hwalk⟩ := h
  exact ⟨w, hw, hcost, fun f x => (hwalk f x).trans (by rw [hE])⟩

theorem trans (a : GRouteF S T E c) (b : GRouteF T U E' c') :
    GRouteF S U (fun f x => E' f (E f x)) (fun φ => c φ + c' φ) := by
  obtain ⟨p, hp, cp, ap⟩ := a
  obtain ⟨q, hq, cq, aq⟩ := b
  refine ⟨p ++ q, hp.append hq, fun φ => by rw [GWord.costR_append, cp, cq], fun f x => ?_⟩
  exact (gwalk_append f p q _).trans ((congrArg (gwalk f q) (ap f x)).trans (aq f (E f x)))

end GRouteF

end RouteF

def decI (m : Nat) : Int := if m % 2 = 0 then ((m / 2 : Nat) : Int) else Int.negSucc (m / 2)

section WarpCode
variable {α : Type} [Fintype α] [DecidableEq α]

noncomputable def KC (K : Int → CMat α) (B : Nat) (c : Nat) : CMat α :=
  if h : c = 0 ∨ B < 2 then 1 else K (decI (c % B)) * KC K B (c / B)
termination_by c
decreasing_by
  have h' : c ≠ 0 ∧ 2 ≤ B := by omega
  exact Nat.div_lt_self (Nat.pos_of_ne_zero h'.1) (by omega)

-- CHECK: unfolding a well-founded definition by `rw [KC]` (equation lemma `KC.eq_1`)
theorem KC_zero (K : Int → CMat α) (B : Nat) : KC K B 0 = 1 := by
  rw [KC, dif_pos (Or.inl rfl)]

end WarpCode

section WarpKey
variable {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

noncomputable def keyV (q : SPw) (K : Int → CMat α) (un : Nat → ρ) {f : ℕ} (x : Data α ρ f) (k : Nat) :
    Sky α f → ℂ :=
  matAct f (KC K q.B (k / q.N)) (x (un (k % q.N)))

theorem keyV_lt (q : SPw) (K : Int → CMat α) (un : Nat → ρ) {f : ℕ} (x : Data α ρ f) {k : Nat} (h : k < q.N) :
    keyV q K un x k = x (un k) := by
  unfold keyV
  rw [Nat.div_eq_of_lt h, Nat.mod_eq_of_lt h, KC_zero, matAct_one]

end WarpKey

section Scal
variable {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

def scD (r : ρ) (q : ℚ) : Matrix ρ ρ ℚ := Matrix.diagonal (fun j => if j = r then q else 1)

def cfC (co : Co) : Coef := ⟨co.neg, co.num, co.den⟩

noncomputable def coQ (co : Co) : ℚ := (cfC co).val

def gm (g : GXD.Gate) : List Micro := mic cfC g.adds

theorem checkmelater_asksless_gm_noflag : True := trivial

noncomputable def eMap (un : Nat → ρ) : WEv → ∀ f, Data α ρ f → Data α ρ f
  | .g g => fun f => point f (actPoint (matP un (gm g)))
  | .sc _ r co => fun f => point f (actPoint (scD (un r) (coQ co)))
  | .w _ _ _ _ => fun _ x => x
  | .za r _ => fun f => point f (actPoint (scD (un r) 0))
  | .zf r => fun f => point f (actPoint (scD (un r) 0))
  | .dn _ _ => fun _ x => x

theorem checkmelater_asksless_eMap_noflag_nowarp : True := trivial

noncomputable def esMap (un : Nat → ρ) : List WEv → ∀ f, Data α ρ f → Data α ρ f
  | [] => fun _ x => x
  | e :: es => fun f x => esMap un es f (eMap un e f x)

theorem checkmelater_asksless_esMap_noflag_nowarp : True := trivial

noncomputable def rowV (q : SPw) (K : Int → CMat α) (un : Nat → ρ) {f : ℕ} (x : Data α ρ f) : Row → Sky α f → ℂ
  | [] => 0
  | e :: L => ((e.2 : ℂ) / (q.D : ℂ)) • keyV q K un x e.1 + rowV q K un x L

noncomputable def vecR (q : SPw) (K : Int → CMat α) (un : Nat → ρ) (emb : ρ → Nat) (R : RT) {f : ℕ}
    (x : Data α ρ f) : Data α ρ f :=
  fun j => rowV q K un x (R.get (emb j))

end Scal

def sgnQ (ng : Bool) (num den : Nat) : ℚ := (if ng then -(num : ℚ) else (num : ℚ)) / (den : ℚ)

structure SCtx (q : SPw) {ρ : Type} (emb : ρ → Nat) (un : Nat → ρ) : Prop where
  hun : ∀ j, un (emb j) = j
  hin : ∀ r, r < q.nr → emb (un r) = r
  hlt : ∀ j, emb j < q.nr

section Rows
variable {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

theorem actPoint_scD (r : ρ) (c : ℚ) (u : ρ → ℂ) (j : ρ) :
    actPoint (scD r c) u j = (if j = r then (c : ℂ) else 1) * u j := by
  unfold actPoint scD
  rw [Finset.sum_eq_single j (fun b _ hb => by rw [Matrix.diagonal_apply_ne _ (Ne.symm hb)]; simp)
    (fun h => absurd (Finset.mem_univ j) h), Matrix.diagonal_apply_eq]
  by_cases h : j = r <;> simp [h]

noncomputable def rowsMat (q : SPw) (un : Nat → ρ) (emb : ρ → Nat) (R : RT) : Matrix ρ ρ ℚ :=
  fun j i => ((R.get (emb j)).map (fun e => if un e.1 = i then (e.2 : ℚ) / (q.D : ℚ) else 0)).sum

def ParOK (q : SPw) : Prop := 1 ≤ q.N ∧ q.nr ≤ q.N ∧ q.nr ≤ 2 ^ q.d ∧ 2 ≤ q.B ∧ 1 ≤ q.D

def ScalOK (q : SPw) (evs : List WEv) (R R' : RT) : Prop :=
  R.wf q.d ∧ ∀ {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
    (K : Int → CMat α) (emb : ρ → Nat) (un : Nat → ρ), SCtx q emb un → (∀ a, K a * K (-a) = 1) →
    ∀ {f : ℕ} (x : Data α ρ f), esMap un evs f (vecR q K un emb R x) = vecR q K un emb R' x

theorem checkmelater_asksless_ScalOK_noflag : True := trivial

theorem actPoint_rowsMat (q : SPw) (un : Nat → ρ) (emb : ρ → Nat) (R : RT) (x : ρ → ℂ) (j : ρ) :
    actPoint (rowsMat q un emb R) x j
      = ((R.get (emb j)).map (fun e => ((((e.2 : ℚ) / (q.D : ℚ)) : ℚ) : ℂ) * x (un e.1))).sum := by
  unfold actPoint rowsMat
  generalize R.get (emb j) = row
  induction row with
  | nil => simp
  | cons e L ih =>
-- CHECK: the `ih` rewrite under `∑ i` and `Finset.sum_eq_single` for the indicator
    simp only [List.map_cons, List.sum_cons, Rat.cast_add, add_mul, Finset.sum_add_distrib, ih]
    congr 1
    rw [Finset.sum_eq_single (un e.1) (fun b _ hb => by rw [if_neg (Ne.symm hb)]; simp)
      (fun h => absurd (Finset.mem_univ _) h), if_pos rfl]

theorem rowV_free (q : SPw) (K : Int → CMat α) (un : Nat → ρ) {f : ℕ} (x : Data α ρ f) (i : Sky α f) :
    ∀ row : Row, (∀ e ∈ row, e.1 < q.N) →
    rowV q K un x row i = (row.map (fun e => ((((e.2 : ℚ) / (q.D : ℚ)) : ℚ) : ℂ) * (fun r => x r i) (un e.1))).sum
  | [], _ => by simp [rowV]
  | e :: L, h => by
    simp only [rowV, List.map_cons, List.sum_cons, Pi.add_apply, Pi.smul_apply, smul_eq_mul]
    rw [keyV_lt q K un x (h e List.mem_cons_self),
      rowV_free q K un x i L (fun e' he' => h e' (List.mem_cons_of_mem _ he'))]
    congr 1
    rw [Rat.cast_div, Rat.cast_intCast, Rat.cast_natCast]

theorem vecR_id (q : SPw) (K : Int → CMat α) (un : Nat → ρ) (emb : ρ → Nat) (hq : SCtx q emb un) (hpar : ParOK q)
    {R : RT} (h0 : idK q R = true) {f : ℕ} (x : Data α ρ f) : vecR q K un emb R x = x := by
  funext j
  show rowV q K un x (R.get (emb j)) = x j
  have hD : (q.D : ℂ) ≠ 0 := by exact_mod_cast (show q.D ≠ 0 by have := hpar.2.2.2.2; omega)
  rw [idK_sound q R h0 (emb j) (hq.hlt j)]
  simp only [rowV]
  rw [keyV_lt q K un x (lt_of_lt_of_le (hq.hlt j) hpar.2.1), hq.hun j, Int.cast_natCast, div_self hD, one_smul,
    add_zero]

theorem vecR_free (q : SPw) (K : Int → CMat α) (un : Nat → ρ) (emb : ρ → Nat) (hq : SCtx q emb un)
    {R : RT} (hfree : freeK q R = true) {f : ℕ} (x : Data α ρ f) :
    vecR q K un emb R x = point f (actPoint (rowsMat q un emb R)) x := by
  funext j i
  show rowV q K un x (R.get (emb j)) i = actPoint (rowsMat q un emb R) (fun r => x r i) j
  rw [actPoint_rowsMat, rowV_free q K un x i _ (freeK_sound q R hfree (emb j) (hq.hlt j))]

end Rows

section Route
variable {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]


theorem scD_gate (L : ρ → CMat α) (r : ρ) (c : ℚ) : GRoute L L (actPoint (scD r c)) (fun _ => 0) :=
  GRoute.gate _ L L (fun i j h => by
    by_cases hij : i = j
    · rw [hij]
    · exact absurd (Matrix.diagonal_apply_ne _ hij) h)

theorem gm_regs (g : GXD.Gate) (t s : Nat) (c : Coef) (h : Micro.add t s c ∈ gm g) :
    t ∈ g.regs ∧ s ∈ g.regs := by
  have h' : Micro.add t s c ∈ (GXD.Gate.adds g).map (fun x => Micro.add x.1 x.2.1 (cfC x.2.2)) := h
  obtain ⟨x, hx, e⟩ := List.mem_map.mp h'
  injection e with e1 e2 e3
  subst e1; subst e2
  exact adds_regs g x hx

theorem checkmelater_asksless_gm_regs_noflag : True := trivial

variable {p : GLab.Par} {emb : ρ → Nat} {un : Nat → ρ}

theorem lf_set (C : GLab.Ctx p emb un) (X : BXMap (Fin p.h) α) (S : Trie) (hS : S.wf p.d) {r : Nat} (hr : r < p.n)
    (f : Nat) : Lf p emb X (S.set r f) = Function.update (Lf p emb X S) (un r) (X.Φ (GLab.lab p.h (p.tab.get f))) := by
  have hrd : r < 2 ^ p.d := lt_of_lt_of_le hr C.hn
  funext j
  by_cases hj : j = un r
  · subst hj
    rw [Function.update_self]
    show X.Φ (GLab.lab p.h (p.tab.get ((S.set r f).get (emb (un r))))) = _
    rw [C.hin r hr, Trie.get_set p.d S hS r r f hrd hrd, if_pos rfl]
  · rw [Function.update_of_ne hj]
    have hne : emb j ≠ r := fun h => hj (by rw [← C.hun j, h])
    show X.Φ (GLab.lab p.h (p.tab.get ((S.set r f).get (emb j)))) = X.Φ (GLab.lab p.h (p.tab.get (S.get (emb j))))
    rw [Trie.get_set p.d S hS r (emb j) f hrd (lt_of_lt_of_le (C.hlt j) C.hn), if_neg hne]

theorem eroute (C : GLab.Ctx p emb un) (X : BXMap (Fin p.h) α) (hα : p.h < Fintype.card α) {wt : List WOp}
    (e : WEv) (S : Trie) (hS : S.wf p.d) (ok : eOk p wt S e) :
    GRouteF (Lf p emb X S) (Lf p emb X (eOut S e)) (eMap un e) (fun φ => rcost φ (eRanks p S e)) ∧
      (eOut S e).wf p.d := by
  cases e with
  | g g =>
    obtain ⟨a, b⟩ := groute C X hα gm (fun g t s c h => gm_regs g t s c h) g S hS ok
    exact ⟨GRouteF.ofG a, b⟩
  | sc fr r co =>
    obtain ⟨a, b⟩ := groute C X hα (fun _ => []) (fun _ _ _ _ h => absurd h List.not_mem_nil)
      (.out fr r [] []) S hS ok
    have a' : GRoute (Lf p emb X S) (Lf p emb X (gOut S (.out fr r [] []))) id
        (fun φ => rcost φ (gRanks p S (.out fr r [] []))) :=
-- CHECK: `matP un []` is `1` by `rfl` (RefBridge relies on the same)
      a.castg (show actPoint (matP un ([] : List Micro)) = id from actPoint_one')
    have g1 := scD_gate (Lf p emb X (gOut S (.out fr r [] []))) (un r) (coQ co)
    exact ⟨(GRouteF.ofG (a'.trans g1)).cast (fun φ => add_zero _), b⟩
  | w r a f0 f1 => exact False.elim ok
  | za r fr =>
    refine ⟨?_, Trie.wf_set p.d S hS r fr⟩
    have g : GRoute (Lf p emb X S) (Lf p emb X (S.set r fr)) (actPoint (scD (un r) 0)) (fun _ => 0) :=
      GRoute.gate _ _ _ (fun i j hij => by
        by_cases e : i = j
        · subst e
          have hi : i ≠ un r := fun h => hij (by subst h; simp [scD])
          rw [lf_set C X S hS ok fr, Function.update_of_ne hi]
        · exact absurd (by simp [scD, Matrix.diagonal_apply_ne _ e]) hij)
    exact (GRouteF.ofG g).cast (fun φ => (rcost_nil φ).symm)
  | zf r =>
    exact ⟨(GRouteF.ofG (scD_gate (Lf p emb X S) (un r) 0)).cast (fun φ => (rcost_nil φ).symm), hS⟩
  | dn r fr =>
    obtain ⟨hr, hd, hsub⟩ := ok
    have dU := lab_dim (tabK_good p.h p.tab C.hT fr)
    have dV := lab_dim (tabK_good p.h p.tab C.hT (S.get r))
    have hVle : (GLab.lab p.h (p.tab.get (S.get r))).dim ≤ p.h := by
      have := Finset.card_le_univ (GLab.lab p.h (p.tab.get (S.get r))).s
      rw [Fintype.card_fin] at this
      exact this
    have mv : SMv (Fintype.card α) (GLab.lab p.h (p.tab.get (S.get r))) (GLab.lab p.h (p.tab.get fr))
        [(GLab.lab p.h (p.tab.get (S.get r))).dim - (GLab.lab p.h (p.tab.get fr)).dim] :=
      SMv.of_sup _ _ hsub (by rw [dU, dV]; exact hd) (by omega)
    have st := (X.fmv mv).step (un r)
    have b := GRoute.on_role (Lf p emb X S) (un r) (X.Φ (GLab.lab p.h (p.tab.get fr)))
      (c := fun φ => rcost φ [(GLab.lab p.h (p.tab.get (S.get r))).dim - (GLab.lab p.h (p.tab.get fr)).dim])
      (by
        show GStep (un r) (X.Φ (GLab.lab p.h (p.tab.get (S.get (emb (un r)))))) _ _
        rw [C.hin r hr]; exact st)
    rw [← lf_set C X S hS hr fr] at b
    refine ⟨(GRouteF.ofG b).cast (fun φ => ?_), Trie.wf_set p.d S hS r fr⟩
    show rcost φ [_] = rcost φ [cdim (p.tab.get (S.get r)) - cdim (p.tab.get fr)]
    rw [dU, dV]

theorem checkmelater_asksless_eroute_nowarp : True := trivial

theorem esroute (C : GLab.Ctx p emb un) (X : BXMap (Fin p.h) α) (hα : p.h < Fintype.card α) {wt : List WOp}
    : ∀ (evs : List WEv) (S : Trie), S.wf p.d → esOk p wt S evs →
    GRouteF (Lf p emb X S) (Lf p emb X (esOut S evs)) (esMap un evs) (fun φ => rcost φ (esRanks p S evs)) := by
  intro evs
  induction evs with
  | nil => intro S _ _; exact GRouteF.refl.cast (fun φ => (rcost_nil φ).symm)
  | cons e es ih =>
    intro S hS ok
    obtain ⟨a, hS1⟩ := eroute C X hα e S hS ok.1
    exact (a.trans (ih _ hS1 ok.2)).cast (fun φ => (rcost_append φ _ _).symm)

theorem RunW.route (C : GLab.Ctx p emb un) (X : BXMap (Fin p.h) α) (hα : p.h < Fintype.card α) {wt : List WOp}
    {S S' : Trie} {evs : List WEv} {rs : List Nat}
    (R : RunW p wt S evs S' rs) (hS : S.wf p.d) :
    GRouteF (Lf p emb X S) (Lf p emb X S') (esMap un evs) (fun φ => rcost φ rs) := by
  obtain ⟨ok, rfl, rfl⟩ := R
  exact esroute C X hα evs S hS ok

theorem checkmelater_asksless_RunW_route_nowarp : True := trivial

theorem warp_grouteS (C : GLab.Ctx p emb un) (X : BXMap (Fin p.h) α) (hα : p.h < Fintype.card α) {wt : List WOp}
    {S S' : Trie} {evs : List WEv} {rs : List Nat}
    (R : RunW p wt S evs S' rs) (hS : S.wf p.d)
    (q : SPw) (hpar : ParOK q) (hq : SCtx q emb un) {R0 R' : RT} (hR' : R'.wf q.d) (h0 : idK q R0 = true)
    (hfree : freeK q R' = true) (hSc : ScalOK q evs R0 R') :
    GRoute (Lf p emb X S) (Lf p emb X S') (actPoint (rowsMat q un emb R')) (fun φ => rcost φ rs) := by
  refine GRouteF.toG ((RunW.route C X hα R hS).congrF (fun f x => ?_))
  -- the free algebra is read at the trivial letters `K = 1`
  calc esMap un evs f x = esMap un evs f (vecR q (fun _ => (1 : CMat α)) un emb R0 x) := by
        rw [vecR_id q (fun _ => (1 : CMat α)) un emb hq hpar h0 x]
    _ = vecR q (fun _ => (1 : CMat α)) un emb R' x :=
        hSc.2 (fun _ => (1 : CMat α)) emb un hq (fun _ => Matrix.one_mul _) x
    _ = point f (actPoint (rowsMat q un emb R')) x := vecR_free q (fun _ => (1 : CMat α)) un emb hq hfree x

theorem checkmelater_asksless_warp_grouteS_nowarp : True := trivial

end Route

structure Num (v R nc : Nat) (emb : Box (Fin v) (Fin R) (Fin nc) → Nat) : Prop where
  hx : ∀ t : Fin v, emb (bX t) = t.val
  hy : ∀ t : Fin v, emb (bY t) = v + t.val
  hs : ∀ q : Fin R, emb (bS q) = 2 * v + q.val
  hc : ∀ c : Fin nc, 2 * v + R ≤ emb (bC c)

noncomputable def WCert.exits (c : WCert) : Finset (Fin c.R) :=
  univ.filter (fun q : Fin c.R => memK (2 * c.v + q.val) c.el = true)

def incL (c : WCert) : CR.L3 (Fin c.v) (Fin c.R) → Box (Fin c.v) (Fin c.R) (Fin c.nc)
  | .inl b => .inl b
  | .inr q => .inr (.inl q)

noncomputable def WCert.L (c : WCert) (emb : Box (Fin c.v) (Fin c.R) (Fin c.nc) → Nat) (S : Trie) :
    CR.L3 (Fin c.v) (Fin c.R) → SLbl (Fin c.p.h) :=
  fun r => c.p.labS S (emb (incL c r))

noncomputable def WCert.ent (c : WCert) (emb : Box (Fin c.v) (Fin c.R) (Fin c.nc) → Nat) (q : Fin c.R) :
    SLbl (Fin c.p.h) :=
  XEX.lab0X c.exits (c.L emb c.S0) (c.L emb c.SF) (CR.lS q)

noncomputable def WCert.exq (c : WCert) (emb : Box (Fin c.v) (Fin c.R) (Fin c.nc) → Nat) (q : Fin c.R) :
    SLbl (Fin c.p.h) :=
  if q ∈ c.exits then XEX.exlA (c.L emb c.S0 (CR.lS q)) (c.L emb c.SF (CR.lS q)) else (c.ent emb q).top

structure WRoles (c : WCert) (emb : Box (Fin c.v) (Fin c.R) (Fin c.nc) → Nat)
    (un : Nat → Box (Fin c.v) (Fin c.R) (Fin c.nc)) : Prop where
  C : GLab.Ctx c.p emb un
  num : Num c.v c.R c.nc emb

section
variable {c : WCert} {emb : Box (Fin c.v) (Fin c.R) (Fin c.nc) → Nat} {un : Nat → Box (Fin c.v) (Fin c.R) (Fin c.nc)}

theorem WRoles.sctx (hnr : c.q.nr = c.p.n) (Ro : WRoles c emb un) : SCtx c.q emb un :=
  ⟨Ro.C.hun, fun r hr => Ro.C.hin r (by rw [← hnr]; exact hr), fun j => by rw [hnr]; exact Ro.C.hlt j⟩

end

section Shear
variable {T Sl C : Type}

def shearAB {T Sl C : Type} (α β : T → ℚ) (z : Box T Sl C → ℂ) : Box T Sl C → ℂ :=
  stamp (fun t => z (bX t) + (α t : ℂ) * z (bY t))
    (fun t => (β t : ℂ) * z (bX t) + (1 + (α t : ℂ) * (β t : ℂ)) * z (bY t)) (z ∘ bS) (fun _ => 0)

theorem matAct_lc {γ : Type} [Fintype γ] [DecidableEq γ] (f : ℕ) (M : CMat γ) (a b : ℂ) (u v : Sky γ f → ℂ) :
    matAct f M (fun i => a * u i + b * v i) = fun i => a * matAct f M u i + b * matAct f M v i := by
  have e : (fun i => a * u i + b * v i) = a • u + b • v := by
    funext i; simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul]
  rw [e]
  unfold matAct
  rw [Matrix.mulVec_add, Matrix.mulVec_smul, Matrix.mulVec_smul]
  funext i
  simp only [Pi.add_apply, Pi.smul_apply, smul_eq_mul]

theorem shearAB_comm {γ : Type} [Fintype γ] [DecidableEq γ] (al be : T → ℚ) (Db : T → CMat γ) (Ds : Sl → CMat γ)
    (Dc : C → CMat γ) (f : ℕ) (x : Data γ (Box T Sl C) f) :
    point f (shearAB al be) (multiAct f (stamp Db Db Ds Dc) x)
      = multiAct f (stamp Db Db Ds Dc) (point f (shearAB al be) x) := by
  funext r i
  rcases r with ((t|t)|(q|k))
  · show matAct f (Db t) (x (bX t)) i + (al t : ℂ) * matAct f (Db t) (x (bY t)) i
      = matAct f (Db t) (fun i => x (bX t) i + (al t : ℂ) * x (bY t) i) i
-- CHECK: the `show` forms of the four cases are definitional unfoldings of `point`/`multiAct`/`stamp`
    have h := congrFun (matAct_lc f (Db t) 1 (al t) (x (bX t)) (x (bY t))) i
    simp only [one_mul] at h
    rw [h]
  · show (be t : ℂ) * matAct f (Db t) (x (bX t)) i + (1 + (al t : ℂ) * (be t : ℂ)) * matAct f (Db t) (x (bY t)) i
      = matAct f (Db t) (fun i => (be t : ℂ) * x (bX t) i + (1 + (al t : ℂ) * (be t : ℂ)) * x (bY t) i) i
    rw [matAct_lc]
  · rfl
  · show (0 : ℂ) = matAct f (Dc k) (fun _ => (0 : ℂ)) i
    have e : (fun _ : Sky γ f => (0 : ℂ)) = 0 := rfl
    rw [e]
    unfold matAct
    rw [Matrix.mulVec_zero]
    rfl

end Shear

theorem consNZ_sum {ρ : Type} (D : Nat) (x : ρ → ℂ) (un : Nat → ρ) (k : Nat) (c : Int) (l : Row) :
    ((consNZ k c l).map (fun e => ((((e.2 : ℚ) / (D : ℚ)) : ℚ) : ℂ) * x (un e.1))).sum
      = ((((c : ℚ) / (D : ℚ)) : ℚ) : ℂ) * x (un k)
        + (l.map (fun e => ((((e.2 : ℚ) / (D : ℚ)) : ℚ) : ℂ) * x (un e.1))).sum := by
  unfold consNZ
  by_cases h : c = 0
  · rw [if_pos h, h]; simp
  · rw [if_neg h, List.map_cons, List.sum_cons]

section ShearRows
variable {q : SPw} {v R nc : Nat} {emb : Box (Fin v) (Fin R) (Fin nc) → Nat} {un : Nat → Box (Fin v) (Fin R) (Fin nc)}

theorem rows_shearAB (hq : SCtx q emb un) (hN : Num v R nc emb) (hD : 1 ≤ q.D)
    (α β : Fin v → ℚ) (ab : Nat → Int × Int × Int)
    (hab : ∀ t : Fin v, (((ab t.val).1 : Int) : ℚ) = α t * (q.D : ℚ) ∧ (((ab t.val).2.1 : Int) : ℚ) = β t * (q.D : ℚ) ∧
      (((ab t.val).2.2 : Int) : ℚ) = (1 + α t * β t) * (q.D : ℚ))
    {RF : RT} (hsh : ∀ r, r < 2 * v + R → RF.get r = shRowAB q.D v ab r)
    (z : Box (Fin v) (Fin R) (Fin nc) → ℂ) :
    eraseC (actPoint (rowsMat q un emb RF) (eraseC z)) = shearAB α β z := by
  have hD' : (q.D : ℚ) ≠ 0 := by exact_mod_cast (show q.D ≠ 0 by omega)
  have ux : ∀ t : Fin v, un t.val = bX t := fun t => by rw [← hN.hx t, hq.hun]
  have uy : ∀ t : Fin v, un (v + t.val) = bY t := fun t => by rw [← hN.hy t, hq.hun]
  have us : ∀ s : Fin R, un (2 * v + s.val) = bS s := fun s => by rw [← hN.hs s, hq.hun]
  have qd : ∀ (c : Int) (a : ℚ), (c : ℚ) = a * (q.D : ℚ) → ((((c : ℚ) / (q.D : ℚ)) : ℚ) : ℂ) = (a : ℂ) :=
    fun c a h => by rw [h, mul_div_assoc, div_self hD', mul_one]
  have q1 : (((((q.D : Int) : ℚ) / (q.D : ℚ)) : ℚ) : ℂ) = 1 := by
    rw [qd (q.D : Int) 1 (by push_cast; ring)]; simp
  funext b
  rcases b with ((t|t)|(s|k))
  · have ht := t.isLt
    show actPoint (rowsMat q un emb RF) (eraseC z) (bX t) = z (bX t) + (α t : ℂ) * z (bY t)
    rw [actPoint_rowsMat, hN.hx t, hsh t.val (by omega), shRowAB, if_pos ht]
-- CHECK: `simp only` must leave `↑(↑↑q.D / ↑q.D) * eraseC z (un ↑t) + ...` for the `rw` chain (projections of the row pairs reduced)
    simp only [List.map_cons, List.sum_cons, consNZ_sum, List.map_nil, List.sum_nil, add_zero]
    rw [ux t, Nat.add_comm t.val v, uy t, q1, qd _ _ (hab t).1, one_mul]
    rfl
  · have ht := t.isLt
    show actPoint (rowsMat q un emb RF) (eraseC z) (bY t)
      = (β t : ℂ) * z (bX t) + (1 + (α t : ℂ) * (β t : ℂ)) * z (bY t)
    rw [actPoint_rowsMat, hN.hy t, hsh (v + t.val) (by omega), shRowAB, if_neg (show ¬ (v + t.val < v) by omega),
      if_pos (show v + t.val < 2 * v by omega), Nat.add_sub_cancel_left]
    simp only [consNZ_sum, List.map_nil, List.sum_nil, add_zero]
    rw [ux t, uy t, qd _ _ (hab t).2.1, qd _ _ (hab t).2.2]
    push_cast
    rfl
  · have hs := s.isLt
    show actPoint (rowsMat q un emb RF) (eraseC z) (bS s) = z (bS s)
    rw [actPoint_rowsMat, hN.hs s, hsh (2 * v + s.val) (by omega), shRowAB,
      if_neg (show ¬ (2 * v + s.val < v) by omega), if_neg (show ¬ (2 * v + s.val < 2 * v) by omega)]
    simp only [List.map_cons, List.map_nil, List.sum_cons, List.sum_nil, add_zero]
    rw [us s, q1, one_mul]
    rfl
  · rfl

end ShearRows

def Ctr.al : Ctr → ℚ
  | .F => 0
  | .Bk => -1
  | .M => -1

def Ctr.be : Ctr → ℚ
  | .F => 1
  | .Bk => 0
  | .M => 1 / 2

theorem Ctr.hab (D : Nat) (h2 : 2 ∣ D) (k : Ctr) :
    (((k.ab D).1 : Int) : ℚ) = k.al * (D : ℚ) ∧ (((k.ab D).2.1 : Int) : ℚ) = k.be * (D : ℚ) ∧
      (((k.ab D).2.2 : Int) : ℚ) = (1 + k.al * k.be) * (D : ℚ) := by
  have hh : ((((D / 2 : Nat) : Int)) : ℚ) = (1 / 2 : ℚ) * (D : ℚ) := by
    obtain ⟨m, rfl⟩ := h2
    rw [Nat.mul_div_cancel_left m (by norm_num : 0 < 2)]
    push_cast
    ring
  cases k with
  | F => exact ⟨by simp [Ctr.ab, Ctr.al], by simp [Ctr.ab, Ctr.be], by simp [Ctr.ab, Ctr.al, Ctr.be]⟩
  | Bk => exact ⟨by simp [Ctr.ab, Ctr.al], by simp [Ctr.ab, Ctr.be], by simp [Ctr.ab, Ctr.al, Ctr.be]⟩
  | M =>
    refine ⟨by simp [Ctr.ab, Ctr.al], ?_, ?_⟩
    · show ((((D / 2 : Nat) : Int)) : ℚ) = (1 / 2 : ℚ) * (D : ℚ)
      exact hh
    · show ((((D / 2 : Nat) : Int)) : ℚ) = (1 + (-1 : ℚ) * (1 / 2 : ℚ)) * (D : ℚ)
      rw [hh]
      ring

theorem Ctr.hab_table {v : Nat} (D : Nat) (h2 : 2 ∣ D) (ty : Nat → Ctr) :
    ∀ t : Fin v, ((((ty t.val).ab D).1 : Int) : ℚ) = (ty t.val).al * (D : ℚ) ∧
      ((((ty t.val).ab D).2.1 : Int) : ℚ) = (ty t.val).be * (D : ℚ) ∧
      ((((ty t.val).ab D).2.2 : Int) : ℚ) = (1 + (ty t.val).al * (ty t.val).be) * (D : ℚ) :=
  fun t => Ctr.hab D h2 (ty t.val)

end KLW

