import Submission.Work.GCert.Labels.Def
import Submission.Work.KLowW.Data

namespace KLW
open SSC GXD GLab

noncomputable def evK (p : GLab.Par) (hm hh sh O : Nat) (e : WEv) (S : Trie) (rs : List Nat)
    (k : Trie → List Nat → Bool) : Bool :=
  WEv.rec (motive := fun _ => Bool)
    (fun g => gateK p hm hh sh O g S rs k)
    (fun f r _ => gateK p hm hh sh O (.out f r [] []) S rs k)
    (fun _ _ _ _ => false)
    (fun r f => guard (Nat.ble (Nat.succ r) p.n) (k (S.set r f) rs))
    (fun r => guard (Nat.ble (Nat.succ r) p.n) (k S rs))
    (fun r f => guard (Nat.ble (Nat.succ r) p.n) <|
      S.getK r fun cur => p.tab.getK cur fun ca => p.tab.getK f fun cb =>
      guard (Nat.ble (Nat.succ (Nat.land cb 255)) (Nat.land ca 255)) <|
      guard (elimT p.h hm O (Nat.shiftRight ca sh) (Nat.shiftRight cb sh)) <|
      List.rec (motive := fun _ => Bool) false
        (fun r0 rs' _ => guard (Nat.beq r0 (Nat.sub (Nat.land ca 255) (Nat.land cb 255))) (k (S.set r f) rs')) rs) e

theorem checkmelater_asksless_evK_nowarp : True := trivial

noncomputable def evsK (p : GLab.Par) (hm hh sh O : Nat) :
    List WEv → Trie → List Nat → (Trie → List Nat → Bool) → Bool :=
  List.rec (motive := fun _ => Trie → List Nat → (Trie → List Nat → Bool) → Bool)
    (fun S rs k => k S rs)
    (fun e _ ih S rs k => evK p hm hh sh O e S rs fun S1 rs1 => ih S1 rs1 k)

theorem checkmelater_asksless_evsK_nowarp : True := trivial

noncomputable def segW (p : GLab.Par) (wt : List WOp) (evs : List WEv) (S S' : Trie) (rs : List Nat) : Bool :=
  guard (Nat.ble 1 p.h) <|
  forceN (Nat.sub (Nat.pow 2 p.h) 1) fun hm =>
  forceN (Nat.div (Nat.sub (Nat.pow 2 (Nat.mul p.h p.K)) 1) hm) fun O =>
  guard (Nat.beq (Nat.mul O hm) (Nat.sub (Nat.pow 2 (Nat.mul p.h p.K)) 1))
    (evsK p hm (Nat.mul p.h p.h) (Nat.add 8 p.h) O evs S rs fun S1 rs1 =>
      guard (Trie.beqK S1 S') (List.rec (motive := fun _ => Bool) true (fun _ _ _ => false) rs1))

end KLW
