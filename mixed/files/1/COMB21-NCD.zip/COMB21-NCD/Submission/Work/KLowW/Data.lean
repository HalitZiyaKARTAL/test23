import Submission.Work.GCert.Data.Raw

namespace KLW
open GXD

structure WOp where
  G : List Nat
  Gi : List Nat
  deriving Repr, DecidableEq

inductive WEv where
  | g (gate : Gate)
  | sc (frame r : Nat) (co : Co)
  | w (r : Nat) (op : Int) (f0 f1 : Nat)
  | za (r f : Nat)
  | zf (r : Nat)
  | dn (r f : Nat)
  deriving Repr

end KLW
