import Submission.Work.KLowW.ShearAB
import Submission.Work.WR.Check


namespace KLW
open SSC GXD GLab OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.GF OAI.PowerSaving.RAM
  OAI.PowerSaving.CB Finset Matrix

namespace RefB

theorem wf_of_spec : ∀ (d : Nat) (t : RT), ScalSpec.wf d t → t.wf d
  | 0, .leaf _, _ => trivial
  | d + 1, .node l r, h => ⟨wf_of_spec d l h.1, wf_of_spec d r h.2⟩
  | 0, .node _ _, h => False.elim h
  | _ + 1, .leaf _, h => False.elim h

theorem get_eq : ∀ (d : Nat) (t : RT), t.wf d → ∀ r, r < 2 ^ d → t.get r = ScalSpec.get t r
  | 0, .leaf v, _, r, hr => by
    have h0 : r = 0 := by simpa using hr
    subst h0; simp [RT.get, ScalSpec.get]
  | d + 1, .node l rr, h, r, hr => by
    have hr2 : r / 2 < 2 ^ d := by rw [pow_succ] at hr; omega
    by_cases h2 : r % 2 = 0
    · simp only [RT.get, ScalSpec.get, h2, if_true]; exact get_eq d l h.1 _ hr2
    · simp only [RT.get, ScalSpec.get, h2, if_false]; exact get_eq d rr h.2 _ hr2
  | 0, .node _ _, h, _, _ => False.elim h
  | _ + 1, .leaf _, h, _, _ => False.elim h

def rowB : Row → Nat
  | [] => 0
  | e :: l => max (e.1 + 1) (rowB l)

def trieB : RT → Nat
  | .leaf v => rowB v
  | .node l r => max (trieB l) (trieB r)

theorem rowB_lt : ∀ (row : Row) (e : Nat × Int), e ∈ row → e.1 < rowB row
  | x :: l, e, he => by
    rcases List.mem_cons.mp he with h | h
    · subst h; show e.1 < max (e.1 + 1) (rowB l); omega
    · have := rowB_lt l e h; show e.1 < max (x.1 + 1) (rowB l); omega

theorem trieB_lt : ∀ (t : RT) (r : Nat) (e : Nat × Int), e ∈ ScalSpec.get t r → e.1 < trieB t
  | .leaf v, r, e, he => by
    by_cases h0 : r = 0
    · simp only [ScalSpec.get, h0, if_true] at he; exact rowB_lt v e he
    · simp [ScalSpec.get, h0] at he
  | .node l rr, r, e, he => by
    by_cases h2 : r % 2 = 0
    · simp only [ScalSpec.get, h2, if_true] at he
      have := trieB_lt l _ e he; show e.1 < max (trieB l) (trieB rr); omega
    · simp only [ScalSpec.get, h2, if_false] at he
      have := trieB_lt rr _ e he; show e.1 < max (trieB l) (trieB rr); omega

theorem coef_zero : ∀ (row : Row) (k : Nat), (∀ e ∈ row, e.1 ≠ k) → ScalSpec.coef row k = 0
  | [], _, _ => rfl
  | e :: l, k, h => by
    have h1 : e.1 ≠ k := h e List.mem_cons_self
    simp only [ScalSpec.coef, if_neg h1, zero_add]
    exact coef_zero l k (fun e' he' => h e' (List.mem_cons_of_mem _ he'))

section Val
variable {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
variable (q : SPw) (K : Int → CMat α) (un : Nat → ρ) (emb : ρ → Nat) {f : ℕ} (x : Data α ρ f)

noncomputable def valS (M : Nat) (S : ScalSpec.St) (r : Nat) : Sky α f → ℂ :=
  ∑ k ∈ Finset.range M, ((S r k : ℂ) / (q.D : ℂ)) • keyV q K un x k

noncomputable def vecS (M : Nat) (S : ScalSpec.St) : Data α ρ f := fun j => valS q K un x M S (emb j)

def Bd (M : Nat) (S : ScalSpec.St) : Prop := ∀ r k, M ≤ k → S r k = 0

theorem rowV_coef (M : Nat) : ∀ (row : Row), (∀ e ∈ row, e.1 < M) →
    rowV q K un x row = ∑ k ∈ Finset.range M, ((ScalSpec.coef row k : ℂ) / (q.D : ℂ)) • keyV q K un x k
  | [], _ => by simp [rowV, ScalSpec.coef]
  | e :: l, h => by
    have he : e.1 < M := h e List.mem_cons_self
    have ih := rowV_coef M l (fun e' he' => h e' (List.mem_cons_of_mem _ he'))
    simp only [rowV, ScalSpec.coef]
    rw [ih]
    have hs : ∀ k ∈ Finset.range M,
        ((((if e.1 = k then e.2 else 0) + ScalSpec.coef l k : Int) : ℂ) / (q.D : ℂ)) • keyV q K un x k
        = (if e.1 = k then ((e.2 : ℂ) / (q.D : ℂ)) • keyV q K un x k else 0)
          + ((ScalSpec.coef l k : ℂ) / (q.D : ℂ)) • keyV q K un x k := by
      intro k _
      by_cases hk : e.1 = k
      · simp only [if_pos hk]; push_cast; rw [add_div, add_smul]
      · simp only [if_neg hk]; push_cast; rw [zero_add, zero_add]
    rw [Finset.sum_congr rfl hs, Finset.sum_add_distrib, Finset.sum_ite_eq (Finset.range M) e.1,
      if_pos (Finset.mem_range.mpr he)]

theorem valS_congr (M : Nat) {S S' : ScalSpec.St} {r r' : Nat} (h : S' r' = S r) :
    valS q K un x M S' r' = valS q K un x M S r := by
  unfold valS; rw [h]

theorem valS_scale (M : Nat) {S S' : ScalSpec.St} {r r' : Nat} {den : Nat} {sg : Int} (hden : den ≠ 0)
    (h : ∀ k, (den : Int) * S' r' k = sg * S r k) :
    valS q K un x M S' r' = (((sg : ℚ) / (den : ℚ) : ℚ) : ℂ) • valS q K un x M S r := by
  unfold valS
  rw [Finset.smul_sum]
  refine Finset.sum_congr rfl (fun k _ => ?_)
  rw [smul_smul]
  congr 1
  have hd : (den : ℂ) ≠ 0 := by exact_mod_cast hden
  have hk : ((den : Int) : ℂ) * (S' r' k : ℂ) = (sg : ℂ) * (S r k : ℂ) := by exact_mod_cast h k
  have hk' : (S' r' k : ℂ) = (sg : ℂ) * (S r k : ℂ) / (den : ℂ) := by
    rw [eq_div_iff hd, mul_comm]; exact_mod_cast hk
  rw [hk']; push_cast; ring

theorem valS_add (M : Nat) {S S' : ScalSpec.St} {t s : Nat} {den : Nat} {sg : Int} (hden : den ≠ 0)
    (h : ∀ k, (den : Int) * (S' t k - S t k) = sg * S s k) :
    valS q K un x M S' t = valS q K un x M S t + (((sg : ℚ) / (den : ℚ) : ℚ) : ℂ) • valS q K un x M S s := by
  unfold valS
  rw [Finset.smul_sum, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl (fun k _ => ?_)
  rw [smul_smul, ← add_smul]
  congr 1
  have hd : (den : ℂ) ≠ 0 := by exact_mod_cast hden
  have hk : ((den : Int) : ℂ) * ((S' t k : ℂ) - (S t k : ℂ)) = (sg : ℂ) * (S s k : ℂ) := by exact_mod_cast h k
  have hk' : (S' t k : ℂ) = (S t k : ℂ) + (sg : ℂ) * (S s k : ℂ) / (den : ℂ) := by
    have : (S' t k : ℂ) - (S t k : ℂ) = (sg : ℂ) * (S s k : ℂ) / (den : ℂ) := by
      rw [eq_div_iff hd, mul_comm]; exact_mod_cast hk
    rw [← this]; ring
  rw [hk']; push_cast; ring

theorem valS_zero (M : Nat) {S : ScalSpec.St} {r : Nat} (h : ∀ k, S r k = 0) : valS q K un x M S r = 0 := by
  unfold valS
  exact Finset.sum_eq_zero (fun k _ => by rw [h k]; simp)

end Val

theorem cfC_val (co : Co) : (cfC co).val = (ScalSpec.sg co : ℚ) / (co.den : ℚ) := by
  unfold cfC Coef.val ScalSpec.sg
  cases co.neg <;> simp

section Ev
variable {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
variable {q : SPw} {K : Int → CMat α} {emb : ρ → Nat} {un : Nat → ρ}

theorem bd_other {M : Nat} {S S' : ScalSpec.St} {t : Nat} (hB : Bd M S) (ho : ∀ r, r ≠ t → S' r = S r)
    (ht : ∀ k, M ≤ k → S' t k = 0) : Bd M S' := by
  intro r k hk
  by_cases hr : r = t
  · subst hr; exact ht k hk
  · rw [ho r hr]; exact hB r k hk

theorem add_sound (hq : SCtx q emb un) (M : Nat) {t s : Nat} {co : Co} {S S' : ScalSpec.St}
    (h : ScalSpec.AddStep q t s co S S') (hB : Bd M S) {f : ℕ} (x : Data α ρ f) :
    Bd M S' ∧ point f (actPoint (addMat (un t) (un s) (cfC co).val)) (vecS q K un emb x M S)
      = vecS q K un emb x M S' := by
  obtain ⟨ht, hs, hts, hden, he, ho⟩ := h
  refine ⟨bd_other hB ho (fun k hk => ?_), ?_⟩
  · have := he k
    rw [hB t k hk, hB s k hk] at this
    simpa [hden] using this
  · funext j i
    show actPoint (addMat (un t) (un s) (cfC co).val) (fun r => vecS q K un emb x M S r i) j = _
    rw [SSC.actPoint_addMat]
    by_cases hj : j = un t
    · rw [if_pos hj]
      have e1 : emb j = t := by rw [hj, hq.hin t ht]
      show valS q K un x M S (emb (un t)) i + ((cfC co).val : ℂ) * valS q K un x M S (emb (un s)) i
        = valS q K un x M S' (emb j) i
      rw [hq.hin t ht, hq.hin s hs, e1, valS_add q K un x M hden he, cfC_val]
      rfl
    · rw [if_neg hj]
      have e1 : emb j ≠ t := fun e => hj (by rw [← e, hq.hun])
      show valS q K un x M S (emb j) i = valS q K un x M S' (emb j) i
      rw [valS_congr q K un x M (ho _ e1)]

theorem adds_sound (hq : SCtx q emb un) (M : Nat) : ∀ {l : List (Nat × Nat × Co)} {S S' : ScalSpec.St},
    ScalSpec.Adds q l S S' → Bd M S → ∀ {f : ℕ} (x : Data α ρ f),
    Bd M S' ∧ point f (actPoint (matP un (mic cfC l))) (vecS q K un emb x M S) = vecS q K un emb x M S' := by
  intro l S S' h
  induction h with
  | nil S =>
    intro hB f x
    refine ⟨hB, ?_⟩
    rw [show matP un (mic cfC []) = (1 : Matrix ρ ρ ℚ) from rfl, actPoint_one']; rfl
  | @cons t s co l S S1 S2 h1 _ ih =>
    intro hB f x
    obtain ⟨b1, v1⟩ := add_sound (K := K) hq M h1 hB x
    obtain ⟨b2, v2⟩ := ih b1 x
    refine ⟨b2, ?_⟩
    have e : matP un (mic cfC ((t, s, co) :: l)) = matP un (mic cfC l) * addMat (un t) (un s) (cfC co).val := rfl
    rw [e, actPoint_mul, ← v2, ← v1]
    rfl

theorem scD_sound (hq : SCtx q emb un) (M : Nat) {r : Nat} (hr : r < q.nr) (c : ℚ) {S S' : ScalSpec.St}
    (ho : ∀ r', r' ≠ r → S' r' = S r') {f : ℕ} (x : Data α ρ f)
    (hv : valS q K un x M S' r = (c : ℂ) • valS q K un x M S r) :
    point f (actPoint (scD (un r) c)) (vecS q K un emb x M S) = vecS q K un emb x M S' := by
  funext j i
  show actPoint (scD (un r) c) (fun r' => vecS q K un emb x M S r' i) j = _
  rw [actPoint_scD]
  by_cases hj : j = un r
  · rw [if_pos hj]
    have e1 : emb j = r := by rw [hj, hq.hin r hr]
    show (c : ℂ) * valS q K un x M S (emb j) i = valS q K un x M S' (emb j) i
    rw [e1, hv]; rfl
  · rw [if_neg hj, one_mul]
    have e1 : emb j ≠ r := fun e => hj (by rw [← e, hq.hun])
    show valS q K un x M S (emb j) i = valS q K un x M S' (emb j) i
    rw [valS_congr q K un x M (ho _ e1)]

theorem step_sound (hq : SCtx q emb un) (M : Nat) {e : WEv} {S S' : ScalSpec.St} (h : ScalSpec.Step q e S S')
    (hB : Bd M S) {f : ℕ} (x : Data α ρ f) :
    Bd M S' ∧ eMap un e f (vecS q K un emb x M S) = vecS q K un emb x M S' := by
  cases e with
  | g g => exact adds_sound (K := K) hq M h hB x
  | sc f0 r co =>
    obtain ⟨hr, hn, hden, he, ho⟩ := h
    refine ⟨bd_other hB ho (fun k hk => ?_), ?_⟩
    · have := he k
      rw [hB r k hk] at this
      simpa [hden] using this
    · show point f (actPoint (scD (un r) (coQ co))) (vecS q K un emb x M S) = _
      refine scD_sound hq M hr _ ho x ?_
      rw [valS_scale q K un x M hden he]
      show _ = (((cfC co).val : ℚ) : ℂ) • _
      rw [cfC_val]
  | w r a f0 f1 => exact False.elim h
  | za r f0 =>
    obtain ⟨hr, hz, ho⟩ := h
    refine ⟨bd_other hB ho (fun k _ => hz k), ?_⟩
    show point f (actPoint (scD (un r) 0)) (vecS q K un emb x M S) = _
    refine scD_sound hq M hr _ ho x ?_
    rw [valS_zero q K un x M hz]; simp
  | zf r =>
    obtain ⟨hr, hz, ho⟩ := h
    refine ⟨bd_other hB ho (fun k _ => hz k), ?_⟩
    show point f (actPoint (scD (un r) 0)) (vecS q K un emb x M S) = _
    refine scD_sound hq M hr _ ho x ?_
    rw [valS_zero q K un x M hz]; simp
  | dn r f0 =>
    have e : S' = S := h
    subst e
    exact ⟨hB, rfl⟩

theorem run_sound (hq : SCtx q emb un) (M : Nat) : ∀ {evs : List WEv} {S S' : ScalSpec.St},
    ScalSpec.Run q evs S S' → Bd M S → ∀ {f : ℕ} (x : Data α ρ f),
    Bd M S' ∧ esMap un evs f (vecS q K un emb x M S) = vecS q K un emb x M S' := by
  intro evs S S' h
  induction h with
  | nil S => intro hB f x; exact ⟨hB, rfl⟩
  | @cons e l S S1 S2 h1 _ ih =>
    intro hB f x
    obtain ⟨b1, v1⟩ := step_sound (K := K) hq M h1 hB x
    obtain ⟨b2, v2⟩ := ih b1 x
    refine ⟨b2, ?_⟩
    show esMap un l f (eMap un e f (vecS q K un emb x M S)) = _
    rw [v1, v2]

theorem vecR_eq (hq : SCtx q emb un) (hd : q.nr ≤ 2 ^ q.d) {R : RT} (hR : R.wf q.d) (M : Nat)
    (hM : trieB R ≤ M) {f : ℕ} (x : Data α ρ f) :
    vecR q K un emb R x = vecS q K un emb x M (ScalSpec.St.of R) := by
  funext j
  show rowV q K un x (R.get (emb j)) = valS q K un x M (ScalSpec.St.of R) (emb j)
  rw [get_eq q.d R hR (emb j) (by have := hq.hlt j; omega)]
  exact rowV_coef q K un x M _ (fun e he => by have := trieB_lt R _ e he; omega)

end Ev
end RefB

theorem ParOK.of_ref {q : SPw} {evs : List WEv} {R R' : RT} (h : ScalSpec.RefOK q evs R R') : ParOK q :=
  ⟨h.2.1, h.2.2.1, h.2.2.2.1, h.2.2.2.2.1, h.2.2.2.2.2.1⟩

theorem ScalOK.of_ref {q : SPw} {evs : List WEv} {R R' : RT} (h : ScalSpec.RefOK q evs R R')
    (hR' : R'.wf q.d) : ScalOK q evs R R' := by
  have hR : R.wf q.d := RefB.wf_of_spec q.d R h.1
  have hd : q.nr ≤ 2 ^ q.d := h.2.2.2.1
  refine ⟨hR, ?_⟩
  intro α ρ _ _ _ _ K emb un hq hK f x
  have hB : RefB.Bd (max (RefB.trieB R) (RefB.trieB R')) (ScalSpec.St.of R) := by
    intro r k hk
    exact RefB.coef_zero _ k (fun e he hek => by have := RefB.trieB_lt R r e he; omega)
  obtain ⟨_, v⟩ := RefB.run_sound (K := K) hq _ h.2.2.2.2.2.2 hB x
  rw [RefB.vecR_eq (K := K) hq hd hR _ (Nat.le_max_left _ _) x, v,
    ← RefB.vecR_eq (K := K) hq hd hR' _ (Nat.le_max_right _ _) x]

end KLW
