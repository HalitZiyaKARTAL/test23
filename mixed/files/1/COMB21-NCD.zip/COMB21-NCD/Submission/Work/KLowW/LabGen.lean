import Lean.Elab.Command
import Submission.Work.WR.EvGen

namespace KLowW.LabGen
open Lean Elab Command WR.EvGen

def catE (ty : Expr) (xs : Array Expr) : Expr :=
  let l := listT ty
  xs.pop.foldr (fun x acc => mkApp6 (mkConst ``HAppend.hAppend [0, 0, 0]) l l l
    (mkApp2 (mkConst ``instHAppendOfAppend [0]) l (mkApp (mkConst ``List.instAppend [0]) ty)) x acc) xs.back!

def cmd (s : String) : CommandElabM Unit := do
  match Parser.runParserCategory (← getEnv) `command s with
  | .ok stx => elabCommand stx
  | .error e => throwError e

syntax (name := labStates) "lab_states " ident ident ident ident num : command
@[command_elab labStates] def elabLabStates : CommandElab := fun stx => do
  let ns ← getCurrNamespace
  let nm (i : Nat) := ns ++ stx[i].getId
  let m ← mem.get
  unless m.evs == nm 3 do throwError "lab_states: {stx[3].getId} was not decoded by `wr_events` in this module"
  let natsOf (i : Nat) : CommandElabM (Array Nat) := do
    let some (_, vs) := m.nats.find? (·.1 == nm i)
      | throwError "lab_states: {stx[i].getId} was not decoded in this module"
    return vs
  -- the parts of `evs`: its segments, with their events (all chunks of a segment, in order)
  let ps : Array (Name × Array MEv) := m.segs.map fun s => (s.1, s.2.foldl (fun a c => a ++ c.2) #[])
  let sizes := ps.map (·.2.size)
  let rs ← natsOf 4
  let s0 ← natsOf 1
  let sF ← natsOf 2
  let mut S : Array Nat := (Array.range 2048).map fun k => s0.getD k 0
  let SF : Array Nat := (Array.range 2048).map fun k => sF.getD k 0
  let nat := mkConst ``Nat; let ev := mkConst ``KLW.WEv; let tr := mkConst ``SSC.Trie
  let nmi (s : String) (i : Nat) := ns ++ Name.mkSimple s!"{s}{i}"
  addDef (nmi "labS" 0) tr (mkConst (nm 1)); addDef (nmi "labQ" 0) (listT nat) (mkConst (nm 4))
  let mut j := 0; let mut rk := 0
  let k := nat! stx[5]
  let tot := sizes.foldl (· + ·) 0
  let mut cnt := 0
  for i in [0:k] do
    -- the parts of chunk `i`: up to `(i+1)/k` of all events (whole parts)
    let mut grp : Array (Name × Array MEv) := #[]
    while j < ps.size && (i == k - 1 || cnt * k < (i + 1) * tot) do
      grp := grp.push ps[j]!; cnt := cnt + sizes[j]!; j := j + 1
    let r0 := rk
    for c in grp do
      for e in c.2 do
        -- as `eOut` / `eRanks`: gates and scales take a rank per register whose frame changes, `dn` always one,
        -- `za` none; `zf` names no register
        let regs := if e.kind == 3 then #[] else e.regs
        for r in regs do
          if e.kind == 4 || ((e.kind == 0 || e.kind == 1) && S[r]! != e.f) then rk := rk + 1
          S := S.set! r e.f
    addDef (nmi "labE" i) (listT ev) (catE ev (grp.map fun c => mkConst c.1))
    let Q := mkConst (nmi "labQ" i)
    if i < k - 1 then
      addDef (nmi "labR" i) (listT nat) (mkApp3 (mkConst ``List.take [0]) nat (lit (rk - r0)) Q)
      addDef (nmi "labQ" (i + 1)) (listT nat) (mkApp3 (mkConst ``List.drop [0]) nat (lit (rk - r0)) Q)
      addTrie (nmi "labS" (i + 1)) 11 0 S
    else
      addDef (nmi "labR" i) (listT nat) Q
      addDef (nmi "labS" (i + 1)) tr (mkConst (nm 2))
  unless S == SF do throwError "lab_states: the replay does not end at {stx[2].getId}"
  unless rk == rs.size do throwError "lab_states: {rk} ranks taken, {rs.size} given"
  -- the chunks give back the whole lists
  let cat (s : String) := " ++ (".intercalate ((List.range k).map fun i => s!"{s}{i}") ++ String.mk (List.replicate (k - 1) ')')
  let sp (s : String) := " ".intercalate ((List.range k).map fun i => s!"{s}{i}")
  cmd s!"theorem lab_evs : {cat "labE"} = {stx[3].getId} := by delta {sp "labE"} {stx[3].getId}; simp only [List.append_assoc]"
  cmd s!"theorem lab_rs : {cat "labR"} = {stx[4].getId} := by delta {sp "labR"} {sp "labQ"}; simp only [List.take_append_drop]"

end KLowW.LabGen
