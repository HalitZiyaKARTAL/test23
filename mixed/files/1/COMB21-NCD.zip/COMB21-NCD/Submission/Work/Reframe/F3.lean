import Submission.Work.Reframe.SNet
import Submission.Work.Combine.Ranks
import Submission.Work.SharedSumChecker.Mats


namespace OAI
namespace PowerSaving
namespace RF
open Binary Matrix Finset RAM SS CB
noncomputable section

section
variable {H : Type} [Fintype H] [DecidableEq H]

def reindex (A : OBase H) (σ : Equiv.Perm H) : OBase H where
  v := fun i => A.v (σ i)
  rows := fun i j => by
    rw [A.rows]
    by_cases h : i = j
    · subst h
      rw [if_pos rfl, if_pos rfl]
    · rw [if_neg h, if_neg (fun e : σ i = σ j => h (σ.injective e))]

end

end
end RF
end PowerSaving
end OAI


