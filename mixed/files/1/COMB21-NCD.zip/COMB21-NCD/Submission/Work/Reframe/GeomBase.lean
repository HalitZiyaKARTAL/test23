import Submission.Work.Reframe.FrameAlg


namespace OAI
namespace PowerSaving
namespace RF
open Binary Matrix Finset RAM SS CB
noncomputable section

section Gen
variable {n : Type} [Fintype n] [DecidableEq n]

def diagI (S : Finset n) : Matrix n n F := Matrix.diagonal fun i => if i ∈ S then 1 else 0

lemma diagI_apply (S : Finset n) (a b : n) :
    diagI S a b = if a = b then (if a ∈ S then 1 else 0) else 0 :=
  Matrix.diagonal_apply _ _ _

lemma mul_diagI_mul (M : Matrix n n F) (S : Finset n) (a b : n) :
    (M * diagI S * Mᵀ) a b = ∑ k ∈ S, M a k * M b k := by
  have h1 : (M * diagI S * Mᵀ) a b = ∑ k, M a k * (if k ∈ S then 1 else 0) * M b k := by
    rw [Matrix.mul_apply]
    apply Finset.sum_congr rfl
    intro k _
    unfold diagI
    rw [Matrix.mul_diagonal]
    rfl
  calc (M * diagI S * Mᵀ) a b = ∑ k, M a k * (if k ∈ S then 1 else 0) * M b k := h1
    _ = ∑ k ∈ S, M a k * (if k ∈ S then 1 else 0) * M b k :=
        (Finset.sum_subset (Finset.subset_univ S) (fun k _ hk => by simp [hk])).symm
    _ = ∑ k ∈ S, M a k * M b k := Finset.sum_congr rfl (fun k hk => by simp [hk])

def cmat (A : OBase n) : Matrix n n F := fun a k => A.v k a

lemma cmat_orth (A : OBase n) : (cmat A)ᵀ * cmat A = 1 := by
  ext i j
  have h := A.rows i j
  rw [Matrix.mul_apply, Matrix.one_apply]
  exact h

lemma mat_eq_cmat (A : OBase n) (s : Finset n) : A.mat s = cmat A * diagI s * (cmat A)ᵀ := by
  ext a b
  rw [mul_diagI_mul]
  rfl

def ofCols (M : Matrix n n F) (hM : Mᵀ * M = 1) : OBase n where
  v := fun k a => M a k
  rows := fun i j => by
    have h := congrFun (congrFun hM i) j
    rw [Matrix.mul_apply, Matrix.one_apply] at h
    exact h

lemma ofCols_mat (M : Matrix n n F) (hM : Mᵀ * M = 1) (S : Finset n) :
    (ofCols M hM).mat S = M * diagI S * Mᵀ :=
  mat_eq_cmat (ofCols M hM) S

lemma frame_ofCols (M : Matrix n n F) (hM : Mᵀ * M = 1) (S : Finset n) :
    frame (ofCols M hM) S = frameM (M * diagI S * Mᵀ) := by
  rw [frame_eq, ofCols_mat]

lemma submatrix_diagI (M : Matrix n n F) (π : Equiv.Perm n) (S : Finset n) :
    M.submatrix id π * diagI S * (M.submatrix id π)ᵀ
      = M * diagI (S.map π.toEmbedding) * Mᵀ := by
  ext a b
  have h1 := mul_diagI_mul (M.submatrix id π) S a b
  have h2 := mul_diagI_mul M (S.map π.toEmbedding) a b
  rw [Finset.sum_map] at h2
  exact h1.trans h2.symm

lemma submatrix_orth (M : Matrix n n F) (hM : Mᵀ * M = 1) (π : Equiv.Perm n) :
    (M.submatrix id π)ᵀ * M.submatrix id π = 1 := by
  ext i j
  have h := congrFun (congrFun hM (π i)) (π j)
  rw [Matrix.mul_apply, Matrix.one_apply] at h ⊢
  by_cases hij : i = j
  · subst hij
    rw [if_pos rfl] at h ⊢
    exact h
  · have hne : π i ≠ π j := fun e => hij (π.injective e)
    rw [if_neg hne] at h
    rw [if_neg hij]
    exact h

lemma mul_orth {M N : Matrix n n F} (hM : Mᵀ * M = 1) (hN : Nᵀ * N = 1) :
    (M * N)ᵀ * (M * N) = 1 := by
  rw [Matrix.transpose_mul, Matrix.mul_assoc, ← Matrix.mul_assoc Mᵀ, hM, Matrix.one_mul, hN]

lemma mul_eq_one_comm_F {M N : Matrix n n F} (h : N * M = 1) : M * N = 1 := by
  have hinj : Function.Injective (M *ᵥ ·) := fun v w e => by
    have e' := congrArg (N *ᵥ ·) e
    simp only [Matrix.mulVec_mulVec, h, Matrix.one_mulVec] at e'
    exact e'
  have hv : ∀ v, M *ᵥ (N *ᵥ v) = v := fun v => by
    obtain ⟨w, rfl⟩ := Finite.injective_iff_surjective.mp hinj v
    show M *ᵥ (N *ᵥ (M *ᵥ w)) = M *ᵥ w
    simp only [Matrix.mulVec_mulVec, h, Matrix.one_mulVec]
  ext i j
  have e := congrFun (hv (Pi.single j 1)) i
  rw [Matrix.mulVec_mulVec] at e
  -- CHECK: `dotProduct` (root name in current Mathlib) and the simp normal form of Pi.single sums
  simpa [Matrix.mulVec, dotProduct, Pi.single_apply, Matrix.one_apply] using e

lemma transpose_orth {M : Matrix n n F} (hM : Mᵀ * M = 1) : Mᵀᵀ * Mᵀ = 1 := by
  rw [Matrix.transpose_transpose]
  exact mul_eq_one_comm_F hM

abbrev Orth (n : Type) [Fintype n] [DecidableEq n] := {g : Matrix n n F // gᵀ * g = 1}

namespace Orth

lemma orth' (g : Orth n) : g.1 * g.1ᵀ = 1 := mul_eq_one_comm_F g.2

def one : Orth n := ⟨1, by rw [Matrix.transpose_one, Matrix.one_mul]⟩

lemma card_pos : 1 ≤ Fintype.card (Orth n) := Fintype.card_pos_iff.mpr ⟨one⟩

lemma submatrix_symm (M : Matrix n n F) (π : Equiv.Perm n) :
    (M.submatrix id π).submatrix id π.symm = M := by
  ext a b
  show M a (π (π.symm b)) = M a b
  rw [Equiv.apply_symm_apply]

lemma submatrix_symm' (M : Matrix n n F) (π : Equiv.Perm n) :
    (M.submatrix id π.symm).submatrix id π = M := by
  ext a b
  show M a (π.symm (π b)) = M a b
  rw [Equiv.symm_apply_apply]

def conjPerm (B : Matrix n n F) (hB : Bᵀ * B = 1) (π : Equiv.Perm n) : Orth n ≃ Orth n where
  toFun g := ⟨(g.1 * B).submatrix id π * Bᵀ,
    mul_orth (submatrix_orth _ (mul_orth g.2 hB) π) (transpose_orth hB)⟩
  invFun g := ⟨(g.1 * B).submatrix id π.symm * Bᵀ,
    mul_orth (submatrix_orth _ (mul_orth g.2 hB) π.symm) (transpose_orth hB)⟩
  left_inv g := by
    apply Subtype.ext
    show ((g.1 * B).submatrix id π * Bᵀ * B).submatrix id π.symm * Bᵀ = g.1
    rw [Matrix.mul_assoc ((g.1 * B).submatrix id π), hB, Matrix.mul_one, submatrix_symm,
      Matrix.mul_assoc, mul_eq_one_comm_F hB, Matrix.mul_one]
  right_inv g := by
    apply Subtype.ext
    show ((g.1 * B).submatrix id π.symm * Bᵀ * B).submatrix id π * Bᵀ = g.1
    rw [Matrix.mul_assoc ((g.1 * B).submatrix id π.symm), hB, Matrix.mul_one, submatrix_symm',
      Matrix.mul_assoc, mul_eq_one_comm_F hB, Matrix.mul_one]

lemma conjPerm_mul (B : Matrix n n F) (hB : Bᵀ * B = 1) (π : Equiv.Perm n) (g : Orth n) :
    (conjPerm B hB π g).1 * B = (g.1 * B).submatrix id π := by
  show (g.1 * B).submatrix id π * Bᵀ * B = _
  rw [Matrix.mul_assoc, hB, Matrix.mul_one]

end Orth

end Gen
end
end RF
end PowerSaving
end OAI
