import Submission.Work.Reframe.Basic


namespace OAI
namespace PowerSaving
namespace CB
open Binary Matrix Finset RAM SS
noncomputable section

section
variable {α : Type*} [Fintype α] [DecidableEq α]

lemma frame_mul_unframe (B : OBase α) (q w : Finset α) (h : Disjoint q w) (Z : CMat α) :
    frame B (q ∪ w) * (unframe B q * Z) = frame B w * Z := by
  rw [frame_union B q w h, frame, frame, wrap_comm, ← frame, ← frame, Matrix.mul_assoc,
    ← Matrix.mul_assoc (frame B q), unframe_right, Matrix.one_mul]

end
end
end CB
end PowerSaving
end OAI
