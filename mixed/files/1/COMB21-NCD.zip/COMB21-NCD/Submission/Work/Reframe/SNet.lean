import Submission.Work.Reframe.Basic
import Submission.Work.GFrame.Engine.Route


namespace OAI
namespace PowerSaving
namespace CB
open Binary Matrix Finset RAM SS
noncomputable section

section Erase
variable {T Sl C : Type} [Fintype T] [DecidableEq T] [Fintype Sl] [DecidableEq Sl]
  [Fintype C] [DecidableEq C]

def eraseM : Matrix (Box T Sl C) (Box T Sl C) ℚ := fun i j =>
  Sum.elim (fun _ => if i = j then (1:ℚ) else 0)
    (Sum.elim (fun _ => if i = j then (1:ℚ) else 0) (fun _ => 0)) i

def eraseC (z : Box T Sl C → ℂ) : Box T Sl C → ℂ :=
  stamp (z ∘ bX) (z ∘ bY) (z ∘ bS) (fun _ => 0)

lemma actPoint_eraseM (z : Box T Sl C → ℂ) : actPoint eraseM z = eraseC z := by
  funext i
  rcases i with ((t|t)|(q|c))
  · exact sum_ind_right (Sum.inl (Sum.inl t)) z
  · exact sum_ind_right (Sum.inl (Sum.inr t)) z
  · exact sum_ind_right (Sum.inr (Sum.inl q)) z
  · show ∑ j, (((0:ℚ)) : ℂ) * z j = 0
    simp

def shearF (z : Box T Sl C → ℂ) : Box T Sl C → ℂ :=
  stamp (z ∘ bX) (z ∘ bY + z ∘ bX) (z ∘ bS) (fun _ => 0)

def shearB (z : Box T Sl C → ℂ) : Box T Sl C → ℂ :=
  stamp (z ∘ bX - z ∘ bY) (z ∘ bY) (z ∘ bS) (fun _ => 0)

variable {α : Type} [Fintype α] [DecidableEq α]

lemma xerase {S S' : Box T Sl C → CMat α} (hX : ∀ t, S' (bX t) = S (bX t))
    (hY : ∀ t, S' (bY t) = S (bY t)) (hS : ∀ q, S' (bS q) = S (bS q)) :
    GF.GRoute S S' eraseC (fun _ => 0) := by
  have h := GF.GRoute.gate (α := α) (eraseM (T := T) (Sl := Sl) (C := C)) S S' (fun i j hij => by
    rcases i with ((t|t)|(q|c))
    · have e : (Sum.inl (Sum.inl t) : Box T Sl C) = j := by
        by_contra hne
        exact hij (if_neg hne)
      subst e
      exact hX t
    · have e : (Sum.inl (Sum.inr t) : Box T Sl C) = j := by
        by_contra hne
        exact hij (if_neg hne)
      subst e
      exact hY t
    · have e : (Sum.inr (Sum.inl q) : Box T Sl C) = j := by
        by_contra hne
        exact hij (if_neg hne)
      subst e
      exact hS q
    · exact absurd rfl hij)
  have hg : actPoint (eraseM (T := T) (Sl := Sl) (C := C)) = eraseC := funext fun z => actPoint_eraseM z
  exact hg ▸ h

end Erase

end
end CB
end PowerSaving
end OAI


namespace OAI
namespace PowerSaving
namespace RF
open Binary Matrix Finset RAM SS CB
noncomputable section

abbrev SLive (Γ T Sl : Type) := ((Γ × T) ⊕ (Γ × T)) ⊕ (Γ × Sl)
abbrev SRole (Γ T Sl C : Type) := SLive Γ T Sl ⊕ (Γ × C)

section Roles
variable {Γ T Sl C : Type}

def jX (k : Γ × T) : SRole Γ T Sl C := .inl (.inl (.inl k))
def jY (k : Γ × T) : SRole Γ T Sl C := .inl (.inl (.inr k))
def jS (k : Γ × Sl) : SRole Γ T Sl C := .inl (.inr k)
def jC (k : Γ × C) : SRole Γ T Sl C := .inr k

def mkS {β : Type*} (fX fY : Γ → T → β) (fS : Γ → Sl → β) (fC : Γ → C → β) :
    SRole Γ T Sl C → β
  | .inl (.inl (.inl (g,t))) => fX g t
  | .inl (.inl (.inr (g,t))) => fY g t
  | .inl (.inr (g,q)) => fS g q
  | .inr (g,c) => fC g c

def spos (εX : T → Γ ≃ Γ) (εS : Γ ≃ Γ) (d : Γ) : Box T Sl C → SRole Γ T Sl C :=
  stamp (fun t => jX ((εX t).symm d, t)) (fun t => jY ((εX t).symm d, t))
    (fun q => jS (εS d, q)) (fun c => jC (εS d, c))

lemma spos_inj (εX : T → Γ ≃ Γ) (εS : Γ ≃ Γ) {d d' : Γ} {x y : Box T Sl C}
    (h : (spos εX εS d x : SRole Γ T Sl C) = spos εX εS d' y) : d = d' ∧ x = y := by
  rcases x with ((t|t)|(q|c)) <;> rcases y with ((t'|t')|(q'|c')) <;>
    simp only [spos, stamp, jX, jY, jS, jC, Sum.elim_inl, Sum.elim_inr, Sum.inl.injEq,
      Sum.inr.injEq, Prod.mk.injEq, reduceCtorEq] at h
  · obtain ⟨h1, h2⟩ := h; subst h2; exact ⟨(εX t).symm.injective h1, rfl⟩
  · obtain ⟨h1, h2⟩ := h; subst h2; exact ⟨(εX t).symm.injective h1, rfl⟩
  · obtain ⟨h1, h2⟩ := h; subst h2; exact ⟨εS.injective h1, rfl⟩
  · obtain ⟨h1, h2⟩ := h; subst h2; exact ⟨εS.injective h1, rfl⟩

def sem (εX : T → Γ ≃ Γ) (εS : Γ ≃ Γ) (d : Γ) : Box T Sl C ↪ SRole Γ T Sl C :=
  ⟨spos εX εS d, fun _ _ h => (spos_inj εX εS h).2⟩

lemma spos_X (εX : T → Γ ≃ Γ) (εS : Γ ≃ Γ) (g : Γ) (t : T) :
    (spos εX εS (εX t g) (bX t) : SRole Γ T Sl C) = jX (g, t) := by
  show jX ((εX t).symm (εX t g), t) = _
  rw [Equiv.symm_apply_apply]

lemma spos_Y (εX : T → Γ ≃ Γ) (εS : Γ ≃ Γ) (g : Γ) (t : T) :
    (spos εX εS (εX t g) (bY t) : SRole Γ T Sl C) = jY (g, t) := by
  show jY ((εX t).symm (εX t g), t) = _
  rw [Equiv.symm_apply_apply]

lemma spos_S (εX : T → Γ ≃ Γ) (εS : Γ ≃ Γ) (g : Γ) (q : Sl) :
    (spos εX εS (εS.symm g) (bS q) : SRole Γ T Sl C) = jS (g, q) := by
  show jS (εS (εS.symm g), q) = _
  rw [Equiv.apply_symm_apply]

lemma spos_C (εX : T → Γ ≃ Γ) (εS : Γ ≃ Γ) (g : Γ) (c : C) :
    (spos εX εS (εS.symm g) (bC c) : SRole Γ T Sl C) = jC (g, c) := by
  show jC (εS (εS.symm g), c) = _
  rw [Equiv.apply_symm_apply]

variable [DecidableEq Γ] [DecidableEq T] [DecidableEq Sl] [DecidableEq C]
  [Fintype T] [Fintype Sl] [Fintype C]

lemma sem_dis (εX : T → Γ ≃ Γ) (εS : Γ ≃ Γ) (d d' : Γ) (h : d ≠ d') (x : SRole Γ T Sl C) :
    x ∈ covered (sem εX εS d) → x ∉ covered (sem εX εS d') := by
  simp only [cover_iff, not_exists]
  rintro ⟨u, hu⟩ v hv
  exact h (spos_inj εX εS (hu.trans hv.symm)).1

lemma scovered (εX : T → Γ ≃ Γ) (εS : Γ ≃ Γ) (r : SRole Γ T Sl C) :
    ∃ d, r ∈ covered (sem εX εS d) := by
  rcases r with (((⟨g,t⟩|⟨g,t⟩)|⟨g,q⟩)|⟨g,c⟩)
  · exact ⟨εX t g, (cover_iff ..).mpr ⟨bX t, spos_X εX εS g t⟩⟩
  · exact ⟨εX t g, (cover_iff ..).mpr ⟨bY t, spos_Y εX εS g t⟩⟩
  · exact ⟨εS.symm g, (cover_iff ..).mpr ⟨bS q, spos_S εX εS g q⟩⟩
  · exact ⟨εS.symm g, (cover_iff ..).mpr ⟨bC c, spos_C εX εS g c⟩⟩

end Roles

section Stage
variable {H T Sl C α Γ : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C] [Fintype α] [DecidableEq α]
  [Fintype Γ] [DecidableEq Γ]

end Stage
end
end RF
end PowerSaving
end OAI

