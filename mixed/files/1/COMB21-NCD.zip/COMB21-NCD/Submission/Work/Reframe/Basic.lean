import Submission.Work.Combine.XG
import Submission.Work.SharedSumStructured.Invocation


namespace OAI
namespace PowerSaving
namespace RAM
open Binary Matrix Finset
noncomputable section

section
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

theorem multiAct_mulR (f : ℕ) (S D : ρ → CMat α) (x : Data α ρ f) :
    multiAct f (fun r => S r * D r) x = multiAct f S (multiAct f D x) := by
  funext r
  show matAct f (S r * D r) (x r) = matAct f (S r) (matAct f (D r) (x r))
  rw [matAct_mul]

end
end
end RAM

end PowerSaving
end OAI

