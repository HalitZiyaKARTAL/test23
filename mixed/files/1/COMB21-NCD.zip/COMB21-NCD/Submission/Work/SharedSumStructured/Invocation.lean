import Submission.Work.SharedSumStructured.Labels


namespace OAI
namespace PowerSaving
namespace SS
open Binary Matrix Finset RAM
noncomputable section

section Ap
variable {A B C : Type*} [Fintype B] [Fintype C]

def ap (M : Matrix A B ℚ) (u : B → ℂ) : A → ℂ := fun i => ∑ j, (M i j : ℂ) * u j

lemma ap_mul (M : Matrix A B ℚ) (N : Matrix B C ℚ) (u : C → ℂ) :
    ap (M * N) u = ap M (ap N u) := by
  funext i
  simp only [ap, Matrix.mul_apply, Rat.cast_sum, Rat.cast_mul, sum_mul, mul_sum, mul_assoc]
  rw [sum_comm]
lemma ap_one [DecidableEq B] (u : B → ℂ) : ap (1 : Matrix B B ℚ) u = u := by
  funext i
  simp only [ap, Matrix.one_apply]
  exact sum_ind_right i u
lemma actPoint_eq_ap [DecidableEq B] (M : Matrix B B ℚ) : actPoint M = ap M := rfl
end Ap

section Box
variable (T Sl C : Type)

abbrev Box := (T ⊕ T) ⊕ (Sl ⊕ C)

variable {T Sl C}

def bX (t : T) : Box T Sl C := .inl (.inl t)
def bY (t : T) : Box T Sl C := .inl (.inr t)
def bS (q : Sl) : Box T Sl C := .inr (.inl q)
def bC (c : C) : Box T Sl C := .inr (.inr c)

def stamp {β : Type*} (x y : T → β) (s : Sl → β) (c : C → β) : Box T Sl C → β :=
  Sum.elim (Sum.elim x y) (Sum.elim s c)

variable [Fintype T] [DecidableEq T] [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C]

end Box

structure Circuit (H T Sl C : Type) [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
    [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C] where
  tv : T → Space H
  L : Matrix Sl Sl ℚ
  Linv : Matrix Sl Sl ℚ
  V : Matrix Sl T ℚ
  Jp : Matrix T Sl ℚ
  Jr : Matrix T C ℚ
  Cc : Matrix C Sl ℚ
  φ4 : Sl → Lbl H
  φ5 : Sl → Lbl H
  φ7 : Sl → Lbl H
  cen : C → Lbl H
  hLL : L * Linv = 1
  hLL' : Linv * L = 1
  hid : (Jr * Cc + Jp) * L * V = 1
  cx : ∀ t, Climbs (lineL (tv t)) fullL
  cy : ∀ t, Climbs zeroL (perpL (tv t))
  c04 : ∀ q, Climbs zeroL (φ4 q)
  c57 : ∀ q, Climbs (φ5 q) (φ7 q)
  c7F : ∀ q, Climbs (φ7 q) fullL
  cc : ∀ c, Climbs zeroL (cen c)
  sV : ∀ q t, V q t ≠ 0 → φ4 q = lineL (tv t)
  sC : ∀ c q, Cc c q ≠ 0 → cen c = φ5 q
  sJ : ∀ t q, Jp t q ≠ 0 → φ7 q = perpL (tv t)
  circ : ∀ {α : Type} [Fintype α] [DecidableEq α] (Fm : FMap H α),
    GPath (fun q => Fm.lab (φ4 q)) (fun q => Fm.lab (φ5 q)) (actPoint L) 0 ∧
    GPath (fun q => Fm.lab (φ4 q)) (fun q => Fm.lab (φ5 q)) (actPoint Linvᵀ) 0

section Invocation
variable {H T Sl C : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C]
variable {α : Type} [Fintype α] [DecidableEq α]

variable (K : Circuit H T Sl C)

end Invocation
end
end SS
end PowerSaving
end OAI
