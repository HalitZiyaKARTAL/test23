import Submission.Work.Scratch.Engine


namespace OAI
namespace PowerSaving
namespace SS
open Binary Matrix Finset RAM
noncomputable section

section
variable {α : Type*} [Fintype α] [DecidableEq α]

def Reach (A B : CMat α) (n : ℕ) : Prop :=
  ∃ zs : List (Space α), zs.length = n ∧ (∀ z ∈ zs, dot z z = 1) ∧
    B = (zs.map delta).prod * A


lemma frame_union (A : OBase α) (s t : Finset α) (h : Disjoint s t) :
    frame A (s ∪ t) = frame A s * frame A t := by
  induction s using Finset.induction with
  | empty => simp
  | insert i s hi ih =>
    have hd : Disjoint s t := disjoint_of_subset_left (subset_insert i s) h
    have hit : i ∉ t := fun g => (disjoint_left.mp h) (mem_insert_self i s) g
    have hnot : i ∉ s ∪ t := by simp [hi, hit]
    rw [insert_union, frame_ins A _ i hnot, ih hd, frame_ins A _ i hi, Matrix.mul_assoc]

variable {ρ σ : Type*} [Fintype ρ] [DecidableEq ρ]

structure Fr (α : Type*) where
  M : CMat α
  d : ℕ

def fmass (s : ρ → Fr α) : ℕ := ∑ r, (s r).d

def GPath (s t : ρ → Fr α) (g : (ρ→ℂ) → (ρ→ℂ)) (L : ℕ) : Prop :=
  ∃ p : PWord α ρ, tally p + fmass s = fmass t + 2*L ∧
    ∀ (f : ℕ) (x : Data α ρ f),
      walk f p (multiAct f (fun r => (s r).M) x) = multiAct f (fun r => (t r).M) (point f g x)

end
end
end SS
end PowerSaving
end OAI
