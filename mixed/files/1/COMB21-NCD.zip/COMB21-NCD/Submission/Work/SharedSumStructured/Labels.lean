import Submission.Work.SharedSumStructured.GPath


namespace OAI
namespace PowerSaving
namespace SS
open Binary Matrix Finset RAM
noncomputable section

section Single
variable {H : Type} [Fintype H] [DecidableEq H]

structure Lbl (H : Type) where
  P : Matrix H H F
  d : ℕ

def tt (z : Space H) : Matrix H H F := fun i j => z i * z j

def zeroL : Lbl H := ⟨0, 0⟩
def fullL : Lbl H := ⟨1, Fintype.card H⟩
def lineL (z : Space H) : Lbl H := ⟨tt z, 1⟩
def perpL (z : Space H) : Lbl H := ⟨1 + tt z, Fintype.card H - 1⟩
def Climb (U V : Lbl H) : Prop :=
  ∃ (A : OBase H) (s t : Finset H), s ⊆ t ∧ U.P = A.mat s ∧ V.P = A.mat t ∧
    V.d = U.d + (t \ s).card

inductive Climbs : Lbl H → Lbl H → Prop
  | refl (U : Lbl H) : Climbs U U
  | step {U V W : Lbl H} : Climb U V → Climbs V W → Climbs U W

lemma mat_empty (A : OBase H) : A.mat ∅ = 0 := by
  ext i j; simp [OBase.mat]

lemma mat_single (A : OBase H) (k : H) : A.mat {k} = tt (A.v k) := by
  ext i j; simp [OBase.mat, tt]

lemma mat_compl_single (A : OBase H) (k : H) : A.mat (univ \ {k}) = 1 + tt (A.v k) := by
  rw [OBase.mat_sub A univ {k} (subset_univ _), OBase.mat_univ, mat_single]
  ext i j
  simp only [Matrix.sub_apply, Matrix.add_apply]
  exact CharTwo.sub_eq_add _ _

lemma exists_base_one (z : Space H) (hz : dot z z = 1) (p : H) (hp : z p = 0) :
    ∃ (A : OBase H) (k : H), A.v k = z :=
  ⟨OBase.adapt (OBase.canonical H) p z hz (by simpa [OBase.canonical] using hp), p,
    OBase.adapt_pivot _ _ _ _ _⟩

end Single

def frameM {α : Type*} [Fintype α] [DecidableEq α] (M : Matrix α α F) : CMat α := wrap fun x => lum (M *ᵥ x)

lemma frame_eq {α : Type*} [Fintype α] [DecidableEq α] (A : OBase α) (s : Finset α) :
    frame A s = frameM (A.mat s) := by
  unfold frame frameM
  congr 1
  funext x
  congr 1
  funext i
  rw [OBase.proj_apply]
  rfl

structure FMap (H α : Type) [Fintype H] [DecidableEq H] [Fintype α] [DecidableEq α] where
  Φ : Matrix H H F → CMat α
  off : ℕ
  climb : ∀ (A : OBase H) (s t : Finset H), s ⊆ t →
    Reach (Φ (A.mat s)) (Φ (A.mat t)) (t \ s).card

section FMapLemmas
variable {H α : Type} [Fintype H] [DecidableEq H] [Fintype α] [DecidableEq α]

def FMap.lab (Fm : FMap H α) (U : Lbl H) : Fr α := ⟨Fm.Φ U.P, U.d + Fm.off⟩

end FMapLemmas

section Two
variable {H : Type} [Fintype H] [DecidableEq H]

variable (A B : OBase H) (ka kb : H)

end Two
end
end SS
end PowerSaving
end OAI
