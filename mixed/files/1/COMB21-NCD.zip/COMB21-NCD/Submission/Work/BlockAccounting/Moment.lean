import Mathlib.Analysis.SpecialFunctions.Pow.Real

namespace OAI.PowerSaving.BlockAccounting
open Finset

noncomputable def T (m : ℕ) (z : ℝ) (r n : ℕ) : ℝ := (n:ℝ) * ((r:ℝ)/(m:ℝ))^z

noncomputable def moment (m : ℕ) (z : ℝ) (blocks : List (ℕ × ℕ)) : ℝ :=
  (blocks.map fun b => (b.2:ℝ) * ((b.1:ℝ)/(m:ℝ))^z).sum

lemma log_le_of_le_expsum (x L : ℝ) (N : ℕ) (hx : 0 < x) (hL : 0 ≤ L)
    (h : x ≤ ∑ i ∈ range N, L^i / (i.factorial:ℝ)) : Real.log x ≤ L := by
  have h2 : x ≤ Real.exp L := h.trans (Real.sum_le_exp_of_nonneg hL N)
  calc Real.log x ≤ Real.log (Real.exp L) := Real.log_le_log hx h2
    _ = L := Real.log_exp L

def histFn (l : List (ℕ × ℕ)) (r : ℕ) : ℕ := ((l.filter fun b => b.1 = r).map Prod.snd).sum

lemma histFn_nil (r : ℕ) : histFn [] r = 0 := rfl

lemma histFn_cons (b : ℕ × ℕ) (l : List (ℕ × ℕ)) (r : ℕ) :
    histFn (b::l) r = (if b.1 = r then b.2 else 0) + histFn l r := by
  unfold histFn
  by_cases h : b.1 = r
  · simp [h]
  · simp [h]

end OAI.PowerSaving.BlockAccounting
