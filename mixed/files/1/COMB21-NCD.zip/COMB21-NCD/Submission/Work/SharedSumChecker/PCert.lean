import Submission.Work.SharedSumChecker.Check

namespace SSC

structure PCert where
  p : Par
  v : Nat
  R : Nat
  trips : List Nat
  F4 : List (List Op)
  F5 : List (List Op)
  F7 : List (List Op)
  fins : List (List FinE)
  N : Nat
  src : List Nat
  ret : List Nat
  retLab : List Nat
  pieces : List (List (Nat × Coef))
  scat : List (List (Nat × Coef))
  perps : List Nat
  eF : Nat

namespace PCert
variable (c : PCert)

end PCert

end SSC
