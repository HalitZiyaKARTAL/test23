import Submission.Work.SharedSumChecker.Sound


namespace SSC
open OAI.PowerSaving.Binary OAI.PowerSaving.RAM

theorem beq_true {a b : Nat} (h : Nat.beq a b = true) : a = b := Eq.mp Nat.beq_eq h
theorem ble_true {a b : Nat} (h : Nat.ble a b = true) : a ≤ b := Eq.mp Nat.ble_eq h

theorem guard_true {b k : Bool} (h : guard b k = true) : b = true ∧ k = true := by
  cases b with
  | false => exact absurd h Bool.false_ne_true
  | true => exact ⟨rfl, h⟩

def Trie.get : Trie → Nat → Nat
  | .leaf v, _ => v
  | .node l r, k => if k % 2 = 0 then l.get (k/2) else r.get (k/2)

def Trie.wf : Nat → Trie → Prop
  | 0, .leaf _ => True
  | d+1, .node l r => Trie.wf d l ∧ Trie.wf d r
  | _, _ => False

theorem Trie.getK_leaf (v key : Nat) (k : Nat → Bool) :
    (Trie.leaf v).getK key k = if key = 0 then k v else false := by
  cases key <;> rfl

theorem Trie.getK_node (l r : Trie) (key : Nat) (k : Nat → Bool) :
    (Trie.node l r).getK key k = if key % 2 = 0 then l.getK (key/2) k else r.getK (key/2) k := by
  have h1 : Nat.shiftRight key 1 = key / 2 := Nat.shiftRight_one key
  have h2 : Nat.land key 1 = key % 2 := Nat.and_one_is_mod key
  show Bool.rec (motive := fun _ => Bool) (r.getK (Nat.shiftRight key 1) k)
    (l.getK (Nat.shiftRight key 1) k) (Nat.beq (Nat.land key 1) 0) = _
  rw [h1, h2]
  rcases Nat.mod_two_eq_zero_or_one key with h | h <;> rw [h] <;> rfl

theorem Trie.set_node (l r : Trie) (key x : Nat) :
    (Trie.node l r).set key x =
      if key % 2 = 0 then .node (l.set (key/2) x) r else .node l (r.set (key/2) x) := by
  have h1 : Nat.shiftRight key 1 = key / 2 := Nat.shiftRight_one key
  have h2 : Nat.land key 1 = key % 2 := Nat.and_one_is_mod key
  show Bool.rec (motive := fun _ => Trie) (.node l (r.set (Nat.shiftRight key 1) x))
    (.node (l.set (Nat.shiftRight key 1) x) r) (Nat.beq (Nat.land key 1) 0) = _
  rw [h1, h2]
  rcases Nat.mod_two_eq_zero_or_one key with h | h <;> rw [h] <;> rfl

theorem Trie.wf_set (d : Nat) (t : Trie) (hwf : t.wf d) (key x : Nat) : (t.set key x).wf d := by
  induction d generalizing t key with
  | zero =>
    cases t with
    | leaf v => exact trivial
    | node l r => exact False.elim hwf
  | succ d ih =>
    cases t with
    | leaf v => exact False.elim hwf
    | node l r =>
      obtain ⟨hl, hr⟩ := hwf
      rw [Trie.set_node]
      by_cases h : key % 2 = 0
      · rw [if_pos h]; exact ⟨ih l hl _, hr⟩
      · rw [if_neg h]; exact ⟨hl, ih r hr _⟩

theorem Trie.get_set (d : Nat) (t : Trie) (hwf : t.wf d) (key key' x : Nat) (hk : key < 2^d)
    (hk' : key' < 2^d) : (t.set key x).get key' = if key' = key then x else t.get key' := by
  induction d generalizing t key key' with
  | zero =>
    cases t with
    | leaf v =>
      have h1 : key = 0 := by simpa using hk
      have h2 : key' = 0 := by simpa using hk'
      subst h1; subst h2; rfl
    | node l r => exact False.elim hwf
  | succ d ih =>
    cases t with
    | leaf v => exact False.elim hwf
    | node l r =>
      obtain ⟨hl, hr⟩ := hwf
      have hk2 : key / 2 < 2^d := by rw [pow_succ] at hk; omega
      have hk2' : key' / 2 < 2^d := by rw [pow_succ] at hk'; omega
      rw [Trie.set_node]
      by_cases h : key % 2 = 0 <;> by_cases h' : key' % 2 = 0
      · rw [if_pos h]
        simp only [Trie.get, h', ↓reduceIte]
        rw [ih l hl _ _ hk2 hk2']
        have e : (key'/2 = key/2) ↔ (key' = key) := by omega
        simp only [e]
      · rw [if_pos h]
        simp only [Trie.get, h', ↓reduceIte]
        have e : key' ≠ key := by omega
        rw [if_neg e]
      · rw [if_neg h]
        simp only [Trie.get, h', ↓reduceIte]
        have e : key' ≠ key := by omega
        rw [if_neg e]
      · rw [if_neg h]
        simp only [Trie.get, h', ↓reduceIte]
        rw [ih r hr _ _ hk2 hk2']
        have e : (key'/2 = key/2) ↔ (key' = key) := by omega
        simp only [e]

end SSC
