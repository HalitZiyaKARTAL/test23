import Submission.Work.Scratch.Engine
import Submission.Work.SharedSumChecker.Check


namespace SSC

theorem forceN_eq {α : Type} (n : Nat) (k : Nat → α) : forceN n k = k n := by
  cases n <;> rfl

theorem rep_zero (u : Nat) : rep u 0 = 0 := rfl
theorem rep_succ (u n : Nat) : rep u (n+1) = 2^u * rep u n + 1 := rfl

private theorem step_idx (u q r : Nat) (hu : 0 < u) :
    ¬ (u*(q+1) + r < u) ∧ u*(q+1) + r - u = u*q + r := by
  have h : u*(q+1) = u*q + u := Nat.mul_succ u q
  constructor <;> omega

theorem rep_bit (u : Nat) (hu : 0 < u) (n q r : Nat) (hr : r < u) :
    (rep u n).testBit (u*q + r) = (decide (r = 0) && decide (q < n)) := by
  induction n generalizing q with
  | zero => simp [rep_zero]
  | succ n ih =>
    rw [rep_succ, Nat.testBit_two_pow_mul_add _ (Nat.one_lt_two_pow (Nat.pos_iff_ne_zero.mp hu))]
    cases q with
    | zero =>
      simp only [Nat.mul_zero, Nat.zero_add, hr, ite_true]
      cases r with
      | zero => simp
      | succ r => simp [Nat.testBit_add_one]
    | succ q =>
      obtain ⟨h1, h2⟩ := step_idx u q r hu
      rw [if_neg h1, h2, ih q]
      simp

theorem mul_rep_bit (u : Nat) (hu : 0 < u) (y : Nat) (hy : y < 2^u) (n q r : Nat) (hr : r < u) :
    (y * rep u n).testBit (u*q + r) = (decide (q < n) && y.testBit r) := by
  induction n generalizing q with
  | zero => simp [rep_zero]
  | succ n ih =>
    have e : y * rep u (n+1) = 2^u * (y * rep u n) + y := by rw [rep_succ]; ring
    rw [e, Nat.testBit_two_pow_mul_add _ hy]
    cases q with
    | zero => simp [hr]
    | succ q =>
      obtain ⟨h1, h2⟩ := step_idx u q r hu
      rw [if_neg h1, h2, ih q]
      simp

section
variable (p : Par) (hh : 0 < p.h) (hw : p.h < p.w)
include hh hw

end

end SSC
