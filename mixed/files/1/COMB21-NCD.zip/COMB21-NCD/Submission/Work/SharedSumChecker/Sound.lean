import Submission.Work.SharedSumChecker.Bits


namespace SSC
open OAI.PowerSaving.Binary OAI.PowerSaving.RAM Finset Matrix

inductive Micro where
  | dir (r z : Nat)
  | shift (r z : Nat)
  | add (t s : Nat) (c : Coef)
  | copy (s d : Nat)
  | erase (d : Nat)
  | expect (r e : Nat)

noncomputable def Coef.val (c : Coef) : ℚ :=
  (if c.neg then -(c.num : ℚ) else (c.num : ℚ)) / (c.den : ℚ)

section
variable {ρ : Type*} [Fintype ρ] [DecidableEq ρ]

def addMat (a b : ρ) (c : ℚ) : Matrix ρ ρ ℚ :=
  fun i j => (if i = j then 1 else 0) + (if i = a ∧ j = b then c else 0)

theorem actPoint_addMat (a b : ρ) (c : ℚ) (x : ρ → ℂ) (r : ρ) :
    actPoint (addMat a b c) x r = if r = a then x a + (c:ℂ) * x b else x r := by
  unfold actPoint addMat
  simp only [Rat.cast_add, add_mul, sum_add_distrib]
  rw [sum_ind_right r x]
  by_cases h : r = a
  · subst h
    rw [if_pos rfl]
    congr 1
    rw [sum_eq_single b]
    · simp
    · intro j _ hj; simp [hj]
    · simp
  · rw [if_neg h]
    have h0 : ∑ j, (((if r = a ∧ j = b then c else 0 : ℚ)) : ℂ) * x j = 0 :=
      sum_eq_zero (fun j _ => by simp [h])
    rw [h0, add_zero]

variable {p : Par} {α : Type*} [Fintype α] [DecidableEq α]

end

end SSC
