import Submission.Work.SharedSumChecker.Impl
import Submission.Work.SharedSumStructured.Invocation


namespace SSC
open OAI.PowerSaving.Binary OAI.PowerSaving.RAM OAI.PowerSaving.SS Finset Matrix

section
variable (p : Par)

end

section
variable {ρ : Type} [Fintype ρ] [DecidableEq ρ]

noncomputable def matP (unemb : Nat → ρ) : List Micro → Matrix ρ ρ ℚ
  | [] => 1
  | .add t s c :: ms => matP unemb ms * addMat (unemb t) (unemb s) c.val
  | .dir _ _ :: ms => matP unemb ms
  | .shift _ _ :: ms => matP unemb ms
  | .copy _ _ :: ms => matP unemb ms
  | .erase _ :: ms => matP unemb ms
  | .expect _ _ :: ms => matP unemb ms

theorem actPoint_mul (A B : Matrix ρ ρ ℚ) : actPoint (A * B) = actPoint A ∘ actPoint B := by
  funext u
  rw [actPoint_eq_ap, actPoint_eq_ap, actPoint_eq_ap]
  exact ap_mul A B u

theorem actPoint_one' : actPoint (1 : Matrix ρ ρ ℚ) = id := by
  funext u
  rw [actPoint_eq_ap]
  exact ap_one u

variable (p : Par) {α : Type} [Fintype α] [DecidableEq α]

variable {p}

end

end SSC
