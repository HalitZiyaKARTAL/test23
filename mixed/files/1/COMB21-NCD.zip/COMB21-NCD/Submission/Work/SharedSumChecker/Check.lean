
namespace SSC

noncomputable def forceN {α : Type} (n : Nat) (k : Nat → α) : α :=
  Nat.rec (motive := fun _ => α) (k 0) (fun m _ => k (Nat.succ m)) n

noncomputable def guard (b : Bool) (k : Bool) : Bool := Bool.rec false k b

def rep (u : Nat) : Nat → Nat
  | 0 => 0
  | n+1 => Nat.add (Nat.mul (Nat.pow 2 u) (rep u n)) 1

structure Par where
  h : Nat
  w : Nat
  d : Nat
  cnt : Nat

def Par.K (p : Par) : Nat := Nat.mul p.w p.h
def Par.K2 (p : Par) : Nat := Nat.mul 2 (Nat.mul p.w p.h)
def Par.K3 (p : Par) : Nat := Nat.mul 3 (Nat.mul p.w p.h)
def Par.hm (p : Par) : Nat := Nat.sub (Nat.pow 2 p.h) 1
def Par.km (p : Par) : Nat := rep (Nat.sub p.w 1) p.h
def Par.mm (p : Par) : Nat := rep p.w p.h
def Par.n (p : Par) : Nat := Nat.pow 2 p.d

def spread (p : Par) (z : Nat) : Nat :=
  Nat.land (Nat.mul (Nat.land z p.hm) p.km) p.mm

def updX (p : Par) (L zh z : Nat) : Nat :=
  Nat.xor L (Nat.xor zh (Nat.xor (Nat.shiftLeft (Nat.land L zh) p.K)
    (Nat.shiftLeft (Nat.mul zh (Nat.land z p.hm)) p.K2)))

def upd (p : Par) (L zh z : Nat) : Nat :=
  Nat.add (updX p L zh z) (Nat.shiftLeft p.cnt p.K3)

def cntOf (p : Par) (L : Nat) : Nat := Nat.shiftRight L p.K3

def updS (p : Par) (L z : Nat) : Nat := Nat.xor L (Nat.shiftLeft (spread p z) p.K)

def dec (P : Nat) : Nat := Nat.shiftRight P 64

inductive Trie where
  | leaf (v : Nat)
  | node (l r : Trie)

def Trie.mk : Nat → Trie
  | 0 => .leaf 0
  | d+1 => .node (Trie.mk d) (Trie.mk d)

noncomputable def Trie.getK (t : Trie) : Nat → (Nat → Bool) → Bool :=
  Trie.rec (motive := fun _ => Nat → (Nat → Bool) → Bool)
    (fun v key k => Nat.rec (motive := fun _ => Bool) (k v) (fun _ _ => false) key)
    (fun _ _ gl gr key k => Bool.rec (gr (Nat.shiftRight key 1) k) (gl (Nat.shiftRight key 1) k)
      (Nat.beq (Nat.land key 1) 0)) t

noncomputable def Trie.set (t : Trie) : Nat → Nat → Trie :=
  Trie.rec (motive := fun _ => Nat → Nat → Trie) (fun _ _ v => .leaf v)
    (fun l r sl sr key v => Bool.rec (.node l (sr (Nat.shiftRight key 1) v))
      (.node (sl (Nat.shiftRight key 1) v) r) (Nat.beq (Nat.land key 1) 0)) t

structure Coef where
  neg : Bool
  num : Nat
  den : Nat

inductive Part where
  | old (r : Nat) (dirs : List Nat) (sh : Nat)
  | new (r : Nat) (dirs : List Nat) (sh : Nat)
  | stay (r : Nat)

inductive Op where
  | bip (srcs tgts : List Part) (coefs : List (List Coef))
  | copy (s d : Nat)
  | copyNew (s d : Nat)
  | erase (d : Nat)
  | expect (r : Nat) (e : Nat)

structure FinE where
  r : Nat
  dirs : List Nat
  sh : Nat
  e : Nat

end SSC
