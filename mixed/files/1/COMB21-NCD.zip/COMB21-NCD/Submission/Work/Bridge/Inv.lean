import Submission.Work.Reframe.SNet


namespace OAI
namespace PowerSaving
namespace BR
open Binary Matrix Finset RAM SS CB RF
noncomputable section

section Pkg
variable {H T Sl C : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C]
variable {α : Type} [Fintype α] [DecidableEq α]

def iin (Xm : XMap H α) (tv : T → Space H) (Z : Sl → CMat α) (c : C → CMat α) :
    Box T Sl C → CMat α :=
  stamp (fun t => Xm.Φ (tt (tv t))) (fun _ => Xm.Φ 0) Z c

def iout (Xm : XMap H α) (tv : T → Space H) (Z : Sl → CMat α) (c : C → CMat α) :
    Box T Sl C → CMat α :=
  stamp (fun _ => Xm.Φ 1) (fun t => Xm.Φ (1 + tt (tv t))) Z c

end Pkg

section Stage
variable {H T Sl C α Γ : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C] [Fintype α] [DecidableEq α]
  [Fintype Γ] [DecidableEq Γ]

def bIn (tv : T → Space H) (εX : T → Γ ≃ Γ) (M : Γ → XMap H α) (Z : Γ → Sl → CMat α)
    (c : Γ → C → CMat α) : SRole Γ T Sl C → CMat α :=
  mkS (fun g t => (M (εX t g)).Φ (tt (tv t))) (fun g t => (M (εX t g)).Φ 0) Z c

def bOut (tv : T → Space H) (εX : T → Γ ≃ Γ) (M : Γ → XMap H α) (Z : Γ → Sl → CMat α)
    (c : Γ → C → CMat α) : SRole Γ T Sl C → CMat α :=
  mkS (fun g t => (M (εX t g)).Φ 1) (fun g t => (M (εX t g)).Φ (1 + tt (tv t))) Z c

lemma bIn_sem (tv : T → Space H) (εX : T → Γ ≃ Γ) (εS : Γ ≃ Γ) (M : Γ → XMap H α)
    (Z : Γ → Sl → CMat α) (c : Γ → C → CMat α) (d : Γ) :
    bIn tv εX M Z c ∘ sem εX εS d = iin (M d) tv (fun q => Z (εS d) q) (fun k => c (εS d) k) := by
  funext b
  rcases b with ((t|t)|(q|k))
  · show (M (εX t ((εX t).symm d))).Φ (tt (tv t)) = (M d).Φ (tt (tv t))
    rw [Equiv.apply_symm_apply]
  · show (M (εX t ((εX t).symm d))).Φ 0 = (M d).Φ 0
    rw [Equiv.apply_symm_apply]
  · rfl
  · rfl

lemma bOut_sem (tv : T → Space H) (εX : T → Γ ≃ Γ) (εS : Γ ≃ Γ) (M : Γ → XMap H α)
    (Z : Γ → Sl → CMat α) (c : Γ → C → CMat α) (d : Γ) :
    bOut tv εX M Z c ∘ sem εX εS d = iout (M d) tv (fun q => Z (εS d) q) (fun k => c (εS d) k) := by
  funext b
  rcases b with ((t|t)|(q|k))
  · show (M (εX t ((εX t).symm d))).Φ 1 = (M d).Φ 1
    rw [Equiv.apply_symm_apply]
  · show (M (εX t ((εX t).symm d))).Φ (1 + tt (tv t)) = (M d).Φ (1 + tt (tv t))
    rw [Equiv.apply_symm_apply]
  · rfl
  · rfl


end Stage
end
end BR
end PowerSaving
end OAI

