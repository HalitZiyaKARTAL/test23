import Submission.Work.CtrlAB.Core
import Submission.Work.P4L.View

namespace CtrlAB
namespace UnitAB

section Ring
variable {R : Type*} [CommRing R] [Algebra ℚ R] (q L : R) (D : Nat → R) (NS : Nat)

theorem step_add {u u' : Nat → R} {t s : Nat} {co : GXD.Co} {e : Nat}
    (ht : u' t = u t + algebraMap ℚ R (cq co) * (monoV q L D NS e * u s))
    (ho : ∀ i, i ≠ t → u' i = u i) : u' = semEv q L D NS (.add t s co e) u := by
  funext i
  by_cases h : i = t
  · subst h; simp only [semEv, Function.update_self]; exact ht
  · simp only [semEv, Function.update_of_ne h]; exact ho i h

theorem step_mul {u u' : Nat → R} {r : Nat} {co : GXD.Co}
    (ht : u' r = algebraMap ℚ R (cq co) * u r)
    (ho : ∀ i, i ≠ r → u' i = u i) : u' = semEv q L D NS (.mul r co) u := by
  funext i
  by_cases h : i = r
  · subst h; simp only [semEv, Function.update_self]; exact ht
  · simp only [semEv, Function.update_of_ne h]; exact ho i h

theorem step_mon {u u' : Nat → R} {r m : Nat}
    (ht : u' r = monoV q L D NS m * u r)
    (ho : ∀ i, i ≠ r → u' i = u i) : u' = semEv q L D NS (.mon r m) u := by
  funext i
  by_cases h : i = r
  · subst h; simp only [semEv, Function.update_self]; exact ht
  · simp only [semEv, Function.update_of_ne h]; exact ho i h

theorem step_swp {u u' : Nat → R} {r t : Nat}
    (hr : u' r = u t) (ht : u' t = u r)
    (ho : ∀ i, i ≠ r → i ≠ t → u' i = u i) : u' = semEv q L D NS (.swp r t) u := by
  funext i
  show u' i = if i = r then u t else if i = t then u r else u i
  by_cases h1 : i = r
  · subst h1; rw [if_pos rfl]; exact hr
  · rw [if_neg h1]
    by_cases h2 : i = t
    · subst h2; rw [if_pos rfl]; exact ht
    · rw [if_neg h2]; exact ho i h1 h2

theorem step_one {u u' : Nat → R} {e : CEv} (h : u' = semEv q L D NS e u) :
    u' = semEvs q L D NS [e] u := h

theorem semEvs_append : ∀ (a b : List CEv) (u : Nat → R),
    semEvs q L D NS (a ++ b) u = semEvs q L D NS b (semEvs q L D NS a u)
  | [], _, _ => rfl
  | e :: a, b, u => semEvs_append a b (semEv q L D NS e u)

end Ring

section Data
open OAI.PowerSaving OAI.PowerSaving.Binary
variable {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

lemma qsmul_alg {β : Type*} (c : ℚ) (v : β → ℂ) : ((c : ℂ)) • v = algebraMap ℚ (β → ℂ) c * v := by
  funext x
  simp only [Pi.smul_apply, Pi.mul_apply, smul_eq_mul, Pi.algebraMap_apply]
  try congr 1

variable (f n : ℕ) (mr : ℕ → ρ) (hmr : ∀ i j, i < n → j < n → mr i = mr j → i = j)
include hmr

variable (q L : Sky α f → ℂ) (D : ℕ → Sky α f → ℂ) (NS : ℕ)

end Data

end UnitAB
end CtrlAB

