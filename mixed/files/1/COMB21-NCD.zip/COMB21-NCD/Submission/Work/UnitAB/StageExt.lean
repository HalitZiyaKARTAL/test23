import Submission.Work.XHostT.TProvWAB
import Submission.Work.P4L.ORoute

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option maxHeartbeats 1000000

namespace OAI
namespace PowerSaving
namespace XHostTW
open Binary Matrix Finset RAM SS CB RF BR GF GX

noncomputable section

section Ext
variable {Γ T Sl C R α : Type} [Fintype α] [DecidableEq α]

def gExt (e : SRole Γ T Sl C ↪ R) (G : (SRole Γ T Sl C → ℂ) → SRole Γ T Sl C → ℂ) (x : R → ℂ) : R → ℂ :=
  Function.extend (⇑e) (G (x ∘ ⇑e)) x

lemma gExt_emb (e : SRole Γ T Sl C ↪ R) (G : (SRole Γ T Sl C → ℂ) → SRole Γ T Sl C → ℂ) (x : R → ℂ)
    (r : SRole Γ T Sl C) : gExt e G x (e r) = G (x ∘ ⇑e) r :=
  e.injective.extend_apply _ _ r

lemma gExt_off (e : SRole Γ T Sl C ↪ R) (G : (SRole Γ T Sl C → ℂ) → SRole Γ T Sl C → ℂ) (x : R → ℂ) (i : R)
    (hi : ¬ ∃ a, e a = i) : gExt e G x i = x i :=
  Function.extend_apply' _ _ _ hi

def mExt (e : SRole Γ T Sl C ↪ R) (S : SRole Γ T Sl C → CMat α) : R → CMat α :=
  Function.extend (⇑e) S 1

lemma mExt_emb (e : SRole Γ T Sl C ↪ R) (S : SRole Γ T Sl C → CMat α) (r : SRole Γ T Sl C) :
    mExt e S (e r) = S r :=
  e.injective.extend_apply _ _ r

lemma mExt_off (e : SRole Γ T Sl C ↪ R) (S : SRole Γ T Sl C → CMat α) (i : R) (hi : ¬ ∃ a, e a = i) :
    mExt e S i = 1 := by
  rw [mExt, Function.extend_apply' _ _ _ hi]
  rfl

end Ext

section Call
variable {H T Sl C α Γ R : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C] [Fintype α] [DecidableEq α]
  [Fintype Γ] [DecidableEq Γ] [Fintype R] [DecidableEq R]
variable {Ok : ∀ {β : Type} [Fintype β] [DecidableEq β], GWin H β → Prop}

theorem call_ext (I : GInvWAB H T Sl C Ok) (e : SRole Γ T Sl C ↪ R) (εX : T → Γ ≃ Γ) (M : Γ → GWin H α)
    (hok : ∀ d, Ok (M d)) (N Wn : Γ → Sl → CMat α)
    (hN : ∀ d q, (M d).X.Φ (I.ent q) * N d q = 1)
    (hW : ∀ d q, (M d).X.Φ (I.ent q).top = Wn d q * (M d).X.Φ (I.ent q))
    (Z : Γ → Sl → CMat α) (c0 c1 : Γ → C → CMat α) (B' : SRole Γ T Sl C → CMat α)
    (hB : ∀ r, bIn I.tv εX (fun d => (M d).Xm) Z c0 r * B' r = 1) :
    P4L.ORoute (fun f y => multiAct f (mExt e (bOut I.tv εX (fun d => (M d).Xm) (fun g q => Wn g q * Z g q) c1))
        (point f (gExt e (GAB I.al I.be)) (multiAct f (mExt e B') y)))
      (fun φ => (Fintype.card Γ : ℝ) * I.cost φ) := by
  have h := gistageW_ab I εX M hok N Wn hN hW Z c0 c1
  have hS : mExt e (bIn I.tv εX (fun d => (M d).Xm) Z c0) ∘ ⇑e = bIn I.tv εX (fun d => (M d).Xm) Z c0 := by
    funext r; exact mExt_emb e _ r
  have hT : mExt e (bOut I.tv εX (fun d => (M d).Xm) (fun g q => Wn g q * Z g q) c1) ∘ ⇑e
      = bOut I.tv εX (fun d => (M d).Xm) (fun g q => Wn g q * Z g q) c1 := by
    funext r; exact mExt_emb e _ r
  have h' : GRoute (mExt e (bIn I.tv εX (fun d => (M d).Xm) Z c0) ∘ ⇑e)
      (mExt e (bOut I.tv εX (fun d => (M d).Xm) (fun g q => Wn g q * Z g q) c1) ∘ ⇑e) (GAB I.al I.be)
      (fun φ => (Fintype.card Γ : ℝ) * I.cost φ) := by
    rw [hS, hT]; exact h
  have hL : GRoute (mExt e (bIn I.tv εX (fun d => (M d).Xm) Z c0))
      (mExt e (bOut I.tv εX (fun d => (M d).Xm) (fun g q => Wn g q * Z g q) c1)) (gExt e (GAB I.al I.be))
      (fun φ => (Fintype.card Γ : ℝ) * I.cost φ) := by
    refine GRoute.lift e h' (fun x => ?_) (fun x i hi => ?_) (fun i hi => ?_)
    all_goals first
      | (funext r; exact gExt_emb e _ x r)
      | exact gExt_off e _ x i (fun hx => hi ((cover_iff e i).2 hx))
      | rw [mExt_off e _ i (fun hx => hi ((cover_iff e i).2 hx)), mExt_off e _ i (fun hx => hi ((cover_iff e i).2 hx))]
      | rfl
  refine P4L.ORoute.of_groute hL (fun r => ?_)
  by_cases hr : ∃ a, e a = r
  · obtain ⟨a, rfl⟩ := hr
    rw [mExt_emb, mExt_emb]
    exact hB a
  · rw [mExt_off e _ r hr, mExt_off e _ r hr, one_mul]

end Call

end
end XHostTW
end PowerSaving
end OAI


