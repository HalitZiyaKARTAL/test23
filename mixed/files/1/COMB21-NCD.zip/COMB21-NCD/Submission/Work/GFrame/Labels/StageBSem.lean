import Submission.Work.GFrame.Labels.BXMap
import Submission.Work.GFrame.Clifford.Base


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM CB
noncomputable section

section
variable {α : Type} [Fintype α] [DecidableEq α]

theorem SMv.of_sub {m : ℕ} (U V : SLbl α) (h : ∀ x, U.Mem x → V.Mem x)
    (h1 : U.dim < V.dim) (h2 : V.dim - U.dim < m) : SMv m U V [V.dim - U.dim] := by
  obtain ⟨G₀, s₀, t₀, hst, e1, e2⟩ := exists_common_base U.G V.G U.s V.s h
  have r := SMv.nested_rank U V G₀ s₀ t₀ e1 e2 hst
  have g := SMv.nested (m := m) U V G₀ s₀ t₀ e1 e2 hst (by rw [r]; omega) (by rw [r]; exact h2)
  rw [r] at g
  exact g

theorem SMv.of_sup {m : ℕ} (U V : SLbl α) (h : ∀ x, U.Mem x → V.Mem x)
    (h1 : U.dim < V.dim) (h2 : V.dim - U.dim < m) : SMv m V U [V.dim - U.dim] := by
  obtain ⟨G₀, s₀, t₀, hst, e1, e2⟩ := exists_common_base U.G V.G U.s V.s h
  have r := SMv.nested_rank U V G₀ s₀ t₀ e1 e2 hst
  have a : SMv m V ⟨G₀, t₀⟩ [] := SMv.rebase (fun x => (e2 x).symm)
  have b : SMv m (⟨G₀, t₀⟩ : SLbl α) ⟨G₀, s₀⟩ [(t₀ \ s₀).card] :=
    SMv.down G₀ hst (by rw [r]; omega) (by rw [r]; exact h2)
  have c : SMv m (⟨G₀, s₀⟩ : SLbl α) U [] := SMv.rebase (fun x => (e1 x).symm)
  have g := (a.trans b).trans c
  rw [r] at g
  simpa using g

theorem fmv_old_to_core (A : OBase α) (s : Finset α) :
    FMv (frame A s) (core (coordPerm A) s) [] := by
  obtain ⟨N, hN, e⟩ := frame_core_free A s
  obtain ⟨N', hN', hl, -⟩ := free_inv hN
  refine fmv_of_free hN' ?_
  rw [e, ← Matrix.mul_assoc, hl, Matrix.one_mul]

theorem fmv_core_to_old (A : OBase α) (s : Finset α) :
    FMv (core (coordPerm A) s) (frame A s) [] := by
  obtain ⟨N, hN, e⟩ := frame_core_free A s
  exact fmv_of_free hN e

end

end
end PowerSaving.GF
end OAI
