import Submission.Work.GFrame.Labels.GCalc
import Submission.Work.Bridge.Inv
import Submission.Work.GFrame.Clifford.Base
import Submission.Work.GFrame.Labels.BXMap
import Submission.Work.Reframe.GeomBase
import Submission.Work.GFrame.Labels.StageBSem
import Submission.Work.GFrame.Labels.SchedR
import Submission.Work.GFrame.Engine.Over
import Submission.Work.GFrame.Engine.Sweep


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM SS CB BR RF
noncomputable section

section
variable {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

theorem GRoute.reframe {S T : ρ → CMat α} {g : (ρ→ℂ) → (ρ→ℂ)} {c : (ℕ → ℝ) → ℝ}
    (D : ρ → CMat α) (h : GRoute S T g c)
    (hg : ∀ (f : ℕ) (x : Data α ρ f), point f g (multiAct f D x) = multiAct f D (point f g x)) :
    GRoute (fun r => S r * D r) (fun r => T r * D r) g c := by
  obtain ⟨w, hw, hc, hwalk⟩ := h
  refine ⟨w, hw, hc, fun f x => ?_⟩
  have h1 := multiAct_mulR f S D x
  have h2 := multiAct_mulR f T D (point f g x)
  rw [h1, hwalk, hg, h2]

end


end
end PowerSaving.GF
end OAI


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM CB
noncomputable section

section
variable {H β κ : Type} [Fintype H] [DecidableEq H] [Fintype β] [DecidableEq β]
  [Fintype κ] [DecidableEq κ]

def mvPerm (d : Matrix κ κ F) (hd : dᵀ * d = 1) (hd' : d * dᵀ = 1) : APerm κ where
  π :=
    { toFun := fun y => dᵀ *ᵥ y
      invFun := fun z => d *ᵥ z
      left_inv := fun y => by
        show d *ᵥ (dᵀ *ᵥ y) = y
        rw [Matrix.mulVec_mulVec, hd', Matrix.one_mulVec]
      right_inv := fun z => by
        show dᵀ *ᵥ (d *ᵥ z) = z
        rw [Matrix.mulVec_mulVec, hd, Matrix.one_mulVec] }
  add := fun x y => Matrix.mulVec_add _ x y

def inlPerm (G : APerm H) : APerm (H ⊕ β) where
  π :=
    { toFun := fun y => Sum.elim (G.π (fun i => y (Sum.inl i))) (fun b => y (Sum.inr b))
      invFun := fun z => Sum.elim (G.π.symm (fun i => z (Sum.inl i))) (fun b => z (Sum.inr b))
      left_inv := fun y => by
        funext k
        cases k with
        | inl i => simp
        | inr b => simp
      right_inv := fun z => by
        funext k
        cases k with
        | inl i => simp
        | inr b => simp }
  add := fun x y => by
    funext k
    cases k with
    | inl i =>
      show G.π (fun i => (x + y) (Sum.inl i)) i
        = G.π (fun i => x (Sum.inl i)) i + G.π (fun i => y (Sum.inl i)) i
      have e : (fun i => (x + y) (Sum.inl i)) = (fun i => x (Sum.inl i)) + fun i => y (Sum.inl i) :=
        rfl
      rw [e, G.add]; rfl
    | inr b => rfl

def conjPerm (d : Matrix (H ⊕ β) (H ⊕ β) F) (hd : dᵀ * d = 1) (hd' : d * dᵀ = 1)
    (G : APerm H) : APerm (H ⊕ β) :=
  apComp (mvPerm d hd hd') (inlPerm G)

lemma insub_conj (d : Matrix (H ⊕ β) (H ⊕ β) F) (hd : dᵀ * d = 1) (hd' : d * dᵀ = 1)
    (G : APerm H) (s : Finset H) (q : Finset β) (y : Space (H ⊕ β)) :
    InSub (conjPerm d hd hd' G) (s.disjSum q) y ↔
      InSub G s (fun i => (dᵀ *ᵥ y) (Sum.inl i)) ∧ ∀ b, b ∉ q → (dᵀ *ᵥ y) (Sum.inr b) = 0 := by
  constructor
  · intro h
    refine ⟨fun i hi => ?_, fun b hb => ?_⟩
    · exact h (Sum.inl i) (fun hm => hi (Finset.inl_mem_disjSum.mp hm))
    · exact h (Sum.inr b) (fun hm => hb (Finset.inr_mem_disjSum.mp hm))
  · rintro ⟨h1, h2⟩ k hk
    cases k with
    | inl i => exact h1 i (fun hm => hk (Finset.inl_mem_disjSum.mpr hm))
    | inr b => exact h2 b (fun hm => hk (Finset.inr_mem_disjSum.mpr hm))

def BXMap.ofConj (d : Matrix (H ⊕ β) (H ⊕ β) F) (hd : dᵀ * d = 1) (hd' : d * dᵀ = 1)
    (q : Finset β) : BXMap H (H ⊕ β) where
  liftG := conjPerm d hd hd'
  liftS := fun s => s.disjSum q
  mono := fun h => Finset.disjSum_mono h (Finset.Subset.refl q)
  card := fun {s t} h => by
    have h' : s.disjSum q ⊆ t.disjSum q := Finset.disjSum_mono h (Finset.Subset.refl q)
    rw [Finset.card_sdiff_of_subset h', Finset.card_sdiff_of_subset h, Finset.card_disjSum,
      Finset.card_disjSum]
    omega
  sub := fun {G G' s s'} h y => by
    rw [insub_conj, insub_conj, h]

end
end
end PowerSaving.GF
end OAI


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM CB
noncomputable section
section
variable {α : Type} [Fintype α] [DecidableEq α] {ρ : Type} [Fintype ρ] [DecidableEq ρ]

def GReach (A B : CMat α) (c : (ℕ → ℝ) → ℝ) : Prop :=
  ∀ (ρ : Type) [Fintype ρ] [DecidableEq ρ] (l : ρ), GStep l A B c

namespace GReach
variable {A B C : CMat α} {c c' : (ℕ → ℝ) → ℝ}

theorem refl (A : CMat α) : GReach A A (fun _ => 0) := fun ρ _ _ l => GStep.refl l A

theorem cast (h : GReach A B c) (hc : ∀ φ, c φ = c' φ) : GReach A B c' :=
  fun ρ _ _ l => (h ρ l).cast hc

theorem trans (h : GReach A B c) (g : GReach B C c') : GReach A C (fun φ => c φ + c' φ) :=
  fun ρ _ _ l => (h ρ l).trans (g ρ l)

theorem ofX (h : GReach A B c) : GReach A B c := h

theorem of_subset (hm : 2 ≤ Fintype.card α) (A : OBase α) {s t : Finset α} (h : s ⊆ t) :
    GReach (frame A s) (frame A t)
      (fun φ => splitCost φ (Fintype.card α) (t \ s).card) := by
  intro ρ _ _ l
  have e := A.xup_step (ρ := ρ) hm l s (t \ s) disjoint_sdiff
  rwa [union_sdiff_of_subset h] at e

theorem ofReach (h : Reach A B c) : GReach A B c := h

end GReach

namespace GRoute

theorem castg {S T : ρ → CMat α} {g g' : (ρ→ℂ) → (ρ→ℂ)} {c : (ℕ → ℝ) → ℝ}
    (h : GRoute S T g c) (hg : g = g') : GRoute S T g' c := hg ▸ h

theorem reach_all (S T : ρ → CMat α) (c : ρ → (ℕ → ℝ) → ℝ)
    (h : ∀ r, GReach (S r) (T r) (c r)) :
    GRoute S T id (fun φ => ∑ r, c r φ) := by
  have hh (J : Finset ρ) :
      GRoute S (fun r => if r ∈ J then T r else S r) id (fun φ => ∑ r ∈ J, c r φ) := by
    induction J using Finset.induction_on with
    | empty =>
      have e0 : (fun r => if r ∈ (∅ : Finset ρ) then T r else S r) = S := by
        funext r; simp
      rw [e0]
      exact GRoute.refl.cast (fun φ => by simp)
    | insert l J hl ih =>
      have hsl : (if l ∈ J then T l else S l) = S l := by simp [hl]
      have step : GStep l (if l ∈ J then T l else S l) (T l) (c l) := by
        rw [hsl]; exact h l ρ l
      have b := GRoute.on_role (fun r => if r ∈ J then T r else S r) l (T l) step
      have hupd : Function.update (fun r => if r ∈ J then T r else S r) l (T l) =
          fun r => if r ∈ insert l J then T r else S r := by
        funext r
        by_cases hr : r = l
        · subst hr; simp
        · simp [Function.update_of_ne hr, Finset.mem_insert, hr]
      rw [hupd] at b
      exact (ih.trans b).cast (fun φ => by rw [Finset.sum_insert hl, add_comm])
  have H := hh Finset.univ
  have e1 : (fun r => if r ∈ (Finset.univ : Finset ρ) then T r else S r) = T := by
    funext r; simp
  rw [e1] at H
  exact H

end GRoute
end
end
end PowerSaving.GF
end OAI
