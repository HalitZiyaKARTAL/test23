import Submission.Work.GFrame.Engine.Free

namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset Complex
noncomputable section
section
variable {α : Type*} [Fintype α] [DecidableEq α]

def apId (α : Type*) : APerm α := ⟨Equiv.refl _, fun _ _ => rfl⟩

def apInv (G : APerm α) : APerm α where
  π := G.π.symm
  add := by
    intro x y
    apply G.π.injective
    rw [G.add]; simp

def apComp (G H : APerm α) : APerm α where
  π := G.π.trans H.π
  add := by intro x y; simp [G.add, H.add]

@[simp] lemma apply_apInv (G : APerm α) (x : Space α) : G.π ((apInv G).π x) = x := by
  simp [apInv]

lemma APerm.map_zero' (G : APerm α) : G.π 0 = 0 := by
  have h := G.add 0 0
  rw [add_zero] at h
  have h2 : G.π 0 + G.π 0 = 0 := binary_cancel _
  rw [← h] at h2
  exact h2

lemma permMat_mul_apply (G : APerm α) (M : CMat α) (x y : Space α) :
    (permMat G * M) x y = M (G.π x) y := by
  rw [Matrix.mul_apply]
  simp [permMat]

lemma mul_permMat_apply (M : CMat α) (G : APerm α) (x y : Space α) :
    (M * permMat G) x y = M x (G.π.symm y) := by
  rw [Matrix.mul_apply, Finset.sum_eq_single (G.π.symm y)]
  · simp [permMat]
  · intro b _ hb
    have : ¬ G.π b = y := fun h => hb (by rw [← h]; simp)
    simp [permMat, this]
  · intro h; exact absurd (Finset.mem_univ _) h

lemma permMat_inv_mul (G : APerm α) : permMat (apInv G) * permMat G = 1 := by
  ext x y
  rw [permMat_mul_apply]
  simp [permMat, apInv, Matrix.one_apply]

lemma permMat_mul_inv (G : APerm α) : permMat G * permMat (apInv G) = 1 := by
  ext x y
  rw [permMat_mul_apply]
  simp [permMat, apInv, Matrix.one_apply]

def mkAP (f : Space α → Space α) (hadd : ∀ x y, f (x + y) = f x + f y)
    (hk : ∀ y, f y = 0 → y = 0) : APerm α :=
  ⟨Equiv.ofBijective f (Finite.injective_iff_bijective.mp fun a b hab => by
    have e := hk _ (show f (a + b) = 0 by rw [hadd, hab, binary_cancel])
    calc a = a + (a + b) := by rw [e, add_zero]
      _ = b := by rw [← add_assoc, binary_cancel, zero_add]), hadd⟩

lemma F_self_eq_add : ∀ a b : F, a = a + b ↔ b = 0 := by decide

lemma sgn0 : sign 0 = 1 := if_pos rfl
lemma sgn1 : sign 1 = -1 := if_neg (by decide)

lemma tint_four (t : F) : tint t * (tint t * tint t) * tint t = 1 := by
  rcases bit_cases t with rfl|rfl <;> simp [tint]

lemma tint_four' (t : F) : tint t * (tint t * (tint t * tint t)) = 1 := by
  rcases bit_cases t with rfl|rfl <;> simp [tint]

theorem free_inv {A : CMat α} (h : Free A) : ∃ A', Free A' ∧ A' * A = 1 ∧ A * A' = 1 := by
  induction h with
  | one => exact ⟨1, Free.one, by simp, by simp⟩
  | perm G => exact ⟨permMat (apInv G), Free.perm _, permMat_inv_mul G, permMat_mul_inv G⟩
  | phase z c =>
    refine ⟨phaseMat z c * (phaseMat z c * phaseMat z c),
      Free.mul (Free.phase z c) (Free.mul (Free.phase z c) (Free.phase z c)), ?_, ?_⟩
    · unfold phaseMat
      simp only [Matrix.diagonal_mul_diagonal, tint_four, Matrix.diagonal_one]
    · unfold phaseMat
      simp only [Matrix.diagonal_mul_diagonal, tint_four', Matrix.diagonal_one]
  | shift z => exact ⟨shift z, Free.shift z, shift_sq z, shift_sq z⟩
  | mul _ _ ihA ihB =>
    obtain ⟨A', fA, lA, rA⟩ := ihA
    obtain ⟨B', fB, lB, rB⟩ := ihB
    refine ⟨B' * A', Free.mul fB fA, ?_, ?_⟩
    · rw [Matrix.mul_assoc, ← Matrix.mul_assoc A', lA, Matrix.one_mul, lB]
    · rw [Matrix.mul_assoc, ← Matrix.mul_assoc _ B', rB, Matrix.one_mul, rA]

lemma free_diag_mul {f g : Space α → ℂ} (hf : Free (diagonal f)) (hg : Free (diagonal g)) :
    Free (diagonal fun x => f x * g x) := by
  have h := Free.mul hf hg
  rwa [Matrix.diagonal_mul_diagonal] at h

lemma free_diag_one : Free (diagonal fun _ : Space α => (1 : ℂ)) := by
  rw [Matrix.diagonal_one]; exact Free.one

lemma free_diag_prod {κ : Type*} (s : Finset κ) (f : κ → Space α → ℂ)
    (h : ∀ j ∈ s, Free (diagonal (f j))) : Free (diagonal fun x => ∏ j ∈ s, f j x) := by
  classical
  induction s using Finset.induction_on with
  | empty => simpa using free_diag_one (α := α)
  | insert i s hi ih =>
    have h1 := free_diag_mul (h i (mem_insert_self i s))
      (ih fun j hj => h j (mem_insert_of_mem hj))
    simpa [Finset.prod_insert hi] using h1

lemma free_diag_pow {f : Space α → ℂ} (hf : Free (diagonal f)) (n : ℕ) :
    Free (diagonal fun x => f x ^ n) := by
  induction n with
  | zero => simpa using free_diag_one (α := α)
  | succ n ih =>
    have h := free_diag_mul ih hf
    simpa [pow_succ] using h

theorem free_scalar (n : ℕ) : Free ((I ^ n) • (1 : CMat α)) := by
  have e : (I ^ n) • (1 : CMat α) = diagonal fun _ => I ^ n := by
    ext x y
    by_cases h : x = y
    · subst h; simp
    · simp [Matrix.one_apply, h]
  have hI : Free (diagonal fun _ : Space α => I) := by
    simpa [phaseMat, tint] using Free.phase (0 : Space α) 1
  rw [e]; exact free_diag_pow hI n

lemma add_fun_eq_dot (f : Space α → F) (hf : ∀ x y, f (x + y) = f x + f y) (x : Space α) :
    f x = dot (fun j => f (eu j)) x := by
  have h0 : f 0 = 0 := (F_self_eq_add (f 0) (f 0)).mp (by rw [← hf, add_zero])
  have hs : ∀ t : Finset α, f (∑ j ∈ t, x j • eu j) = ∑ j ∈ t, x j * f (eu j) := by
    intro t
    induction t using Finset.induction_on with
    | empty => simpa using h0
    | insert i t hi ih =>
      rw [Finset.sum_insert hi, Finset.sum_insert hi, hf, ih]
      rcases bit_cases (x i) with h | h <;> simp [h, h0]
  calc f x = f (∑ j, x j • eu j) := congrArg f (funext fun k => by simp [eu])
    _ = ∑ j, x j * f (eu j) := hs univ
    _ = dot (fun j => f (eu j)) x := Finset.sum_congr rfl fun j _ => mul_comm _ _

lemma free_lum_comp (q : Space α → Space α) (hq : ∀ x y, q (x + y) = q x + q y) :
    Free (diagonal fun x => lum (q x)) :=
  free_diag_prod univ (fun i x => tint (q x i)) fun i _ => by
    show Free (diagonal fun x => tint (q x i))
    have e : (diagonal fun x => tint (q x i)) = phaseMat (fun j => q (eu j) i) 0 := by
      unfold phaseMat; congr 1; funext x
      rw [add_zero, ← add_fun_eq_dot (fun x => q x i) fun x y => by simp only [hq, Pi.add_apply]]
    rw [e]; exact Free.phase _ _

lemma lum_inv (x : Space α) : (lum x)⁻¹ = lum x ^ 3 := by
  have h4 : lum x ^ 3 * lum x = 1 := by
    rw [← pow_succ, show (3 + 1 : ℕ) = 2 + 2 by rfl, pow_add, pow_two, lum_sq, sign_sq]
  exact (eq_inv_of_mul_eq_one_left h4).symm

def pk (s : Finset α) : CMat α := wrap fun x => ∏ k ∈ s, tint (x k)

def kg (G : APerm α) : CMat α := fun x y => if G.π x = y then lum x / lum y else 0

def core (G : APerm α) (s : Finset α) : CMat α := kg G * pk s * kg (apInv G)

def InSub (G : APerm α) (s : Finset α) (x : Space α) : Prop := ∀ k, k ∉ s → G.π x k = 0

instance (G : APerm α) (s : Finset α) (x : Space α) : Decidable (InSub G s x) := by
  unfold InSub; infer_instance

lemma kg_eq (G : APerm α) :
    kg G = diagonal lum * permMat G * diagonal (fun y => (lum y)⁻¹) := by
  ext x y
  rw [Matrix.mul_diagonal, Matrix.diagonal_mul]
  simp only [kg, permMat]
  split_ifs <;> simp [div_eq_mul_inv]

theorem free_kg (G : APerm α) : Free (kg G) := by
  have hl := free_lum_comp (α := α) id fun _ _ => rfl
  rw [kg_eq, show (fun x : Space α => (lum x)⁻¹) = fun x => lum (id x) ^ 3 from funext lum_inv]
  exact Free.mul (Free.mul hl (Free.perm G)) (free_diag_pow hl 3)

lemma kg_mul_apply (G : APerm α) (M : CMat α) (x y : Space α) :
    (kg G * M) x y = lum x / lum (G.π x) * M (G.π x) y := by
  rw [Matrix.mul_apply, Finset.sum_eq_single (G.π x)]
  · simp [kg]
  · intro b _ hb
    simp [kg, Ne.symm hb]
  · intro h; exact absurd (mem_univ _) h

lemma mul_kg_inv_apply (G : APerm α) (M : CMat α) (x y : Space α) :
    (M * kg (apInv G)) x y = M x (G.π y) * (lum (G.π y) / lum y) := by
  rw [Matrix.mul_apply, Finset.sum_eq_single (G.π y)]
  · simp [kg, apInv]
  · intro b _ hb
    have : ¬ G.π.symm b = y := fun h => hb (by rw [← h]; simp)
    simp [kg, apInv, this]
  · intro h; exact absurd (mem_univ _) h

lemma kg_mul_inv (G : APerm α) : kg G * kg (apInv G) = 1 := by
  ext x y
  rw [mul_kg_inv_apply]
  have hx := lum_nonzero x
  have hy := lum_nonzero y
  have hg := lum_nonzero (G.π y)
  by_cases h : x = y
  · subst h
    simp only [kg, if_true, Matrix.one_apply_eq]
    field_simp
  · have h' : ¬ G.π x = G.π y := fun h' => h (G.π.injective h')
    simp [kg, h', Matrix.one_apply, h]

lemma kg_inv_mul (G : APerm α) : kg (apInv G) * kg G = 1 := by
  ext x y
  rw [kg_mul_apply]
  have h1 := lum_nonzero ((apInv G).π x)
  simp only [kg, apply_apInv, Matrix.one_apply]
  by_cases h : x = y
  · subst h
    have h2 := lum_nonzero x
    simp only [if_true]
    field_simp
  · simp [h]

lemma kg_comp {G H K : APerm α} (h : ∀ x, K.π x = H.π (G.π x)) : kg G * kg H = kg K := by
  ext x y
  rw [kg_mul_apply]
  simp only [kg, h]
  have h1 := lum_nonzero (G.π x)
  have h2 := lum_nonzero y
  split_ifs <;> first | (field_simp; done) | simp

lemma pk_empty : pk (∅ : Finset α) = 1 := by simp [pk, wrap_one]

lemma pk_union (s t : Finset α) (h : Disjoint s t) : pk (s ∪ t) = pk s * pk t := by
  rw [pk, pk, pk, wrap_mul]
  congr 1
  funext x
  rw [Finset.prod_union h]

lemma pk_sdiff {s t : Finset α} (h : s ⊆ t) : pk t = pk (t \ s) * pk s := by
  rw [← pk_union _ _ Finset.sdiff_disjoint, Finset.sdiff_union_of_subset h]

lemma pk_eq_blockMat (d : Finset α) : pk d = blockMat ((OBase.canonical α).fam d) := by
  rw [OBase.blockMat_fam]
  simp [pk, OBase.canonical]

theorem core_empty (G : APerm α) : core G ∅ = 1 := by
  rw [core, pk_empty, Matrix.mul_one, kg_mul_inv]

theorem core_nested (G : APerm α) {s t : Finset α} (h : s ⊆ t) :
    core G t = kg G * blockMat ((OBase.canonical α).fam (t \ s)) * kg (apInv G) * core G s := by
  rw [← pk_eq_blockMat, core, core, pk_sdiff h]
  simp only [Matrix.mul_assoc]
  rw [← Matrix.mul_assoc (kg (apInv G)) (kg G), kg_inv_mul, Matrix.one_mul]

lemma core_insert (G : APerm α) {i : α} {s : Finset α} (hi : i ∉ s) :
    core G (insert i s) = kg G * dir (eu i) * kg (apInv G) * core G s := by
  have h1 : pk ({i} : Finset α) = dir (eu i) := by
    rw [dir_phase, pk]
    congr 1
    funext x
    simp
  have h2 : pk (insert i s) = pk {i} * pk s := by
    rw [← pk_union _ _ (Finset.disjoint_singleton_left.mpr hi), Finset.insert_eq]
  rw [core, core, h2, h1]
  simp only [Matrix.mul_assoc]
  rw [← Matrix.mul_assoc (kg (apInv G)) (kg G), kg_inv_mul, Matrix.one_mul]

end

lemma cb_eq : cb = -(ca * I) := by
  unfold ca cb
  linear_combination (1 / 2 : ℂ) * Complex.I_sq

lemma littleC_eq (a b : F) : littleC a b = ca / tint (a + b) := by
  rcases bit_cases a with rfl|rfl <;> rcases bit_cases b with rfl|rfl <;>
    simp [littleC, tint] <;> exact cb_eq

section
variable {α : Type*} [Fintype α] [DecidableEq α]

lemma pk_eq_digit (s : Finset α) :
    pk s = digitProd fun k => if k ∈ s then littleC else (1 : Matrix F F ℂ) := by
  unfold pk
  apply wrap_of
  have hd : diagonal (fun x : Space α => ∏ k ∈ s, tint (x k))
      = digitProd (fun k => diagonal (if k ∈ s then tint else fun _ => (1 : ℂ))) := by
    rw [digitProd_diagonal]
    congr 1
    funext x
    symm
    simp only [ite_apply]
    rw [Finset.prod_ite_mem, Finset.univ_inter]
  rw [hd]
  unfold wal
  rw [digitProd_mul, digitProd_mul]
  congr 1
  funext k
  split_ifs
  · exact little_phase
  · rw [Matrix.one_mul, Matrix.diagonal_one, Matrix.mul_one]

lemma pk_apply (s : Finset α) (a b : Space α) :
    pk s a b = if (∀ k, k ∉ s → a k = b k) then ca ^ s.card / lum (a + b) else 0 := by
  rw [pk_eq_digit, digitProd_apply]
  by_cases h : ∀ k, k ∉ s → a k = b k
  · rw [if_pos h]
    have h1 : ∀ k, (if k ∈ s then littleC else (1 : Matrix F F ℂ)) (a k) (b k)
        = (if k ∈ s then ca else 1) / tint ((a + b) k) := by
      intro k
      by_cases hk : k ∈ s
      · simp only [if_pos hk, littleC_eq, Pi.add_apply]
      · have hab := h k hk
        simp [if_neg hk, hab, tint]
    simp only [h1]
    rw [Finset.prod_div_distrib, Finset.prod_ite_mem, Finset.univ_inter, Finset.prod_const]
    rfl
  · rw [if_neg h]
    push_neg at h
    obtain ⟨k, hk, hne⟩ := h
    apply Finset.prod_eq_zero (mem_univ k)
    simp [if_neg hk, Matrix.one_apply, hne]

lemma pk_apply' (s : Finset α) (a v : Space α) :
    pk s a (a + v) = if (∀ k, k ∉ s → v k = 0) then ca ^ s.card / lum v else 0 := by
  rw [pk_apply, ← add_assoc, binary_cancel, zero_add]
  exact if_congr (forall_congr' fun k => imp_congr_right fun _ => F_self_eq_add (a k) (v k))
    rfl rfl

theorem core_apply (G : APerm α) (s : Finset α) (x u : Space α) :
    core G s x (x + u) = if InSub G s u then
      ca ^ s.card * sign (dot x u + dot (G.π x) (G.π u)) / lum u else 0 := by
  have hcond : (∀ k, k ∉ s → G.π x k = (G.π x + G.π u) k) ↔ InSub G s u :=
    forall_congr' fun k => imp_congr_right fun _ => F_self_eq_add (G.π x k) (G.π u k)
  rw [core, mul_kg_inv_apply, kg_mul_apply, pk_apply, G.add,
    show G.π x + (G.π x + G.π u) = G.π u by rw [← add_assoc, binary_cancel, zero_add],
    if_congr hcond rfl rfl]
  by_cases hu : InSub G s u
  · rw [if_pos hu, if_pos hu, lum_add (G.π x) (G.π u), lum_add x u, sign_add]
    have h1 := lum_nonzero x
    have h2 := lum_nonzero (G.π x)
    have h3 := lum_nonzero (G.π u)
    have h4 := lum_nonzero u
    -- CHECK: field_simp/ring closing pattern after the ±1 case split
    rcases bit_cases (dot x u) with h | h <;> rcases bit_cases (dot (G.π x) (G.π u)) with h' | h' <;>
      simp only [h, h', sgn0, sgn1] <;> field_simp <;> ring
  · rw [if_neg hu, if_neg hu]; simp

def supEquiv (s : Finset α) : {c : Space α // ∀ k, k ∉ s → c k = 0} ≃ (s → F) where
  toFun c := fun k => c.1 k.1
  invFun d := ⟨fun k => if hk : k ∈ s then d ⟨k, hk⟩ else 0, fun k hk => by simp [hk]⟩
  left_inv c := by
    apply Subtype.ext
    funext k
    by_cases hk : k ∈ s
    · simp [hk]
    · simp [hk, c.2 k hk]
  right_inv d := by
    funext k
    simp

theorem same_card {G G' : APerm α} {s s' : Finset α}
    (h : ∀ x, InSub G s x ↔ InSub G' s' x) : s.card = s'.card := by
  have hc : ∀ (G : APerm α) (s : Finset α), Fintype.card {x // InSub G s x} = 2 ^ s.card :=
    fun G s => by
      have e1 : {x // InSub G s x} ≃ {c : Space α // ∀ k, k ∉ s → c k = 0} :=
        Equiv.subtypeEquiv G.π (fun x => Iff.rfl)
      -- CHECK: `Fintype.card F = 2` by `rfl` (replaces the original's `simp [ZMod.card]`)
      rw [Fintype.card_congr (e1.trans (supEquiv s)),
        Fintype.card_fun, Fintype.card_coe, show Fintype.card F = 2 from rfl]
  have e := Fintype.card_congr (Equiv.subtypeEquivRight h)
  rw [hc, hc] at e
  exact Nat.pow_right_injective (le_refl 2) e

theorem climb_rank {G G' G₀ : APerm α} {s t s₀ t₀ : Finset α}
    (h1 : ∀ x, InSub G s x ↔ InSub G₀ s₀ x) (h2 : ∀ x, InSub G₀ t₀ x ↔ InSub G' t x)
    (hst : s₀ ⊆ t₀) : (t₀ \ s₀).card = t.card - s.card := by
  rw [Finset.card_sdiff_of_subset hst, same_card h1, same_card h2]

def rq (H : APerm α) (s : Finset α) (x : Space α) : Space α :=
  fun k => if k ∈ s then x k + dot (H.π x) (H.π (eu k)) else 0

lemma rq_add (H : APerm α) (s : Finset α) (x y : Space α) :
    rq H s (x + y) = rq H s x + rq H s y := by
  funext k
  simp only [rq, Pi.add_apply, H.add, dot_add_left]
  split_ifs <;> ring

lemma rq_dot (H : APerm α) (s : Finset α) (x u : Space α) (hu : ∀ k, k ∉ s → u k = 0) :
    dot (rq H s x) u = dot x u + dot (H.π x) (H.π u) := by
  rw [show dot (H.π x) (H.π u) = dot (fun j => dot (H.π x) (H.π (eu j))) u from
    add_fun_eq_dot (fun u => dot (H.π x) (H.π u))
      (fun a b => by simp only [H.add, dot_add_right]) u, ← dot_add_left]
  show ∑ j, rq H s x j * u j = ∑ j, (x + fun j => dot (H.π x) (H.π (eu j))) j * u j
  apply Finset.sum_congr rfl
  intro j _
  by_cases hj : j ∈ s
  · simp only [rq, if_pos hj, Pi.add_apply]
  · rw [hu j hj, mul_zero, mul_zero]

lemma rq_ker (H : APerm α) (s s' : Finset α)
    (hH : ∀ y, (∀ k, k ∉ s → y k = 0) ↔ InSub H s' y)
    (z : Space α) (hz : z + rq H s z = 0) : z = 0 := by
  have hq : rq H s z = z :=
    calc rq H s z = z + (z + rq H s z) := by rw [← add_assoc, binary_cancel, zero_add]
      _ = z := by rw [hz, add_zero]
  have hzV : ∀ k, k ∉ s → z k = 0 := fun k hk => by rw [← hq]; exact if_neg hk
  have hHz : H.π z = 0 := by
    funext j
    by_cases hj : j ∈ s'
    · have hv : InSub H s' (H.π.symm (eu j)) := fun k hk => by
        rw [Equiv.apply_symm_apply]
        exact if_neg fun (h : j = k) => hk (h ▸ hj)
      have e := rq_dot H s z _ ((hH _).mpr hv)
      rw [hq, Equiv.apply_symm_apply, dot_eu_right] at e
      exact (F_self_eq_add _ _).mp e
    · exact ((hH z).mp hzV) j hj
  exact H.π.injective (by rw [hHz, H.map_zero'])

theorem rep_aux (H : APerm α) (s s' : Finset α)
    (hH : ∀ y, (∀ k, k ∉ s → y k = 0) ↔ InSub H s' y) :
    ∃ M, Free M ∧ core H s' = M * pk s := by
  have hc : s.card = s'.card := same_card (G := apId α) (s := s) hH
  refine ⟨diagonal (fun x => lum (rq H s x)) *
      permMat (mkAP (fun x => x + rq H s x) (fun x y => by simp only [rq_add]; abel)
        (fun z hz => rq_ker H s s' hH z hz)),
    Free.mul (free_lum_comp _ (rq_add H s)) (Free.perm _), ?_⟩
  ext x y
  obtain ⟨u, rfl⟩ : ∃ u, y = x + u := ⟨x + y, by rw [← add_assoc, binary_cancel, zero_add]⟩
  rw [Matrix.mul_assoc, Matrix.diagonal_mul, permMat_mul_apply, core_apply]
  show _ = lum (rq H s x) * pk s (x + rq H s x) (x + u)
  rw [show x + u = (x + rq H s x) + (rq H s x + u) by
    rw [add_assoc, ← add_assoc (rq H s x), binary_cancel, zero_add], pk_apply']
  have hv : (∀ k, k ∉ s → (rq H s x + u) k = 0) ↔ ∀ k, k ∉ s → u k = 0 :=
    forall_congr' fun k => imp_congr_right fun hk => by
      show rq H s x k + u k = 0 ↔ _; rw [show rq H s x k = 0 from if_neg hk, zero_add]
  by_cases hu : ∀ k, k ∉ s → u k = 0
  · rw [if_pos ((hH u).mp hu), if_pos (hv.mpr hu), ← rq_dot H s x u hu, lum_add, hc]
    have h1 := lum_nonzero (rq H s x)
    have h2 := lum_nonzero u
    -- CHECK: field_simp/ring closing pattern
    rcases bit_cases (dot (rq H s x) u) with h | h <;> simp only [h, sgn0, sgn1] <;>
      field_simp <;> ring
  · rw [if_neg (mt (hH u).mpr hu), if_neg (mt hv.mp hu), mul_zero]

theorem rep_change (G G' : APerm α) (s s' : Finset α)
    (h : ∀ x, InSub G s x ↔ InSub G' s' x) :
    ∃ N, Free N ∧ core G' s' = N * core G s := by
  obtain ⟨M, hM, hcore⟩ := rep_aux (apComp (apInv G) G') s s' fun y => by
    have e := h (G.π.symm y)
    simp only [InSub, Equiv.apply_symm_apply] at e
    exact e
  have e3 : core G' s' = kg G * core (apComp (apInv G) G') s' * kg (apInv G) := by
    unfold core
    rw [← kg_comp (G := G) (H := apComp (apInv G) G') (K := G') fun x => by simp [apComp, apInv],
      ← kg_comp (G := apInv (apComp (apInv G) G')) (H := apInv G) (K := apInv G')
        fun x => by simp [apComp, apInv]]
    simp only [Matrix.mul_assoc]
  refine ⟨kg G * M * kg (apInv G), Free.mul (Free.mul (free_kg G) hM) (free_kg _), ?_⟩
  rw [e3, hcore, core]
  simp only [Matrix.mul_assoc]
  rw [← Matrix.mul_assoc (kg (apInv G)) (kg G), kg_inv_mul, Matrix.one_mul]

def coordPerm (A : OBase α) : APerm α where
  π := { toFun := fun x k => dot (A.v k) x
         invFun := fun c => ∑ k, c k • A.v k
         left_inv := by
           intro x
           show ∑ k, dot (A.v k) x • A.v k = x
           exact A.proj_univ x
         right_inv := by
           intro c
           funext j
           show dot (A.v j) (∑ k, c k • A.v k) = c j
           rw [dot_sum]
           simp [A.rows] }
  add := by
    intro x y
    funext k
    show dot (A.v k) (x + y) = dot (A.v k) x + dot (A.v k) y
    exact dot_add_right _ _ _

lemma kg_shift_kg (A : OBase α) (i : α) :
    kg (coordPerm A) * shift (eu i) * kg (apInv (coordPerm A))
      = (I / lum (A.v i)) • shift (A.v i) := by
  ext x y
  rw [mul_kg_inv_apply, kg_mul_apply]
  simp only [shift, Matrix.smul_apply, smul_eq_mul]
  have hG : (coordPerm A).π (A.v i) = eu i := by
    funext k
    show dot (A.v k) (A.v i) = if i = k then 1 else 0
    rw [A.rows]; exact if_congr eq_comm rfl rfl
  have hiff : (coordPerm A).π x + eu i = (coordPerm A).π y ↔ x + A.v i = y := by
    rw [← hG, ← (coordPerm A).add]
    exact (coordPerm A).π.injective.eq_iff
  by_cases h : x + A.v i = y
  · rw [if_pos (hiff.2 h), if_pos h]
    subst h
    have h2 : dot ((coordPerm A).π x) (eu i) = dot x (A.v i) := by
      rw [dot_eu_right]; exact dot_symm _ _
    have hl : lum (eu i : Space α) = I := by
      have h : ∀ k, tint (eu i k) = if i = k then I else 1 := by
        intro k
        by_cases hk : i = k <;> simp [eu, tint, hk]
      simp only [lum, h, Finset.prod_ite_eq, mem_univ, if_true]
    rw [(coordPerm A).add, hG, lum_add, lum_add, hl, h2]
    have hx := lum_nonzero x
    have hgx := lum_nonzero ((coordPerm A).π x)
    have hv := lum_nonzero (A.v i)
    have hs : sign (dot x (A.v i)) ≠ 0 := by
      rcases bit_cases (dot x (A.v i)) with h|h <;> simp [h, sign]
    field_simp
  · rw [if_neg (fun h' => h (hiff.1 h')), if_neg h]
    simp

lemma step_scalar (A : OBase α) (i : α) :
    ∃ n : ℕ, delta (A.v i)
      = (I ^ n) • (kg (coordPerm A) * dir (eu i) * kg (apInv (coordPerm A))) := by
  have hk : kg (coordPerm A) * dir (eu i) * kg (apInv (coordPerm A))
      = ca • (1 : CMat α) + cb • ((I / lum (A.v i)) • shift (A.v i)) := by
    unfold dir
    rw [Matrix.mul_add, Matrix.add_mul, Matrix.mul_smul, Matrix.smul_mul, Matrix.mul_one,
      kg_mul_inv, Matrix.mul_smul, Matrix.smul_mul, kg_shift_kg]
  rcases lum_of_unit (A.v i) (A.self i) with h|h
  · refine ⟨0, ?_⟩
    rw [hk, h, delta_pos _ h, div_self Complex.I_ne_zero, pow_zero, one_smul, one_smul]
    rfl
  · refine ⟨3, ?_⟩
    have hI3 : (I : ℂ) ^ 3 = -I := by
      rw [pow_succ, pow_two, Complex.I_mul_I]; ring
    have hdiv : I / -I = (-1 : ℂ) := by
      rw [div_neg, div_self Complex.I_ne_zero]
    rw [hk, h, delta_neg _ h, hI3, hdiv]
    unfold dir
    rw [Matrix.mul_add, Matrix.mul_smul, Matrix.mul_smul, Matrix.mul_one, shift_sq, smul_add,
      smul_smul, smul_smul, smul_smul,
      show -I * ca = cb by unfold ca cb; linear_combination (-1 / 2 : ℂ) * Complex.I_sq]
    have e : -I * cb * -1 = ca := by
      unfold ca cb; linear_combination (-1 / 2 : ℂ) * Complex.I_sq
    rw [e, add_comm]

theorem frame_core (A : OBase α) (s : Finset α) :
    ∃ n : ℕ, frame A s = (I ^ n) • core (coordPerm A) s := by
  induction s using Finset.induction_on with
  | empty => exact ⟨0, by rw [frame_zero, core_empty, pow_zero, one_smul]⟩
  | insert i s hi ih =>
    obtain ⟨n, hn⟩ := ih
    obtain ⟨m, hm⟩ := step_scalar A i
    refine ⟨m + n, ?_⟩
    rw [frame_ins A s i hi, hn, hm, core_insert _ hi, Matrix.smul_mul, Matrix.mul_smul,
      smul_smul, ← pow_add]

theorem frame_core_free (A : OBase α) (s : Finset α) :
    ∃ N, Free N ∧ frame A s = N * core (coordPerm A) s := by
  obtain ⟨n, hn⟩ := frame_core A s
  exact ⟨(I ^ n) • (1 : CMat α), free_scalar n, by rw [Matrix.smul_mul, Matrix.one_mul]; exact hn⟩

lemma insub_coordPerm (A : OBase α) (s : Finset α) (x : Space α) :
    InSub (coordPerm A) s x ↔ ∀ k, k ∉ s → dot (A.v k) x = 0 := Iff.rfl

def flagMap (L : APerm α) (p : Space α) (a : α) (y : Space α) : Space α :=
  L.π (y + y a • p) + y a • eu a

theorem flag (t : Finset α) : ∀ W : Space α → Prop, W 0 → (∀ x y, W x → W y → W (x + y)) →
    (∀ y, W y → ∀ k, k ∉ t → y k = 0) →
    ∃ (L : APerm α) (s₀ : Finset α), s₀ ⊆ t ∧ (∀ y k, k ∉ t → L.π y k = y k) ∧
      ∀ y, InSub L s₀ y ↔ W y := by
  induction t using Finset.induction_on with
  | empty =>
    intro W h0 _ ht
    refine ⟨apId α, ∅, Finset.Subset.refl _, fun _ _ _ => rfl, fun y =>
      ⟨fun hy => ?_, fun hy k _ => ht y hy k (Finset.notMem_empty k)⟩⟩
    have e : y = 0 := funext fun k => hy k (Finset.notMem_empty k)
    rw [e]; exact h0
  | insert a t ha ih =>
    intro W h0 hadd ht
    have hni : ∀ {k}, k ∉ insert a t ↔ ¬k = a ∧ k ∉ t := by
      intro k; rw [Finset.mem_insert, not_or]
    have hsub : ∀ y, W y → y a = 0 → ∀ k, k ∉ t → y k = 0 := fun y hy hya k hk => by
      by_cases hka : k = a
      · rw [hka]; exact hya
      · exact ht y hy k (hni.mpr ⟨hka, hk⟩)
    by_cases hc : ∀ y, W y → y a = 0
    · obtain ⟨L, s₀, hs, hfix, hL⟩ := ih W h0 hadd fun y hy => hsub y hy (hc y hy)
      exact ⟨L, s₀, hs.trans (Finset.subset_insert a t),
        fun y k hk => hfix y k (hni.mp hk).2, hL⟩
    obtain ⟨p, hp, hpa⟩ : ∃ p, W p ∧ p a = 1 := by
      by_contra hh
      exact hc fun y hy => (bit_cases (y a)).resolve_right fun h => hh ⟨y, hy, h⟩
    have hsm : ∀ c : F, W (c • p) := fun c => by
      rcases bit_cases c with rfl | rfl
      · rw [zero_smul]; exact h0
      · rw [one_smul]; exact hp
    obtain ⟨L, s₀, hs, hfix, hL⟩ := ih (fun y => W y ∧ y a = 0) ⟨h0, rfl⟩
      (fun x y hx hy => ⟨hadd x y hx.1 hy.1, by
        show x a + y a = 0; rw [hx.2, hy.2, add_zero]⟩)
      (fun y hy => hsub y hy.1 hy.2)
    have hz0 : ∀ y : Space α, (y + y a • p) a = 0 := fun y => by
      show y a + y a * p a = 0; rw [hpa, mul_one, cancel]
    have fadd : ∀ x y, flagMap L p a (x + y) = flagMap L p a x + flagMap L p a y := fun x y => by
      simp only [flagMap, Pi.add_apply, add_smul]
      rw [show x + y + (x a • p + y a • p) = (x + x a • p) + (y + y a • p) by abel, L.add]
      abel
    have fout : ∀ y k, k ≠ a → flagMap L p a y k = L.π (y + y a • p) k := fun y k hk => by
      show L.π (y + y a • p) k + y a * (if a = k then (1 : F) else 0) = _
      rw [if_neg (Ne.symm hk), mul_zero, add_zero]
    have fker : ∀ y, flagMap L p a y = 0 → y = 0 := fun y hy => by
      have hya : y a = 0 := by
        have e := congrFun hy a
        change L.π (y + y a • p) a + y a * (if a = a then (1 : F) else 0) = 0 at e
        rwa [hfix _ a ha, hz0, zero_add, if_pos rfl, mul_one] at e
      have e : flagMap L p a y = L.π y := by simp only [flagMap, hya, zero_smul, add_zero]
      exact L.π.injective (by rw [← e, hy, L.map_zero'])
    refine ⟨mkAP (flagMap L p a) fadd fker, insert a s₀, Finset.insert_subset_insert a hs,
      fun y k hk => ?_, fun y => ⟨fun hy => ?_, fun hy k hk => ?_⟩⟩
    · show flagMap L p a y k = y k
      rw [fout y k (hni.mp hk).1, hfix _ k (hni.mp hk).2]
      show y k + y a * p k = y k
      rw [ht p hp k hk, mul_zero, add_zero]
    · have hz : InSub L s₀ (y + y a • p) := fun k hk => by
        by_cases hka : k = a
        · rw [hka, hfix _ a ha]; exact hz0 y
        · rw [← fout y k hka]
          exact hy k (by rw [Finset.mem_insert, not_or]; exact ⟨hka, hk⟩)
      have e := hadd _ _ ((hL _).mp hz).1 (hsm (y a))
      rwa [add_assoc, binary_cancel, add_zero] at e
    · rw [Finset.mem_insert, not_or] at hk
      show flagMap L p a y k = 0
      rw [fout y k hk.1]
      exact (hL _).mpr ⟨hadd _ _ hy (hsm _), hz0 y⟩ k hk.2

theorem exists_common_base (G G' : APerm α) (s t : Finset α)
    (h : ∀ x, InSub G s x → InSub G' t x) :
    ∃ (G₀ : APerm α) (s₀ t₀ : Finset α), s₀ ⊆ t₀ ∧ (∀ x, InSub G s x ↔ InSub G₀ s₀ x) ∧
      (∀ x, InSub G₀ t₀ x ↔ InSub G' t x) := by
  obtain ⟨L, s₀, hs, hfix, hL⟩ := flag t (fun y => InSub G s (G'.π.symm y))
    (fun k _ => by
      show G.π (G'.π.symm 0) k = 0
      rw [show G'.π.symm 0 = 0 from (apInv G').map_zero', G.map_zero', Pi.zero_apply])
    (fun x y hx hy k hk => by
      show G.π (G'.π.symm (x + y)) k = 0
      rw [show G'.π.symm (x + y) = G'.π.symm x + G'.π.symm y from (apInv G').add x y, G.add]
      show G.π (G'.π.symm x) k + G.π (G'.π.symm y) k = 0
      rw [hx k hk, hy k hk, add_zero])
    (fun y hy k hk => by
      have e := h _ hy k hk
      rwa [Equiv.apply_symm_apply] at e)
  refine ⟨apComp G' L, s₀, t, hs, fun x => ?_, fun x => ?_⟩
  · have e := hL (G'.π x)
    simp only [Equiv.symm_apply_apply] at e
    exact e.symm
  · show (∀ k, k ∉ t → L.π (G'.π x) k = 0) ↔ ∀ k, k ∉ t → G'.π x k = 0
    exact forall_congr' fun k => imp_congr_right fun hk => by rw [hfix _ _ hk]

end
end
end PowerSaving.GF
end OAI
