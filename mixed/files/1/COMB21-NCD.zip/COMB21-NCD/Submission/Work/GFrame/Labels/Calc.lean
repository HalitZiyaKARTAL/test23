import Submission.Work.Combine.XG
import Submission.Work.GFrame.Engine.Free


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM CB
noncomputable section

section FMv
variable {α : Type} [Fintype α] [DecidableEq α]

inductive FMv : CMat α → CMat α → List ℕ → Prop
  | free {M A : CMat α} : GF.Free A → FMv M (A * M) []
  | block {M : CMat α} {r : ℕ} (z : Fin r → Space α) : LinearIndependent F z → 1 ≤ r →
      r < Fintype.card α → FMv M (blockMat z * M) [r]
  | trans {M N L : CMat α} {a b : List ℕ} : FMv M N a → FMv N L b → FMv M L (a ++ b)
  | zero {M N : CMat α} {a : List ℕ} : FMv M N a → FMv M N (0 :: a)

namespace FMv
variable {M N L : CMat α} {rs : List ℕ}

theorem refl (M : CMat α) : FMv M M [] := by
  have h := FMv.free (M := M) GF.Free.one
  rwa [one_mul] at h

theorem factor {A B : CMat α} {r : ℕ} (z : Fin r → Space α) (ind : LinearIndependent F z)
    (h1 : 1 ≤ r) (h2 : r < Fintype.card α) (hA : GF.Free A) (hB : GF.Free B) (M : CMat α) :
    FMv M (A * blockMat z * B * M) [r] := by
  have e : A * blockMat z * B * M = A * (blockMat z * (B * M)) := by simp only [mul_assoc]
  rw [e]
  exact ((FMv.free (M := M) hB).trans (FMv.block z ind h1 h2)).trans (FMv.free hA)

theorem step {ρ : Type} [Fintype ρ] [DecidableEq ρ] (h : FMv M N rs) (l : ρ) :
    GStep l M N (fun φ => rcost φ rs) := by
  induction h with
  | free hA => exact (gstep_free hA l _).cast (fun φ => (rcost_nil φ).symm)
  | block z ind h1 h2 =>
    exact (gstep_block l _ z ind h1 h2).cast
      (fun φ => by rw [rcost_single, bcost_pos φ (by omega)])
  | trans _ _ iha ihb =>
    exact (iha.trans ihb).cast (fun φ => (rcost_append φ _ _).symm)
  | zero _ ih =>
    exact ih.cast (fun φ => by rw [rcost_cons, bcost_zero, zero_add])

end FMv
end FMv

end
end PowerSaving.GF
end OAI
