import Submission.Work.GFrame.Labels.Calc
import Submission.Work.GFrame.Engine.Route


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM CB
noncomputable section

section
variable {α : Type} [Fintype α] [DecidableEq α]

theorem fmv_of_factor {M N A B : CMat α} {r : ℕ} (z : Fin r → Space α)
    (ind : LinearIndependent F z) (h1 : 1 ≤ r) (h2 : r < Fintype.card α)
    (hA : GF.Free A) (hB : GF.Free B) (hN : N = A * blockMat z * B * M) :
    FMv M N [r] := by
  subst hN
  exact FMv.factor z ind h1 h2 hA hB M

theorem fmv_of_free {M N A : CMat α} (hA : GF.Free A) (hN : N = A * M) :
    FMv M N [] := by
  subst hN
  exact FMv.free hA

variable {𝓛 ρ : Type} [Fintype ρ] [DecidableEq ρ]

end
end
end PowerSaving.GF
end OAI
