import Submission.Work.GFrame.Labels.GCalc


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM CB
noncomputable section

section
variable {α : Type} [Fintype α] [DecidableEq α] {𝓛 ρ : Type} [Fintype ρ] [DecidableEq ρ]

def Reach (M N : CMat α) (c : (ℕ → ℝ) → ℝ) : Prop :=
  ∀ (ρ : Type) [Fintype ρ] [DecidableEq ρ] (l : ρ), GStep l M N c

theorem FMv.reach {M N : CMat α} {rs : List ℕ} (h : FMv M N rs) :
    Reach M N (fun φ => rcost φ rs) := fun ρ _ _ l => FMv.step h l

end
end
end PowerSaving.GF
end OAI

