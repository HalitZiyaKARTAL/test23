import Submission.Work.GFrame.Engine.Free


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM
noncomputable section
section
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

def GRoute (S T : ρ → CMat α) (g : (ρ→ℂ) → (ρ→ℂ)) (c : (ℕ → ℝ) → ℝ) : Prop :=
  ∃ w : GWord α ρ, w.Proper (Fintype.card α) ∧ (∀ φ, w.costR φ = c φ) ∧
    ∀ (f : ℕ) (x : Data α ρ f), gwalk f w (multiAct f S x) = multiAct f T (point f g x)

namespace GRoute
variable {S T U : ρ → CMat α}

theorem refl : GRoute S S id (fun _ => 0) :=
  ⟨[], GWord.proper_nil _, fun _ => rfl, fun f x => rfl⟩

theorem cast {g : (ρ→ℂ) → (ρ→ℂ)} {c c' : (ℕ → ℝ) → ℝ} (h : GRoute S T g c)
    (hc : ∀ φ, c φ = c' φ) : GRoute S T g c' := by
  obtain ⟨w, hw, hcost, hwalk⟩ := h
  exact ⟨w, hw, fun φ => (hcost φ).trans (hc φ), hwalk⟩

theorem trans {g h : (ρ→ℂ) → (ρ→ℂ)} {c c' : (ℕ → ℝ) → ℝ} (a : GRoute S T g c)
    (b : GRoute T U h c') : GRoute S U (h ∘ g) (fun φ => c φ + c' φ) := by
  obtain ⟨p,hp,cp,ap⟩ := a
  obtain ⟨q,hq,cq,aq⟩ := b
  refine ⟨p++q, hp.append hq, fun φ => by rw [GWord.costR_append, cp, cq], ?_⟩
  intro f x
  rw [gwalk_append, ap, aq]; rfl

theorem ofX {g : (ρ→ℂ) → (ρ→ℂ)} {c : (ℕ → ℝ) → ℝ} (h : GRoute S T g c) : GRoute S T g c := h

theorem gate (g : Matrix ρ ρ ℚ) (S T : ρ → CMat α)
    (cond : ∀ i j, g i j ≠ 0 → T i = S j) :
    GRoute S T (actPoint g) (fun _ => 0) := by
  refine ⟨GWord.ofB [.localM g], GWord.proper_ofB ?_, ?_, ?_⟩
  · intro mv hmv
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hmv
    subst hmv; trivial
  · intro φ
    rw [GWord.costR_ofB]
    simp [BWord.costR, BMove.costR, BMove.rk?]
  intro f x
  rw [gwalk_ofB, show BWord.flat [BMove.localM g] = [Move.localM g] from rfl]
  let M (r : ρ) := digitProd (fun _ : Fin f => S r)
  let N (r : ρ) := digitProd (fun _ : Fin f => T r)
  funext r i
  change ∑ j, (g r j:ℂ)* (∑ a, M j i a * x j a)
    = ∑ a, N r i a * (∑ j, (g r j:ℂ)*x j a)
  simp only [mul_sum]
  rw [sum_comm]
  apply sum_congr rfl
  intro a ha
  apply sum_congr rfl
  intro j hj
  by_cases gh : g r j = 0
  · simp [gh]
  · dsimp only [M, N]
    rw [cond r j gh]
    ac_rfl

theorem on_role (S : ρ → CMat α) (l : ρ) (N : CMat α) {c : (ℕ → ℝ) → ℝ}
    (h : GStep l (S l) N c) :
    GRoute S (Function.update S l N) id c := by
  obtain ⟨w, V, hw, hc, hV, hwalk⟩ := h
  refine ⟨w, hw, hc, fun f x => ?_⟩
  rw [hwalk, show point f id x = x from rfl]
  funext j
  by_cases hj : j = l
  · subst hj
    simp [roleAct, multiAct, hV]
  · simp [roleAct, multiAct, hj]

end GRoute
end
end
end PowerSaving.GF
end OAI
