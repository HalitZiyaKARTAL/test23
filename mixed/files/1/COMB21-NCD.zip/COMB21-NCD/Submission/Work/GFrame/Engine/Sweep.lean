import Submission.Work.GFrame.Engine.Adapt


namespace OAI
namespace PowerSaving.RAM
open Binary Matrix Ty Finset GF
noncomputable section

section
universe U
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
variable {ι : Type U}
variable {m : Bool} {f : ι → ℕ} {s : Ty} {x : ι → T s}
    {cl : Paint} {X : Layout α} {R : Layout ρ} {r : ℕ} {v : ∀ i, Grain α ρ r (f i)}
    {b : Bank (hatch cl) ι}

def gferry (r f : ℕ) (mv : GMove α ρ) (v : Grain α ρ r f) : Grain α ρ r f :=
  fun x => mv.act f (fun i j => v (i,x.2.1,j)) x.1 x.2.2

def gcoast (r f : ℕ) (w : GWord α ρ) (v : Grain α ρ r f) : Grain α ρ r f :=
  fun x => gwalk f w (fun i j => v (i,x.2.1,j)) x.1 x.2.2

section
variable {B : ι → ℕ}

lemma Rig.ferry_pointG (h : Rig m B f s x cl X R r v) (gr gi : Matrix ρ ρ ℚ) (q : ∀ i, Beach α ρ r (f i))
    (g : Knows m B s x fun i => (fleet X R r (f i)).loc (q i)) :
    Has m B s (c cl) x fun i => gferry r (f i) (.localG gr gi) (v i) (q i) := by
  have h1 := h.ferry_point gr q g
  have h2 := h.ferry_point gi q g
  have hI : Has m B s sc x fun _ => Complex.I := h.imag
  convert h1.add (hI.mul h2) using 1
  funext i
  simp only [gferry, GMove.act, ferry, Move.go, point, actPointG, actPoint]
  rw [Finset.mul_sum, ← Finset.sum_add_distrib]
  refine Finset.sum_congr rfl fun j _ => ?_
  ring

lemma Rig.pointG_cost (h : Rig m B f s x cl X R r v) (gr gi : Matrix ρ ρ ℚ) :
    Can m B s (a (c cl)) x
      (fun i => (fleet X R r (f i)).tape (gferry r (f i) (.localG gr gi) (v i)))
      (fun i => (fleet X R r (f i)).n) := by
  refine h.chart _ ?_
  let S := Σ i, Beach α ρ r (f i)
  have hg := h.gather (fun d : S => d.1)
    (fun d => ((x d.1, (fleet X R r (f d.1)).loc d.2):T (p s w))) (t:=p s w) Can.first
  exact hg.ferry_pointG gr gi (fun d => d.2) Can.second

end

end

end
end PowerSaving.RAM
end OAI

