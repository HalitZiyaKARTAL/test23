import Submission.Work.Block.WHT


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset
noncomputable section

structure APerm (α : Type*) where
  π : Space α ≃ Space α
  add : ∀ x y, π (x + y) = π x + π y

section Mats
variable {α : Type*} [Fintype α] [DecidableEq α]

def permMat (G : APerm α) : CMat α := fun x y => if G.π x = y then 1 else 0

def phaseMat (z : Space α) (c : F) : CMat α := Matrix.diagonal fun x => tint (dot z x + c)

end Mats

inductive GMove (α ρ : Type*)
  | old (mv : BMove α ρ)
  | perm (l : ρ) (G : APerm α)
  | phase (l : ρ) (z : Space α) (c : F)
  | localG (gr gi : Matrix ρ ρ ℚ)

abbrev GWord (α ρ : Type*) := List (GMove α ρ)

namespace GMove
variable {α ρ : Type*}

def shadow : GMove α ρ → BMove α ρ
  | .old mv => mv
  | .perm _ _ => .localM 0
  | .phase _ _ _ => .localM 0
  | .localG _ _ => .localM 0

def rk? (mv : GMove α ρ) : Option ℕ := mv.shadow.rk?
def costR (φ : ℕ → ℝ) (mv : GMove α ρ) : ℝ := mv.shadow.costR φ
def Proper (u : ℕ) (mv : GMove α ρ) : Prop := mv.shadow.Proper u

@[simp] lemma costR_perm (φ : ℕ → ℝ) (l : ρ) (G : APerm α) :
    (GMove.perm l G : GMove α ρ).costR φ = 0 := rfl
@[simp] lemma costR_phase (φ : ℕ → ℝ) (l : ρ) (z : Space α) (c : F) :
    (GMove.phase l z c : GMove α ρ).costR φ = 0 := rfl
@[simp] lemma costR_old (φ : ℕ → ℝ) (mv : BMove α ρ) : (GMove.old mv).costR φ = mv.costR φ := rfl
@[simp] lemma costR_localG (φ : ℕ → ℝ) (gr gi : Matrix ρ ρ ℚ) :
    (GMove.localG gr gi : GMove α ρ).costR φ = 0 := rfl
lemma proper_localG (u : ℕ) (gr gi : Matrix ρ ρ ℚ) :
    (GMove.localG gr gi : GMove α ρ).Proper u := trivial
@[simp] lemma proper_old (u : ℕ) (mv : BMove α ρ) : (GMove.old mv).Proper u ↔ mv.Proper u :=
  Iff.rfl

end GMove

namespace GWord
variable {α ρ : Type*}

def shadow (w : GWord α ρ) : BWord α ρ := w.map GMove.shadow
def costR (φ : ℕ → ℝ) (w : GWord α ρ) : ℝ := (w.map (GMove.costR φ)).sum
def Proper (u : ℕ) (w : GWord α ρ) : Prop := ∀ mv ∈ w, mv.Proper u
def hist (w : GWord α ρ) (r : ℕ) : ℕ := w.shadow.hist r
def ofB (w : BWord α ρ) : GWord α ρ := w.map GMove.old

@[simp] lemma shadow_nil : shadow ([] : GWord α ρ) = [] := rfl
@[simp] lemma shadow_cons (mv : GMove α ρ) (w : GWord α ρ) :
    shadow (mv :: w) = mv.shadow :: shadow w := rfl
@[simp] lemma shadow_ofB (w : BWord α ρ) : shadow (ofB w) = w := by
  simp [shadow, ofB, List.map_map, Function.comp_def, GMove.shadow]

lemma costR_shadow (φ : ℕ → ℝ) (w : GWord α ρ) : costR φ w = BWord.costR φ w.shadow := by
  unfold costR BWord.costR shadow
  rw [List.map_map]
  rfl
@[simp] lemma costR_nil (φ : ℕ → ℝ) : costR φ ([] : GWord α ρ) = 0 := rfl
lemma costR_cons (φ : ℕ → ℝ) (mv : GMove α ρ) (w : GWord α ρ) :
    costR φ (mv :: w) = mv.costR φ + costR φ w := by simp [costR]
lemma costR_append (φ : ℕ → ℝ) (w w' : GWord α ρ) :
    costR φ (w ++ w') = costR φ w + costR φ w' := by simp [costR]
lemma costR_ofB (φ : ℕ → ℝ) (w : BWord α ρ) : costR φ (ofB w) = BWord.costR φ w := by
  rw [costR_shadow, shadow_ofB]
lemma Proper.tail {u : ℕ} {mv : GMove α ρ} {w : GWord α ρ} (h : Proper u (mv :: w)) :
    Proper u w := fun x hx => h x (List.mem_cons_of_mem _ hx)
lemma Proper.head {u : ℕ} {mv : GMove α ρ} {w : GWord α ρ} (h : Proper u (mv :: w)) :
    mv.Proper u := h mv List.mem_cons_self
lemma Proper.append {u : ℕ} {w w' : GWord α ρ} (h : Proper u w) (h' : Proper u w') :
    Proper u (w ++ w') := by
  intro mv hmv
  rcases List.mem_append.mp hmv with h1|h1
  · exact h mv h1
  · exact h' mv h1
lemma proper_nil (u : ℕ) : Proper u ([] : GWord α ρ) := fun _ h => by simp at h
lemma proper_ofB {u : ℕ} {w : BWord α ρ} (h : w.Proper u) : Proper u (ofB w) := by
  intro mv hmv
  obtain ⟨g, hg, rfl⟩ := List.mem_map.mp hmv
  exact h g hg

end GWord

section Sem
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

def actPointG (gr gi : Matrix ρ ρ ℚ) (x : ρ → ℂ) (r : ρ) : ℂ :=
  ∑ j, ((gr r j : ℂ) + (gi r j : ℂ) * Complex.I) * x j

def GMove.act (f : ℕ) : GMove α ρ → Data α ρ f → Data α ρ f
  | .old mv => mv.act f
  | .perm l G => roleAct f l (permMat G)
  | .phase l z c => roleAct f l (phaseMat z c)
  | .localG gr gi => point f (actPointG gr gi)

def gwalk (f : ℕ) (w : GWord α ρ) (x : Data α ρ f) : Data α ρ f :=
  w.foldl (fun y mv => mv.act f y) x

@[simp] lemma gwalk_nil (f : ℕ) (x : Data α ρ f) : gwalk f ([] : GWord α ρ) x = x := rfl
lemma gwalk_cons (f : ℕ) (mv : GMove α ρ) (w : GWord α ρ) (x : Data α ρ f) :
    gwalk f (mv :: w) x = gwalk f w (mv.act f x) := rfl
lemma gwalk_append (f : ℕ) (p q : GWord α ρ) (x : Data α ρ f) :
    gwalk f (p ++ q) x = gwalk f q (gwalk f p x) := by simp [gwalk]

lemma gwalk_ofB (f : ℕ) (w : BWord α ρ) (x : Data α ρ f) :
    gwalk f (GWord.ofB w) x = walk f w.flat x := by
  induction w generalizing x with
  | nil => rfl
  | cons mv w ih =>
    rw [walk_flat_cons, ← ih]
    rfl

def GStep (l : ρ) (M N : CMat α) (c : (ℕ → ℝ) → ℝ) : Prop :=
  ∃ (w : GWord α ρ) (U : CMat α), w.Proper (Fintype.card α) ∧ (∀ φ, w.costR φ = c φ) ∧
    U * M = N ∧ ∀ (f : ℕ) (x : Data α ρ f), gwalk f w x = roleAct f l U x

end Sem
end
end PowerSaving.GF
end OAI
