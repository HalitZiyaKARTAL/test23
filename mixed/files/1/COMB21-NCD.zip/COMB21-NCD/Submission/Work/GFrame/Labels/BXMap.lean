import Submission.Work.GFrame.Labels.GCalc
import Submission.Work.GFrame.Clifford.Base


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM CB
noncomputable section

section
variable {α : Type} [Fintype α] [DecidableEq α]

structure SLbl (α : Type) where
  G : APerm α
  s : Finset α

namespace SLbl
def rep (U : SLbl α) : CMat α := core U.G U.s
def Mem (U : SLbl α) (x : Space α) : Prop := InSub U.G U.s x
def dim (U : SLbl α) : ℕ := U.s.card
end SLbl

def indv (d : Finset α) : Space α := ∑ k ∈ d, eu k

lemma pk_sq (d : Finset α) : pk d * pk d = shift (indv d) := by
  rw [pk, wrap_mul, shift_phase]
  congr 1
  funext x
  rw [← Finset.prod_mul_distrib]
  simp_rw [tint_sq]
  rw [← sign_sum]
  congr 1
  rw [indv, dot_sum_left]
  simp

theorem core_down (G : APerm α) {s t : Finset α} (h : s ⊆ t) :
    core G s = (kg G * shift (indv (t \ s))) * blockMat ((OBase.canonical α).fam (t \ s))
      * kg (apInv G) * core G t := by
  rw [core_nested G h, ← pk_eq_blockMat]
  have e : kg G * shift (indv (t \ s)) * pk (t \ s) * kg (apInv G)
        * (kg G * pk (t \ s) * kg (apInv G) * core G s)
      = kg G * (shift (indv (t \ s)) * (pk (t \ s) * ((kg (apInv G) * kg G) * pk (t \ s))))
        * kg (apInv G) * core G s := by
    simp only [Matrix.mul_assoc]
  rw [e, kg_inv_mul, Matrix.one_mul, pk_sq, shift_sq, Matrix.mul_one, kg_mul_inv,
    Matrix.one_mul]

def RepChange (α : Type) [Fintype α] [DecidableEq α] : Prop :=
  ∀ (G G' : APerm α) (s s' : Finset α), (∀ x, InSub G s x ↔ InSub G' s' x) →
    ∃ N : CMat α, GF.Free N ∧ core G' s' = N * core G s

inductive SMv (m : ℕ) : SLbl α → SLbl α → List ℕ → Prop
  | stay (U : SLbl α) : SMv m U U []
  | up (G : APerm α) {s t : Finset α} : s ⊆ t → 1 ≤ (t \ s).card →
      (t \ s).card < m → SMv m ⟨G, s⟩ ⟨G, t⟩ [(t \ s).card]
  | down (G : APerm α) {s t : Finset α} : s ⊆ t → 1 ≤ (t \ s).card →
      (t \ s).card < m → SMv m ⟨G, t⟩ ⟨G, s⟩ [(t \ s).card]
  | rebase {U V : SLbl α} : (∀ x, U.Mem x ↔ V.Mem x) → SMv m U V []
  | trans {U V W : SLbl α} {a b : List ℕ} : SMv m U V a → SMv m V W b → SMv m U W (a ++ b)

theorem fmv_core_up (G : APerm α) {s t : Finset α} (h : s ⊆ t) (h1 : 1 ≤ (t \ s).card)
    (h2 : (t \ s).card < Fintype.card α) :
    FMv (core G s) (core G t) [(t \ s).card] :=
  fmv_of_factor _ ((OBase.canonical α).fam_indep _) h1 h2 (free_kg G) (free_kg _)
    (core_nested G h)

theorem fmv_core_down (G : APerm α) {s t : Finset α} (h : s ⊆ t) (h1 : 1 ≤ (t \ s).card)
    (h2 : (t \ s).card < Fintype.card α) :
    FMv (core G t) (core G s) [(t \ s).card] :=
  fmv_of_factor _ ((OBase.canonical α).fam_indep _) h1 h2
    (GF.Free.mul (free_kg G) (GF.Free.shift _)) (free_kg _) (core_down G h)

theorem SMv.fmv (hR : RepChange α) {U V : SLbl α} {rs : List ℕ}
    (h : SMv (Fintype.card α) U V rs) :
    FMv U.rep V.rep rs := by
  induction h with
  | stay U => exact FMv.refl _
  | up G h h1 h2 => exact fmv_core_up G h h1 h2
  | down G h h1 h2 => exact fmv_core_down G h h1 h2
  | rebase h =>
    obtain ⟨N, hN, e⟩ := hR _ _ _ _ h
    exact fmv_of_free hN e
  | trans _ _ iha ihb => exact FMv.trans iha ihb

variable {ρ : Type} [Fintype ρ] [DecidableEq ρ]

end
end
end PowerSaving.GF
end OAI


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM CB
noncomputable section

section
variable {α : Type} [Fintype α] [DecidableEq α]

theorem repChange (α : Type) [Fintype α] [DecidableEq α] : RepChange α :=
  fun G G' s s' h => rep_change G G' s s' h

theorem SMv.fmv' {U V : SLbl α} {rs : List ℕ} (h : SMv (Fintype.card α) U V rs) :
    FMv U.rep V.rep rs := SMv.fmv (repChange α) h

theorem SMv.nested {m : ℕ} (U V : SLbl α) (G₀ : APerm α) (s₀ t₀ : Finset α)
    (h1 : ∀ x, U.Mem x ↔ InSub G₀ s₀ x) (h2 : ∀ x, InSub G₀ t₀ x ↔ V.Mem x) (hst : s₀ ⊆ t₀)
    (hr1 : 1 ≤ (t₀ \ s₀).card) (hr2 : (t₀ \ s₀).card < m) :
    SMv m U V [(t₀ \ s₀).card] := by
  have a : SMv m U ⟨G₀, s₀⟩ [] := SMv.rebase h1
  have b : SMv m (⟨G₀, s₀⟩ : SLbl α) ⟨G₀, t₀⟩ [(t₀ \ s₀).card] := SMv.up G₀ hst hr1 hr2
  have c : SMv m (⟨G₀, t₀⟩ : SLbl α) V [] := SMv.rebase h2
  have h := (a.trans b).trans c
  simpa using h

theorem SMv.nested_rank (U V : SLbl α) (G₀ : APerm α) (s₀ t₀ : Finset α)
    (h1 : ∀ x, U.Mem x ↔ InSub G₀ s₀ x) (h2 : ∀ x, InSub G₀ t₀ x ↔ V.Mem x) (hst : s₀ ⊆ t₀) :
    (t₀ \ s₀).card = V.dim - U.dim :=
  climb_rank (G := U.G) (G' := V.G) (s := U.s) (t := V.s) h1 h2 hst

variable {ρ : Type} [Fintype ρ] [DecidableEq ρ]

end
end
end PowerSaving.GF
end OAI


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM CB
noncomputable section

structure BXMap (H α : Type) [Fintype H] [DecidableEq H] [Fintype α] [DecidableEq α] where
  liftG : APerm H → APerm α
  liftS : Finset H → Finset α
  mono : ∀ {s t : Finset H}, s ⊆ t → liftS s ⊆ liftS t
  card : ∀ {s t : Finset H}, s ⊆ t → (liftS t \ liftS s).card = (t \ s).card
  sub : ∀ {G G' : APerm H} {s s' : Finset H}, (∀ x, InSub G s x ↔ InSub G' s' x) →
    ∀ y, InSub (liftG G) (liftS s) y ↔ InSub (liftG G') (liftS s') y

section
variable {H α : Type} [Fintype H] [DecidableEq H] [Fintype α] [DecidableEq α]

namespace BXMap
variable (X : BXMap H α)

def lab (U : SLbl H) : SLbl α := ⟨X.liftG U.G, X.liftS U.s⟩

def Φ (U : SLbl H) : CMat α := (X.lab U).rep

theorem smv {m : ℕ} {U V : SLbl H} {rs : List ℕ} (h : SMv m U V rs) :
    SMv m (X.lab U) (X.lab V) rs := by
  induction h with
  | stay U => exact SMv.stay _
  | up G hst h1 h2 =>
    have e := X.card hst
    have h := SMv.up (m := m) (X.liftG G) (X.mono hst) (by rw [e]; exact h1)
      (by rw [e]; exact h2)
    rw [e] at h
    exact h
  | down G hst h1 h2 =>
    have e := X.card hst
    have h := SMv.down (m := m) (X.liftG G) (X.mono hst) (by rw [e]; exact h1)
      (by rw [e]; exact h2)
    rw [e] at h
    exact h
  | rebase h => exact SMv.rebase (X.sub h)
  | trans _ _ iha ihb => exact SMv.trans iha ihb

theorem fmv {U V : SLbl H} {rs : List ℕ} (h : SMv (Fintype.card α) U V rs) :
    FMv (X.Φ U) (X.Φ V) rs := SMv.fmv' (X.smv h)

end BXMap

variable {ρ : Type} [Fintype ρ] [DecidableEq ρ]

end
end
end PowerSaving.GF
end OAI
