import Submission.Work.GFrame.Engine.Letters
import Submission.Work.BlockApply.Exact


namespace OAI
namespace PowerSaving.GF
open Binary Matrix Finset RAM
noncomputable section
section
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

inductive Free : CMat α → Prop
  | one : Free 1
  | perm (G : APerm α) : Free (permMat G)
  | phase (z : Space α) (c : F) : Free (phaseMat z c)
  | shift (z : Space α) : Free (Binary.shift z)
  | mul {A B : CMat α} : Free A → Free B → Free (A * B)

namespace GStep
variable {l : ρ} {M N K : CMat α} {c c' : (ℕ → ℝ) → ℝ}

theorem refl (l : ρ) (M : CMat α) : GStep l M M (fun _ => 0) := by
  refine ⟨[], 1, GWord.proper_nil _, fun _ => rfl, one_mul _, fun f x => ?_⟩
  funext j
  simp [roleAct]

theorem cast (a : GStep l M N c) (h : ∀ φ, c φ = c' φ) : GStep l M N c' := by
  obtain ⟨w, U, hw, hc, hU, hwalk⟩ := a
  exact ⟨w, U, hw, fun φ => (hc φ).trans (h φ), hU, hwalk⟩

theorem trans (a : GStep l M N c) (b : GStep l N K c') :
    GStep l M K (fun φ => c φ + c' φ) := by
  obtain ⟨w, U, hw, hc, hU, hwalk⟩ := a
  obtain ⟨w', V, hw', hc', hV, hwalk'⟩ := b
  refine ⟨w ++ w', V * U, hw.append hw', fun φ => by rw [GWord.costR_append, hc, hc'],
    by rw [mul_assoc, hU, hV], fun f x => ?_⟩
  rw [gwalk_append, hwalk, hwalk', roleAct_mul]

end GStep

lemma gstep_letter (l : ρ) (M U : CMat α) (mv : GMove α ρ) (hp : mv.Proper (Fintype.card α))
    (hact : ∀ (f : ℕ) (x : Data α ρ f), mv.act f x = roleAct f l U x) :
    GStep l M (U * M) (fun φ => mv.costR φ) := by
  refine ⟨[mv], U, ?_, fun φ => ?_, rfl, fun f x => hact f x⟩
  · intro g hg
    rw [List.mem_singleton] at hg
    subst hg; exact hp
  · simp [GWord.costR]

theorem gstep_free {A : CMat α} (h : Free A) (l : ρ) (M : CMat α) :
    GStep l M (A * M) (fun _ => 0) := by
  induction h generalizing M with
  | one => rw [one_mul]; exact GStep.refl l M
  | perm G => exact gstep_letter l M _ (.perm l G) trivial (fun f x => rfl)
  | phase z c => exact gstep_letter l M _ (.phase l z c) trivial (fun f x => rfl)
  | shift z => exact gstep_letter l M _ (.old (.shift l z)) trivial (fun f x => rfl)
  | mul hA hB ihA ihB =>
    rw [mul_assoc]
    exact ((ihB M).trans (ihA _)).cast (fun φ => by simp)

theorem gstep_block (l : ρ) (M : CMat α) {rk : ℕ} (z : Fin rk → Space α)
    (ind : LinearIndependent F z) (h1 : 1 ≤ rk) (h2 : rk < Fintype.card α) :
    GStep l M (blockMat z * M) (fun φ => φ rk) :=
  gstep_letter l M _ (.old (.block l rk z ind)) ⟨h1, h2⟩ (fun f x => rfl)

theorem gstep_of_factor (l : ρ) (M : CMat α) {rk : ℕ} (z : Fin rk → Space α)
    (ind : LinearIndependent F z) {A B : CMat α} (hA : Free A) (hB : Free B)
    (h1 : 1 ≤ rk) (h2 : rk < Fintype.card α) :
    GStep l M (A * blockMat z * B * M) (fun φ => φ rk) := by
  have h := ((gstep_free hB l M).trans (gstep_block l (B * M) z ind h1 h2)).trans
    (gstep_free hA l (blockMat z * (B * M)))
  have e : A * (blockMat z * (B * M)) = A * blockMat z * B * M := by
    simp only [mul_assoc]
  rw [e] at h
  exact h.cast (fun φ => by simp)

lemma _root_.OAI.PowerSaving.Binary.OBase.xup_small (A : OBase α) (l : ρ) (c d : Finset α) (h : Disjoint c d)
    (h1 : 1 ≤ d.card) (h2 : d.card < Fintype.card α) :
    GStep l (frame A c) (frame A (c ∪ d)) (fun φ => φ d.card) := by
  refine ⟨GWord.ofB [BMove.block l d.card (A.fam d) (A.fam_indep d), BMove.shift l (A.corr d)],
    Binary.shift (A.corr d) * blockMat (A.fam d), GWord.proper_ofB ?_, ?_, ?_, ?_⟩
  · intro mv hmv
    simp only [List.mem_cons, List.not_mem_nil, or_false] at hmv
    rcases hmv with rfl|rfl
    · exact ⟨h1, h2⟩
    · trivial
  · intro φ
    rw [GWord.costR_ofB]
    simp [BWord.costR, BMove.costR, BMove.rk?]
  · rw [← A.deltas_eq, ← A.frame_union c d h]
  · intro f x
    rw [gwalk_ofB, walk_flat_cons, walk_flat_cons]
    change roleAct f l (Binary.shift (A.corr d)) (roleAct f l (blockMat (A.fam d)) x) = _
    rw [roleAct_mul]

lemma _root_.OAI.PowerSaving.Binary.OBase.xup_step (A : OBase α) (hm : 2 ≤ Fintype.card α) (l : ρ)
    (c d : Finset α) (h : Disjoint c d) :
    GStep l (frame A c) (frame A (c ∪ d))
      (fun φ => splitCost φ (Fintype.card α) d.card) := by
  by_cases h0 : d.card = 0
  · have hd : d = ∅ := Finset.card_eq_zero.mp h0
    subst hd
    rw [Finset.union_empty]
    exact (GStep.refl l _).cast (fun φ => by simp [splitCost])
  · by_cases h2 : d.card < Fintype.card α
    · exact (A.xup_small l c d h (Nat.pos_of_ne_zero h0) h2).cast
        (fun φ => by simp [splitCost, h0, h2])
    · have hfull : d.card = Fintype.card α :=
        le_antisymm (Finset.card_le_univ d) (Nat.le_of_not_lt h2)
      obtain ⟨i, hi⟩ : d.Nonempty := Finset.card_pos.mp (Nat.pos_of_ne_zero h0)
      have hcard : (d.erase i).card = Fintype.card α - 1 := by
        rw [Finset.card_erase_of_mem hi, hfull]
      have hd1 : Disjoint c (d.erase i) := h.mono_right (Finset.erase_subset i d)
      have hd2 : Disjoint (c ∪ d.erase i) {i} := by
        rw [Finset.disjoint_singleton_right, Finset.mem_union, not_or]
        exact ⟨fun hc => Finset.disjoint_left.mp h hc hi, fun he => (Finset.mem_erase.mp he).1 rfl⟩
      have e1 := A.xup_small l c (d.erase i) hd1 (by rw [hcard]; omega) (by rw [hcard]; omega)
      have e2 := A.xup_small l (c ∪ d.erase i) {i} hd2 (by simp)
        (by rw [Finset.card_singleton]; omega)
      have e := e1.trans e2
      rw [OBase.erase_union' c d i hi] at e
      refine e.cast (fun φ => ?_)
      simp only [splitCost, if_neg h0, if_neg h2, hcard, Finset.card_singleton]

end
end
end PowerSaving.GF
end OAI
