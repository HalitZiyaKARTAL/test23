import Submission.Work.G17.Geom
import Submission.Work.P4L.Seg

set_option maxHeartbeats 2000000

namespace OAI
namespace PowerSaving
namespace G17
open Binary Matrix Finset RAM SS CB RF BC GX GF

noncomputable section

section Gen
variable {H : Type} [Fintype H] [DecidableEq H] (l : H) (hH : Fintype.card H = 9)

lemma setX_mono (a : ℕ) : ∀ b, a ≤ b → b ≤ 17 → setX l a ⊆ setX l b
  | 0, hab, _ => by
    have e : a = 0 := by omega
    subst e; exact Finset.Subset.refl _
  | b + 1, hab, hb => by
    rcases Nat.lt_or_ge a (b + 1) with h | h
    · rw [(setX_succ l b (by omega)).1]
      exact (setX_mono a b (by omega) (by omega)).trans Finset.subset_union_left
    · have e : a = b + 1 := by omega
      subst e; exact Finset.Subset.refl _

include hH in
lemma card_incr (k : ℕ) (hk : k < 17) : (incr l k).card = 8 := by
  cases k with
  | zero => rw [incr_def0, card_JC, card_compl_single, hH, Finset.card_empty]
  | succ k => rw [incr_defS l k (by omega), card_JC, card_qC, Finset.card_empty, Finset.card_singleton, hH]

include hH in
lemma card_LC137 : Fintype.card (LC (Fin 16) H l) = 137 := by
  rw [card_LC, Fintype.card_fin, hH]

include hH in
lemma card_setX : ∀ k, k ≤ 17 → (setX l k).card = 1 + 8 * k
  | 0, _ => by
    show (JC {l} (∅ : Finset (Fin 16 × Hp H l))).card = 1 + 8 * 0
    rw [card_JC, Finset.card_singleton, Finset.card_empty]
  | k + 1, hk => by
    obtain ⟨e, d⟩ := setX_succ l k (by omega)
    rw [e, Finset.card_union_of_disjoint d, card_setX k (by omega), card_incr l hH k (by omega)]
    ring

include hH in
lemma card_setY : ∀ k, k ≤ 17 → (setY l k).card = 8 * k
  | 0, _ => by
    show (JC (∅ : Finset H) (∅ : Finset (Fin 16 × Hp H l))).card = 8 * 0
    rw [card_JC, Finset.card_empty, Finset.card_empty]
  | k + 1, hk => by
    obtain ⟨e, d⟩ := setY_succ l k (by omega)
    rw [e, Finset.card_union_of_disjoint d, card_setY k (by omega), card_incr l hH k (by omega)]
    ring

lemma setX_add (a n : ℕ) (h : a + n < 17) :
    setX l (a + n + 1) = setX l a ∪ ((Finset.range (n + 1)).biUnion fun j => incr l (a + j)) ∧
      Disjoint (setX l a) ((Finset.range (n + 1)).biUnion fun j => incr l (a + j)) := by
  induction n with
  | zero =>
    simp only [Nat.add_zero, zero_add, Finset.range_one, Finset.singleton_biUnion]
    exact setX_succ l a (by omega)
  | succ n ih =>
    obtain ⟨e, d⟩ := ih (by omega)
    obtain ⟨e2, d2⟩ := setX_succ l (a + n + 1) (by omega)
    have hb : (Finset.range (n + 1 + 1)).biUnion (fun j => incr l (a + j))
        = incr l (a + n + 1) ∪ (Finset.range (n + 1)).biUnion (fun j => incr l (a + j)) := by
      rw [Finset.range_add_one, Finset.biUnion_insert, show a + (n + 1) = a + n + 1 by omega]
    have hs : setX l (a + (n + 1) + 1) = setX l (a + n + 1 + 1) := rfl
    refine ⟨?_, ?_⟩
    · rw [hs, e2, e, hb, Finset.union_assoc, Finset.union_comm (incr l (a + n + 1))]
    · rw [hb, Finset.disjoint_union_right]
      exact ⟨Finset.disjoint_of_subset_left (by rw [e]; exact Finset.subset_union_left) d2, d⟩

lemma setX_eq (k : ℕ) (hk : k ≤ 17) : setX l k = setY l k ∪ {Sum.inl l} := (setX_pivot l k hk).1

lemma pivot_sub_setX (k : ℕ) (hk : k ≤ 17) : ({Sum.inl l} : Finset (LC (Fin 16) H l)) ⊆ setX l k := by
  rw [(setX_pivot l k hk).1]
  exact Finset.subset_union_right

lemma disj_incr (U : Finset (LC (Fin 16) H l)) (k : ℕ) (hk : k < 17) (hU : U ⊆ setX l k) :
    Disjoint U (incr l k) :=
  Finset.disjoint_of_subset_left hU (setX_succ l k hk).2

end Gen


end
end G17
end PowerSaving
end OAI

