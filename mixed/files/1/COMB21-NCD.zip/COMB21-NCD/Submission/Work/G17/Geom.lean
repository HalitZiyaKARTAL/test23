import Submission.Work.Bridge377.WinC

set_option maxHeartbeats 1000000

namespace OAI
namespace PowerSaving
namespace G17
open Binary Matrix Finset RAM SS CB RF BC GX GF

noncomputable section

def bs (k : ℕ) : Finset (Fin 16) := univ.filter (fun c => c.val < k)

lemma bs_zero : bs 0 = ∅ := by ext c; simp [bs]

lemma bs_succ (k : ℕ) (hk : k < 16) : bs (k + 1) = insert ⟨k, hk⟩ (bs k) := by
  ext c
  simp only [bs, Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_insert]
  constructor
  · intro h
    rcases (by omega : c.val < k ∨ c.val = k) with h' | h'
    · exact Or.inr h'
    · exact Or.inl (Fin.ext h')
  · rintro (h | h)
    · rw [h]; exact Nat.lt_succ_self k
    · exact Nat.lt_succ_of_lt h

lemma not_mem_bs (k : ℕ) (hk : k < 16) : (⟨k, hk⟩ : Fin 16) ∉ bs k := by simp [bs]

lemma mem_bs_succ (k : ℕ) (hk : k < 16) : (⟨k, hk⟩ : Fin 16) ∈ bs (k + 1) := by simp [bs]

lemma hB : 1 ≤ Fintype.card (Fin 16) := by
  first
    | exact Fintype.card_pos
    | simp
    | decide

section Sets
variable {H : Type} [Fintype H] [DecidableEq H] (l : H)

def setX : ℕ → Finset (LC (Fin 16) H l)
  | 0 => JC {l} ∅
  | k + 1 => JC univ (qC (bs k))

def setY : ℕ → Finset (LC (Fin 16) H l)
  | 0 => JC ∅ ∅
  | k + 1 => JC (univ \ {l}) (qC (bs k))

def incr : ℕ → Finset (LC (Fin 16) H l)
  | 0 => JC (univ \ {l}) ∅
  | k + 1 => if h : k < 16 then JC ∅ (qC {(⟨k, h⟩ : Fin 16)}) else ∅

lemma setX_def0 : setX l 0 = JC {l} ∅ := rfl
lemma setX_defS (k : ℕ) : setX l (k + 1) = JC univ (qC (bs k)) := rfl
lemma setY_def0 : setY l 0 = JC ∅ ∅ := rfl
lemma setY_defS (k : ℕ) : setY l (k + 1) = JC (univ \ {l}) (qC (bs k)) := rfl
lemma incr_def0 : incr l 0 = JC (univ \ {l}) ∅ := rfl
lemma incr_defS (k : ℕ) (hk : k < 16) : incr l (k + 1) = JC ∅ (qC {(⟨k, hk⟩ : Fin 16)}) := by
  simp only [incr, hk, ↓reduceDIte]

lemma JC_mem_inl (s : Finset H) (q : Finset (Fin 16 × Hp H l)) (h : H) :
    (Sum.inl h : LC (Fin 16) H l) ∈ JC s q ↔ h ∈ s := Finset.inl_mem_disjSum

lemma JC_mem_inr (s : Finset H) (q : Finset (Fin 16 × Hp H l)) (b : Fin 16 × Hp H l) :
    (Sum.inr b : LC (Fin 16) H l) ∈ JC s q ↔ b ∈ q := Finset.inr_mem_disjSum

lemma JC_qC_insert (s : Finset H) (bs : Finset (Fin 16)) (c : Fin 16) :
    JC s (qC (l := l) (insert c bs)) = JC s (qC bs) ∪ JC ∅ (qC {c}) := by
  ext x
  rcases x with h | ⟨b, j⟩
  · simp only [Finset.mem_union, JC_mem_inl, Finset.notMem_empty, or_false]
  · simp only [Finset.mem_union, JC_mem_inr, mem_qC, Finset.mem_insert, Finset.mem_singleton]
    tauto

lemma JC_qC_disj (s : Finset H) (bs : Finset (Fin 16)) (c : Fin 16) (hc : c ∉ bs) :
    Disjoint (JC s (qC (l := l) bs)) (JC ∅ (qC {c})) := by
  rw [Finset.disjoint_left]
  intro x hx hy
  rcases x with h | ⟨b, j⟩
  · rw [JC_mem_inl] at hy; exact Finset.notMem_empty h hy
  · rw [JC_mem_inr, mem_qC] at hx hy
    rw [Finset.mem_singleton] at hy
    exact hc (hy ▸ hx)

lemma JC_pivot (s : Finset H) (hs : l ∈ s) (q : Finset (Fin 16 × Hp H l)) :
    JC s q = JC (s \ {l}) q ∪ {Sum.inl l} := by
  ext x
  rcases x with h | b
  · rw [Finset.mem_union, JC_mem_inl, JC_mem_inl, Finset.mem_sdiff, Finset.mem_singleton,
      Finset.mem_singleton]
    constructor
    · intro hh
      by_cases e : h = l
      · right; rw [e]
      · left; exact ⟨hh, e⟩
    · rintro (⟨hh, -⟩ | e)
      · exact hh
      · cases e; exact hs
  · rw [Finset.mem_union, JC_mem_inr, JC_mem_inr, Finset.mem_singleton]
    constructor
    · intro hb; exact Or.inl hb
    · rintro (hb | e)
      · exact hb
      · cases e

lemma JC_pivot_disj (s : Finset H) (q : Finset (Fin 16 × Hp H l)) :
    Disjoint (JC (s \ {l}) q) {Sum.inl l} := by
  rw [Finset.disjoint_singleton_right, JC_mem_inl, Finset.mem_sdiff, Finset.mem_singleton]
  exact fun h => h.2 rfl

lemma JC_univ_split : JC (univ : Finset H) (∅ : Finset (Fin 16 × Hp H l)) = JC {l} ∅ ∪ JC (univ \ {l}) ∅ := by
  ext x
  rcases x with h | b
  · rw [Finset.mem_union, JC_mem_inl, JC_mem_inl, JC_mem_inl, Finset.mem_singleton, Finset.mem_sdiff,
      Finset.mem_singleton]
    constructor
    · intro _
      by_cases e : h = l
      · exact Or.inl e
      · exact Or.inr ⟨Finset.mem_univ h, e⟩
    · intro _; exact Finset.mem_univ h
  · rw [Finset.mem_union, JC_mem_inr, JC_mem_inr, JC_mem_inr]
    simp

lemma JC_univ_split_disj : Disjoint (JC {l} (∅ : Finset (Fin 16 × Hp H l))) (JC (univ \ {l}) ∅) := by
  rw [Finset.disjoint_left]
  intro x hx hy
  rcases x with h | b
  · rw [JC_mem_inl, Finset.mem_singleton] at hx
    rw [JC_mem_inl, Finset.mem_sdiff, Finset.mem_singleton] at hy
    exact hy.2 hx
  · rw [JC_mem_inr] at hx; exact Finset.notMem_empty b hx

lemma JC_empty_split : JC (∅ : Finset H) (∅ : Finset (Fin 16 × Hp H l)) ∪ JC (univ \ {l}) ∅ = JC (univ \ {l}) ∅ := by
  ext x
  rcases x with h | b
  · rw [Finset.mem_union, JC_mem_inl, JC_mem_inl]
    simp
  · rw [Finset.mem_union, JC_mem_inr, JC_mem_inr]
    simp

lemma JC_empty_disj : Disjoint (JC (∅ : Finset H) (∅ : Finset (Fin 16 × Hp H l))) (JC (univ \ {l}) ∅) := by
  rw [Finset.disjoint_left]
  intro x hx _
  rcases x with h | b
  · rw [JC_mem_inl] at hx; exact Finset.notMem_empty h hx
  · rw [JC_mem_inr] at hx; exact Finset.notMem_empty b hx

lemma setX_succ (k : ℕ) (hk : k < 17) :
    setX l (k + 1) = setX l k ∪ incr l k ∧ Disjoint (setX l k) (incr l k) := by
  cases k with
  | zero =>
    rw [setX_defS, setX_def0, incr_def0, bs_zero, qC_empty]
    exact ⟨JC_univ_split l, JC_univ_split_disj l⟩
  | succ k =>
    have hk' : k < 16 := by omega
    rw [setX_defS, setX_defS, incr_defS l k hk', bs_succ k hk']
    exact ⟨JC_qC_insert l _ (bs k) ⟨k, hk'⟩, JC_qC_disj l _ (bs k) ⟨k, hk'⟩ (not_mem_bs k hk')⟩

lemma setY_succ (k : ℕ) (hk : k < 17) :
    setY l (k + 1) = setY l k ∪ incr l k ∧ Disjoint (setY l k) (incr l k) := by
  cases k with
  | zero =>
    rw [setY_defS, setY_def0, incr_def0, bs_zero, qC_empty]
    exact ⟨(JC_empty_split l).symm, JC_empty_disj l⟩
  | succ k =>
    have hk' : k < 16 := by omega
    rw [setY_defS, setY_defS, incr_defS l k hk', bs_succ k hk']
    exact ⟨JC_qC_insert l _ (bs k) ⟨k, hk'⟩, JC_qC_disj l _ (bs k) ⟨k, hk'⟩ (not_mem_bs k hk')⟩

lemma setX_pivot (k : ℕ) (hk : k ≤ 17) :
    setX l k = setY l k ∪ {Sum.inl l} ∧ Disjoint (setY l k) {Sum.inl l} := by
  cases k with
  | zero =>
    rw [setX_def0, setY_def0]
    refine ⟨?_, ?_⟩
    · have h := JC_pivot l {l} (Finset.mem_singleton_self l) ∅
      rw [Finset.sdiff_self] at h
      exact h
    · have h := JC_pivot_disj l {l} ∅
      rw [Finset.sdiff_self] at h
      exact h
  | succ k =>
    rw [setX_defS, setY_defS]
    exact ⟨JC_pivot l univ (Finset.mem_univ l) _, JC_pivot_disj l univ _⟩

end Sets

section Frames
variable {H T : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  (base : T → OBase H) (l : H)

def gaugeE : ℕ → T → Orth (LC (Fin 16) H l) ≃ Orth (LC (Fin 16) H l)
  | 0 => fun _ => Equiv.refl _
  | k + 1 => fun t => if h : k < 16 then RrC (base t) l (⟨k, h⟩ : Fin 16) else Equiv.refl _

lemma gaugeE_zero (t : T) : gaugeE base l 0 t = Equiv.refl _ := rfl

lemma gaugeE_succ (k : ℕ) (hk : k < 16) (t : T) : gaugeE base l (k + 1) t = RrC (base t) l (⟨k, hk⟩ : Fin 16) := by
  simp only [gaugeE, hk, ↓reduceDIte]

end Frames

section Win
variable {H : Type} [Fintype H] [DecidableEq H]

def winN (l : H) (hH : Fintype.card H = 9) (n : ℕ) (d : Orth (LC (Fin 16) H l)) : GWin H (LC (Fin 16) H l) :=
  gwinC hB (by omega) d (qC (bs n))

lemma winN_Φ (l : H) (hH : Fintype.card H = 9) (n : ℕ) (d : Orth (LC (Fin 16) H l)) (M : Matrix H H F) :
    (winN l hH n d).Xm.Φ M = PhiC d (qC (bs n)) M := rfl

end Win

section Stages
variable {H T : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  (base : T → OBase H) (l : H) (hH : Fintype.card H = 9)

lemma stage_Xin (k : ℕ) (hk : k ≤ 16) (t : T) (g : Orth (LC (Fin 16) H l)) :
    (winN l hH k (gaugeE base l k t g)).Xm.Φ (tt ((base t).v l)) = frame (BBC (base t) l g) (setX l k) := by
  rw [winN_Φ]
  cases k with
  | zero =>
    rw [gaugeE_zero, Equiv.refl_apply, bs_zero, qC_empty, setX_def0]
    exact classT_X0 (base t) l g
  | succ k =>
    have hk' : k < 16 := by omega
    rw [gaugeE_succ base l k hk', bs_succ k hk', setX_defS]
    have e := bank_inX (base t) l (bs k) (⟨k, hk'⟩ : Fin 16) (not_mem_bs k hk') g
    rw [mat_single] at e
    exact e

lemma stage_Xout (k : ℕ) (hk : k ≤ 16) (t : T) (g : Orth (LC (Fin 16) H l)) :
    (winN l hH k (gaugeE base l k t g)).Xm.Φ 1 = frame (BBC (base t) l g) (setX l (k + 1)) := by
  rw [winN_Φ, setX_defS]
  cases k with
  | zero =>
    rw [gaugeE_zero, Equiv.refl_apply]
    have e := PhiC_BBC (base t) l g (qC (bs 0)) univ
    rw [OBase.mat_univ] at e
    exact e
  | succ k =>
    have hk' : k < 16 := by omega
    rw [gaugeE_succ base l k hk']
    exact classT_X (base t) l (bs (k + 1)) (⟨k, hk'⟩ : Fin 16) (mem_bs_succ k hk') g

lemma stage_Yin (k : ℕ) (hk : k ≤ 16) (t : T) (g : Orth (LC (Fin 16) H l)) :
    (winN l hH k (gaugeE base l k t g)).Xm.Φ 0 = frame (BBC (base t) l g) (setY l k) := by
  rw [winN_Φ]
  cases k with
  | zero =>
    rw [gaugeE_zero, Equiv.refl_apply, bs_zero, qC_empty, setY_def0]
    exact classT_Y0 (base t) l g
  | succ k =>
    have hk' : k < 16 := by omega
    rw [gaugeE_succ base l k hk', bs_succ k hk', setY_defS]
    have e := bank_inY (base t) l (bs k) (⟨k, hk'⟩ : Fin 16) (not_mem_bs k hk') g
    rw [mat_empty] at e
    exact e

lemma stage_Yout (k : ℕ) (hk : k ≤ 16) (t : T) (g : Orth (LC (Fin 16) H l)) :
    (winN l hH k (gaugeE base l k t g)).Xm.Φ (1 + tt ((base t).v l)) = frame (BBC (base t) l g) (setY l (k + 1)) := by
  rw [winN_Φ, setY_defS]
  cases k with
  | zero =>
    rw [gaugeE_zero, Equiv.refl_apply]
    have e := PhiC_BBC (base t) l g (qC (bs 0)) (univ \ {l})
    rw [mat_compl_single] at e
    exact e
  | succ k =>
    have hk' : k < 16 := by omega
    rw [gaugeE_succ base l k hk']
    exact classT_Y (base t) l (bs (k + 1)) (⟨k, hk'⟩ : Fin 16) (mem_bs_succ k hk') g

end Stages

end
end G17
end PowerSaving
end OAI

