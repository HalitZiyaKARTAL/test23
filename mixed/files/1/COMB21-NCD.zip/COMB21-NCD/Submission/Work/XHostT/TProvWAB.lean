import Submission.Work.KLowW.ShearAB
import Submission.Work.KLowW.InvAB
import Submission.Work.BlockApply.Exact
import Submission.Work.GFrame.Engine.Route
import Submission.Work.GCert.Chain.Win
import Submission.Work.Bridge.Net
import Submission.Work.GFrame.Top.Stage
import Submission.Work.Gauge.Defs
import Submission.Work.Combine.XG
import Submission.Work.XHost.Frames
import Submission.Work.BridgeC.Stage
import Submission.Work.GCert.Data.Raw
import Submission.Work.SharedSumChecker.Check
import Submission.Work.Combine.Ranks
import Submission.Work.SharedSumStructured.Invocation
import Submission.Work.SharedSumChecker.Mats
import Submission.Work.Gauge.Labels
import Submission.Work.GFrame.Labels.Calc
import Submission.Work.Bridge.Inv

namespace PWG
open OAI.PowerSaving OAI.PowerSaving.SS KLW GLab

variable {v R nc : Nat}

def embB (v R nc : Nat) : Box (Fin v) (Fin R) (Fin nc) → Nat :=
  stamp (fun t => t.val) (fun t => v + t.val) (fun q => 2 * v + q.val) (fun k => 2 * v + R + k.val)

def unB (v R nc : Nat) (hc : 0 < nc) (r : Nat) : Box (Fin v) (Fin R) (Fin nc) :=
  if h1 : r < v then bX ⟨r, h1⟩
  else if h2 : r < 2 * v then bY ⟨r - v, by omega⟩
  else if h3 : r < 2 * v + R then bS ⟨r - 2 * v, by omega⟩
  else if h4 : r < 2 * v + R + nc then bC ⟨r - (2 * v + R), by omega⟩
  else bC ⟨0, hc⟩

theorem unB_embB (hc : 0 < nc) (j : Box (Fin v) (Fin R) (Fin nc)) : unB v R nc hc (embB v R nc j) = j := by
  rcases j with ((t | t) | (q | k))
  · have ht := t.isLt
    show unB v R nc hc t.val = bX t
    unfold unB
    rw [dif_pos ht]
  · have ht := t.isLt
    show unB v R nc hc (v + t.val) = bY t
    unfold unB
    rw [dif_neg (show ¬ (v + t.val < v) by omega), dif_pos (show v + t.val < 2 * v by omega)]
    exact congrArg bY (Fin.ext (Nat.add_sub_cancel_left _ _))
  · have hq := q.isLt
    show unB v R nc hc (2 * v + q.val) = bS q
    unfold unB
    rw [dif_neg (show ¬ (2 * v + q.val < v) by omega), dif_neg (show ¬ (2 * v + q.val < 2 * v) by omega),
      dif_pos (show 2 * v + q.val < 2 * v + R by omega)]
    exact congrArg bS (Fin.ext (Nat.add_sub_cancel_left _ _))
  · have hk := k.isLt
    show unB v R nc hc (2 * v + R + k.val) = bC k
    unfold unB
    rw [dif_neg (show ¬ (2 * v + R + k.val < v) by omega), dif_neg (show ¬ (2 * v + R + k.val < 2 * v) by omega),
      dif_neg (show ¬ (2 * v + R + k.val < 2 * v + R) by omega),
      dif_pos (show 2 * v + R + k.val < 2 * v + R + nc by omega)]
    exact congrArg bC (Fin.ext (Nat.add_sub_cancel_left _ _))

theorem embB_unB (hc : 0 < nc) (r : Nat) (hr : r < 2 * v + R + nc) : embB v R nc (unB v R nc hc r) = r := by
  unfold unB
  split_ifs with h1 h2 h3
  · rfl
  · show v + (r - v) = r
    omega
  · show 2 * v + (r - 2 * v) = r
    omega
  · show 2 * v + R + (r - (2 * v + R)) = r
    omega

theorem embB_lt (j : Box (Fin v) (Fin R) (Fin nc)) : embB v R nc j < 2 * v + R + nc := by
  rcases j with ((t | t) | (q | k))
  · show t.val < _
    have := t.isLt
    omega
  · show v + t.val < _
    have := t.isLt
    omega
  · show 2 * v + q.val < _
    have := q.isLt
    omega
  · show 2 * v + R + k.val < _
    have := k.isLt
    omega

end PWG


namespace KLW
open SSC GXD GLab OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.GF OAI.PowerSaving.RAM
  OAI.PowerSaving.SS OAI.PowerSaving.CB OAI.PowerSaving.BR OAI.PowerSaving.GX OAI.PowerSaving.XEX
  OAI.PowerSaving.B401 Finset Matrix

section
variable {H T Sl C : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C]

structure GInvEAB (H T Sl C : Type) [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
    [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C]
    (Ok : ∀ {α : Type} [Fintype α] [DecidableEq α], GWin H α → Prop) where
  tv : T → Space H
  hunit : ∀ t, dot (tv t) (tv t) = 1
  hgap : ∀ t, ∃ p, tv t p = 0
  cost : (ℕ → ℝ) → ℝ
  ent : Sl → SLbl H
  al : T → ℚ
  be : T → ℚ
  run : ∀ {α : Type} [Fintype α] [DecidableEq α] (W : GWin H α), Ok W → ∀ (N Wn : Sl → CMat α),
    (∀ q, W.X.Φ (ent q) * N q = 1) → (∀ q, W.X.Φ (ent q).top = Wn q * W.X.Φ (ent q)) →
    ∀ (Z : Sl → CMat α) (c0 c1 : C → CMat α),
    GRoute (iin W.Xm tv Z c0) (iout W.Xm tv (fun q => Wn q * Z q) c1) (shearAB al be) cost

variable {Ok : ∀ {α : Type} [Fintype α] [DecidableEq α], GWin H α → Prop}

def GInvAB.toEW (I : GInvAB H T Sl C Ok) (ent' : Sl → SLbl H)
    (hd : ∀ q, Fintype.card H - (ent' q).dim = (I.ex q).dim - (I.ent q).dim) : GInvEAB H T Sl C Ok where
  tv := I.tv
  hunit := I.hunit
  hgap := I.hgap
  cost := I.cost
  ent := ent'
  al := I.al
  be := I.be
  run := fun W hOk N Wn hN hW Z c0 c1 =>
    exRouteE I.ent I.ex I.hexG I.hexs ent' hd W (fun N Wn hN hW Z c0 c1 => I.run W hOk N Wn hN hW Z c0 c1) N Wn hN hW Z c0 c1

noncomputable def GInvAB.entS (I : GInvAB H T Sl C Ok) (q : Sl) : SLbl H :=
  exEntS I.ent I.ex q

lemma GInvAB.entS_hd (I : GInvAB H T Sl C Ok) (q : Sl) :
    Fintype.card H - (I.entS q).dim = (I.ex q).dim - (I.ent q).dim :=
  exEntS_hd I.ent I.ex q

noncomputable def GInvAB.toEW' (I : GInvAB H T Sl C Ok) : GInvEAB H T Sl C Ok := I.toEW I.entS I.entS_hd

end

theorem rolesAB (c : WCert) {ab : Nat → Int × Int × Int} (V : WValidAB c ab) (hd : c.p.n ≤ 2 ^ c.p.d)
    (hc : 0 < c.nc) : WRoles c (PWG.embB c.v c.R c.nc) (PWG.unB c.v c.R c.nc hc) where
  C :=
    { hT := V.tab
      hn := hd
      hun := PWG.unB_embB hc
      hin := fun r hr => PWG.embB_unB hc r (by rw [V.hn] at hr; exact hr)
      hlt := fun j => by rw [V.hn]; exact PWG.embB_lt j }
  num :=
    { hx := fun _ => rfl
      hy := fun _ => rfl
      hs := fun _ => rfl
      hc := fun k => by
        show 2 * c.v + c.R ≤ 2 * c.v + c.R + k.val
        omega }

section
variable {c : WCert} {ab : Nat → Int × Int × Int} {emb : Box (Fin c.v) (Fin c.R) (Fin c.nc) → Nat}
  {un : Nat → Box (Fin c.v) (Fin c.R) (Fin c.nc)}

theorem resAB (V : WValidAB c ab) (Ro : WRoles c emb un) (q : Fin c.R) :
    (c.exq emb q).dim - (c.ent emb q).dim
      = Bool.rec (motive := fun _ => Nat) (c.p.h - cdim (c.p.tab.get (c.S0.get (2 * c.v + q.val))))
          (cdim (c.p.tab.get (c.SF.get (2 * c.v + q.val))) - cdim (c.p.tab.get (c.S0.get (2 * c.v + q.val))))
          (memK (2 * c.v + q.val) c.el) := by
  have hU : (c.L emb c.S0 (CR.lS q)).dim = cdim (c.p.tab.get (c.S0.get (2 * c.v + q.val))) := by
    show (GLab.lab c.p.h (c.p.tab.get (c.S0.get (emb (bS q))))).dim = _
    rw [Ro.num.hs q, V.dim]
  have hV : (c.L emb c.SF (CR.lS q)).dim = cdim (c.p.tab.get (c.SF.get (2 * c.v + q.val))) := by
    show (GLab.lab c.p.h (c.p.tab.get (c.SF.get (emb (bS q))))).dim = _
    rw [Ro.num.hs q, V.dim]
  unfold WCert.exq WCert.ent
  cases hm : memK (2 * c.v + q.val) c.el with
  | false =>
    have hq : q ∉ c.exits := fun h => by
      have := (Finset.mem_filter.mp h).2; rw [hm] at this; exact Bool.false_ne_true this
    rw [if_neg hq, SLbl.top_dim, Fintype.card_fin, XEX.lab0X_nE _ _ _ hq, hU]
  | true =>
    have hq : q ∈ c.exits := Finset.mem_filter.mpr ⟨Finset.mem_univ _, hm⟩
    rw [if_pos hq, XEX.lab0X_E _ _ _ hq, XEX.exlA_dim _ _ (V.hsub Ro q hq), XEX.entA_dim _ _ (V.hsub Ro q hq),
      hU, hV]

end
end KLW


set_option maxHeartbeats 4000000
namespace OAI
namespace PowerSaving
namespace XHostTW
open Binary Matrix Finset RAM SS CB RF BR GF GX BC B401 XHost
noncomputable section

abbrev GInvWAB (H T Sl C : Type) [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
    [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C]
    (Ok : ∀ {α : Type} [Fintype α] [DecidableEq α], GWin H α → Prop) :=
  KLW.GInvEAB H T Sl C Ok

section Prov
variable {H T Sl C : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C]
variable {Ok : ∀ {α : Type} [Fintype α] [DecidableEq α], GWin H α → Prop}

def GInvWAB.ofEAB (I : KLW.GInvEAB H T Sl C Ok) : GInvWAB H T Sl C Ok := I

end Prov

section Stage
variable {Γ T Sl C : Type}

def GAB (al be : T → ℚ) (x : SRole Γ T Sl C → ℂ) : SRole Γ T Sl C → ℂ :=
  mkS (fun g t => x (jX (g, t)) + (al t : ℂ) * x (jY (g, t)))
    (fun g t => (be t : ℂ) * x (jX (g, t)) + (1 + (al t : ℂ) * (be t : ℂ)) * x (jY (g, t)))
    (fun g q => x (jS (g, q))) (fun _ _ => 0)

end Stage

section ProvStage
variable {H T Sl C : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C]
variable {Ok : ∀ {α : Type} [Fintype α] [DecidableEq α], GWin H α → Prop}
variable {α Γ : Type} [Fintype α] [DecidableEq α] [Fintype Γ] [DecidableEq Γ] (I : GInvWAB H T Sl C Ok)

theorem gistageW_ab (εX : T → Γ ≃ Γ) (M : Γ → GWin H α) (hok : ∀ d, Ok (M d)) (N Wn : Γ → Sl → CMat α)
    (hN : ∀ d q, (M d).X.Φ (I.ent q) * N d q = 1)
    (hW : ∀ d q, (M d).X.Φ (I.ent q).top = Wn d q * (M d).X.Φ (I.ent q))
    (Z : Γ → Sl → CMat α) (c0 c1 : Γ → C → CMat α) :
    GRoute (bIn I.tv εX (fun d => (M d).Xm) Z c0)
      (bOut I.tv εX (fun d => (M d).Xm) (fun g q => Wn g q * Z g q) c1)
      (GAB I.al I.be) (fun φ => (Fintype.card Γ : ℝ) * I.cost φ) := by
  refine gsstage εX (Equiv.refl Γ) (h := KLW.shearAB I.al I.be) (cost := I.cost) (fun d => ?_) (fun d x => ?_)
  · rw [bIn_sem, bOut_sem]
    exact I.run (M d) (hok d) (N d) (Wn d) (hN d) (hW d) _ _ _
  · funext b
    rcases b with ((t|t)|(q|k)) <;> rfl

end ProvStage

end
end XHostTW
end PowerSaving
end OAI

