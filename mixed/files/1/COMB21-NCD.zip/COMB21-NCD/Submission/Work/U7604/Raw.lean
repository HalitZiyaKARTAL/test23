import Submission.Work.U7604.Roles
import Submission.Work.U7604.Segs
import Submission.Work.U7604.SegsA
import Submission.Work.U7604.SegsB
import Submission.Work.U7604.RawLists

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option maxHeartbeats 4000000

namespace OAI.PowerSaving.U7604
open Binary Matrix Finset RAM SS CB RF BC GX GF P4L CtrlAB CtrlAB.UnitAB

noncomputable section

def aOf : Rl → OBase Lb
  | .inl (g, _, c) => Ab g c
  | .inr _ => OBase.canonical _
def pv : Lb := Sum.inl 0
def vP (r : Rl) : Space Lb := (aOf r).v pv

abbrev gG (κ : Bool) (r z : Rg) (u₁ u₂ v₁ v₂ : ℚ) : ∀ f : ℕ, Dat f → Dat f := gGop κ r z u₁ u₂ v₁ v₂
def shU (r : Rl) : CMat Lb := Binary.shift (vP r)
def thU (r : Rl) : CMat Lb := Binary.shift (vP r + (aOf r).corr {pv}) * blockMat ((aOf r).fam {pv})
def wS (b : Bool) (a : ℕ) : Finset Lb := if b then G17.setY (0 : Fin 9) a else G17.setX (0 : Fin 9) a
def wB (b : Bool) (a m : ℕ) (r : Rl) : CMat Lb :=
  (if b then Binary.shift (vP r) else 1) * frame (aOf r) (G17.setX (0 : Fin 9) (a + m + 1))
def wU (b : Bool) (a m : ℕ) (r : Rl) : CMat Lb := wB b a m r * unframe (aOf r) (wS b a)

def opS : Sg → ∀ f, Dat f → Dat f
  | .jc _ => fun _ y => y
  | .add κ t s ng n d => gOp (gAdd κ (.inl t) (.inl s) (KLW.sgnQ ng n d))
  | .mul κ r ng n d => gOp (gMul κ (.inl r) (KLW.sgnQ ng n d))
  | .swp κ a b => gOp (gSwp κ (.inl a) (.inl b))
  | .lam κ r e => fun f y => (if e then gG κ (.inl r) (.inr 0) (1/2) (1/2) (1/2) (-1/2)
      else gG κ (.inl r) (.inr 0) (1/2) (-1/2) (1/2) (1/2)) f
      (onS (mS κ (.inr 0)) shU f (gOp (gLin κ (.inr 0) (.inl r) 0 1 1) f y))
  | .qsh κ r => onS (mS κ (.inl r)) shU
  | .thin κ j t s => fun f y => gOp (gAdd κ (.inl t) (.inr j) 1) f
      (onS (mS κ (.inr j)) thU f (gOp (gLin κ (.inr j) (.inl s) 0 1 1) f y))
  | .idle κ r a m => onS (mS κ (.inl r)) (wU false a m)
  | .idlq κ r a m => onS (mS κ (.inl r)) (wU true a m)

lemma card137 : Fintype.card Lb = 137 := G17.card_LC137 (0 : Fin 9) (Fintype.card_fin 9)
lemma cX (k : ℕ) (hk : k ≤ 17) : (G17.setX (0 : Fin 9) k).card = 1 + 8 * k := G17.card_setX (0 : Fin 9) (Fintype.card_fin 9) k hk
lemma cY (k : ℕ) (hk : k ≤ 17) : (G17.setY (0 : Fin 9) k).card = 8 * k := G17.card_setY (0 : Fin 9) (Fintype.card_fin 9) k hk

lemma sum_mS (κ : Bool) (X : Rg) (x : ℝ) : ∑ _r ∈ mS κ X, x = (Fintype.card Γ : ℝ) * (nK κ * x) := by
  rw [sum_const, card_mS, nsmul_eq_mul]; push_cast; ring

lemma route_gGk (κ : Bool) (r z : Rg) (u₁ u₂ v₁ v₂ : ℚ) : ORoute (gG κ r z u₁ u₂ v₁ v₂) (fun _ => 0) :=
  route_gG _ _

lemma route_w (b : Bool) (κ : Bool) (X : Rg) (a m : ℕ) (h : a + m < 17) (hb : b = true → 1 ≤ a) :
    ORoute (onS (mS κ X) (wU b a m)) (fun φ => (Fintype.card Γ : ℝ) * (nK κ * φ (8 * (m + 1) + if b then 1 else 0))) := by
  refine (route_onS' (mS κ X) (fun r => frame (aOf r) (wS b a)) (fun r => unframe (aOf r) (wS b a)) (wB b a m)
    (fun r _ => frame_mul_unframe _ _) (fun _ φ => bcost φ (8 * (m + 1) + if b then 1 else 0)) (fun r _ => ?_)).cast
    (fun f y => rfl) (fun φ => ?_)
  · have hsub : wS b a ⊆ G17.setX (0 : Fin 9) (a + m + 1) := by
      cases b
      · exact G17.setX_mono (0 : Fin 9) a (a + m + 1) (by omega) (by omega)
      · simp only [wS, if_true]
        exact (Finset.subset_union_left).trans ((G17.setX_eq (0 : Fin 9) a (by omega)).symm ▸
          G17.setX_mono (0 : Fin 9) a (a + m + 1) (by omega) (by omega)) -- CHECK
    have hk : (8 * (m + 1) + if b then 1 else 0) + (wS b a).card = (G17.setX (0 : Fin 9) (a + m + 1)).card := by
      cases b <;> simp only [wS, if_true, if_false, Bool.false_eq_true] <;>
        [rw [cX a (by omega), cX _ (by omega)]; rw [cY a (by omega), cX _ (by omega)]] <;> ring_nf <;> omega
    have hs : 1 ≤ (wS b a).card := by
      cases b
      · simp only [wS, Bool.false_eq_true, if_false]; rw [cX a (by omega)]; omega
      · simp only [wS, if_true]; rw [cY a (by omega)]; have := hb rfl; omega
    have hr := (GReach.ofX (reach_of_pos (by rw [card137]; norm_num) (aOf r) hsub _ hk hs)) _ r
    cases b
    · simpa [wB] using hr
    · exact gstep_shiftR hr _
  · rw [sum_mS]; congr 2
    rw [bcost, if_neg (by omega)]

lemma route_th (κ : Bool) (j : Fin 4) : ORoute (onS (mS κ (.inr j)) thU) (fun φ => (Fintype.card Γ : ℝ) * (nK κ * φ 1)) := by
  refine (route_onS (mS κ (.inr j)) thU (fun _ φ => φ 1) (fun r _ => ?_)).cast (fun f y => rfl) (fun φ => sum_mS _ _ _)
  have h := gstep_of_factor r (1 : CMat Lb) ((aOf r).fam {pv}) ((aOf r).fam_indep _)
    (Free.shift (vP r + (aOf r).corr {pv})) Free.one (by simp) (by simp [card137])
  simp only [Matrix.mul_one, Finset.card_singleton] at h
  exact h

lemma route_sh (κ : Bool) (X : Rg) : ORoute (onS (mS κ X) shU) (fun _ => 0) :=
  (route_onS (mS κ X) shU (fun _ _ => 0) (fun r _ => gstep_shift r _)).cast (fun f y => rfl) (fun φ => by simp)

lemma lc_nil (φ : ℕ → ℝ) : listCost φ [] = 0 := by rw [listCost, List.map_nil, List.sum_nil]
lemma lc_one (φ : ℕ → ℝ) (b : ℕ × ℕ) : listCost φ [b] = (b.2 : ℝ) * φ b.1 := by
  rw [listCost, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil, add_zero]

theorem route_S (s : Sg) (hs : ∀ k, s ≠ .jc k) (hw : okS s = true) :
    ORoute (opS s) (fun φ => (Fintype.card Γ : ℝ) * listCost φ s.blk) := by
  -- every route is built with its matrices EXPLICIT, then cast to `opS s` by `simp only [opS]` (no rfl through gOp)
  cases s with
  | jc k => exact absurd rfl (hs k)
  | add κ t s ng n d =>
    have R := route_gM (gAdd κ (.inl t) (.inl s) (KLW.sgnQ ng n d))
    exact R.cast (fun f y => by simp only [opS]) (fun φ => by
      show (0 : ℝ) = _; rw [show Sg.blk (.add κ t s ng n d) = [] from rfl, lc_nil, mul_zero])
  | mul κ r ng n d =>
    have R := route_gM (gMul κ (.inl r) (KLW.sgnQ ng n d))
    exact R.cast (fun f y => by simp only [opS]) (fun φ => by
      show (0 : ℝ) = _; rw [show Sg.blk (.mul κ r ng n d) = [] from rfl, lc_nil, mul_zero])
  | swp κ a b =>
    have R := route_gM (gSwp κ (.inl a) (.inl b))
    exact R.cast (fun f y => by simp only [opS]) (fun φ => by
      show (0 : ℝ) = _; rw [show Sg.blk (.swp κ a b) = [] from rfl, lc_nil, mul_zero])
  | lam κ r e =>
    cases e
    · have R := ((route_gM (gLin κ (.inr 0) (.inl r) 0 1 1)).trans (route_sh κ (.inr 0))).trans
        (route_gGk κ (.inl r) (.inr 0) (1/2) (-1/2) (1/2) (1/2))
      exact R.cast (fun f y => by simp only [opS, Bool.false_eq_true, ↓reduceIte]) (fun φ => by
        show (0 : ℝ) + 0 + 0 = _
        rw [show Sg.blk (.lam κ r false) = [] from rfl, lc_nil, mul_zero, add_zero, add_zero])
    · have R := ((route_gM (gLin κ (.inr 0) (.inl r) 0 1 1)).trans (route_sh κ (.inr 0))).trans
        (route_gGk κ (.inl r) (.inr 0) (1/2) (1/2) (1/2) (-1/2))
      exact R.cast (fun f y => by simp only [opS, ↓reduceIte]) (fun φ => by
        show (0 : ℝ) + 0 + 0 = _
        rw [show Sg.blk (.lam κ r true) = [] from rfl, lc_nil, mul_zero, add_zero, add_zero])
  | qsh κ r =>
    have R := route_sh κ (.inl r)
    exact R.cast (fun f y => by simp only [opS]) (fun φ => by
      show (0 : ℝ) = _; rw [show Sg.blk (.qsh κ r) = [] from rfl, lc_nil, mul_zero])
  | thin κ j t s =>
    have R := ((route_gM (gLin κ (.inr j) (.inl s) 0 1 1)).trans (route_th κ j)).trans
      (route_gM (gAdd κ (.inl t) (.inr j) 1))
    exact R.cast (fun f y => by simp only [opS]) (fun φ => by
      show (0 : ℝ) + (Fintype.card Γ : ℝ) * (nK κ * φ 1) + 0 = _
      rw [show Sg.blk (.thin κ j t s) = [(1, nK κ)] from rfl, lc_one, zero_add, add_zero])
  | idle κ r a m =>
    simp only [okS] at hw
    have R := route_w false κ (.inl r) a m (by simpa using hw) (fun h => absurd h Bool.false_ne_true)
    exact R.cast (fun f y => by simp only [opS]) (fun φ => by
      show (Fintype.card Γ : ℝ) * (nK κ * φ (8 * (m + 1) + if false = true then 1 else 0)) = _
      rw [show Sg.blk (.idle κ r a m) = [(8 * (m + 1), nK κ)] from rfl, lc_one, if_neg Bool.false_ne_true, add_zero])
  | idlq κ r a m =>
    simp only [okS, Bool.and_eq_true, decide_eq_true_eq] at hw
    have R := route_w true κ (.inl r) a m hw.1 (fun _ => hw.2)
    exact R.cast (fun f y => by simp only [opS]) (fun φ => by
      show (Fintype.card Γ : ℝ) * (nK κ * φ (8 * (m + 1) + if true = true then 1 else 0)) = _
      rw [show Sg.blk (.idlq κ r a m) = [(8 * (m + 1) + 1, nK κ)] from rfl, lc_one, if_pos rfl])

def FixC (κ : Bool) (op : ∀ f, Dat f → Dat f) : Prop :=
  ∀ f (y : Dat f) r, (∀ g X c, r = .inl (g, X, c) → cl c ≠ κ) → op f y r = y r

lemma fix_lin (κ : Bool) {r z : Rg} {u v : ℚ} : FixC κ (gOp (gLin κ r z u v 1)) := fun f y r' hr => fixLin f y r' hr
lemma fix_add (κ : Bool) {t s : Rg} {v : ℚ} : FixC κ (gOp (gAdd κ t s v)) := fun f y r' hr => by
  rw [gAdd_eq]; exact fixLin f y r' hr
lemma fix_mul (κ : Bool) {r : Rg} {v : ℚ} : FixC κ (gOp (gMul κ r v)) := fun f y r' hr => by
  rw [gMul_eq]; exact fixLin f y r' hr
lemma fix_swp (κ : Bool) {a b : Rg} : FixC κ (gOp (gSwp κ a b)) := fun f y r' hr => fixSwp f y r' hr

lemma fix_gG (κ : Bool) (r z : Rg) (u₁ u₂ v₁ v₂ : ℚ) : FixC κ (gG κ r z u₁ u₂ v₁ v₂) := fun f y r' hr => by
  exact gG_off f y r' hr

lemma fix_on (κ : Bool) (X : Rg) (U : Rl → CMat Lb) : FixC κ (onS (mS κ X) U) := fun f y r hr => by
  simp only [onS]
  rw [if_neg]
  intro hm
  obtain ⟨g, c, h, rfl⟩ := mem_mS.mp hm
  exact hr g X c rfl h

lemma fix_comp {κ : Bool} {op op' : ∀ f, Dat f → Dat f} (h : FixC κ op) (h' : FixC κ op') :
    FixC κ (fun f y => op' f (op f y)) := fun f y r hr => (h' f (op f y) r hr).trans (h f y r hr)

def Sg.k : Sg → Bool
  | .jc _ => true | .add κ .. => κ | .mul κ .. => κ | .swp κ .. => κ | .lam κ .. => κ | .qsh κ .. => κ
  | .thin κ .. => κ | .idle κ .. => κ | .idlq κ .. => κ

theorem fix_S (s : Sg) (hs : ∀ k, s ≠ .jc k) : FixC s.k (opS s) := by
  cases s with
  | jc k => exact absurd rfl (hs k)
  | add => exact fix_add _
  | mul => exact fix_mul _
  | swp => exact fix_swp _
  | lam κ r e =>
    intro f y r' hr
    cases e <;> simp only [opS, Bool.false_eq_true, if_false, if_true] <;>
      rw [fix_gG κ _ _ _ _ _ _ f _ r' hr, fix_on κ _ _ f _ r' hr, fix_lin κ f y r' hr]
  | qsh => exact fix_on _ _ _
  | thin κ j t s =>
    intro f y r' hr
    simp only [opS]
    rw [fix_add κ f _ r' hr, fix_on κ _ _ f _ r' hr, fix_lin κ f y r' hr]
  | idle => exact fix_on _ _ _
  | idlq => exact fix_on _ _ _

section View
variable (f : ℕ) (g : Γ) (c : Cp)

lemma V_at (y : Dat f) (i : Fin 36) : V f g c y i.val = walsh f (y (mR g i c)) := dif_pos i.2

lemma V_ext {y y' : Dat f} (h : ∀ i : Fin 36, y' (mR g i c) = y (mR g i c)) : V f g c y' = V f g c y := by
  funext i
  unfold V
  split_ifs with hi
  · rw [h]
  · rfl

lemma V_off {κ : Bool} {op : ∀ f, Dat f → Dat f} (h : FixC κ op) (hc : cl c ≠ κ) (y : Dat f) :
    V f g c (op f y) = V f g c y :=
  V_ext f g c (fun i => h f y _ (fun g' X c' e => by simp only [mR, Sum.inl.injEq, Prod.mk.injEq] at e; rw [← e.2.2]; exact hc))

lemma walsh_shU (r : Rl) (w : Sky Lb f → ℂ) :
    walsh f (matAct f (shU r) w) = prodF f (fun x => sign (dot (vP r) x)) * walsh f w := by
  rw [shU, shift_phase, walsh_matAct_wrap]

lemma walsh_shift (v : Space Lb) (w : Sky Lb f → ℂ) :
    walsh f (matAct f (Binary.shift v) w) = prodF f (fun x => sign (dot v x)) * walsh f w := by
  rw [shift_phase, walsh_matAct_wrap]

lemma frs (k : ℕ) (hk : k < 17) :
    prodF f (fr (Ab g c) (G17.setX (0 : Fin 9) (k + 1))) = prodF f (fr (Ab g c) (G17.setX (0 : Fin 9) k)) * DD f g c (k + 1) := by
  obtain ⟨e, d⟩ := G17.setX_succ (0 : Fin 9) k hk
  rw [e, fr_union _ _ _ d, DD, Nat.add_sub_cancel]
  exact prodF_mul f _ _

lemma frs_win (a : ℕ) : ∀ n, a + n ≤ 17 →
    prodF f (fr (Ab g c) (G17.setX (0 : Fin 9) (a + n))) = prodF f (fr (Ab g c) (G17.setX (0 : Fin 9) a)) * ∏ j ∈ range n, DD f g c (a + 1 + j)
  | 0, _ => by simp
  | n + 1, h => by
    rw [← add_assoc, frs f g c (a + n) (by omega), frs_win a n (by omega), prod_range_succ, mul_assoc]
    rw [show a + 1 + n = a + n + 1 by ring]

lemma frXY (a : ℕ) (ha : a ≤ 17) :
    prodF f (fr (Ab g c) (G17.setX (0 : Fin 9) a)) = prodF f (fr (Ab g c) (G17.setY (0 : Fin 9) a)) * qq f g c := by
  obtain ⟨e, d⟩ := G17.setX_pivot (0 : Fin 9) a ha
  rw [e, fr_union _ _ _ d, qq]
  exact prodF_mul f _ _

lemma walsh_wU (b : Bool) (a m : ℕ) (h : a + m < 17) (X : Rg) (w : Sky Lb f → ℂ) :
    walsh f (matAct f (wU b a m (.inl (g, X, c))) w)
      = (if b then qq f g c ^ 3 else 1) * (∏ j ∈ range (m + 1), DD f g c (a + 1 + j)) * walsh f w := by
  have hw := frs_win f g c a (m + 1) (by omega)
  rw [show a + (m + 1) = a + m + 1 by ring] at hw
  cases b
  · simp only [wU, wB, wS, if_false, Bool.false_eq_true, Matrix.one_mul, ← matAct_mul, walsh_frame, walsh_unframe]
    simp only [aOf] at *
    rw [hw]
    have hi := prodF_inv_mul f (Ab g c) (G17.setX (0 : Fin 9) a)
    calc _ = (prodF f (fun x => (fr (Ab g c) (G17.setX (0 : Fin 9) a) x)⁻¹) * prodF f (fr (Ab g c) (G17.setX (0 : Fin 9) a)))
          * (∏ j ∈ range (m + 1), DD f g c (a + 1 + j)) * walsh f w := by ring
      _ = _ := by rw [hi]; all_goals simp
  · simp only [wU, wB, wS, if_true, ← matAct_mul, walsh_frame, walsh_unframe, walsh_shift]
    simp only [aOf, vP] at *
    rw [hw, frXY f g c a (by omega)]
    have hi := prodF_inv_mul f (Ab g c) (G17.setY (0 : Fin 9) a)
    have hs : prodF f (fun x => sign (dot ((Ab g c).v pv) x)) = qq f g c ^ 2 := sG_eq f g c
    rw [hs]
    calc _ = (prodF f (fun x => (fr (Ab g c) (G17.setY (0 : Fin 9) a) x)⁻¹) * prodF f (fr (Ab g c) (G17.setY (0 : Fin 9) a)))
          * (qq f g c ^ 2 * qq f g c) * (∏ j ∈ range (m + 1), DD f g c (a + 1 + j)) * walsh f w := by ring
      _ = _ := by rw [hi]; ring

lemma walsh_thU (X : Rg) (w : Sky Lb f → ℂ) :
    walsh f (matAct f (thU (.inl (g, X, c))) w) = qq f g c ^ 3 * walsh f w := by
  have e : thU (.inl (g, X, c)) = Binary.shift (vP (.inl (g, X, c))) * frame (Ab g c) {pv} := by
    rw [thU, ← MX.shift_mul_shift, Matrix.mul_assoc, ← frame_eq_shift_blockMat]; rfl
  rw [e, ← matAct_mul, walsh_shift, walsh_frame]
  simp only [vP, aOf]
  rw [show prodF f (fun x => sign (dot ((Ab g c).v pv) x)) = qq f g c ^ 2 from sG_eq f g c]
  simp only [qq, pv]; ring

lemma onS_on {κ : Bool} (X0 : Rg) (U : Rl → CMat Lb) (y : Dat f) (X : Rg) (hc : cl c = κ) :
    onS (mS κ X0) U f y (.inl (g, X, c)) = if X = X0 then matAct f (U (.inl (g, X, c))) (y (.inl (g, X, c))) else y (.inl (g, X, c)) := by
  simp only [onS]
  by_cases h : X = X0
  · subst h; rw [if_pos (mem_mS.mpr ⟨g, c, hc, rfl⟩), if_pos rfl]
  · rw [if_neg h, if_neg]
    intro hm; obtain ⟨g', c', _, e⟩ := mem_mS.mp hm
    simp only [Sum.inl.injEq, Prod.mk.injEq] at e; exact h e.2.1

lemma gG_on {κ : Bool} (r z : Rg) (hrz : r ≠ z) (u₁ u₂ v₁ v₂ : ℚ) (y : Dat f) (X : Rg) (hc : cl c = κ) :
    gG κ r z u₁ u₂ v₁ v₂ f y (.inl (g, X, c)) = if X = r then
      ((u₁ : ℂ) + u₂ * Complex.I) • y (.inl (g, r, c)) + ((v₁ : ℂ) + v₂ * Complex.I) • y (.inl (g, z, c))
      else y (.inl (g, X, c)) := by
  exact gG_val f g c y X hc

lemma walsh_cmb (a b : ℂ) (x y : Sky Lb f → ℂ) : walsh f (a • x + b • y) = a • walsh f x + b • walsh f y := by
  rw [walsh_add, walsh_smul, walsh_smul]

lemma cq_eq (ng : Bool) (n d : ℕ) : cq ⟨ng, n, d⟩ = KLW.sgnQ ng n d := rfl

theorem view_on (s : Sg) (hs : ∀ k, s ≠ .jc k) (hw : okS s = true) (hc : cl c = s.k) (y : Dat f) :
    V f g c (opS s f y) = semEvs (qq f g c) (LL f g c) (DD f g c) 18 (s.evs (cl c)) (V f g c y) := by
  have hq := q4 f g c
  cases s with
  | jc k => exact absurd rfl (hs k)
  | add κ t s ng n d =>
    simp only [Sg.k] at hc
    simp only [Sg.evs, hc, if_true]
    refine step_one _ _ _ _ (step_add _ _ _ _ ?_ ?_)
    · rw [V_at f g c _ t, V_at f g c _ t, V_at f g c _ s]
      simp only [opS, mR]; rw [gAdd_on f g c _ _ hc, if_pos rfl, walsh_add, walsh_smul,
        monoV_qpow _ _ _ _ 0 (by norm_num), pow_zero, one_mul, cq_eq, qsmul_alg]
    · intro i hi
      unfold V; split_ifs with h
      · simp only [opS, mR]; rw [gAdd_on f g c _ _ hc, if_neg (fun e => hi (by
          simp only [Sum.inl.injEq] at e; exact congrArg Fin.val e))]
        simp
      · rfl
  | mul κ r ng n d =>
    simp only [Sg.k] at hc
    simp only [Sg.evs, hc, if_true]
    refine step_one _ _ _ _ (step_mul _ _ _ _ ?_ ?_)
    · rw [V_at f g c _ r, V_at f g c _ r]
      simp only [opS, mR]; rw [gMul_on f g c _ _ hc, if_pos rfl, walsh_smul, cq_eq, qsmul_alg]
    · intro i hi
      unfold V; split_ifs with h
      · simp only [opS, mR]; rw [gMul_on f g c _ _ hc, if_neg (fun e => hi (by
          simp only [Sum.inl.injEq] at e; exact congrArg Fin.val e))]
      · rfl
  | swp κ a b =>
    simp only [Sg.k] at hc
    simp only [Sg.evs, hc, if_true]
    have hab : a ≠ b := by simpa [okS] using hw
    refine step_one _ _ _ _ (step_swp _ _ _ _ ?_ ?_ ?_)
    · rw [V_at f g c _ a, V_at f g c _ b]
      simp only [opS, mR]; rw [gSwp_on f g c _ _ hc, if_pos rfl]
    · rw [V_at f g c _ b, V_at f g c _ a]
      simp only [opS, mR]; rw [gSwp_on f g c _ _ hc, if_neg (fun e => hab (by
          simp only [Sum.inl.injEq] at e; exact e.symm)), if_pos rfl]
    · intro i h1 h2
      unfold V; split_ifs with h
      · simp only [opS, mR]; rw [gSwp_on f g c _ _ hc, if_neg (fun e => h1 (by
          simp only [Sum.inl.injEq] at e; exact congrArg Fin.val e)), if_neg (fun e => h2 (by simp only [Sum.inl.injEq] at e; exact congrArg Fin.val e))]
      · rfl
  | lam κ r e =>
    simp only [Sg.k] at hc
    simp only [Sg.evs, hc, if_true]
    have hrz : (Sum.inl r : Rg) ≠ Sum.inr 0 := Sum.inl_ne_inr
    refine step_one _ _ _ _ (step_mon _ _ _ _ ?_ ?_)
    · rw [V_at f g c _ r, V_at f g c _ r]
      cases e
      · simp only [opS, if_false, Bool.false_eq_true, mR]
        rw [gG_on f g c _ _ hrz _ _ _ _ _ _ hc, if_pos rfl, onS_on f g c _ _ _ _ hc, onS_on f g c _ _ _ _ hc,
          if_neg hrz, if_pos rfl, gLin_on f g c _ _ hc, gLin_on f g c _ _ hc, if_neg hrz, if_pos rfl]
        simp only [Rat.cast_zero, Rat.cast_one, zero_smul, one_smul, zero_add]
        rw [walsh_cmb, walsh_shU, mono_Lq]
        simp only [vP, aOf]
        rw [show prodF f (fun x => sign (dot ((Ab g c).v pv) x)) = qq f g c ^ 2 from sG_eq f g c]
        funext w
        simp only [LL, LamQ.lamF, Pi.mul_apply, Pi.smul_apply, Pi.add_apply, Pi.pow_apply, smul_eq_mul, ca, cb]
        have h4 := congrFun hq w
        simp only [Pi.pow_apply, Pi.one_apply] at h4
        push_cast
        linear_combination (-(1/2 : ℂ) + Complex.I/2) * walsh f (y (.inl (g, .inl r, c))) w * h4 -- CHECK
      · simp only [opS, if_true, mR]
        rw [gG_on f g c _ _ hrz _ _ _ _ _ _ hc, if_pos rfl, onS_on f g c _ _ _ _ hc, onS_on f g c _ _ _ _ hc,
          if_neg hrz, if_pos rfl, gLin_on f g c _ _ hc, gLin_on f g c _ _ hc, if_neg hrz, if_pos rfl]
        simp only [Rat.cast_zero, Rat.cast_one, zero_smul, one_smul, zero_add]
        rw [walsh_cmb, walsh_shU, mono_L]
        simp only [vP, aOf]
        rw [show prodF f (fun x => sign (dot ((Ab g c).v pv) x)) = qq f g c ^ 2 from sG_eq f g c]
        funext w
        simp only [LL, LamQ.lamF, Pi.mul_apply, Pi.smul_apply, Pi.add_apply, Pi.pow_apply, smul_eq_mul, ca, cb]
        push_cast; ring
    · intro i hi
      unfold V; split_ifs with h
      · have hne : (Sum.inl ⟨i, h⟩ : Rg) ≠ Sum.inl r := fun e => hi (by simp only [Sum.inl.injEq] at e; rw [← e])
        cases e <;> simp only [opS, if_false, if_true, Bool.false_eq_true, mR] <;>
        rw [gG_on f g c _ _ hrz _ _ _ _ _ _ hc, if_neg hne, onS_on f g c _ _ _ _ hc, if_neg Sum.inl_ne_inr,
          gLin_on f g c _ _ hc, if_neg Sum.inl_ne_inr, Rat.cast_one, one_smul]
      · rfl
  | qsh κ r =>
    simp only [Sg.k] at hc
    simp only [Sg.evs, hc, if_true]
    refine step_one _ _ _ _ (step_mon _ _ _ _ ?_ ?_)
    · rw [V_at f g c _ r, V_at f g c _ r]
      simp only [opS, mR]; rw [onS_on f g c _ _ _ _ hc, if_pos rfl, walsh_shU, monoV_qpow _ _ _ _ 2 (by norm_num)]
      simp only [vP, aOf]; rw [show prodF f (fun x => sign (dot ((Ab g c).v pv) x)) = qq f g c ^ 2 from sG_eq f g c]
    · intro i hi
      unfold V; split_ifs with h
      · simp only [opS, mR]; rw [onS_on f g c _ _ _ _ hc, if_neg (fun e => hi (by simp only [Sum.inl.injEq] at e; exact congrArg Fin.val e))]
      · rfl
  | thin κ j t s =>
    simp only [Sg.k] at hc
    simp only [Sg.evs, hc, if_true]
    have hrz : (Sum.inr j : Rg) ≠ Sum.inl s := Sum.inr_ne_inl
    refine step_one _ _ _ _ (step_add _ _ _ _ ?_ ?_)
    · rw [V_at f g c _ t, V_at f g c _ t, V_at f g c _ s]
      simp only [opS, mR]
      rw [gAdd_on f g c _ _ hc, if_pos rfl, onS_on f g c _ _ _ _ hc, onS_on f g c _ _ _ _ hc,
        if_neg Sum.inl_ne_inr, if_pos rfl, gLin_on f g c _ _ hc, gLin_on f g c _ _ hc, if_neg Sum.inl_ne_inr, if_pos rfl]
      simp only [Rat.cast_zero, Rat.cast_one, zero_smul, one_smul, zero_add]
      rw [walsh_add, walsh_thU,
        monoV_qpow _ _ _ _ 3 (by norm_num), cq_eq]
      simp [KLW.sgnQ]
    · intro i hi
      unfold V; split_ifs with h
      · simp only [opS, mR]
        rw [gAdd_on f g c _ _ hc, if_neg (fun e => hi (by simp only [Sum.inl.injEq] at e; exact congrArg Fin.val e)),
          onS_on f g c _ _ _ _ hc, if_neg Sum.inl_ne_inr, gLin_on f g c _ _ hc,
          if_neg Sum.inl_ne_inr]
        simp
      · rfl
  | idle κ r a m =>
    simp only [Sg.k] at hc
    simp only [Sg.evs, hc, if_true]
    have ham : a + m < 17 := by simpa [okS] using hw
    refine step_one _ _ _ _ (step_mon _ _ _ _ ?_ ?_)
    · rw [V_at f g c _ r, V_at f g c _ r]
      simp only [opS, mR]; rw [onS_on f g c _ _ _ _ hc, if_pos rfl, walsh_wU f g c false a m ham, mono_w _ _ _ a m ham]
      all_goals simp
    · intro i hi
      unfold V; split_ifs with h
      · simp only [opS, mR]; rw [onS_on f g c _ _ _ _ hc, if_neg (fun e => hi (by simp only [Sum.inl.injEq] at e; exact congrArg Fin.val e))]
      · rfl
  | idlq κ r a m =>
    simp only [Sg.k] at hc
    simp only [Sg.evs, hc, if_true]
    have ham : a + m < 17 := by simp only [okS, Bool.and_eq_true, decide_eq_true_eq] at hw; exact hw.1
    refine step_one _ _ _ _ (step_mon _ _ _ _ ?_ ?_)
    · rw [V_at f g c _ r, V_at f g c _ r]
      simp only [opS, mR]; rw [onS_on f g c _ _ _ _ hc, if_pos rfl, walsh_wU f g c true a m ham, mono_wq _ _ _ a m ham]
      simp only [if_true]
    · intro i hi
      unfold V; split_ifs with h
      · simp only [opS, mR]; rw [onS_on f g c _ _ _ _ hc, if_neg (fun e => hi (by simp only [Sum.inl.injEq] at e; exact congrArg Fin.val e))]
      · rfl

theorem view_S (s : Sg) (hs : ∀ k, s ≠ .jc k) (hw : okS s = true) (y : Dat f) :
    V f g c (opS s f y) = semEvs (qq f g c) (LL f g c) (DD f g c) 18 (s.evs (cl c)) (V f g c y) := by
  by_cases hc : cl c = s.k
  · exact view_on f g c s hs hw hc y
  · rw [V_off f g c (fix_S s hs) hc]
    have : s.evs (cl c) = [] := by
      cases s <;> simp only [Sg.evs, Sg.k] at hc ⊢ <;> first | exact absurd rfl (hs _) | simp [Ne.symm hc]
    rw [this]; rfl

end View

end

end OAI.PowerSaving.U7604

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option maxHeartbeats 4000000
set_option maxRecDepth 100000

namespace OAI.PowerSaving.U7604
open Binary Matrix Finset RAM SS CB RF BR BC GX GF P4L CtrlAB CtrlAB.UnitAB XHostTW

noncomputable section

abbrev SR := SRole Γ (Fin 200) (Fin 1101) (Fin 68)

lemma tv_cp (t : Fin 200) : Iv.tv t = Iv.tv (pT (cpT t)) := by
  have hl := (lay t).2.2.2
  have hc := List.all_eq_true.mp copy_ok (cpN t.val) (List.mem_range.mpr (lay t).2.1)
  simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq] at hc
  show KLW.WCert.tv GXD.W7604.wc t = KLW.WCert.tv GXD.W7604.wc (pT (cpT t)) -- CHECK: ginv.tv = wc.tv by rfl
  simp only [KLW.WCert.tv, pT, cN_cpT, Nat.mod_eq_of_lt hc.2]
  rw [show GXD.W7604.wc.ports = GXD.W7604.ports from rfl, hl]

lemma htv (t : Fin 200) : Iv.tv t = (bT t).v 0 := by
  rw [tv_cp, bT, bB]; exact bz_spec _ (Iv.hunit _) (Iv.hgap _)

def eKf (k : Fin 17) : SR → Rl
  | .inl (.inl (.inl (g, t))) => mR g (xT t) (cpT t)
  | .inl (.inl (.inr (g, t))) => mR g (yT t) (cpT t)
  | .inl (.inr (g, q)) => fR g k q
  | .inr (g, cc) => .inr (.inr (g, cc))

lemma eKf_inj (k : Fin 17) : Function.Injective (eKf k) := by
  rintro (((⟨g, t⟩ | ⟨g, t⟩) | ⟨g, q⟩) | ⟨g, cc⟩) (((⟨g', t'⟩ | ⟨g', t'⟩) | ⟨g', q'⟩) | ⟨g', cc'⟩) h <;>
    simp only [eKf, mR, fR, Sum.inl.injEq, Sum.inr.injEq, Prod.mk.injEq, reduceCtorEq] at h
  · obtain ⟨rfl, h1, h2⟩ := h; rw [port_inj h2 (xT_host h1)]
  · exact absurd h.2.1 (xT_ne_yT _ _)
  · exact absurd h.2.1.symm (xT_ne_yT _ _)
  · obtain ⟨rfl, h1, h2⟩ := h; rw [port_inj h2 (yT_host h1)]
  · obtain ⟨rfl, -, rfl⟩ := h; rfl
  · obtain ⟨rfl, rfl⟩ := h; rfl

def eK (k : Fin 17) : SR ↪ Rl := ⟨eKf k, eKf_inj k⟩

abbrev hH9 : Fintype.card (Fin 9) = 9 := Fintype.card_fin 9
def Mw (k : Fin 17) (d : Γ) : GWin (Fin 9) Lb := G17.winN (0 : Fin 9) hH9 k.val d
def εJ (k : Fin 17) : Fin 200 → Γ ≃ Γ := G17.gaugeE bT (0 : Fin 9) k.val
def Wn (k : Fin 17) (d : Γ) (q : Fin 1101) : CMat Lb := entW (Mw k d).X (Iv.ent q)
def B'J (k : Fin 17) : SR → CMat Lb :=
  mkS (fun g t => unframe (BBC (bT t) 0 g) (G17.setX (0 : Fin 9) k.val))
    (fun g t => unframe (BBC (bT t) 0 g) (G17.setY (0 : Fin 9) k.val)) (fun _ _ => 1) (fun _ _ => 1)
def bOJ (k : Fin 17) : SR → CMat Lb :=
  bOut Iv.tv (εJ k) (fun d => (Mw k d).Xm) (fun g q => Wn k g q * 1) (fun _ _ => 1)

def jOp (k : Fin 17) (f : ℕ) (y : Dat f) : Dat f :=
  multiAct f (mExt (eK k) (bOJ k)) (point f (gExt (eK k) (GAB Iv.al Iv.be)) (multiAct f (mExt (eK k) (B'J k)) y))

lemma mkS_inv {Γ' T Sl C : Type} (a b a' b' : Γ' → T → CMat Lb) (c c' : Γ' → Sl → CMat Lb) (d d' : Γ' → C → CMat Lb)
    (h1 : ∀ g t, a g t * a' g t = 1) (h2 : ∀ g t, b g t * b' g t = 1) (h3 : ∀ g q, c g q * c' g q = 1)
    (h4 : ∀ g x, d g x * d' g x = 1) : ∀ r : SRole Γ' T Sl C, mkS a b c d r * mkS a' b' c' d' r = 1
  | .inl (.inl (.inl (g, t))) => h1 g t
  | .inl (.inl (.inr (g, t))) => h2 g t
  | .inl (.inr (g, q)) => h3 g q
  | .inr (g, x) => h4 g x

lemma hBJ (k : Fin 17) : ∀ r : SR,
    bIn Iv.tv (εJ k) (fun d => (Mw k d).Xm) (fun _ _ => (1 : CMat Lb)) (fun _ _ => (1 : CMat Lb)) r * B'J k r = 1 := by
  have hk : k.val ≤ 16 := by omega
  have h1 : ∀ (g : Γ) (t : Fin 200), (Mw k (εJ k t g)).Xm.Φ (tt (Iv.tv t))
      * unframe (BBC (bT t) 0 g) (G17.setX (0 : Fin 9) k.val) = 1 := fun g t => by
    rw [htv, Mw, εJ, G17.stage_Xin bT (0 : Fin 9) hH9 k.val hk t g]; exact frame_mul_unframe _ _
  have h2 : ∀ (g : Γ) (t : Fin 200), (Mw k (εJ k t g)).Xm.Φ 0
      * unframe (BBC (bT t) 0 g) (G17.setY (0 : Fin 9) k.val) = 1 := fun g t => by
    rw [Mw, εJ, G17.stage_Yin bT (0 : Fin 9) hH9 k.val hk t g]; exact frame_mul_unframe _ _
  exact mkS_inv _ _ _ _ _ _ _ _ h1 h2 (fun _ _ => Matrix.mul_one 1) (fun _ _ => Matrix.mul_one 1)

theorem route_J (k : Fin 17) : ORoute (jOp k) (fun φ => (Fintype.card Γ : ℝ) * GXD.W7604.invPrice φ) := by
  have R := call_ext Iv (eK k) (εJ k) (Mw k) (fun _ => trivial) (fun d q => entN (Mw k d).X (Iv.ent q)) (Wn k)
    (fun d q => entN_spec _ _) (fun d q => entW_spec _ _) (fun _ _ => 1) (fun _ _ => 1) (fun _ _ => 1) (B'J k) (hBJ k)
  exact R.cast (fun f y => rfl) (fun φ => by rw [PWGW7604.ginv_cost])

section Val
variable (f : ℕ) (k : Fin 17)

lemma jOp_emb (y : Dat f) (a : SR) :
    jOp k f y (eK k a) = matAct f (bOJ k a)
      (fun w => GAB Iv.al Iv.be (fun b => matAct f (B'J k b) (y (eK k b)) w) a) := by
  funext w
  show matAct f (mExt (eK k) (bOJ k) (eK k a))
    (point f (gExt (eK k) (GAB Iv.al Iv.be)) (multiAct f (mExt (eK k) (B'J k)) y) (eK k a)) w = _
  rw [mExt_emb]
  congr 1
  funext w'
  show gExt (eK k) (GAB Iv.al Iv.be) (fun r => multiAct f (mExt (eK k) (B'J k)) y r w') (eK k a) = _
  rw [gExt_emb]
  congr 1
  funext b
  show matAct f (mExt (eK k) (B'J k) (eK k b)) (y (eK k b)) w' = _
  rw [mExt_emb]

lemma jOp_off (y : Dat f) (r : Rl) (h : ¬ ∃ a, eK k a = r) : jOp k f y r = y r := by
  funext w
  show matAct f (mExt (eK k) (bOJ k) r)
    (point f (gExt (eK k) (GAB Iv.al Iv.be)) (multiAct f (mExt (eK k) (B'J k)) y) r) w = y r w
  rw [mExt_off _ _ r h, matAct_one]
  show gExt (eK k) (GAB Iv.al Iv.be) (fun r' => multiAct f (mExt (eK k) (B'J k)) y r' w) r = y r w
  rw [gExt_off _ _ _ r h]
  show matAct f (mExt (eK k) (B'J k) r) (y r) w = y r w
  rw [mExt_off _ _ r h, matAct_one]

lemma matAct_smul' (M : CMat Lb) (a : ℂ) (x : Sky Lb f → ℂ) : matAct f M (a • x) = a • matAct f M x := by
  unfold matAct; exact Matrix.mulVec_smul _ _ _

lemma jX_val (y : Dat f) (g : Γ) (t : Fin 200) :
    walsh f (jOp k f y (mR g (xT t) (cpT t)))
      = DD f g (cpT t) (k.val + 1) * walsh f (y (mR g (xT t) (cpT t)))
        + (Iv.al t : ℂ) • (DD f g (cpT t) (k.val + 1) * (qq f g (cpT t) * walsh f (y (mR g (yT t) (cpT t))))) := by
  have hk : k.val < 17 := k.2
  have e : jOp k f y (mR g (xT t) (cpT t)) = _ := jOp_emb f k y (.inl (.inl (.inl (g, t))))
  rw [e]
  have h1 : bOJ k (.inl (.inl (.inl (g, t)))) = frame (Ab g (cpT t)) (G17.setX (0 : Fin 9) (k.val + 1)) := by
    show (Mw k (εJ k t g)).Xm.Φ 1 = _
    rw [Mw, εJ, G17.stage_Xout bT (0 : Fin 9) hH9 k.val (by omega) t g]; rfl
  rw [h1]
  have e2 : (fun w => GAB Iv.al Iv.be (fun b => matAct f (B'J k b) (y (eK k b)) w) (.inl (.inl (.inl (g, t)))))
      = matAct f (unframe (Ab g (cpT t)) (G17.setX (0 : Fin 9) k.val)) (y (mR g (xT t) (cpT t)))
        + (Iv.al t : ℂ) • matAct f (unframe (Ab g (cpT t)) (G17.setY (0 : Fin 9) k.val)) (y (mR g (yT t) (cpT t))) := by
    funext w; rfl -- CHECK: GAB/mkS/jX/jY reduce by rfl
  rw [e2, matAct_add, matAct_smul', walsh_add, walsh_smul]
  obtain ⟨eX, dX⟩ := G17.setX_succ (0 : Fin 9) k.val hk
  obtain ⟨eP, dP⟩ := G17.setX_pivot (0 : Fin 9) k.val (by omega)
  congr 1
  · rw [eX, walsh_ratio f _ _ _ dX]; rfl
  · congr 1
    rw [eX, eP]
    rw [eP] at dX
    rw [walsh_cross_b f _ _ _ _ dX dP]; rfl

lemma jY_val (y : Dat f) (g : Γ) (t : Fin 200) :
    walsh f (jOp k f y (mR g (yT t) (cpT t)))
      = (Iv.be t : ℂ) • (DD f g (cpT t) (k.val + 1) * (qI f g (cpT t) * walsh f (y (mR g (xT t) (cpT t)))))
        + (1 + (Iv.al t : ℂ) * (Iv.be t : ℂ)) • (DD f g (cpT t) (k.val + 1) * walsh f (y (mR g (yT t) (cpT t)))) := by
  have hk : k.val < 17 := k.2
  have e : jOp k f y (mR g (yT t) (cpT t)) = _ := jOp_emb f k y (.inl (.inl (.inr (g, t))))
  rw [e]
  have h1 : bOJ k (.inl (.inl (.inr (g, t)))) = frame (Ab g (cpT t)) (G17.setY (0 : Fin 9) (k.val + 1)) := by
    show (Mw k (εJ k t g)).Xm.Φ (1 + tt (Iv.tv t)) = _
    rw [htv, Mw, εJ, G17.stage_Yout bT (0 : Fin 9) hH9 k.val (by omega) t g]; rfl
  rw [h1]
  have e2 : (fun w => GAB Iv.al Iv.be (fun b => matAct f (B'J k b) (y (eK k b)) w) (.inl (.inl (.inr (g, t)))))
      = (Iv.be t : ℂ) • matAct f (unframe (Ab g (cpT t)) (G17.setX (0 : Fin 9) k.val)) (y (mR g (xT t) (cpT t)))
        + (1 + (Iv.al t : ℂ) * (Iv.be t : ℂ)) • matAct f (unframe (Ab g (cpT t)) (G17.setY (0 : Fin 9) k.val)) (y (mR g (yT t) (cpT t))) := by
    funext w; rfl -- CHECK
  rw [e2, matAct_add, matAct_smul', matAct_smul', walsh_add, walsh_smul, walsh_smul]
  obtain ⟨eY, dY⟩ := G17.setY_succ (0 : Fin 9) k.val hk
  obtain ⟨eP, dP⟩ := G17.setX_pivot (0 : Fin 9) k.val (by omega)
  congr 1
  · congr 1
    rw [eY, eP, walsh_cross f _ _ _ _ dY dP]; rfl
  · congr 1
    rw [eY, walsh_ratio f _ _ _ dY]; rfl

lemma jF_val (y : Dat f) (g : Γ) (q : Fin 1101) : jOp k f y (fR g k q) = matAct f (Wn k g q) (y (fR g k q)) := by
  have e : jOp k f y (fR g k q) = _ := jOp_emb f k y (.inl (.inr (g, q)))
  rw [e]
  show matAct f (Wn k g q * 1) (fun w => matAct f 1 (y (fR g k q)) w) = _
  rw [Matrix.mul_one, matAct_one]

lemma jF_off (y : Dat f) (g : Γ) (k' : Fin 17) (q : Fin 1101) (h : k' ≠ k) : jOp k f y (fR g k' q) = y (fR g k' q) :=
  jOp_off f k y _ (by
    rintro ⟨((⟨_, _⟩ | ⟨_, _⟩) | ⟨g', q'⟩) | ⟨_, _⟩, e⟩ <;>
      simp only [eK, Function.Embedding.coeFn_mk, eKf, mR, fR, reduceCtorEq, Sum.inr.injEq, Sum.inl.injEq,
        Prod.mk.injEq] at e
    exact h e.2.1.symm)

end Val

section JView
variable {R : Type*} [CommRing R] [Algebra ℚ R] (q L : R) (D : ℕ → R)

lemma semJ_A (k : ℕ) (hk : k < 17) (u : ℕ → R) : semEvs q L D 18 (jEvs true k) u = fun i =>
    if i = 0 then D (k + 1) * (u 0 + q ^ 3 * u 1) else if i = 1 then D (k + 1) * u 1
    else if i = 19 then D (k + 1) * (u 19 - q * u 20) else if i = 20 then D (k + 1) * u 20 else u i := by
  funext i
  simp only [jEvs, if_true, semEvs, semEv, Function.update_apply, mono_j q L D k hk,
    monoV_qpow q L D 18 3 (by norm_num), monoV_qpow q L D 18 1 (by norm_num), cq, KLW.sgnQ]
  split_ifs <;> simp_all <;> ring

lemma semJ_B (k : ℕ) (hk : k < 17) (hq : q ^ 4 = 1) (u : ℕ → R) : semEvs q L D 18 (jEvs false k) u = fun i =>
    if i = 0 then D (k + 1) * (u 0 + algebraMap ℚ R (1/2) * (q ^ 3 * (u 1 - q * u 0)))
    else if i = 1 then D (k + 1) * (u 1 - q * u 0) else u i := by
  funext i
  simp only [jEvs, Bool.false_eq_true, if_false, semEvs, semEv, Function.update_apply, mono_j q L D k hk,
    monoV_qpow q L D 18 3 (by norm_num), monoV_qpow q L D 18 1 (by norm_num), cq, KLW.sgnQ]
  split_ifs <;> simp_all <;> ring

end JView

lemma ctr_ok : (List.range 200).all (fun t => GXD.W7604.ctr.getD t KLW.Ctr.F ==
    (if hostN t then KLW.Ctr.Bk else if 96 ≤ cpN t then KLW.Ctr.M else KLW.Ctr.F)) = true := by decide +kernel

lemma ctr_t (t : Fin 200) : GXD.W7604.ctr.getD t.val KLW.Ctr.F =
    (if hostN t.val then KLW.Ctr.Bk else if 96 ≤ cpN t.val then KLW.Ctr.M else KLW.Ctr.F) := by
  have h := List.all_eq_true.mp ctr_ok t.val (List.mem_range.mpr t.2)
  simpa using h

lemma notin (g : Γ) (c : Cp) (i : Fin 36)
    (h : ∀ t : Fin 200, cpT t = c → i ≠ xT t ∧ i ≠ yT t) (k : Fin 17) : ¬ ∃ a, eK k a = mR g i c := by
  rintro ⟨((⟨g', t⟩ | ⟨g', t⟩) | ⟨g', q⟩) | ⟨g', cc⟩, e⟩ <;>
    simp only [eK, Function.Embedding.coeFn_mk, eKf, mR, fR, reduceCtorEq, Sum.inl.injEq, Prod.mk.injEq] at e
  · exact (h t e.2.2).1 e.2.1.symm
  · exact (h t e.2.2).2 e.2.1.symm

theorem view_J (f : ℕ) (g : Γ) (c : Cp) (k : Fin 17) (y : Dat f) :
    V f g c (jOp k f y) = semEvs (qq f g c) (LL f g c) (DD f g c) 18 ((Sg.jc k).evs (cl c)) (V f g c y) := by
  have hq := q4 f g c
  have hqi := qI_eq f g c
  simp only [Sg.evs]
  funext i
  cases c with
  | inl a =>
    have hP := tP_spec (.inl a)
    have hH := tH_spec a
    have alP : (Iv.al (tP (.inl a)) : ℂ) = 0 ∧ (Iv.be (tP (.inl a)) : ℂ) = 1 := by
      rw [PWGW7604.ginv_al, PWGW7604.ginv_be]; simp only [ctr_t, hP.2, Bool.false_eq_true, if_false]
      rw [if_neg (show ¬ (96 ≤ cpN (tP (.inl a)).val) by rw [← cN_cpT, hP.1]; simp [cN])]
      simp [KLW.Ctr.al, KLW.Ctr.be]
    have alH : (Iv.al (tH a) : ℂ) = -1 ∧ (Iv.be (tH a) : ℂ) = 0 := by
      rw [PWGW7604.ginv_al, PWGW7604.ginv_be]; simp only [ctr_t, hH.2, if_true]; simp [KLW.Ctr.al, KLW.Ctr.be]
    simp only [cl, Sum.isLeft_inl, if_true, jEvsA]
    rw [semJ_A _ _ _ k.val k.2]
    beta_reduce
    unfold V
    have xP : xT (tP (.inl a)) = 1 := by simp [xT, hP.2]
    have yP : yT (tP (.inl a)) = 0 := by simp [yT, hP.2]
    have xH : xT (tH a) = 19 := by simp [xT, hH.2]
    have yH : yT (tH a) = 20 := by simp [yT, hH.2]
    by_cases hi : i < 36
    · simp only [dif_pos hi]
      by_cases h0 : i = 0
      · subst h0
        have := jY_val f k y g (tP (.inl a))
        rw [hP.1, xP, yP, alP.1, alP.2] at this
        rw [show (⟨0, hi⟩ : Fin 36) = 0 from rfl, this, hqi]
        simp only [dif_pos (show (1:ℕ) < 36 by norm_num), dif_pos (show (0:ℕ) < 36 by norm_num)]
        simp; ring
      by_cases h1 : i = 1
      · subst h1
        have := jX_val f k y g (tP (.inl a))
        rw [hP.1, xP, yP, alP.1] at this
        rw [show (⟨1, hi⟩ : Fin 36) = 1 from rfl, this]
        simp
      by_cases h19 : i = 19
      · subst h19
        have := jX_val f k y g (tH a)
        rw [hH.1, xH, yH, alH.1] at this
        rw [show (⟨19, hi⟩ : Fin 36) = 19 from rfl, this]
        simp only [dif_pos (show (20:ℕ) < 36 by norm_num)]
        simp; ring
      by_cases h20 : i = 20
      · subst h20
        have := jY_val f k y g (tH a)
        rw [hH.1, xH, yH, alH.1, alH.2] at this
        rw [show (⟨20, hi⟩ : Fin 36) = 20 from rfl, this]
        simp
      · simp only [h0, h1, h19, h20, if_false]
        rw [jOp_off f k y _ (notin g (.inl a) ⟨i, hi⟩ (fun t ht => by
          rcases regs_A a t ht with rfl | rfl
          · rw [xP, yP]; exact ⟨fun e => h1 (by simpa using congrArg Fin.val e), fun e => h0 (by simpa using congrArg Fin.val e)⟩
          · rw [xH, yH]; exact ⟨fun e => h19 (by simpa using congrArg Fin.val e), fun e => h20 (by simpa using congrArg Fin.val e)⟩) k)]
    · simp only [dif_neg hi]
      split_ifs <;> first | omega | rfl
  | inr b =>
    have hP := tP_spec (.inr b)
    have alP : (Iv.al (tP (.inr b)) : ℂ) = -1 ∧ (Iv.be (tP (.inr b)) : ℂ) = 1/2 := by
      rw [PWGW7604.ginv_al, PWGW7604.ginv_be]; simp only [ctr_t, hP.2, Bool.false_eq_true, if_false]
      rw [if_pos (show 96 ≤ cpN (tP (.inr b)).val by rw [← cN_cpT, hP.1]; simp [cN])]
      simp [KLW.Ctr.al, KLW.Ctr.be]
    simp only [cl, Sum.isLeft_inr, Bool.false_eq_true, if_false, jEvsB]
    rw [semJ_B _ _ _ k.val k.2 hq]
    beta_reduce
    unfold V
    have xP : xT (tP (.inr b)) = 1 := by simp [xT, hP.2]
    have yP : yT (tP (.inr b)) = 0 := by simp [yT, hP.2]
    by_cases hi : i < 36
    · simp only [dif_pos hi]
      by_cases h0 : i = 0
      · subst h0
        have := jY_val f k y g (tP (.inr b))
        rw [hP.1, xP, yP, alP.1, alP.2] at this
        rw [show (⟨0, hi⟩ : Fin 36) = 0 from rfl, this, hqi]
        simp only [dif_pos (show (1:ℕ) < 36 by norm_num), dif_pos (show (0:ℕ) < 36 by norm_num)]
        funext w
        have h4 := congrFun hq w
        simp only [Pi.pow_apply, Pi.one_apply] at h4
        simp [Algebra.smul_def]
        linear_combination (1/2 : ℂ) * DD f g (Sum.inr b) (k.val + 1) w * walsh f (y (mR g 0 (Sum.inr b))) w * h4
      by_cases h1 : i = 1
      · subst h1
        have := jX_val f k y g (tP (.inr b))
        rw [hP.1, xP, yP, alP.1] at this
        rw [show (⟨1, hi⟩ : Fin 36) = 1 from rfl, this]
        simp only [dif_pos (show (0:ℕ) < 36 by norm_num)]
        simp; ring
      · simp only [h0, h1, if_false]
        rw [jOp_off f k y _ (notin g (.inr b) ⟨i, hi⟩ (fun t ht => by
          rw [regs_B b t ht, xP, yP]
          exact ⟨fun e => h1 (by simpa using congrArg Fin.val e), fun e => h0 (by simpa using congrArg Fin.val e)⟩) k)]
    · simp only [dif_neg hi]
      split_ifs <;> first | omega | rfl

end

end OAI.PowerSaving.U7604

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option maxHeartbeats 4000000

namespace OAI.PowerSaving.U7604
open Binary Matrix Finset RAM SS CB RF BC GX GF P4L CtrlAB CtrlAB.UnitAB XHostTW

noncomputable section

def segOp : Sg → ∀ f, Dat f → Dat f
  | .jc k => jOp k
  | s => opS s

lemma segOp_eq (s : Sg) (hs : ∀ k, s ≠ .jc k) : segOp s = opS s := by
  cases s <;> first | exact absurd rfl (hs _) | rfl

def runL : List Sg → ∀ f, Dat f → Dat f
  | [] => fun _ y => y
  | s :: l => fun f y => runL l f (segOp s f y)

def cS (s : Sg) (φ : ℕ → ℝ) : ℝ :=
  (Fintype.card Γ : ℝ) * (listCost φ s.blk + if s.jk.isSome then GXD.W7604.invPrice φ else 0)

lemma route_seg (s : Sg) (hw : okS s = true) : ORoute (segOp s) (cS s) := by
  by_cases hs : ∃ k, s = .jc k
  · obtain ⟨k, rfl⟩ := hs
    exact (route_J k).cast (fun f y => by simp only [segOp]) (fun φ => by
      rw [cS, show Sg.blk (.jc k) = [] from rfl, show (Sg.jk (.jc k)).isSome = true from rfl, if_pos rfl, lc_nil, zero_add])
  · push_neg at hs
    rw [segOp_eq s hs]
    refine (route_S s hs hw).cast (fun _ _ => rfl) (fun φ => ?_)
    have : s.jk = none := by cases s <;> first | exact absurd rfl (hs _) | rfl
    rw [cS, this, Option.isSome_none, if_neg Bool.false_ne_true, add_zero]

lemma route_L : ∀ l : List Sg, l.all okS = true → ORoute (runL l) (fun φ => (l.map fun s => cS s φ).sum)
  | [], _ => ORoute.refl.cast (fun _ _ => rfl) (fun _ => rfl)
  | s :: l, h => by
    simp only [List.all_cons, Bool.and_eq_true] at h
    exact ((route_seg s h.1).trans (route_L l h.2)).cast (fun f y => by simp only [runL])
      (fun φ => by simp only [List.map_cons, List.sum_cons])

lemma view_seg (f : ℕ) (g : Γ) (c : Cp) (s : Sg) (hw : okS s = true) (y : Dat f) :
    V f g c (segOp s f y) = semEvs (qq f g c) (LL f g c) (DD f g c) 18 (s.evs (cl c)) (V f g c y) := by
  by_cases hs : ∃ k, s = .jc k
  · obtain ⟨k, rfl⟩ := hs; exact view_J f g c k y
  · push_neg at hs; rw [segOp_eq s hs]; exact view_S f g c s hs hw y

lemma view_L (f : ℕ) (g : Γ) (c : Cp) : ∀ (l : List Sg), l.all okS = true → ∀ y : Dat f,
    V f g c (runL l f y) = semEvs (qq f g c) (LL f g c) (DD f g c) 18 (l.flatMap (·.evs (cl c))) (V f g c y)
  | [], _, y => rfl
  | s :: l, h, y => by
    simp only [List.all_cons, Bool.and_eq_true] at h
    rw [runL, view_L f g c l h.2, view_seg f g c s h.1, List.flatMap_cons, semEvs_append]

lemma fresh_L (f : ℕ) (g : Γ) (k : Fin 17) (q : Fin 1101) : ∀ (l : List Sg), (l.filterMap Sg.jk).Nodup → ∀ y : Dat f,
    runL l f y (fR g k q) = if k.val ∈ l.filterMap Sg.jk then matAct f (Wn k g q) (y (fR g k q)) else y (fR g k q)
  | [], _, y => by simp [runL]
  | s :: l, hn, y => by
    show runL l f (segOp s f y) (fR g k q) = _
    rw [fresh_L f g k q l (by
      cases s <;> simp only [List.filterMap_cons, Sg.jk] at hn ⊢ <;> first | exact hn | exact (List.nodup_cons.mp hn).2)]
    by_cases hs : ∃ k', s = .jc k'
    · obtain ⟨k', rfl⟩ := hs
      simp only [List.filterMap_cons, Sg.jk, List.mem_cons] at hn ⊢
      by_cases hk : k' = k
      · subst hk
        have : k'.val ∉ l.filterMap Sg.jk := (List.nodup_cons.mp hn).1
        simp only [this, if_false, true_or, if_true, segOp, jF_val]
      · have hne : k.val ≠ k'.val := fun e => hk (Fin.ext e.symm)
        simp only [segOp, jF_off f k' y g k q (fun e => hk e.symm), hne, false_or]
    · push_neg at hs
      have hj : s.jk = none := by cases s <;> first | exact absurd rfl (hs _) | rfl
      have hf : segOp s f y (fR g k q) = y (fR g k q) := by
        rw [segOp_eq s hs]; exact fix_S s hs f y _ (fun _ _ _ e => by cases e)
      simp only [List.filterMap_cons, hj, hf]

abbrev rS (q : Fin 1101) : ℕ := GXD.W7604.schedRes.getD q.val 0

lemma rS_le (q : Fin 1101) : 1 ≤ rS q ∧ rS q ≤ 9 := by
  have h := List.all_eq_true.mp sched_ok.2 (rS q) (by
    rw [rS, List.getD_eq_getElem?_getD, List.getElem?_eq_getElem (by rw [sched_ok.1]; exact q.2), Option.getD_some]
    exact List.getElem_mem _)
  simpa using h

def Dr (q : Fin 1101) : Finset Lb :=
  Classical.choose (Finset.exists_subset_card_eq (s := (univ : Finset Lb)) (n := rS q)
    (by rw [card_univ, card137]; have := (rS_le q).2; omega)) -- CHECK: name exists_subset_card_eq
lemma Dr_card (q : Fin 1101) : (Dr q).card = rS q :=
  (Classical.choose_spec (Finset.exists_subset_card_eq (s := (univ : Finset Lb)) (n := rS q)
    (by rw [card_univ, card137]; have := (rS_le q).2; omega))).2

lemma hWn (k : Fin 17) (d : Γ) (q : Fin 1101) :
    ∃ (C C' : CMat Lb) (R : Finset Lb), Free C ∧ Free C' ∧ R.card = rS q ∧ Wn k d q = C * pk R * C' := by
  obtain ⟨C, C', R, h1, h2, h3, h4⟩ := entW_form (Mw k d).X (Iv.ent q)
  exact ⟨C, C', R, h1, h2, by rw [h3]; exact GXD.W7604.hent q, h4⟩

theorem fc (k : Fin 17) : ∃ Zp : Γ → Fin 1101 → CMat Lb, (∀ d q, GReach 1 (Zp d q) (fun _ => 0)) ∧
    (∀ d q, GReach (Wn k d q * Zp d q) (pk (Dr q)) (fun φ => bcost φ ((Dr q).card - rS q))) :=
  fresh_call (Γ := Γ) (Wn k) rS (hWn k) Dr (fun q => (Dr_card q).ge)
    (fun q => by rw [Dr_card, Nat.sub_self, card137]; norm_num)

def zp (k : Fin 17) : Γ → Fin 1101 → CMat Lb := Classical.choose (fc k)

def isF : Rl → Bool
  | .inr (.inl _) => true
  | _ => false
def frS : Finset Rl := univ.filter fun r => isF r = true
lemma mem_frS' {r : Rl} : r ∈ frS ↔ isF r = true := by simp only [frS, Finset.mem_filter, Finset.mem_univ, true_and]
-- frS is opaque from here on: no whnf of its membership (that would enumerate the gauge group)
attribute [irreducible] frS

def zU : Rl → CMat Lb
  | .inr (.inl p) => zp p.2.1 p.1 p.2.2
  | _ => 1
def zA : Rl → CMat Lb
  | .inr (.inl p) => Wn p.2.1 p.1 p.2.2 * zp p.2.1 p.1 p.2.2
  | _ => 1
def zB : Rl → CMat Lb
  | .inr (.inl p) => pk (Dr p.2.2)
  | _ => 1

lemma all3 {A B C' : Type} {P : A ⊕ (B ⊕ C') → Prop} (h1 : ∀ a, P (.inl a)) (h2 : ∀ b, P (.inr (.inl b)))
    (h3 : ∀ c, P (.inr (.inr c))) : ∀ r, P r
  | .inl a => h1 a
  | .inr (.inl b) => h2 b
  | .inr (.inr c) => h3 c

lemma stepZ : ∀ r : Rl, GStep r 1 (zU r) (fun _ => 0) :=
  all3 (P := fun r => GStep r 1 (zU r) (fun _ => 0)) (fun _ => GStep.refl _ _)
    (fun p => ((Classical.choose_spec (fc p.2.1)).1 p.1 p.2.2) Rl _) (fun _ => GStep.refl _ _)

lemma stepE : ∀ r : Rl, GStep r (zA r) (zB r) (fun _ => 0) :=
  all3 (P := fun r => GStep r (zA r) (zB r) (fun _ => 0)) (fun _ => GStep.refl _ _)
    (fun p => (((Classical.choose_spec (fc p.2.1)).2 p.1 p.2.2) Rl _).cast (fun φ => by
      rw [Dr_card, Nat.sub_self, bcost_zero])) (fun _ => GStep.refl _ _)

lemma route_prep : ORoute (onS frS zU) (fun _ => 0) :=
  (route_onS frS zU (fun _ _ => 0) (fun r _ => stepZ r)).cast (fun _ _ => rfl) (fun _ => Finset.sum_const_zero)

lemma route_end : ∃ U : Rl → CMat Lb, (∀ r ∈ frS, U r * zA r = zB r) ∧
    ORoute (fun f y r => if r ∈ frS then matAct f (U r) (y r) else y r) (fun _ => 0) := by
  obtain ⟨U, hU, R⟩ := ORoute.steps frS zA zB (fun r φ => 0) (fun r _ => stepE r)
  exact ⟨U, hU, R.cast (fun _ _ => rfl) (fun _ => Finset.sum_const_zero)⟩

def uE : Rl → CMat Lb := Classical.choose route_end
def endF (f : ℕ) (y : Dat f) : Dat f := fun r => if r ∈ frS then matAct f (uE r) (y r) else y r

def aT (c : Cp) (i : Fin 36) : ℕ := (dTab (cl c)).getD i.val 0
def mT (c : Cp) (i : Fin 36) : ℕ := (nTab (cl c)).getD i.val 0
def Sx (c : Cp) (i : Fin 36) : Finset Lb := G17.setX (0 : Fin 9) (aT c i + mT c i + 1) \ G17.setY (0 : Fin 9) (aT c i)

def isM : Rl → Bool
  | .inl p => p.2.1.isLeft
  | _ => false
def mainS : Finset Rl := univ.filter fun r => isM r = true
lemma mem_mainS' {r : Rl} : r ∈ mainS ↔ isM r = true := by
  simp only [mainS, Finset.mem_filter, Finset.mem_univ, true_and]
-- mainS is opaque from here on (as frS)
attribute [irreducible] mainS

def zz (p : Γ × Rg × Cp) : Space Lb :=
  match p.2.1 with
  | .inl i => (Ab p.1 p.2.2).v pv + (Ab p.1 p.2.2).corr (Sx p.2.2 i)
  | .inr _ => 0
def shZ : Rl → CMat Lb
  | .inl p => Binary.shift (zz p)
  | _ => 1

lemma stepS : ∀ r : Rl, GStep r 1 (shZ r) (fun _ => 0) :=
  all3 (P := fun r => GStep r 1 (shZ r) (fun _ => 0)) (fun p => gstep_shift _ _) (fun _ => GStep.refl _ _)
    (fun _ => GStep.refl _ _)

lemma route_sh2 : ORoute (onS mainS shZ) (fun _ => 0) :=
  (route_onS mainS shZ (fun _ _ => 0) (fun r _ => stepS r)).cast (fun _ _ => rfl) (fun _ => Finset.sum_const_zero)

def wOp (f : ℕ) (y : Dat f) : Dat f := onS mainS shZ f (endF f (runL segs f (onS frS zU f y)))

def wCost (φ : ℕ → ℝ) : ℝ := (segs.map fun s => cS s φ).sum

lemma route_word : ORoute wOp (fun φ => wCost φ) := by
  obtain ⟨-, R⟩ := Classical.choose_spec route_end
  exact (((route_prep.trans (route_L segs segs_ok.1)).trans R).trans route_sh2).cast
    (fun f y => rfl)
    (fun φ => by simp only [wCost, zero_add, add_zero])

section Close
variable (f : ℕ)

lemma tabA (c : Cp) (i : Fin 36) : aT c i + mT c i < 17 ∧
    (if cl c then CtrlAB.A7113.diag else CtrlAB.B7113.diag).getD i.val 0 = 3 + wM (aT c i) (mT c i) := by
  cases hc : cl c
  · obtain ⟨h1, h2⟩ := diag_B
    have h3 := List.all_eq_true.mp h2 i.val (List.mem_range.mpr i.2)
    simp only [decide_eq_true_eq] at h3
    refine ⟨by simpa [aT, mT, hc] using h3, ?_⟩
    simp only [Bool.false_eq_true, if_false, h1, aT, mT, hc]
    simp [List.getD_eq_getElem?_getD, i.2]
  · obtain ⟨h1, h2⟩ := diag_A
    have h3 := List.all_eq_true.mp h2 i.val (List.mem_range.mpr i.2)
    simp only [decide_eq_true_eq] at h3
    refine ⟨by simpa [aT, mT, hc] using h3, ?_⟩
    simp only [if_true, h1, aT, mT, hc]
    simp [List.getD_eq_getElem?_getD, i.2]

lemma diag_view (g : Γ) (c : Cp) (y : Dat f) (i : Fin 36) :
    V f g c (runL segs f y) i.val = qq f g c ^ 3 * (∏ j ∈ range (mT c i + 1), DD f g c (aT c i + 1 + j)) * V f g c y i.val := by
  rw [view_L f g c segs segs_ok.1]
  obtain ⟨hlt, hd⟩ := tabA c i
  cases hc : cl c
  · rw [segs_B]
    have := CtrlAB.B7113.ctrl_diag (qq f g c) (LL f g c) (DD f g c) (q4 f g c) (L2 f g c) (V f g c y) i.val i.2
    rw [show CtrlAB.B7113.P.NS = 18 from rfl] at this
    rw [this]; simp only [hc, Bool.false_eq_true, if_false] at hd; rw [hd, mono_wq _ _ _ _ _ hlt]
  · rw [segs_A]
    have := CtrlAB.A7113.ctrl_diag (qq f g c) (LL f g c) (DD f g c) (q4 f g c) (L2 f g c) (V f g c y) i.val i.2
    rw [show CtrlAB.A7113.P.NS = 18 from rfl] at this
    rw [this]; simp only [hc, if_true] at hd; rw [hd, mono_wq _ _ _ _ _ hlt]

lemma sub_Y (c : Cp) (i : Fin 36) : G17.setY (0 : Fin 9) (aT c i) ⊆ G17.setX (0 : Fin 9) (aT c i + mT c i + 1) := by
  have h := (tabA c i).1
  have h1 : G17.setY (0 : Fin 9) (aT c i) ⊆ G17.setX (0 : Fin 9) (aT c i) := by
    rw [G17.setX_eq (0 : Fin 9) _ (by omega)]; exact Finset.subset_union_left
  exact h1.trans (G17.setX_mono (0 : Fin 9) _ _ (by omega) (by omega))

lemma fr_Sx (g : Γ) (c : Cp) (i : Fin 36) :
    prodF f (fr (Ab g c) (Sx c i)) = qq f g c * ∏ j ∈ range (mT c i + 1), DD f g c (aT c i + 1 + j) := by
  have h := (tabA c i).1
  have e1 : G17.setX (0 : Fin 9) (aT c i + mT c i + 1) = G17.setY (0 : Fin 9) (aT c i) ∪ Sx c i :=
    (Finset.union_sdiff_of_subset (sub_Y c i)).symm
  have hw := frs_win f g c (aT c i) (mT c i + 1) (by omega) -- CHECK: namespace (frs_win is in U7604)
  have e2 : prodF f (fr (Ab g c) (G17.setY (0 : Fin 9) (aT c i) ∪ Sx c i))
      = prodF f (fr (Ab g c) (G17.setY (0 : Fin 9) (aT c i))) * prodF f (fr (Ab g c) (Sx c i)) := by
    rw [fr_union (Ab g c) _ (Sx c i) (by unfold Sx; exact disjoint_sdiff)]; exact prodF_mul f _ _
  rw [show aT c i + (mT c i + 1) = aT c i + mT c i + 1 by ring, e1, e2, frXY f g c _ (by omega)] at hw
  have hi := prodF_inv_mul f (Ab g c) (G17.setY (0 : Fin 9) (aT c i))
  calc prodF f (fr (Ab g c) (Sx c i))
      = (prodF f (fun x => (fr (Ab g c) (G17.setY (0 : Fin 9) (aT c i)) x)⁻¹) * prodF f (fr (Ab g c) (G17.setY (0 : Fin 9) (aT c i))))
        * prodF f (fr (Ab g c) (Sx c i)) := by rw [hi, one_mul]
    _ = _ := by
      rw [mul_assoc]
      have : prodF f (fr (Ab g c) (G17.setY (0 : Fin 9) (aT c i))) * prodF f (fr (Ab g c) (Sx c i))
          = prodF f (fr (Ab g c) (G17.setY (0 : Fin 9) (aT c i))) * qq f g c * ∏ j ∈ range (mT c i + 1), DD f g c (aT c i + 1 + j) := by
        rw [← hw]
      rw [this, ← mul_assoc, ← mul_assoc, hi, one_mul]

lemma mR_nfr (g : Γ) (i : Fin 36) (c : Cp) : mR g i c ∉ frS := by rw [mem_frS']; exact Bool.false_ne_true
lemma mR_main (g : Γ) (i : Fin 36) (c : Cp) : mR g i c ∈ mainS := by rw [mem_mainS']; rfl
lemma fR_nmain (g : Γ) (k : Fin 17) (q : Fin 1101) : fR g k q ∉ mainS := by rw [mem_mainS']; exact Bool.false_ne_true
lemma fR_fr (g : Γ) (k : Fin 17) (q : Fin 1101) : fR g k q ∈ frS := by rw [mem_frS']; rfl
lemma onS_out {s : Finset Rl} {U : Rl → CMat Lb} {y : Dat f} {r : Rl} (h : r ∉ s) : onS s U f y r = y r := if_neg h
lemma onS_in {s : Finset Rl} {U : Rl → CMat Lb} {y : Dat f} {r : Rl} (h : r ∈ s) :
    onS s U f y r = matAct f (U r) (y r) := if_pos h

lemma main_end (y : Dat f) (g : Γ) (i : Fin 36) (c : Cp) :
    wOp f y (mR g i c) = matAct f (blockMat ((Ab g c).fam (Sx c i))) (y (mR g i c)) := by
  have h1 : onS frS zU f y (mR g i c) = y (mR g i c) := onS_out f (mR_nfr g i c)
  have h2 : ∀ y' : Dat f, endF f y' (mR g i c) = y' (mR g i c) := fun y' => if_neg (mR_nfr g i c)
  have h3 : wOp f y (mR g i c)
      = matAct f (shZ (mR g i c)) (endF f (runL segs f (onS frS zU f y)) (mR g i c)) := onS_in f (mR_main g i c)
  rw [h3, h2]
  show matAct f (Binary.shift ((Ab g c).v pv + (Ab g c).corr (Sx c i))) _ = _
  apply normal_qi
  have hv := diag_view f g c (onS frS zU f y) i
  rw [V_at, V_at, h1] at hv
  rw [hv, fr_Sx, show prodF f (fun x => sign (dot ((Ab g c).v pv) x)) = qq f g c ^ 2 from sG_eq f g c]
  ring

lemma fresh_end (y : Dat f) (g : Γ) (k : Fin 17) (q : Fin 1101) :
    wOp f y (fR g k q) = matAct f (pk (Dr q)) (y (fR g k q)) := by
  have hm := fR_nmain g k q
  have hf := fR_fr g k q
  have h3 : wOp f y (fR g k q) = endF f (runL segs f (onS frS zU f y)) (fR g k q) := onS_out f hm
  have h4 : endF f (runL segs f (onS frS zU f y)) (fR g k q)
      = matAct f (uE (fR g k q)) (runL segs f (onS frS zU f y) (fR g k q)) := if_pos hf
  have h5 : onS frS zU f y (fR g k q) = matAct f (zU (fR g k q)) (y (fR g k q)) := onS_in f hf
  rw [h3, h4]
  rw [fresh_L f g k q segs (by rw [segs_ok.2]; exact List.nodup_range),
    if_pos (by rw [segs_ok.2]; exact List.mem_range.mpr k.2), h5, matAct_mul, matAct_mul, Matrix.mul_assoc]
  obtain ⟨hU, -⟩ := Classical.choose_spec route_end
  have := hU _ hf
  simp only [zA, zB, fR] at this
  show matAct f (uE (fR g k q) * (Wn k g q * zp k g q)) _ = _
  rw [show uE (fR g k q) * (Wn k g q * zp k g q) = pk (Dr q) from this]

end Close

end

end OAI.PowerSaving.U7604

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option maxHeartbeats 4000000
set_option maxRecDepth 100000

namespace OAI.PowerSaving.U7604
open Binary Matrix Finset RAM SS CB RF BC GX GF XHostTW P4L

noncomputable section

lemma lc_ins (φ : ℕ → ℝ) (b : ℕ × ℕ) : ∀ l, listCost φ (ins b l) = b.2 * φ b.1 + listCost φ l
  | [] => by rw [ins, listCost_cons]
  | c :: l => by
    unfold ins
    by_cases h1 : b.1 = c.1
    · rw [if_pos h1, listCost_cons, listCost_cons, h1]; push_cast; ring
    · rw [if_neg h1]
      by_cases h2 : b.1 < c.1
      · rw [if_pos h2, listCost_cons]
      · rw [if_neg h2, listCost_cons, listCost_cons, lc_ins φ b l]; ring

lemma lc_nrm (φ : ℕ → ℝ) : ∀ l, listCost φ (nrm l) = listCost φ l
  | [] => rfl
  | b :: l => by rw [nrm, List.foldr_cons, lc_ins, ← nrm, lc_nrm φ l, listCost_cons]

lemma lc_append (φ : ℕ → ℝ) (l l' : List (ℕ × ℕ)) :
    listCost φ (l ++ l') = listCost φ l + listCost φ l' := by
  unfold listCost; rw [List.map_append, List.sum_append]

lemma lc_rep (φ : ℕ → ℝ) (L : List (ℕ × ℕ)) : ∀ n, listCost φ (List.replicate n L).flatten = n * listCost φ L
  | 0 => by rw [List.replicate_zero, List.flatten_nil, lc_nil, Nat.cast_zero, zero_mul]
  | n + 1 => by rw [List.replicate_succ, List.flatten_cons, lc_append, lc_rep φ L n]; push_cast; ring

lemma lc_Pnat (φ : ℕ → ℝ) : listCost φ Pnat = GXD.W7604.invPrice φ := by
  rw [Pnat]
  simp only [listCost_cons, lc_nil]
  unfold GXD.W7604.invPrice; push_cast; ring

lemma lc_flat (φ : ℕ → ℝ) (L : List Sg) :
    listCost φ (L.flatMap Sg.blk) = (L.map fun s => listCost φ s.blk).sum := by
  induction L with
  | nil => rfl
  | cons s L ih => rw [List.flatMap_cons, lc_append, ih]; rfl

lemma cnt_jk (x : ℝ) : ∀ L : List Sg, (L.map fun s => if s.jk.isSome then x else 0).sum = (L.filterMap Sg.jk).length * x
  | [] => by simp
  | s :: L => by
    have ih := cnt_jk x L
    rw [List.map_cons, List.sum_cons, ih, List.filterMap_cons]
    cases h : s.jk with
    | none => simp
    | some b => simp; ring

lemma wCost_eq (φ : ℕ → ℝ) : wCost φ = (Fintype.card Γ : ℝ) * listCost φ Praw := by
  have hP : Praw = Pc := rfl
  rw [hP, ← price_ok, lc_nrm, lc_append, lc_flat]
  have h17 : listCost φ (List.replicate 17 Pnat).flatten = 17 * GXD.W7604.invPrice φ := by
    rw [lc_rep, lc_Pnat]; norm_num
  rw [h17, wCost]
  simp only [cS, mul_add, List.sum_map_add, ← List.sum_map_mul_left] -- CHECK
  rw [show (segs.map fun s => (Fintype.card Γ : ℝ) * (if s.jk.isSome then GXD.W7604.invPrice φ else 0)).sum
      = (Fintype.card Γ : ℝ) * (segs.map fun s => if s.jk.isSome then GXD.W7604.invPrice φ else 0).sum by
    rw [List.sum_map_mul_left], cnt_jk, segs_ok.2, List.length_range]
  rw [List.sum_map_mul_left]; push_cast; ring

lemma card_Sx (c : Cp) (i : Fin 36) : (Sx c i).card = rkT (cl c) i.val := by
  have h := (tabA c i).1
  rw [Sx, Finset.card_sdiff, Finset.inter_eq_left.mpr (sub_Y c i), cX _ (by omega), cY _ (by omega)]
  simp only [rkT, aT, mT] at *; omega

def tgA (a : Fin 36 × Cp) : ℕ := rkT (cl a.2) a.1.val
def tgB (b : Fin 17 × Fin 1101) : ℕ := rS b.2
def trL : Lv → ℕ := Sum.elim (fun p => tgA p.2) (fun p => tgB p.2)
def tzL : ∀ l : Lv, Fin (trL l) → Space Lb
  | .inl p => fun j => (Ab p.1 p.2.2).fam (Sx p.2.2 p.2.1) (Fin.cast (card_Sx _ _).symm j)
  | .inr p => fun j => FH.targ (Dr p.2.2) (Fin.cast (Dr_card _).symm j)

lemma bm_cast {m n : ℕ} (h : m = n) (z : Fin n → Space Lb) : blockMat (fun j : Fin m => z (Fin.cast h j)) = blockMat z := by
  subst h; rfl

lemma histTc (r : ℕ) : BlockAccounting.histFn Traw r = histC Tc r := rfl

lemma hC_cons (b : ℕ × ℕ) (l : List (ℕ × ℕ)) (r : ℕ) : histC (b :: l) r = (if b.1 = r then b.2 else 0) + histC l r := by
  unfold histC; by_cases h : b.1 = r <;> simp [h, List.filter_cons]

lemma hC_ins (b : ℕ × ℕ) (r : ℕ) : ∀ l, histC (ins b l) r = (if b.1 = r then b.2 else 0) + histC l r
  | [] => by rw [ins, hC_cons]
  | c :: l => by
    unfold ins
    by_cases h1 : b.1 = c.1
    · rw [if_pos h1, hC_cons, hC_cons, h1]; split_ifs <;> omega
    · rw [if_neg h1]
      by_cases h2 : b.1 < c.1
      · rw [if_pos h2, hC_cons]
      · rw [if_neg h2, hC_cons, hC_cons, hC_ins b r l]; omega

lemma hC_nrm (r : ℕ) : ∀ l, histC (nrm l) r = histC l r
  | [] => rfl
  | b :: l => by rw [nrm, List.foldr_cons, hC_ins, ← nrm, hC_nrm r l, hC_cons]

lemma hC_append (a b : List (ℕ × ℕ)) (r : ℕ) : histC (a ++ b) r = histC a r + histC b r := by
  unfold histC; rw [List.filter_append, List.map_append, List.sum_append]

lemma hC_map (h : ℕ → ℕ) (c r : ℕ) : ∀ l : List ℕ,
    histC (l.map fun x => (h x, c)) r = c * (l.map fun x => if h x = r then 1 else 0).sum
  | [] => rfl
  | x :: l => by
    rw [List.map_cons, hC_cons, hC_map h c r l, List.map_cons, List.sum_cons]
    split_ifs <;> simp <;> ring

def cntL (r : ℕ) : ℕ := 96 * ((nTab true).map fun x => if 1 + 8 * (x + 1) = r then 1 else 0).sum
  + 8 * ((nTab false).map fun x => if 1 + 8 * (x + 1) = r then 1 else 0).sum
  + 17 * (GXD.W7604.schedRes.map fun x => if x = r then 1 else 0).sum

lemma cntL_eq (r : ℕ) : cntL r = BlockAccounting.histFn Traw r := by
  rw [histTc, ← tgt_ok, hC_nrm, hC_append, hC_append, hC_map, hC_map, hC_map, cntL]; ring

lemma count_gen {G A B : Type} [Fintype G] [Fintype A] [Fintype B] [inst : Fintype ((G × A) ⊕ (G × B))]
    (tr : (G × A) ⊕ (G × B) → ℕ)
    (ta : A → ℕ) (tb : B → ℕ) (r : ℕ) (ha : ∀ g a, tr (.inl (g, a)) = ta a) (hb : ∀ g b, tr (.inr (g, b)) = tb b) :
    (univ.filter fun l => tr l = r).card
      = Fintype.card G * ((∑ a, if ta a = r then 1 else 0) + ∑ b, if tb b = r then 1 else 0) := by
  -- any instance of the role type is the standard one (so the caller's instance never needs unfolding)
  obtain rfl : inst = instFintypeSum _ _ := Subsingleton.elim _ _
  rw [Finset.card_filter, Fintype.sum_sum_type, Fintype.sum_prod_type, Fintype.sum_prod_type]
  simp only [ha, hb, Finset.sum_const, Finset.card_univ, smul_eq_mul, mul_add]

lemma sumA (r : ℕ) : (∑ a : Fin 36 × Cp, if tgA a = r then 1 else 0)
    = 96 * ((nTab true).map fun x => if 1 + 8 * (x + 1) = r then 1 else 0).sum
      + 8 * ((nTab false).map fun x => if 1 + 8 * (x + 1) = r then 1 else 0).sum := by
  have cA : ∀ (a : Fin 96) (i : Fin 36), tgA (i, .inl a) = rkT true i.val := fun a i => rfl
  have cB : ∀ (b : Fin 8) (i : Fin 36), tgA (i, .inr b) = rkT false i.val := fun b i => rfl
  rw [Fintype.sum_prod_type]
  simp only [Fintype.sum_sum_type, cA, cB, Finset.sum_const,
    Finset.card_univ, Fintype.card_fin, smul_eq_mul, Finset.sum_add_distrib, ← Finset.mul_sum, rkT]
  rw [sum_map_getD (nTab true) 0, sum_map_getD (nTab false) 0, nT_len, nT_len]
  simp only [Fin.sum_univ_eq_sum_range (fun i => if 1 + 8 * ((nTab true).getD i 0 + 1) = r then 1 else 0) 36,
    Fin.sum_univ_eq_sum_range (fun i => if 1 + 8 * ((nTab false).getD i 0 + 1) = r then 1 else 0) 36]

lemma sumB (r : ℕ) : (∑ b : Fin 17 × Fin 1101, if tgB b = r then 1 else 0)
    = 17 * (GXD.W7604.schedRes.map fun x => if x = r then 1 else 0).sum := by
  rw [Fintype.sum_prod_type]
  have cQ : ∀ (k : Fin 17) (q : Fin 1101), tgB (k, q) = rS q := fun _ _ => rfl
  simp only [cQ, Finset.sum_const, Finset.card_univ, Fintype.card_fin, smul_eq_mul]
  rw [sum_map_getD GXD.W7604.schedRes 0, sched_ok.1]
  simp only [rS, Fin.sum_univ_eq_sum_range (fun i => if GXD.W7604.schedRes.getD i 0 = r then 1 else 0) 1101]

lemma hcnt (r : ℕ) : (univ.filter fun l : Lv => trL l = r).card = Fintype.card Γ * BlockAccounting.histFn Traw r :=
  calc (univ.filter fun l : Lv => trL l = r).card
      = Fintype.card Γ * ((∑ a, if tgA a = r then 1 else 0) + ∑ b, if tgB b = r then 1 else 0) :=
        count_gen trL tgA tgB r (fun _ _ => rfl) (fun _ _ => rfl)
    _ = Fintype.card Γ * cntL r := by rw [sumA, sumB, cntL]
    _ = Fintype.card Γ * BlockAccounting.histFn Traw r := by rw [cntL_eq]

lemma tz_main (g : Γ) (i : Fin 36) (c : Cp) :
    blockMat (tzL (.inl (g, (i, c)))) = blockMat ((Ab g c).fam (Sx c i)) := by
  unfold tzL
  exact bm_cast (card_Sx c i).symm ((Ab g c).fam (Sx c i))

lemma tz_fresh (g : Γ) (k : Fin 17) (q : Fin 1101) :
    blockMat (tzL (.inr (g, (k, q)))) = blockMat (FH.targ (Dr q)) := by
  unfold tzL
  exact bm_cast (Dr_card q).symm (FH.targ (Dr q))

lemma cert (w : GWord Lb Rl) (hw : ∀ f (y : Dat f), gwalk f w y = wOp f y) :
    MX.GLiveKernelM eL (fun l => blockMat (tzL l)) w := by
  intro f v _ l
  rw [hw]
  rcases l with ⟨g, i, c⟩ | ⟨g, k, q⟩
  · show wOp f v (mR g i c) = matAct f (blockMat (tzL (.inl (g, (i, c))))) (v (mR g i c))
    have e : blockMat (tzL (.inl (g, (i, c)))) = blockMat ((Ab g c).fam (Sx c i)) := tz_main g i c
    rw [e]; exact main_end f v g i c
  · show wOp f v (fR g k q) = matAct f (blockMat (tzL (.inr (g, (k, q))))) (v (fR g k q))
    have e : blockMat (tzL (.inr (g, (k, q)))) = blockMat (FH.targ (Dr q)) := tz_fresh g k q
    rw [e, fresh_end, FH.pk_eq_targ]

theorem rawCert_exists : ∃ (α ρ σ : Type) (_ : Fintype α) (_ : DecidableEq α) (_ : Fintype ρ)
    (_ : DecidableEq ρ) (_ : Fintype σ) (_ : DecidableEq σ),
    ∃ (e : σ → ρ) (tr : σ → ℕ) (tz : ∀ l, Fin (tr l) → Space α) (wd : GWord α ρ) (G : ℕ),
      Function.Injective e ∧ (∀ l, LinearIndependent F (tz l)) ∧ wd.Proper (Fintype.card α) ∧
      MX.GLiveKernelM e (fun l => blockMat (tz l)) wd ∧
      1 ≤ G ∧ Fintype.card α = 137 ∧
      (∀ l, 1 ≤ tr l ∧ tr l ≤ 137) ∧
      (∀ r, (Finset.univ.filter fun l => tr l = r).card = G * BlockAccounting.histFn Traw r) ∧
      (∀ r, wd.hist r = G * BlockAccounting.histFn Praw r) := by
  obtain ⟨w, hP, hc, hw⟩ := route_word
  refine ⟨Lb, Rl, Lv, inferInstance, inferInstance, inferInstance, inferInstance, inferInstance, inferInstance,
    eL, trL, tzL, w, Fintype.card Γ, eL_inj, fun l => ?_, hP, cert w hw, Orth.card_pos, card137, fun l => ?_,
    hcnt, fun r => hist_of_price w _ Praw (fun φ => by rw [hc]; exact wCost_eq φ) r⟩
  · rcases l with p | p
    · exact (OBase.fam_indep _ _).comp _ (Fin.cast_injective _)
    · exact (FH.targ_indep _).comp _ (Fin.cast_injective _)
  · rcases l with p | p
    · exact rk_le _ p.2.1.val p.2.1.2
    · show 1 ≤ rS p.2.2 ∧ rS p.2.2 ≤ 137
      have := rS_le p.2.2; exact ⟨this.1, by omega⟩

end


end OAI.PowerSaving.U7604
