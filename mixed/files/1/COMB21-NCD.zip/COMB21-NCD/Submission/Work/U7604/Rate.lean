import Submission.Work.TensorProto.Strictify
import Submission.Work.BlockAccounting.Moment4
import Submission.Work.BlockAccounting.Sharp
import Submission.Work.U7604.RawLists

namespace TensorProto.U7604
open OAI.PowerSaving.BlockAccounting Finset

@[irreducible] def ofHist (l : List (ℕ × ℕ)) : Multiset ℕ := (l.map fun b => Multiset.replicate b.2 b.1).sum
abbrev TU7604 := OAI.PowerSaving.U7604.Traw
abbrev PU7604 := OAI.PowerSaving.U7604.Praw

lemma ofHist_cons (a : ℕ × ℕ) (l : List (ℕ × ℕ)) :
    ofHist (a :: l) = Multiset.replicate a.2 a.1 + ofHist l := by simp [ofHist]

lemma mom_ofHist (t : ℝ) : ∀ l : List (ℕ × ℕ),
    mom t (ofHist l) = (137:ℝ) ^ t * (l.map fun b => T 137 t b.1 b.2).sum
  | [] => by simp [ofHist, mom]
  | a :: l => by
    rw [ofHist_cons, mom_add, mom_replicate, mom_ofHist t l, List.map_cons, List.sum_cons, mul_add]
    congr 1
    have h : (0:ℝ) < (137:ℝ) ^ t := Real.rpow_pos_of_pos (by norm_num) t
    simp only [T, Nat.cast_ofNat]
    rw [Real.div_rpow (Nat.cast_nonneg _) (by norm_num), mul_comm ((137:ℝ) ^ t), mul_assoc,
      div_mul_cancel₀ _ h.ne']

lemma mom_one : ∀ l : List (ℕ × ℕ), mom 1 (ofHist l) = (l.map fun b => (b.2:ℝ) * b.1).sum
  | [] => by simp [ofHist, mom]
  | a :: l => by
    rw [ofHist_cons, mom_add, mom_replicate, mom_one l, Real.rpow_one, List.map_cons, List.sum_cons]

lemma card_ofHist : ∀ l : List (ℕ × ℕ), Multiset.card (ofHist l) = (l.map Prod.snd).sum
  | [] => by simp [ofHist]
  | a :: l => by simp [ofHist_cons, card_ofHist l]

lemma log_le_es (x L : ℝ) (s n : ℕ) (hx : 0 < x) (hL : 0 ≤ L)
    (h : x ≤ (∑ i ∈ range n, (L/2^s)^i / (i.factorial:ℝ))^(2^s)) : Real.log x ≤ L := by
  have hy0 : 0 ≤ L / 2^s := div_nonneg hL (by positivity)
  have h1 := Real.sum_le_exp_of_nonneg hy0 n
  have h2 : ((2^s : ℕ) : ℝ) * (L / 2^s) = L := by push_cast; field_simp
  have he : Real.exp L = (Real.exp (L / 2^s))^(2^s) := by rw [← Real.exp_nat_mul, h2]
  have h3 : x ≤ Real.exp L := by
    rw [he]
    exact h.trans (pow_le_pow_left₀ (sum_nonneg fun i _ => div_nonneg (pow_nonneg hy0 i) (Nat.cast_nonneg _)) h1 _)
  calc Real.log x ≤ Real.log (Real.exp L) := Real.log_le_log hx h3
    _ = L := Real.log_exp L

lemma up (r n : ℕ) (L q : ℝ) (hr : 0 < r) (hL0 : 0 ≤ L) (hL1 : L ≤ 100)
    (hx : ((137:ℕ):ℝ) / (r:ℝ) ≤ (∑ i ∈ range 12, (L/2^4)^i / (i.factorial:ℝ))^(2^4))
    (hq : (n:ℝ) * ((r:ℝ)/((137:ℕ):ℝ) * (1 + (230:ℝ)/62961*L + ((230:ℝ)/62961*L)^2/2 + ((230:ℝ)/62961*L)^3/6
      + ((230:ℝ)/62961*L)^4*(5/96))) ≤ q) : T 137 (1 - (230:ℝ)/62961) r n ≤ q :=
  term_le4 137 r n _ L q hr (by norm_num) (by norm_num) hL0
    (log_le_es _ L 4 12 (div_pos (by norm_num) (by exact_mod_cast hr)) hL0 hx) (by linarith) hq

lemma lo (r n : ℕ) (L q : ℝ) (hr : 0 < r) (hL0 : 0 ≤ L) (hL1 : L ≤ 16)
    (hx : ((∑ i ∈ range 12, (L/2^4)^i / (i.factorial:ℝ))
        + (L/2^4)^12 * (((12:ℕ):ℝ)+1) / ((((12:ℕ)).factorial:ℝ) * ((12:ℕ):ℝ)))^(2^4) ≤ ((137:ℕ):ℝ) / (r:ℝ))
    (hq : q ≤ (n:ℝ) * ((r:ℝ)/((137:ℕ):ℝ) * (1 + (230:ℝ)/62961*L + ((230:ℝ)/62961*L)^2/2
      + ((230:ℝ)/62961*L)^3/6))) : q ≤ T 137 (1 - (230:ℝ)/62961) r n :=
  term_ge 137 r n _ L q hr (by norm_num) (by norm_num) hL0
    (le_log_of_expbound _ L 4 12 (by norm_num) hL0 (by norm_num; linarith) hx) hq

lemma sumP : (PU7604.map fun b => T 137 (1 - (230:ℝ)/62961) b.1 b.2).sum ≤ (1093208944569/500000000:ℝ) := by
  simp only [PU7604, OAI.PowerSaving.U7604.Praw, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
  refine (add_le_add (up 1 68129 (491998092583/100000000000:ℝ) (126577645867/250000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 2 14450 (422683374527/100000000000:ℝ) (214231414147/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 3 14059 (1910684318581/500000000000:ℝ) (15609454663/50000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 4 3757 (353368656471/100000000000:ℝ) (111118614821/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 5 5899 (827635753349/250000000000:ℝ) (217911432381/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 6 289 (1564110728301/500000000000:ℝ) (12802401839/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 7 187 (1487035388387/500000000000:ℝ) (2414779367/250000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 8 741 (56810787683/20000000000:ℝ) (43721408889/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 9 32 (2722756348493/1000000000000:ℝ) (2123203289/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 16 416 (214739220359/100000000000:ℝ) (9793311829/200000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 24 416 (870963547741/500000000000:ℝ) (73341126347/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 32 416 (145424502303/100000000000:ℝ) (24421363763/250000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 40 416 (307775367929/250000000000:ℝ) (24401464661/200000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 48 416 (524389957461/500000000000:ℝ) (73155653843/500000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 56 416 (447314617547/500000000000:ℝ) (42650107477/250000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (up 64 208 (76109784247/100000000000:ℝ) (97438418133/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (le_refl (0:ℝ)))))))))))))))))).trans (le_of_eq (by norm_num))

lemma sumT : (437283578569/200000000:ℝ) ≤ (TU7604.map fun b => T 137 (1 - (230:ℝ)/62961) b.1 b.2).sum := by
  simp only [TU7604, OAI.PowerSaving.U7604.Traw, List.map_cons, List.map_nil, List.sum_cons, List.sum_nil]
  have h137 : T 137 (1 - (230:ℝ)/62961) 137 208 = 208 := by norm_num [T]
  refine (le_of_eq (by norm_num)).trans (add_le_add (lo 1 306 (4919980925827/1000000000000:ℝ) (2274083543/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 2 357 (4226833745267/1000000000000:ℝ) (2646388049/500000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 3 799 (3821368637159/1000000000000:ℝ) (17742306353/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 4 3825 (3533686564707/1000000000000:ℝ) (113129811307/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 5 1360 (3310543013393/1000000000000:ℝ) (50238946891/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 6 731 (3128221456599/1000000000000:ℝ) (32382545797/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 7 323 (2974070776771/1000000000000:ℝ) (8341965079/500000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 8 544 (2840539384147/1000000000000:ℝ) (32097768449/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 9 10888 (272275634849/100000000000:ℝ) (361209959217/500000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 17 416 (208676758177/100000000000:ℝ) (260077241/5000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 25 416 (850552550479/500000000000:ℝ) (76385614751/1000000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 33 416 (35586834109/25000000000:ℝ) (805814417/8000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 41 416 (603204429561/500000000000:ℝ) (3907694571/31250000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 49 416 (257040156929/250000000000:ℝ) (14934821009/100000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 57 416 (109616207249/125000000000:ℝ) (8681781947/50000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 65 416 (745593655931/1000000000000:ℝ) (7916423093/40000000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (lo 73 208 (314760742339/500000000000:ℝ) (6942955507/62500000:ℝ) (by norm_num) (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial]) (by norm_num))
    (add_le_add (le_of_eq h137.symm)
    (le_refl (0:ℝ))))))))))))))))))))

lemma powb (a x b : ℝ) (v k : ℕ) (hk : 0 < k) (hx : 0 ≤ x) (ha0 : 0 ≤ a) (ha : a ≤ 1 - x)
    (hb : 1 / (1 + v * x / k) ^ k ≤ b) : a ^ v ≤ b := by
  have hk' : (k:ℝ) ≠ 0 := Nat.cast_ne_zero.mpr hk.ne'
  have hy : 0 ≤ (v:ℝ) * x / k := div_nonneg (mul_nonneg (Nat.cast_nonneg v) hx) (Nat.cast_nonneg k)
  have e : (k:ℝ) * ((v:ℝ) * x / k) = v * x := by rw [mul_div_assoc', mul_div_cancel_left₀ _ hk']
  have h1 : a ^ v ≤ Real.exp (-x) ^ v :=
    pow_le_pow_left₀ ha0 (ha.trans (by linarith [Real.add_one_le_exp (-x)])) v
  have h2 : (1 + v * x / k) ^ k ≤ Real.exp (v * x / k) ^ k :=
    pow_le_pow_left₀ (by linarith) (by linarith [Real.add_one_le_exp ((v:ℝ) * x / k)]) k
  have h3 : Real.exp (-x) ^ v * Real.exp (v * x / k) ^ k = 1 := by
    rw [← Real.exp_nat_mul, ← Real.exp_nat_mul, ← Real.exp_add, e]; simp
  calc a ^ v ≤ Real.exp (-x) ^ v := h1
    _ = 1 / Real.exp (v * x / k) ^ k := by rw [eq_div_iff (by positivity), h3]
    _ ≤ 1 / (1 + v * x / k) ^ k := one_div_le_one_div_of_le (pow_pos (by linarith) k) h2
    _ ≤ b := hb

lemma fin (K E SP ST M1 C : ℝ) (hK : 137 * (1 - 230/62961 * (491998092583/100000000000:ℝ)) ≤ K) (hE : 1 + 230/62961 * (2397895272797/1000000000000:ℝ) ≤ E)
    (hSP0 : 0 ≤ SP) (hSP : SP ≤ (1093208944569/500000000:ℝ)) (hST : (437283578569/200000000:ℝ) ≤ ST) (hM1 : M1 = 296156) (hC : C = 22461) :
    (K * SP / (K * ST)) ^ 12800 + 2 * (M1 / (E * (K * ST))) ^ 12800
      + 2 * (C * ((12:ℕ):ℝ) / (E * (K * ST))) ^ 12800 ≤ 1 := by
  have hK0 : 0 < K := lt_of_lt_of_le (by norm_num) hK
  have hE0 : 0 < E := lt_of_lt_of_le (by norm_num) hE
  have hST0 : 0 < ST := lt_of_lt_of_le (by norm_num) hST
  have hD : (1 + 230/62961 * (2397895272797/1000000000000:ℝ)) * (137 * (1 - 230/62961 * (491998092583/100000000000:ℝ)) * (437283578569/200000000:ℝ)) ≤ E * (K * ST) :=
    mul_le_mul hE (mul_le_mul hK hST (by norm_num) hK0.le) (by norm_num) hE0.le
  have hD0 : 0 < E * (K * ST) := mul_pos hE0 (mul_pos hK0 hST0)
  have h1 := powb (K * SP / (K * ST)) (1/10^9) (1 - 12799/10^9) 12800 1 (by norm_num) (by norm_num)
    (div_nonneg (mul_nonneg hK0.le hSP0) (mul_pos hK0 hST0).le)
    (by rw [mul_div_mul_left _ _ hK0.ne', div_le_iff₀ hST0]; linarith) (by norm_num)
  have h2 := powb (M1 / (E * (K * ST))) (18/10000) (1/10^6) 12800 16 (by norm_num) (by norm_num)
    (by rw [hM1]; exact div_nonneg (by norm_num) hD0.le)
    (by rw [hM1, div_le_iff₀ hD0]; linarith) (by norm_num)
  have h3 := powb (C * ((12:ℕ):ℝ) / (E * (K * ST))) (4/100) (1/10^6) 12800 16 (by norm_num) (by norm_num)
    (by rw [hC]; exact div_nonneg (by norm_num) hD0.le)
    (by rw [hC, div_le_iff₀ hD0]; norm_num; linarith) (by norm_num)
  linarith

theorem strict :
    mom (1 - ((230:ℝ)/62961)) (strictP (ofHist TU7604) (ofHist PU7604) 12800 (11 ^ 12800) (12 ^ 12800))
      ≤ mom (1 - ((230:ℝ)/62961)) (strictT (ofHist TU7604) 12800 (12 ^ 12800)) := by
  have hK : 137 * (1 - 230/62961 * (491998092583/100000000000:ℝ)) ≤ (137:ℝ) ^ (1 - (230:ℝ)/62961) := by
    have hl : Real.log 137 ≤ (491998092583/100000000000:ℝ) :=
      log_le_es 137 _ 4 12 (by norm_num) (by norm_num) (by norm_num [sum_range_succ, Nat.factorial])
    rw [Real.rpow_def_of_pos (by norm_num),
      show Real.log 137 * (1 - 230/62961) = Real.log 137 + -(230/62961 * Real.log 137) by ring,
      Real.exp_add, Real.exp_log (by norm_num)]
    linarith [Real.add_one_le_exp (-(230/62961 * Real.log 137))]
  have hE : 1 + 230/62961 * (2397895272797/1000000000000:ℝ) ≤ ((11:ℕ):ℝ) ^ ((230:ℝ)/62961) := by
    have hl : (2397895272797/1000000000000:ℝ) ≤ Real.log ((11:ℕ):ℝ) := le_log_of_expbound _ _ 4 12 (by norm_num) (by norm_num)
      (by norm_num) (by norm_num [sum_range_succ, Nat.factorial])
    rw [Real.rpow_def_of_pos (by norm_num)]
    linarith [Real.add_one_le_exp (Real.log ((11:ℕ):ℝ) * ((230:ℝ)/62961))]
  have hc : (TU7604.map Prod.snd).sum = 22461 := by decide
  have hM : (PU7604.map fun b => (b.2:ℝ) * b.1).sum = 296156 := by
    norm_num [PU7604, OAI.PowerSaving.U7604.Praw]
  have hP0 : 0 ≤ (PU7604.map fun b => T 137 (1 - (230:ℝ)/62961) b.1 b.2).sum := by
    have h := mom_nonneg (1 - (230:ℝ)/62961) (ofHist PU7604)
    rw [mom_ofHist] at h
    by_contra hn
    push_neg at hn
    have := mul_neg_of_pos_of_neg (Real.rpow_pos_of_pos (show (0:ℝ) < 137 by norm_num) (1 - (230:ℝ)/62961)) hn
    linarith
  refine strictify (u := (230:ℝ)/62961) (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num) ?_ ?_
  · rw [mom_ofHist]
    exact mul_pos (Real.rpow_pos_of_pos (by norm_num) _) (lt_of_lt_of_le (by norm_num) sumT)
  · rw [show (1:ℝ) - 230/62961 + 230/62961 = 1 by ring, show (1:ℝ) - (1 - 230/62961) = 230/62961 by ring,
      mom_one, card_ofHist, mom_ofHist, mom_ofHist]
    exact fin _ _ _ _ _ _ hK hE hP0 sumP sumT hM (by rw [hc]; norm_num)

end TensorProto.U7604

