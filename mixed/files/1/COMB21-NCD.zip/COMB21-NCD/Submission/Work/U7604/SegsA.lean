import Submission.Work.U7604.SgCore
import Submission.Work.CtrlAB.A7113

set_option maxHeartbeats 4000000
set_option maxRecDepth 100000

namespace OAI.PowerSaving.U7604

theorem segs_A : segs.flatMap (·.evs true) = CtrlAB.A7113.evs := by decide +kernel

theorem diag_A : CtrlAB.A7113.diag = (List.range 36).map (fun i => 3 + wM ((dTab true).getD i 0) ((nTab true).getD i 0))
    ∧ (List.range 36).all (fun i => decide ((dTab true).getD i 0 + (nTab true).getD i 0 < 17)) = true := by decide +kernel

end OAI.PowerSaving.U7604
