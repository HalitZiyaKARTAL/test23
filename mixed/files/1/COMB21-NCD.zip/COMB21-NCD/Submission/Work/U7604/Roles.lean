import Submission.Work.U7604.Lay
import Submission.Work.MixAB.W7604Glue
import Submission.Work.UnitAB.StageExt
import Submission.Work.UnitAB.ViewGen
import Submission.Work.G17.Lemmas
import Submission.Work.P4L.View
import Submission.Work.P4L.Seg
import Submission.Work.P4L.LamQ
import Submission.Work.P4L.Fresh
import Submission.Work.P4L.CertGen
import Submission.Work.GCert.Chain.Geom
import Submission.Work.CtrlAB.Diag7113
import Submission.Work.Mixed.HeadM1

set_option linter.unusedSectionVars false
set_option linter.unusedVariables false
set_option maxHeartbeats 1000000

namespace OAI.PowerSaving.U7604
open Binary Matrix Finset RAM SS CB RF BC GX GF P4L CtrlAB

noncomputable section

abbrev Lb := LC (Fin 16) (Fin 9) (0 : Fin 9)
abbrev Γ := Orth Lb
abbrev Rg := Fin 36 ⊕ Fin 4
abbrev Oth := (Γ × (Fin 17 × Fin 1101)) ⊕ (Γ × Fin 68)
abbrev Rl := (Γ × Rg × Cp) ⊕ Oth
abbrev Lv := (Γ × (Fin 36 × Cp)) ⊕ (Γ × (Fin 17 × Fin 1101))
abbrev Dat (f : ℕ) := Data Lb Rl f

instance iDΓ : DecidableEq Γ := BC.instDecEqOrthLC
instance iFΓ : Fintype Γ := BC.instFintypeOrthLC
instance iDR : DecidableEq (Γ × Rg × Cp) := @instDecidableEqProd Γ (Rg × Cp) iDΓ inferInstance
instance iDO : DecidableEq Oth :=
  @instDecidableEqSum _ _ (@instDecidableEqProd Γ _ iDΓ inferInstance) (@instDecidableEqProd Γ _ iDΓ inferInstance)
instance iDRl : DecidableEq Rl := @instDecidableEqSum _ _ iDR iDO
instance iFRl : Fintype Rl := inferInstanceAs (Fintype ((Γ × Rg × Cp) ⊕ Oth))

def mR (g : Γ) (i : Fin 36) (c : Cp) : Rl := .inl (g, .inl i, c)
def fR (g : Γ) (k : Fin 17) (q : Fin 1101) : Rl := .inr (.inl (g, (k, q)))
def eL : Lv → Rl
  | .inl (g, (i, c)) => mR g i c
  | .inr p => .inr (.inl p)

lemma eL_inj : Function.Injective eL := by
  rintro (⟨g, i, c⟩ | p) (⟨g', i', c'⟩ | p') h <;> simp_all [eL, mR]

def cl (c : Cp) : Bool := c.isLeft

def rowG (κ : Bool) (P : Rg → Prop) [DecidablePred P] (A B : Rg → Rg) (u v : Rg → ℚ) (o : ℚ) : Matrix Rl Rl ℚ
  | .inl (g, X, c) => if cl c = κ ∧ P X then
      fun r' => (if r' = .inl (g, A X, c) then u X else 0) + (if r' = .inl (g, B X, c) then v X else 0)
    else fun r' => if r' = .inl (g, X, c) then o else 0
  | .inr a => fun r' => if r' = .inr a then o else 0

lemma ratCast_iteQ (P : Prop) [Decidable P] (q : ℚ) : (((if P then q else 0 : ℚ)) : ℂ) = if P then (q : ℂ) else 0 := by
  split_ifs <;> simp

section Abs
variable {ρ : Type} [Fintype ρ] [DecidableEq ρ]

lemma act2 (G : Matrix ρ ρ ℚ) (r a b : ρ) (u v : ℚ)
    (h : G r = fun r' => (if r' = a then u else 0) + (if r' = b then v else 0)) (x : ρ → ℂ) :
    actPoint G x r = (u : ℂ) * x a + (v : ℂ) * x b := by
  unfold actPoint
  rw [h]
  simp only [Rat.cast_add, ratCast_iteQ, add_mul, ite_mul, zero_mul, Finset.sum_add_distrib, Finset.sum_ite_eq',
    Finset.mem_univ, if_true]

lemma act1 (G : Matrix ρ ρ ℚ) (r : ρ) (o : ℚ) (h : G r = fun r' => if r' = r then o else 0) (x : ρ → ℂ) :
    actPoint G x r = (o : ℂ) * x r := by
  unfold actPoint
  rw [h]
  simp only [ratCast_iteQ, ite_mul, zero_mul, Finset.sum_ite_eq', Finset.mem_univ, if_true]

end Abs

attribute [local irreducible] actPoint

section Rows
variable {κ : Bool} {P : Rg → Prop} [DecidablePred P] {A B : Rg → Rg} {u v : Rg → ℚ} {o : ℚ}

lemma rowG_hit (g : Γ) (X : Rg) (c : Cp) (h : cl c = κ ∧ P X) :
    rowG κ P A B u v o (.inl (g, X, c)) = fun r' => (if r' = .inl (g, A X, c) then u X else 0)
      + (if r' = .inl (g, B X, c) then v X else 0) := by
  rw [rowG, if_pos h]

lemma rowG_offL (g : Γ) (X : Rg) (c : Cp) (h : ¬ (cl c = κ ∧ P X)) :
    rowG κ P A B u v o (.inl (g, X, c)) = fun r' => if r' = .inl (g, X, c) then o else 0 := by
  rw [rowG, if_neg h]

lemma rowG_offR (a : Oth) : rowG κ P A B u v o (.inr a) = fun r' => if r' = .inr a then o else 0 := by
  rw [rowG]

lemma row_hit (x : Rl → ℂ) (g : Γ) (X : Rg) (c : Cp) (h : cl c = κ ∧ P X) :
    actPoint (rowG κ P A B u v o) x (.inl (g, X, c)) = (u X : ℂ) * x (.inl (g, A X, c)) + (v X : ℂ) * x (.inl (g, B X, c)) :=
  act2 _ _ _ _ _ _ (rowG_hit g X c h) x

lemma row_off (x : Rl → ℂ) (r : Rl) (h : ∀ g X c, r = .inl (g, X, c) → ¬ (cl c = κ ∧ P X)) :
    actPoint (rowG κ P A B u v o) x r = (o : ℂ) * x r := by
  rcases r with ⟨g, X, c⟩ | a
  · exact act1 _ _ _ (rowG_offL g X c (h g X c rfl)) x
  · exact act1 _ _ _ (rowG_offR a) x

end Rows

attribute [irreducible] rowG

def gLin (κ : Bool) (r z : Rg) (u v o : ℚ) : Matrix Rl Rl ℚ :=
  rowG κ (fun X => X = r) (fun _ => r) (fun _ => z) (fun _ => u) (fun _ => v) o
lemma gLin_eq (κ : Bool) (r z : Rg) (u v o : ℚ) :
    gLin κ r z u v o = rowG κ (fun X => X = r) (fun _ => r) (fun _ => z) (fun _ => u) (fun _ => v) o := rfl
def gAdd (κ : Bool) (t s : Rg) (v : ℚ) : Matrix Rl Rl ℚ := gLin κ t s 1 v 1
lemma gAdd_eq (κ : Bool) (t s : Rg) (v : ℚ) : gAdd κ t s v = gLin κ t s 1 v 1 := rfl
def gMul (κ : Bool) (r : Rg) (v : ℚ) : Matrix Rl Rl ℚ := gLin κ r r v 0 1
lemma gMul_eq (κ : Bool) (r : Rg) (v : ℚ) : gMul κ r v = gLin κ r r v 0 1 := rfl
def gSwp (κ : Bool) (a b : Rg) : Matrix Rl Rl ℚ :=
  rowG κ (fun X => X = a ∨ X = b) (fun X => if X = a then b else a) id (fun _ => 1) (fun _ => 0) 1
lemma gSwp_eq (κ : Bool) (a b : Rg) : gSwp κ a b
    = rowG κ (fun X => X = a ∨ X = b) (fun X => if X = a then b else a) id (fun _ => 1) (fun _ => 0) 1 := rfl

@[reducible] def gOp (G : Matrix Rl Rl ℚ) : ∀ f : ℕ, Dat f → Dat f := fun f => point f (actPoint G)
lemma gOp_apply (G : Matrix Rl Rl ℚ) (f : ℕ) (y : Dat f) (r : Rl) (w : Sky Lb f) :
    gOp G f y r w = actPoint G (fun r => y r w) r := by
  rw [gOp, point]

def gGop (κ : Bool) (r z : Rg) (u₁ u₂ v₁ v₂ : ℚ) : ∀ f : ℕ, Dat f → Dat f :=
  fun f => point f (actPointG (gLin κ r z u₁ v₁ 1) (gLin κ r z u₂ v₂ 0))
lemma gGop_apply (κ : Bool) (r z : Rg) (u₁ u₂ v₁ v₂ : ℚ) (f : ℕ) (y : Dat f) (r' : Rl) (w : Sky Lb f) :
    gGop κ r z u₁ u₂ v₁ v₂ f y r' w = actPointG (gLin κ r z u₁ v₁ 1) (gLin κ r z u₂ v₂ 0) (fun r => y r w) r' := by
  rw [gGop, point]

section GateVals
variable (f : ℕ) (g : Γ) (c : Cp) {κ : Bool}

lemma off_of (hc : cl c = κ) {P : Rg → Prop} {X : Rg} (h : ¬ P X) :
    ∀ g' X' c', (.inl (g, X, c) : Rl) = .inl (g', X', c') → ¬ (cl c' = κ ∧ P X') := by
  intro g' X' c' e ⟨_, hP⟩
  simp only [Sum.inl.injEq, Prod.mk.injEq] at e
  exact h (e.2.1 ▸ hP)

lemma gLinP (x : Rl → ℂ) (hc : cl c = κ) (r z : Rg) (u v o : ℚ) (X : Rg) :
    actPoint (gLin κ r z u v o) x (.inl (g, X, c))
      = if X = r then (u : ℂ) * x (.inl (g, r, c)) + (v : ℂ) * x (.inl (g, z, c)) else (o : ℂ) * x (.inl (g, X, c)) := by
  rw [gLin_eq]
  by_cases h : X = r
  · rw [if_pos h, row_hit (κ := κ) (P := fun X => X = r) (A := fun _ => r) (B := fun _ => z) (u := fun _ => u)
      (v := fun _ => v) (o := o) x g X c ⟨hc, h⟩]
  · rw [if_neg h, row_off (κ := κ) (P := fun X => X = r) (A := fun _ => r) (B := fun _ => z) (u := fun _ => u)
      (v := fun _ => v) (o := o) x _ (off_of g c hc h)]

lemma gLin_offP (x : Rl → ℂ) {r z : Rg} {u v o : ℚ} (r' : Rl) (hr : ∀ g X c, r' = .inl (g, X, c) → cl c ≠ κ) :
    actPoint (gLin κ r z u v o) x r' = (o : ℂ) * x r' := by
  rw [gLin_eq, row_off (κ := κ) (P := fun X => X = r) (A := fun _ => r) (B := fun _ => z) (u := fun _ => u)
    (v := fun _ => v) (o := o) x r' (fun g X c e h => hr g X c e h.1)]

lemma gLin_on (y : Dat f) (X : Rg) (hc : cl c = κ) {r z : Rg} {u v o : ℚ} :
    gOp (gLin κ r z u v o) f y (.inl (g, X, c))
      = if X = r then (u : ℂ) • y (.inl (g, r, c)) + (v : ℂ) • y (.inl (g, z, c)) else (o : ℂ) • y (.inl (g, X, c)) := by
  funext w
  rw [gOp_apply, gLinP g c _ hc]
  by_cases h : X = r
  · rw [if_pos h, if_pos h, Pi.add_apply, Pi.smul_apply, Pi.smul_apply, smul_eq_mul, smul_eq_mul]
  · rw [if_neg h, if_neg h, Pi.smul_apply, smul_eq_mul]

lemma gAdd_on (y : Dat f) (X : Rg) (hc : cl c = κ) {t s : Rg} {v : ℚ} :
    gOp (gAdd κ t s v) f y (.inl (g, X, c)) = y (.inl (g, X, c)) + if X = t then (v : ℂ) • y (.inl (g, s, c)) else 0 := by
  rw [gAdd_eq, gLin_on f g c y X hc]
  by_cases h : X = t
  · rw [if_pos h, if_pos h]; subst h; rw [Rat.cast_one, one_smul]
  · rw [if_neg h, if_neg h, Rat.cast_one, one_smul, add_zero]

lemma gMul_on (y : Dat f) (X : Rg) (hc : cl c = κ) {r : Rg} {v : ℚ} :
    gOp (gMul κ r v) f y (.inl (g, X, c)) = if X = r then (v : ℂ) • y (.inl (g, X, c)) else y (.inl (g, X, c)) := by
  rw [gMul_eq, gLin_on f g c y X hc]
  by_cases h : X = r
  · rw [if_pos h, if_pos h]; subst h; rw [Rat.cast_zero, zero_smul, add_zero]
  · rw [if_neg h, if_neg h, Rat.cast_one, one_smul]

lemma gSwp_on (y : Dat f) (X : Rg) (hc : cl c = κ) {a b : Rg} :
    gOp (gSwp κ a b) f y (.inl (g, X, c)) = if X = a then y (.inl (g, b, c)) else if X = b then y (.inl (g, a, c))
      else y (.inl (g, X, c)) := by
  funext w
  rw [gOp_apply, gSwp_eq]
  by_cases h1 : X = a
  · rw [row_hit (κ := κ) (P := fun X => X = a ∨ X = b) (A := fun X => if X = a then b else a) (B := id)
      (u := fun _ => 1) (v := fun _ => 0) (o := 1) _ g X c ⟨hc, Or.inl h1⟩, if_pos h1]
    simp only [if_pos h1, Rat.cast_one, Rat.cast_zero, one_mul, zero_mul, add_zero]
  · by_cases h2 : X = b
    · rw [row_hit (κ := κ) (P := fun X => X = a ∨ X = b) (A := fun X => if X = a then b else a) (B := id)
      (u := fun _ => 1) (v := fun _ => 0) (o := 1) _ g X c ⟨hc, Or.inr h2⟩, if_neg h1, if_pos h2]
      simp only [if_neg h1, Rat.cast_one, Rat.cast_zero, one_mul, zero_mul, add_zero]
    · rw [row_off (κ := κ) (P := fun X => X = a ∨ X = b) (A := fun X => if X = a then b else a) (B := id)
      (u := fun _ => 1) (v := fun _ => 0) (o := 1) _ _ (off_of g c hc (P := fun X => X = a ∨ X = b) (not_or.mpr ⟨h1, h2⟩)), if_neg h1, if_neg h2,
        Rat.cast_one, one_mul]

lemma gGP (x : Rl → ℂ) (X : Rg) (hc : cl c = κ) {r z : Rg} {u₁ u₂ v₁ v₂ : ℚ} :
    actPointG (gLin κ r z u₁ v₁ 1) (gLin κ r z u₂ v₂ 0) x (.inl (g, X, c)) = if X = r then
      ((u₁ : ℂ) + u₂ * Complex.I) * x (.inl (g, r, c)) + ((v₁ : ℂ) + v₂ * Complex.I) * x (.inl (g, z, c))
      else x (.inl (g, X, c)) := by
  rw [actPointG_eq, gLinP g c _ hc, gLinP g c _ hc]
  by_cases h : X = r
  · rw [if_pos h, if_pos h, if_pos h]; ring
  · rw [if_neg h, if_neg h, if_neg h, Rat.cast_one, Rat.cast_zero, one_mul, zero_mul, mul_zero, add_zero]

lemma gG_val (y : Dat f) (X : Rg) (hc : cl c = κ) {r z : Rg} {u₁ u₂ v₁ v₂ : ℚ} :
    gGop κ r z u₁ u₂ v₁ v₂ f y (.inl (g, X, c)) = if X = r then
      ((u₁ : ℂ) + u₂ * Complex.I) • y (.inl (g, r, c)) + ((v₁ : ℂ) + v₂ * Complex.I) • y (.inl (g, z, c))
      else y (.inl (g, X, c)) := by
  funext w
  rw [gGop_apply, gGP g c _ X hc]
  by_cases h : X = r
  · rw [if_pos h, if_pos h, Pi.add_apply, Pi.smul_apply, Pi.smul_apply, smul_eq_mul, smul_eq_mul]
  · rw [if_neg h, if_neg h]

end GateVals

lemma gG_off {κ : Bool} {r z : Rg} {u₁ u₂ v₁ v₂ : ℚ} (f : ℕ) (y : Dat f) (r' : Rl)
    (hr : ∀ g X c, r' = .inl (g, X, c) → cl c ≠ κ) : gGop κ r z u₁ u₂ v₁ v₂ f y r' = y r' := by
  funext w
  rw [gGop_apply, actPointG_eq, gLin_offP _ r' hr, gLin_offP _ r' hr, Rat.cast_one, Rat.cast_zero, one_mul, zero_mul,
    mul_zero, add_zero]

lemma fixLin {κ : Bool} {r z : Rg} {u v : ℚ} (f : ℕ) (y : Dat f) (r' : Rl)
    (hr : ∀ g X c, r' = .inl (g, X, c) → cl c ≠ κ) : gOp (gLin κ r z u v 1) f y r' = y r' := by
  funext w
  rw [gOp_apply, gLin_offP _ r' hr, Rat.cast_one, one_mul]
lemma fixSwp {κ : Bool} {a b : Rg} (f : ℕ) (y : Dat f) (r' : Rl)
    (hr : ∀ g X c, r' = .inl (g, X, c) → cl c ≠ κ) : gOp (gSwp κ a b) f y r' = y r' := by
  funext w
  rw [gOp_apply, gSwp_eq, row_off (κ := κ) (P := fun X => X = a ∨ X = b) (A := fun X => if X = a then b else a) (B := id)
      (u := fun _ => 1) (v := fun _ => 0) (o := 1) _ r' (fun g X c e h => hr g X c e h.1), Rat.cast_one, one_mul]

-- (the gate lemmas are done: `actPoint` back to its default for the route and everything after)
attribute [local semireducible] actPoint

lemma route_gM (G : Matrix Rl Rl ℚ) : ORoute (α := Lb) (gOp G) (fun _ => 0) := ORoute.localM G

lemma route_gG (gr gi : Matrix Rl Rl ℚ) :
    ORoute (α := Lb) (fun f => point f (actPointG gr gi)) (fun _ => 0) :=
  ⟨[GMove.localG gr gi], fun mv hmv => by rw [List.mem_singleton] at hmv; subst hmv; exact GMove.proper_localG _ gr gi,
    fun φ => by simp [GWord.costR, GMove.costR, GMove.shadow, BMove.costR, BMove.rk?],
    fun f y => by rw [gwalk_cons, gwalk_nil, GMove.act]⟩ -- CHECK: or CRUB2Z's ORoute.localG (P4L) if the bus takes it

def onS (s : Finset Rl) (U : Rl → CMat Lb) (f : ℕ) (y : Dat f) : Dat f :=
  fun r => if r ∈ s then matAct f (U r) (y r) else y r

lemma route_onS (s : Finset Rl) (B : Rl → CMat Lb) (c : Rl → (ℕ → ℝ) → ℝ) (h : ∀ r ∈ s, GStep r 1 (B r) (c r)) :
    ORoute (onS s B) (fun φ => ∑ r ∈ s, c r φ) :=
  (ORoute.steps_inv s (fun _ => 1) (fun _ => 1) B (fun _ _ => mul_one 1) c h).cast
    (fun f y => by funext r; simp only [onS, Matrix.mul_one]) (fun _ => rfl)

lemma route_onS' (s : Finset Rl) (A A' B : Rl → CMat Lb) (hA : ∀ r ∈ s, A r * A' r = 1)
    (c : Rl → (ℕ → ℝ) → ℝ) (h : ∀ r ∈ s, GStep r (A r) (B r) (c r)) :
    ORoute (onS s (fun r => B r * A' r)) (fun φ => ∑ r ∈ s, c r φ) :=
  (ORoute.steps_inv s A A' B hA c h).cast (fun f y => rfl) (fun _ => rfl)

lemma gstep_shiftR {ρ : Type} [Fintype ρ] [DecidableEq ρ] {r : ρ} {M N : CMat Lb} {c : (ℕ → ℝ) → ℝ}
    (h : GStep r M N c) (z : Space Lb) : GStep r M (Binary.shift z * N) c := by
  have h2 : GStep r N (Binary.shift z * N) (fun _ => 0) := by
    obtain ⟨w, U, hw, hc, hU, hwalk⟩ := gstep_shift (α := Lb) r z
    exact ⟨w, U, hw, hc, by rw [show U = Binary.shift z by rw [← hU, Matrix.mul_one]], hwalk⟩
  exact (h.trans h2).cast (fun φ => by simp)

def mS (κ : Bool) (X : Rg) : Finset Rl := (univ.filter fun p : Γ × Cp => cl p.2 = κ).image fun p => .inl (p.1, X, p.2)

lemma mem_mS {κ : Bool} {X : Rg} {r : Rl} : r ∈ mS κ X ↔ ∃ g c, cl c = κ ∧ r = .inl (g, X, c) := by
  simp only [mS, mem_image, mem_filter, mem_univ, true_and]
  constructor
  · rintro ⟨⟨g, c⟩, h, rfl⟩; exact ⟨g, c, h, rfl⟩
  · rintro ⟨g, c, h, rfl⟩; exact ⟨⟨g, c⟩, h, rfl⟩

lemma card_mS (κ : Bool) (X : Rg) : (mS κ X).card = Fintype.card Γ * nK κ := by
  rw [mS, card_image_of_injective _ (fun a b h => by
    obtain ⟨g, c⟩ := a; obtain ⟨g', c'⟩ := b; simp only [Sum.inl.injEq, Prod.mk.injEq] at h
    rw [h.1, h.2.2])]
  rw [show (univ.filter fun p : Γ × Cp => cl p.2 = κ) = (univ : Finset Γ) ×ˢ (univ.filter fun c : Cp => cl c = κ) by
    ext p; simp, card_product, card_univ]
  congr 1
  rw [Finset.card_filter, Fintype.sum_sum_type]
  cases κ <;> simp [cl, nK] -- CHECK: the two constant sums (96 / 8)

attribute [irreducible] mS

abbrev Iv := PWGW7604.ginv

def bz (z : Space (Fin 9)) : OBase (Fin 9) :=
  if h : dot z z = 1 ∧ ∃ p, z p = 0 then Classical.choose (base_ex z h.1 h.2 0) else OBase.canonical _

lemma bz_spec (z : Space (Fin 9)) (h1 : dot z z = 1) (h2 : ∃ p, z p = 0) : z = (bz z).v 0 := by
  rw [bz, dif_pos ⟨h1, h2⟩]; exact Classical.choose_spec (base_ex z h1 h2 0)

def bB (c : Cp) : OBase (Fin 9) := bz (Iv.tv (pT c))
def bT (t : Fin 200) : OBase (Fin 9) := bB (cpT t)

def Ab (g : Γ) (c : Cp) : OBase Lb := BBC (bB c) 0 g

section Alg
variable (f : ℕ) (g : Γ) (c : Cp)

def qq : Sky Lb f → ℂ := prodF f (fr (Ab g c) {Sum.inl 0})
def qI : Sky Lb f → ℂ := prodF f (fun x => (fr (Ab g c) {Sum.inl 0} x)⁻¹)
def sG : Sky Lb f → ℂ := prodF f (fun x => sign (dot ((Ab g c).v (Sum.inl 0)) x))
def LL : Sky Lb f → ℂ := LamQ.lamF (qq f g c)
def DD (j : ℕ) : Sky Lb f → ℂ := prodF f (fr (Ab g c) (G17.incr (0 : Fin 9) (j - 1)))
def V (y : Dat f) (i : ℕ) : Sky Lb f → ℂ := if h : i < 36 then walsh f (y (mR g ⟨i, h⟩ c)) else 0

lemma q4 : qq f g c ^ 4 = 1 := LamQ.prodF_fr_pow4 f _ _
lemma qqi : qq f g c * qI f g c = 1 := q_mul_qi f _ _
lemma qI_eq : qI f g c = qq f g c ^ 3 := by
  have h := qqi f g c
  calc qI f g c = qI f g c * qq f g c ^ 4 := by rw [q4, mul_one]
    _ = qq f g c ^ 3 * (qq f g c * qI f g c) := by ring
    _ = _ := by rw [h, mul_one]
lemma sG_eq : sG f g c = qq f g c ^ 2 := by
  have h1 : qI f g c = qq f g c * sG f g c := qi_split f _ _
  have h := qqi f g c
  calc sG f g c = sG f g c * qq f g c ^ 4 := by rw [q4, mul_one]
    _ = qq f g c ^ 2 * (qq f g c * (qq f g c * sG f g c)) := by ring
    _ = _ := by rw [← h1, h, mul_one]
lemma L2 : LL f g c ^ 2 = qq f g c ^ 2 := LamQ.lamF_sq _ (q4 f g c)

end Alg

section Mono
variable {R : Type*} [CommRing R] [Algebra ℚ R]

lemma dp_win : ∀ (n : ℕ) (D : ℕ → R) (a k : ℕ), a + k ≤ n → dp D n (2 ^ a * (2 ^ k - 1)) = ∏ j ∈ range k, D (a + j)
  | 0, D, a, k, h => by
    obtain ⟨rfl, rfl⟩ : a = 0 ∧ k = 0 := by omega
    rfl
  | n + 1, D, a + 1, k, h => by
    have e1 : 2 ^ (a + 1) * (2 ^ k - 1) = 2 * (2 ^ a * (2 ^ k - 1)) := by ring
    rw [dp, e1, Nat.mul_mod_right, Nat.mul_div_cancel_left _ (by norm_num), dp_win n _ a k (by omega)]
    simp only [show (0 : ℕ) % 2 = 1 ↔ False by decide, if_false, one_mul]
    exact Finset.prod_congr rfl (fun j _ => by rw [show a + 1 + j = a + j + 1 by ring])
  | n + 1, D, 0, 0, h => by rw [show 2 ^ 0 * (2 ^ 0 - 1) = 0 by rfl, dp_zero]; rfl
  | n + 1, D, 0, k + 1, h => by
    have hp : 1 ≤ 2 ^ k := Nat.one_le_two_pow
    have e : 2 ^ 0 * (2 ^ (k + 1) - 1) = 2 * (2 ^ k - 1) + 1 := by rw [pow_succ]; omega
    rw [dp, e, show (2 * (2 ^ k - 1) + 1) % 2 = 1 by omega, show (2 * (2 ^ k - 1) + 1) / 2 = 2 ^ k - 1 by omega,
      if_pos rfl, prod_range_succ']
    have := dp_win n (fun i => D (i + 1)) 0 k (by omega)
    rw [show 2 ^ 0 * (2 ^ k - 1) = 2 ^ k - 1 by simp] at this
    rw [this, mul_comm]
    exact congrArg₂ _ (Finset.prod_congr rfl (fun j _ => by rw [zero_add, zero_add])) rfl

lemma mono_w (q L : R) (D : ℕ → R) (a m : ℕ) (h : a + m < 17) :
    monoV q L D 18 (wM a m) = ∏ j ∈ range (m + 1), D (a + 1 + j) := by
  unfold monoV wM
  rw [show 8 * (2 ^ (a + 1) * (2 ^ (m + 1) - 1)) % 4 = 0 by omega,
    show 8 * (2 ^ (a + 1) * (2 ^ (m + 1) - 1)) / 4 % 2 = 0 by omega,
    show 8 * (2 ^ (a + 1) * (2 ^ (m + 1) - 1)) / 8 = 2 ^ (a + 1) * (2 ^ (m + 1) - 1) by omega,
    dp_win 18 D (a + 1) (m + 1) (by omega)]
  simp

lemma mono_wq (q L : R) (D : ℕ → R) (a m : ℕ) (h : a + m < 17) :
    monoV q L D 18 (3 + wM a m) = q ^ 3 * ∏ j ∈ range (m + 1), D (a + 1 + j) := by
  unfold monoV wM
  rw [show (3 + 8 * (2 ^ (a + 1) * (2 ^ (m + 1) - 1))) % 4 = 3 by omega,
    show (3 + 8 * (2 ^ (a + 1) * (2 ^ (m + 1) - 1))) / 4 % 2 = 0 by omega,
    show (3 + 8 * (2 ^ (a + 1) * (2 ^ (m + 1) - 1))) / 8 = 2 ^ (a + 1) * (2 ^ (m + 1) - 1) by omega,
    dp_win 18 D (a + 1) (m + 1) (by omega)]
  simp

lemma mono_j (q L : R) (D : ℕ → R) (k : ℕ) (h : k < 17) : monoV q L D 18 (8 * 2 ^ (k + 1)) = D (k + 1) := by
  have := mono_w q L D k 0 (by omega)
  rw [show wM k 0 = 8 * 2 ^ (k + 1) by simp [wM]] at this
  rw [this]; simp

lemma mono_L (q L : R) (D : ℕ → R) : monoV q L D 18 4 = L := by simp [monoV, dp_zero]
lemma mono_Lq (q L : R) (D : ℕ → R) : monoV q L D 18 6 = q ^ 2 * L := by simp [monoV, dp_zero]

end Mono

end

end OAI.PowerSaving.U7604
