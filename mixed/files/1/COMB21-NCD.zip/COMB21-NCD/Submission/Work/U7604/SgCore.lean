import Submission.Work.CtrlAB.Pack7113

set_option maxRecDepth 100000

namespace OAI.PowerSaving.U7604
open CtrlAB GXD

inductive Sg where
  | jc (k : Fin 17)
  | add (κ : Bool) (t s : Fin 36) (ng : Bool) (num den : Nat)
  | mul (κ : Bool) (r : Fin 36) (ng : Bool) (num den : Nat)
  | swp (κ : Bool) (a b : Fin 36)
  | lam (κ : Bool) (r : Fin 36) (e : Bool)
  | qsh (κ : Bool) (r : Fin 36)
  | thin (κ : Bool) (j : Fin 4) (t s : Fin 36)
  | idle (κ : Bool) (r : Fin 36) (a m : Nat)
  | idlq (κ : Bool) (r : Fin 36) (a m : Nat)
  deriving DecidableEq

def wM (a m : Nat) : Nat := 8 * (2 ^ (a + 1) * (2 ^ (m + 1) - 1))

def jEvs (κ : Bool) (k : Nat) : List CEv :=
  let M := 8 * 2 ^ (k + 1)
  if κ then [.add 0 1 ⟨false, 1, 1⟩ 3, .mon 1 M, .mon 0 M, .add 19 20 ⟨true, 1, 1⟩ 1, .mon 19 M, .mon 20 M]
  else [.add 1 0 ⟨true, 1, 1⟩ 1, .add 0 1 ⟨false, 1, 2⟩ 3, .mon 1 M, .mon 0 M]

abbrev jEvsA (k : Nat) : List CEv := jEvs true k
abbrev jEvsB (k : Nat) : List CEv := jEvs false k

def Sg.evs : Sg → Bool → List CtrlAB.CEv
  | .jc k, κ => if κ then jEvsA k else jEvsB k
  | .add κ' t s ng num den, κ => if κ' = κ then [.add t.val s.val ⟨ng, num, den⟩ 0] else []
  | .mul κ' r ng num den, κ => if κ' = κ then [.mul r.val ⟨ng, num, den⟩] else []
  | .swp κ' a b, κ => if κ' = κ then [.swp a.val b.val] else []
  | .lam κ' r e, κ => if κ' = κ then [.mon r.val (if e then 4 else 6)] else []
  | .qsh κ' r, κ => if κ' = κ then [.mon r.val 2] else []
  | .thin κ' j t s, κ => if κ' = κ then [.add t.val s.val ⟨false, 1, 1⟩ 3] else []
  | .idle κ' r a m, κ => if κ' = κ then [.mon r.val (wM a m)] else []
  | .idlq κ' r a m, κ => if κ' = κ then [.mon r.val (3 + wM a m)] else []

/-- the word (generated) -/
ctrl_segs

def okS : Sg → Bool
  | .swp _ a b => a != b
  | .idle _ _ a m => decide (a + m < 17)
  | .idlq _ _ a m => decide (a + m < 17) && decide (1 ≤ a)
  | _ => true

def Sg.jk : Sg → Option Nat
  | .jc k => some k.val
  | _ => none

def nTab : Bool → List Nat
  | true => [16,7,6,5,4,3,2,1,0,0,1,2,3,4,5,6,7,8,16,7,6,5,4,3,2,1,0,0,1,2,3,4,5,6,7,8]
  | false => [16,16,7,7,6,6,5,5,4,4,3,3,2,2,1,1,8,8,7,7,6,6,5,5,4,4,3,3,2,2,1,1,0,0,0,0]
def dTab : Bool → List Nat
  | true => [0,0,1,2,3,4,5,6,7,8,8,8,8,8,8,8,8,8,0,0,1,2,3,4,5,6,7,8,8,8,8,8,8,8,8,8]
  | false => [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,8,7,7,8,8]
def rkT (κ : Bool) (i : Nat) : Nat := 1 + 8 * ((nTab κ).getD i 0 + 1)
def nK (κ : Bool) : Nat := if κ then 96 else 8

def bpos : List Nat := [15, 17, 27, 34, 35, 42, 47, 55]
def aPos : List Nat := (List.range 104).filter (fun t => !bpos.contains t)
def idx (x : Nat) : List Nat → Nat
  | [] => 0
  | y :: l => if x = y then 0 else idx x l + 1
def cpN (t : Nat) : Nat := if 104 ≤ t then t - 104 else if bpos.contains t then 96 + idx t bpos else idx t aPos
def hostN (t : Nat) : Bool := decide (104 ≤ t)
def portN (c : Nat) (h : Bool) : Nat := if h then 104 + c else if 96 ≤ c then bpos.getD (c - 96) 0 else aPos.getD c 0

def Sg.blk : Sg → List (Nat × Nat)
  | .thin κ .. => [(1, nK κ)]
  | .idle κ _ _ m => [(8 * (m + 1), nK κ)]
  | .idlq κ _ _ m => [(8 * (m + 1) + 1, nK κ)]
  | _ => []
def Pnat : List (Nat × Nat) := [(1, 3985), (2, 850), (3, 827), (4, 221), (5, 347), (6, 17), (7, 11), (8, 5)]
def Pc : List (Nat × Nat) := [(1, 68129), (2, 14450), (3, 14059), (4, 3757), (5, 5899), (6, 289), (7, 187), (8, 741), (9, 32), (16, 416), (24, 416), (32, 416), (40, 416), (48, 416), (56, 416), (64, 208)]
def ins (b : Nat × Nat) : List (Nat × Nat) → List (Nat × Nat)
  | [] => [b]
  | c :: l => if b.1 = c.1 then (c.1, c.2 + b.2) :: l else if b.1 < c.1 then b :: c :: l else c :: ins b l
def nrm (l : List (Nat × Nat)) : List (Nat × Nat) := l.foldr ins []

end OAI.PowerSaving.U7604
