import Submission.OAI.Computability.FourierTransform.Goal

namespace OAI

namespace PowerSaving
noncomputable section
open RAM RAM.Ty Filter Asymptotics

def statedSavingTB19 : ℝ := 36530550/(10:ℝ)^10

def decimalExponentTB19 : ℝ := 1 - statedSavingTB19

def decimalTimeTB19 (n : ℕ) : ℝ := (n:ℝ) * (Real.log (n:ℝ)) ^ decimalExponentTB19

def TimeBoundsTB19 (W : ℕ → ℕ) : Prop :=
  let W' := fun n : ℕ => (W n : ℝ)
  W' =O[atTop] paperTime ∧ W' =O[atTop] decimalTimeTB19 ∧ W' =o[atTop] nlogn

def DFTGoalTB19 : Prop := ∃ order solve W, DFTProgram order solve W ∧ TimeBoundsTB19 W

def ConvGoalTB19 : Prop := ∃ order solve W, ConvProgram order solve W ∧ TimeBoundsTB19 W

end
end PowerSaving

end OAI
