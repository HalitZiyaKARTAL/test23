import Submission.Work.U7604.Segs

set_option maxRecDepth 100000

namespace OAI.PowerSaving.U7604

abbrev Cp := Fin 96 ⊕ Fin 8

def cN : Cp → Nat
  | .inl a => a.val
  | .inr b => 96 + b.val

def cpT (t : Fin 200) : Cp := if h : cpN t.val < 96 then .inl ⟨cpN t.val, h⟩ else .inr ⟨(cpN t.val - 96) % 8, Nat.mod_lt _ (by decide)⟩
def xT (t : Fin 200) : Fin 36 := if hostN t.val then 19 else 1
def yT (t : Fin 200) : Fin 36 := if hostN t.val then 20 else 0
def pT (c : Cp) : Fin 200 := ⟨portN (cN c) false % 200, Nat.mod_lt _ (by decide)⟩

theorem lay (t : Fin 200) : portN (cpN t.val) (hostN t.val) = t.val ∧ cpN t.val < 104 ∧ (hostN t.val = true → cpN t.val < 96)
    ∧ GXD.W7604.ports.getD t.val 0 = GXD.W7604.ports.getD (portN (cpN t.val) false) 0 := by
  have h := List.all_eq_true.mp lay_ok t.val (List.mem_range.mpr t.2)
  simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq, Bool.or_eq_true, Bool.not_eq_true'] at h
  obtain ⟨⟨⟨h1, h2⟩, h3⟩, h4⟩ := h
  refine ⟨h1, h2, fun hh => ?_, h4⟩
  rcases h3 with h3 | h3
  · rw [hh] at h3; cases h3
  · exact h3

theorem cN_cpT (t : Fin 200) : cN (cpT t) = cpN t.val := by
  have h := (lay t).2.1
  unfold cpT
  by_cases h1 : cpN t.val < 96
  · rw [dif_pos h1]; rfl
  · rw [dif_neg h1]; simp only [cN]; omega

theorem tOf (t : Fin 200) : portN (cN (cpT t)) (hostN t.val) = t.val := by rw [cN_cpT]; exact (lay t).1

theorem xT_host {t t' : Fin 200} (h : xT t = xT t') : hostN t.val = hostN t'.val := by
  unfold xT at h; cases h1 : hostN t.val <;> cases h2 : hostN t'.val <;> simp_all <;> revert h <;> decide
theorem yT_host {t t' : Fin 200} (h : yT t = yT t') : hostN t.val = hostN t'.val := by
  unfold yT at h; cases h1 : hostN t.val <;> cases h2 : hostN t'.val <;> simp_all <;> revert h <;> decide
theorem xT_ne_yT (t t' : Fin 200) : xT t ≠ yT t' := by
  unfold xT yT; cases hostN t.val <;> cases hostN t'.val <;> decide

theorem port_inj {t t' : Fin 200} (hc : cpT t = cpT t') (hh : hostN t.val = hostN t'.val) : t = t' :=
  Fin.ext (by rw [← tOf t, ← tOf t', hc, hh])

def tP (c : Cp) : Fin 200 := pT c
def tH (a : Fin 96) : Fin 200 := ⟨104 + a.val, by omega⟩

theorem tP_spec (c : Cp) : cpT (tP c) = c ∧ hostN (tP c).val = false := by
  have hc := List.all_eq_true.mp copy_ok (cN c) (List.mem_range.mpr (by cases c <;> simp [cN] <;> omega))
  simp only [Bool.and_eq_true, beq_iff_eq, decide_eq_true_eq] at hc
  obtain ⟨⟨h1, h2⟩, h3⟩ := hc
  have e : (tP c).val = portN (cN c) false := by simp [tP, pT, Nat.mod_eq_of_lt h3]
  refine ⟨?_, by rw [e, h2]⟩
  have h4 : cpN (tP c).val = cN c := by rw [e, h1]
  unfold cpT
  cases c with
  | inl a => simp only [h4, cN, a.2, dif_pos]
  | inr b => rw [dif_neg (by rw [h4]; simp [cN])]; congr; simp only [h4, cN]; omega

theorem tH_spec (a : Fin 96) : cpT (tH a) = .inl a ∧ hostN (tH a).val = true := by
  have h : cpN (tH a).val = a.val := by simp [tH, cpN]
  refine ⟨?_, by simp [tH, hostN]⟩
  unfold cpT; rw [dif_pos (by rw [h]; exact a.2)]; congr 1; exact Fin.ext h

theorem regs_A (a : Fin 96) (t : Fin 200) (ht : cpT t = .inl a) : t = tP (.inl a) ∨ t = tH a := by
  cases hh : hostN t.val
  · left; exact port_inj (by rw [ht, (tP_spec _).1]) (by rw [hh, (tP_spec _).2])
  · right; exact port_inj (by rw [ht, (tH_spec a).1]) (by rw [hh, (tH_spec a).2])

theorem regs_B (b : Fin 8) (t : Fin 200) (ht : cpT t = .inr b) : t = tP (.inr b) := by
  cases hh : hostN t.val
  · exact port_inj (by rw [ht, (tP_spec _).1]) (by rw [hh, (tP_spec _).2])
  · exfalso
    have := (lay t).2.2.1 hh
    unfold cpT at ht; rw [dif_pos this] at ht; cases ht

end OAI.PowerSaving.U7604

