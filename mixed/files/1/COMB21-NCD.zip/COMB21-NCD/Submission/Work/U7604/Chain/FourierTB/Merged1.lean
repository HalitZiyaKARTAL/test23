import Submission.Work.U7604.Chain.FourierTB.Goal
import Submission.Work.U7604.Chain.BQTEngine
import Submission.Work.U7604.Raw

-- bos_merge: begin U7604.Chain.FourierTB.Seam
-- round 3 (cut c): OpenAI's FourierTransform/Main.lean and Merged2.lean are no longer in the package; the
-- three lemmas the seam below uses from them are moved here VERBATIM (same names, same namespace and opens).

section


namespace OAI
namespace PowerSaving
noncomputable section

def alphaTB19 : ℝ := 1 - 3653055065/(10:ℝ)^12

theorem alphaTB19_pos : 0 < alphaTB19 := by norm_num [alphaTB19]
theorem alphaTB19_lt : alphaTB19 < 1 := by norm_num [alphaTB19]

lemma envelope_monoTB19 (z : ℝ) (hz : 0 ≤ z) {a b : ℕ} (h : a ≤ b) : envelope z a ≤ envelope z b := by
  unfold envelope
  gcongr

-- `envelope_le` (for `z ≤ 1`) and `envelope_real` (for `0 ≤ z`) already exist: Work/Block/WHT.lean:26, :31.

def hillsTB19 (k : ℕ) := Nat.ceil (((k:ℝ)+1)^alphaTB19)

lemma hillsTB19_pos (k : ℕ) : 1≤hillsTB19 k := envelope_pos alphaTB19 k

lemma hillsTB19_mono {a b : ℕ} (h : a≤b) : hillsTB19 a ≤ hillsTB19 b := envelope_monoTB19 alphaTB19 alphaTB19_pos.le h

lemma hillsTB19_le (k : ℕ) : hillsTB19 k ≤ k+1 := envelope_le alphaTB19 alphaTB19_lt.le k

lemma hillsTB19_real (k : ℕ) : (hillsTB19 k:ℝ) ≤ 2*((k:ℝ)+1)^alphaTB19 := envelope_real alphaTB19 alphaTB19_pos.le k

namespace SeamTB19
open Binary Matrix Finset RAM RAM.Ty
universe U

set_option maxRecDepth 100000 in
theorem engine_TB19 (cl : Paint) (m : Bool) {ι : Type U} (k : ι→ℕ) (v : ∀ i, Bits (k i) → ℂ) :
    Can m (fun i => 2^k i) (simIn cl) (bundle cl)
      (fun i => givenBits cl (k i) (v i)) (fun i => (bits (k i)).tape (ripple (k i) (v i)))
      (fun i => 2^k i*envelope alphaTB19 (k i)) := by
  obtain ⟨α, ρ, σ, i1, i2, i3, i4, i5, i6, e, tr, tz, wd, G, he, hind, hP, hw, hG, hα, htr, hcnt, hhist⟩ :=
    U7604.rawCert_exists
  exact @TensorEng.bqt19_engine_of_rawG α ρ σ i1 i2 i3 i4 i5 i6 e tr tz wd G he hind hP hw hG hα htr hcnt hhist
    alphaTB19 (by norm_num [alphaTB19]) (by norm_num [alphaTB19]) m cl _ k v

end SeamTB19

namespace RAM
open Binary Matrix Ty Finset
universe U

theorem hillsTB19_program (cl : Paint) (m : Bool) {ι : Type U} (k : ι→ℕ)
    (v : ∀ i, Bits (k i) → ℂ) :
    Can m (fun i => 2^k i) (simIn cl) (bundle cl)
      (fun i => givenBits cl (k i) (v i)) (fun i => (bits (k i)).tape (ripple (k i) (v i)))
      (fun i => 2^k i*hillsTB19 (k i)) :=
  SeamTB19.engine_TB19 cl m k v

end RAM

end
end PowerSaving
end OAI

end
-- bos_merge: end U7604.Chain.FourierTB.Seam

-- bos_merge: begin U7604.Chain.FourierTB.SectorAlgorithm
section

namespace OAI

namespace PowerSaving.RAM
open Ty Finset Grove Shard Binary
noncomputable section

universe U V

-- prepare data structure pack (stamped fields plus x entries). Also need original chips tape.
def upholsteryTB19 (n : ℕ) (f : ℕ→Shard) :=
  Tape.tab n fun i => chip (f i)

abbrev ragTyTB19 (cl : Paint) := p chipTy (c cl)

def ragTB19 (n : ℕ) (f : ℕ→Shard) (x : Line) (j : ℕ) :=
  (chip (patch n f j),stow n f x j)

def rollsTB19 (n : ℕ) (f : ℕ→Shard) (x : Line) (j : ℕ) :=
  if (patch n f j).seat=0 then Tape.tab (patch n f j).width (glimpse n f x j)
  else Tape.tab 0 (fun _ => (0:ℂ))

namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι} {q : Bench m κ}
  {cl : Paint} {k l n : ι → ℕ} {x : ι→Line} {f : ι → ℕ→Shard}

-- cost-sensitive use of binary kernel, when input generated within budget
theorem gleamTTB19 (hw : ∀ i,n i=2^k i) (hg : ∀ i,k i≤l i) (hn : b.Nick n) (hk : b.Nick k)
    (hI : b.Moves (fun _ => 0) sc fun _ => Complex.I)
    (hx : b.Moves n (a (c cl)) fun i => Tape.tab (n i) (x i)) :
    b.Moves (fun i => n i*hillsTB19 (l i)) (a (c cl)) fun i =>
      Tape.tab (n i) (gleam (k i) (x i)) := by
  let W i := n i*hillsTB19 (l i)
  let v i (d : Bits (k i)) := x i ((bits (k i)).loc d)
  have ht : Dom W n := Dom.of_le (fun i => Nat.le_mul_of_pos_right _ (hillsTB19_pos _))
  have hx' : b.Moves W (a (c cl)) fun i => (bits (k i)).tape (v i) := by
    refine (hx.weaken ht).congr ?_
    intro i
    refine Layout.verify _ _ 0 (v i) (hw i) ?_
    intro d; rw [Tape.look_tab, hw,ite_eq_left (show (bits (k i)).loc d < 2^k i from (bits _).bd d)]
  have hi := hillsTB19_program cl m k v
  have he : b.Moves W (a (c cl)) fun i => (bits (k i)).tape (ripple (k i) (v i)) := by
    have hu : Small b.size (fun i => 2^k i) := hn.small.mono fun i => (hw i).ge
    have hj : ∀ i, 2^k i*hillsTB19 (k i) ≤ W i := fun i => Nat.mul_le_mul (by rw [hw])
      (hillsTB19_mono (hg i))
    exact Can.then_do ((hk.close.ease W).pair ((hI.ease W).pair hx')) ((hi.ambient hu).mono hj)
  refine he.congr ?_
  intro i; symm
  apply Layout.verify _ _ 0 (ripple (k i) (v i)) (hw i)
  intro d
  rw [Tape.look_tab, hw,ite_eq_left (show (bits (k i)).loc d < 2^k i from (bits _).bd d)]
  exact gleam_loc _ _ d

structure MattingTB19 (b : Bench m ι) (n l : ι→ℕ) (f : ι → ℕ→Shard) : Prop where
  length : b.Nick n
  shape : ∀ i, Quilt (n i) (l i) (f i)
  cover : b.Moves (fun _ => 0) (a chipTy) fun i => upholsteryTB19 (n i) (f i)

namespace MattingTB19
variable {j : ι→ℕ}

lemma transfer {n l : κ→ℕ} {f : κ→ℕ→Shard} (h : q.MattingTB19 n l f) {p}
    (g : b.Instant q p) :
    b.MattingTB19 (fun i => n (p i)) (fun i => l (p i)) (fun i => f (p i)) :=
  ⟨h.length.transfer g,fun _ => h.shape _,h.cover.transfer g⟩

lemma kitOf (h : b.MattingTB19 n l f) (hj : b.Nick j) (hg : ∀ i,j i<n i) :
    b.Kit fun i => f i (j i) :=
  Kit.grab h.length.small (fun i => (h.shape i).mark _ (hg i))
    (Moves.pick (n:=n) (t:=chipTy) _ h.cover hj.close hg)

lemma packT (h : b.MattingTB19 n l f)
    (hx : b.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab (n i) (x i)) :
    b.Moves n (a (ragTyTB19 cl)) fun i => Tape.tab (n i) (ragTB19 (n i) (f i) (x i)) := by
  let Tchip (i : ι) (j : ℕ) : T (ragTyTB19 cl) := (chip (f i j),x i j) -- τ?
  have F := Instant.scan b n
  have hh := chop h.length
  have hp := (h.transfer F).kitOf hh During.hj
  have hs : (b.scan n).Moves (fun _ => 0) (c cl) fun i => x i.i i.j :=
    Moves.pick (n:=fun i => n i.i) (t:=c cl) _ (hx.transfer F) hh.close During.hj
  have ht := scatterNow (t:=ragTyTB19 cl) h.length
    (fun i j => ((f i j).addr,Tchip i j)) (hp.addr.close.pair (hp.lend.pair hs))
  exact ht.congr (fun i => (h.shape i).reloc.sow (Tchip i) _)

end MattingTB19

variable (cl) in
structure WeftTB19 (b : Bench m ι) (n l : ι→ℕ) (f : ι → ℕ→Shard) (x : ι → Line) : Prop where
  mat : b.MattingTB19 n l f
  packed : b.Moves (fun _ => 0) (a (ragTyTB19 cl)) fun i =>
    Tape.tab (n i) (ragTB19 (n i) (f i) (x i))
  unitI : b.Moves (fun _ => 0) sc fun _ => Complex.I

namespace WeftTB19
variable {j : ι→ℕ}

lemma transfer {n l : κ→ℕ} {f : κ→ℕ→Shard} {x : κ→Line}
    (h : q.WeftTB19 cl n l f x) {p} (g : b.Instant q p) :
    b.WeftTB19 cl (fun i => n (p i)) (fun i => l (p i)) (fun i => f (p i)) (fun i => x (p i)) :=
  ⟨h.mat.transfer g,h.packed.transfer g,h.unitI.transfer g⟩

lemma kitOf (h : b.WeftTB19 cl n l f x) (hj : b.Nick j) (hg : ∀ i,j i<n i) :
    b.Kit fun i => patch (n i) (f i) (j i) :=
  Kit.grab h.mat.length.small (fun i => (h.mat.shape i).patch_mark (hg i))
    (Moves.pick (n:=n) (t:=ragTyTB19 cl) _ h.packed hj.close hg).fst
lemma stowOf (h : b.WeftTB19 cl n l f x) (hj : b.Nick j) (hg : ∀ i,j i<n i) :
    b.Moves (fun _ => 0) (c cl) fun i => stow (n i) (f i) (x i) (j i) :=
  (Moves.pick (n:=n) (t:=ragTyTB19 cl) _ h.packed hj.close hg).snd

-- rollsTB19 at a sector start.
lemma shine (h : b.WeftTB19 cl n l f x) (hj : b.Nick j) (hg : ∀ i,j i<n i)
    (hz : ∀ i,(patch (n i) (f i) (j i)).seat=0) :
    b.Moves (fun i => seatfare (n i) (f i) (j i) * hillsTB19 (l i)) (a (c cl))
      fun i => rollsTB19 (n i) (f i) (x i) (j i) := by
  let B i := patch (n i) (f i) (j i)
  let Q i := (B i).width
  have HK := h.kitOf hj hg
  have he (i : ι) : (B i).Mark (n i) (l i) := (h.mat.shape i).patch_mark (hg i)
  have hh (i : ι) : j i+Q i ≤ n i := by
    have A : (B i).tip ≤ n i := (he i).endsBy
    have hx : (B i).addr=j i := (h.mat.shape i).patch_addr (hg i)
    have hy : (B i).seat=0 := hz i
    unfold tip at A; unfold addr at hx; dsimp only [Q]; omega
  let S i := slit (n i) (f i) (x i) (j i)
  have ht : b.Moves Q (a (c cl)) fun i => Tape.tab (Q i) (S i) := by
    have F := Instant.scan b Q
    have hi := chop HK.widths
    have hw := (hj.transfer F).add hi
    exact arrayNow HK.widths (t:=c cl) S ((h.transfer F).stowOf hw fun i =>
      lt_of_lt_of_le (Nat.add_lt_add_left i.hj _) (hh _))
  simp only [seatfare,rollsTB19,hz,ite_true]
  exact gleamTTB19 (fun i => (he i).size) (fun i => (he i).tall)
    HK.widths HK.tall h.unitI ht

lemma arrays (h : b.WeftTB19 cl n l f x) :
    b.Moves (fun i => n i*hillsTB19 (l i)) (a (a (c cl)))
      fun i => Tape.tab (n i) (rollsTB19 (n i) (f i) (x i)) := by
  let W (i : ι) := n i*hillsTB19 (l i)
  let D := b.scan n
  let C (i : ι) j := seatfare (n i) (f i) j*hillsTB19 (l i)
  let Y (i : ι) := rollsTB19 (n i) (f i) (x i)
  have hn := h.mat.length
  have F := Instant.scan b n
  have hk := h.transfer F
  have hs := chop hn
  have hb := (hk.kitOf hs During.hj).seat
  have ht : D.Moves (fun d => C d.i d.j) (a (c cl)) fun d => Y d.i d.j := by
    let Q (i : During n) := (patch (n i.i) (f i.i) i.j).seat
    refine inspectz (n:=Q) hb ?_ ?_
    · have ha := Instant.along D (Subtype.val (p:=fun i => Q i=0))
      exact (hk.transfer ha).shine (hs.transfer ha) (fun i => i.val.hj)
        (fun i => i.property)
    · let A := {i // Q i ≠ 0}
      let M := D.along (Subtype.val (p:=fun i => Q i≠0))
      have hh := arrayNow (b:=M) (t:=c cl) (Nick.wc 0) (fun _ _ => 0) Moves.zero
      refine (hh.weaken (Dom.const _ _)).congr ?_
      intro i
      have hB : Q i.val ≠ 0 := i.property
      simp only [Q] at hB
      simp only [Y,rollsTB19,hB,↓reduceIte]
  have he := arrayM (t:=a (c cl)) hn Y ht (u:=C)
  refine he.weaken ?_
  refine ⟨3,fun i => ?_⟩
  dsimp only [C]
  rw [← sum_mul, fare_sum _ _ _ (h.mat.shape i)]
  have hm := Nat.le_mul_of_pos_right (n i) (hillsTB19_pos (l i))
  omega

lemma woven (h : b.WeftTB19 cl n l f x) :
    b.Moves (fun i => n i*hillsTB19 (l i)) (a (c cl))
      fun i => Tape.tab (n i) fun j =>
        glimpse (n i) (f i) (x i) (f i j).start (f i j).seat := by
  let W i := n i*hillsTB19 (l i)
  let T i := rollsTB19 (n i) (f i) (x i)
  let V i := Tape.tab (n i) (T i)
  let D := b.extend (a (a (c cl))) V
  have F := Instant.extend b (t:=a (a (c cl))) V
  have G := Instant.scan D n
  have HK : Dom W n := Dom.of_le (fun i => Nat.le_mul_of_pos_right _ (hillsTB19_pos _))
  let B (d : During n) := f d.i d.j
  have hn := (h.mat.length.transfer F)
  have hh := (h.mat.transfer (G.next F)).kitOf (chop hn) During.hj
  have hg (d : During n) := (h.mat.shape d.i).mark d.j d.hj
  have hm (d : During n) : (B d).start < n d.i := (hg d).starts.trans_le (hg d).endsBy
  have ht := Moves.pick (t:=a (c cl)) (n:=fun d : During n => n d.i) (fun d j => T d.i j)
    ((cherry (W:=fun _ => 0) b (t:=a (a (c cl))) V).transfer G)
    hh.starts.close hm
  have he (d : During n) :
      T d.i (B d).start = Tape.tab (B d).width
        (glimpse (n d.i) (f d.i) (x d.i) (B d).start) := by
    have hM := (h.mat.shape d.i).patch_align d.hj (le_refl (B d).start) (hg d).starts
    have he : (patch (n d.i) (f d.i) (B d).start).seat=0 := hM.2.trans (Nat.sub_self _)
    simp only [T,rollsTB19,he,ite_true]
    rw [hM.1.2.1]
  have hj := Moves.pick (b:=D.scan n) (n:=fun d => (B d).width) (t:=c cl)
    (fun d => glimpse (n d.i) (f d.i) (x d.i) (B d).start) (ht.congr he) hh.seat.close
    (fun d => (hg d).place)
  exact caseM h.arrays ((arrayNow (t:=c cl) hn (fun i j => glimpse (n i) (f i) (x i) (f i j).start (f i j).seat) hj).weaken HK)

end WeftTB19

lemma MattingTB19.cardT (h : b.MattingTB19 n l f)
    (hx : b.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab (n i) (x i))
    (hI : b.Moves (fun _ => 0) sc fun _ => Complex.I) :
    b.Moves (fun i => n i*hillsTB19 (l i)) (a (c cl))
      fun i => Tape.tab (n i) fun j =>
        glimpse (n i) (f i) (x i) (f i j).start (f i j).seat := by
  let V i := Tape.tab (n i) (ragTB19 (n i) (f i) (x i))
  let D := b.extend (a (ragTyTB19 cl)) V
  have F := Instant.extend b (t:=a (ragTyTB19 cl)) V
  have hk : D.WeftTB19 cl n l f x := ⟨h.transfer F,cherry (t:=a (ragTyTB19 cl)) b V,hI.transfer F⟩
  refine caseM ((h.packT hx).weaken (Dom.of_le (fun i =>
    Nat.le_mul_of_pos_right _ (hillsTB19_pos _)))) hk.woven

end Bench
end
end PowerSaving.RAM

end OAI

end
-- bos_merge: end U7604.Chain.FourierTB.SectorAlgorithm

-- bos_merge: begin U7604.Chain.FourierTB.SynchronizedAlgorithm
section

namespace OAI

namespace PowerSaving.RAM
open Ty Finset Grove Slant
noncomputable section

universe U V
namespace Bench
variable {m : Bool} {ι : Type U} {κ : Type V} {b : Bench m ι} {q : Bench m κ}
  {cl : Paint} {l d : ι → ℕ} {r : ι→Axes} {u : ι→ℕ→Stroke} {x : ι→Line}

lemma tapeCongrTB19 {α : Type*} (n : ℕ) (x y : ℕ → α) (h : ∀ i<n,x i=y i) :
    Tape.tab n x=Tape.tab n y := by
  unfold Tape.tab
  congr 1
  funext i; exact h _ i.isLt

namespace Bough

theorem waterTB19 (h : b.Bough l r u) (hI : b.Moves (fun _ => 0) sc fun _ => Complex.I)
    (hx : b.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab (extent (r i) (l i)) (x i)) :
    b.Moves (fun i => extent (r i) (l i)*hillsTB19 (l i)) (a (c cl)) fun i =>
      Tape.tab (extent (r i) (l i))
        (graft (extent (r i) (l i)) (Grove.canopy (r i) (fun j => leafC (u i j)) (l i)) (x i)) := by
  let n i := extent (r i) (l i)
  let V i := mosaic (r i) (u i) (l i)
  let Y i := upholsteryTB19 (n i) (V i)
  let D := b.extend (a chipTy) Y
  have F := Instant.extend b Y (t:=a chipTy)
  have hn : b.Nick n := ⟨hx.len h.fen.span,h.fen.span⟩
  have he : D.MattingTB19 n l V :=
    ⟨hn.transfer F,fun i => mosaic_quilt _ _ _ (h.fen.good i) (h.good i),
      cherry b Y (t:=a chipTy)⟩
  have hd : Dom (fun i => n i*hillsTB19 (l i)) n :=
    Dom.of_le (fun i => Nat.le_mul_of_pos_right _ (hillsTB19_pos _))
  have ht := caseM (h.bedding.weaken hd) (he.cardT (hx.transfer F) (hI.transfer F))
  exact ht.congr fun i => tapeCongrTB19 (n i) _ _ fun j hj =>
    (graft_glimpse _ _ _ (h.fen.good i) (h.good i) _ _ hj).symm

theorem swellTB19 (h : b.Bough l r u) (hI : b.Moves (fun _ => 0) sc fun _ => Complex.I)
    (hx : b.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab (extent (r i) (l i)) (x i)) :
    b.Moves (fun i => extent (r i) (l i)*hillsTB19 (l i)) (a (c cl)) fun i =>
      Tape.tab (extent (r i) (l i))
        (graft (extent (r i) (l i)) (Grove.canopy (r i) (fun j => leafC (u i j)) (l i))
          (graft (extent (r i) (l i)) (Grove.canopy (r i) (fun j => leafM (u i j)) (l i))
            (x i))) := by
  let n i := extent (r i) (l i)
  let f i := graft (n i) (Grove.canopy (r i) (fun j => leafM (u i j)) (l i)) (x i)
  let y i := Tape.tab (n i) (f i)
  let D := b.extend (a (c cl)) y
  have F := Instant.extend b y (t:=a (c cl))
  have ht := (h.transfer F).waterTB19 (x:=f) (hI.transfer F)
    (cherry b y (t:=a (c cl)))
  exact caseM ((h.glean cl x hx).weaken (Dom.of_le (fun i => Nat.le_mul_of_pos_right _
    (hillsTB19_pos _)))) ht
end Bough

structure ThicketTB19 (b : Bench m ι) (l d : ι→ℕ) (r : ι→Axes) (u : ι → ℕ → Reel) : Prop where
  fen : b.Fen l r
  beats : b.Nick d
  sounds : ∀ i, ∀ j<l i, (u i j).Sound (r i j)
  length : ∀ i, ∀ j<l i, (u i j).beats=d i
  atlas : b.Moves (fun _ => 0) (a treeTy) fun i =>
    Tape.tab (l i) fun j => treeT (r i j) (u i j)

variable {pV : ι → ℕ → Reel}
namespace ThicketTB19

lemma transfer {l d : κ→ℕ} {r : κ→Axes} {u : κ → ℕ→Reel} (h : q.ThicketTB19 l d r u)
    {f} (g : b.Instant q f) :
    b.ThicketTB19 (fun i => l (f i)) (fun i => d (f i)) (fun i => r (f i)) (fun i => u (f i)) :=
  ⟨h.fen.transfer g,h.beats.transfer g,fun _ => h.sounds _,fun _ => h.length _,
    h.atlas.transfer g⟩

lemma digitize (h : b.ThicketTB19 l d r pV) {t} (ht : b.Nick t) (hk : ∀ i,t i<d i) :
    b.Bough l r (fun i j => (pV i j).atBeat (t i)) := by
  let T i j := treeT (r i j) (pV i j)
  let D := b.scan l
  have F := Instant.scan b l
  have hh (i : During l) : t i.i < (pV i.i i.j).beats := by rw [h.length _ _ i.hj]; exact hk _
  refine ⟨h.fen,fun i => h.sounds i.i i.j i.hj (t i.i) (hh i),?_⟩
  have hx := Moves.pick (t:=treeTy) (n:=fun i : During l => l i.i)
    (fun i => T i.i) (h.atlas.transfer F) (chop h.fen.high).close During.hj
  exact Moves.pick (t:=leafTy) (n:=fun i => (pV i.i i.j).beats) _ hx (ht.transfer F).close hh

theorem conduct (h : b.ThicketTB19 l d r pV) (hI : b.Moves (fun _ => 0) sc fun _ => Complex.I)
    (hx : b.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab (extent (r i) (l i)) (x i)) :
    b.Moves (fun i => d i* (extent (r i) (l i)*hillsTB19 (l i)))
      (a (c cl)) fun i => Tape.tab (extent (r i) (l i))
        (forest (r i) (l i) (pV i) (x i) (d i)) := by
  let n i := extent (r i) (l i)
  let T i := forest (r i) (l i) (pV i) (x i)
  let A i j := Tape.tab (n i) (T i j)
  have F := Instant.climbs b d (t:=a (c cl)) A
  have ht := (h.transfer F).digitize (stride h.beats (t:=a (c cl)) A) During.hj
  have he := ht.swellTB19 (x:=fun i => T i.i i.j) (hI.transfer F) (tokenNow b d (t:=a (c cl)) A)
  have hu := repeatM h.beats A hx he (u:=fun i _ => n i*hillsTB19 (l i)) (t:=a (c cl))
  refine hu.weaken ?_
  refine ⟨2,fun i => ?_⟩
  have hh := Nat.le_mul_of_pos_right (d i) (Nat.mul_pos (h.fen.good i).extent_pos
    (hillsTB19_pos (l i)))
  simp only [sum_const,card_range,smul_eq_mul]
  unfold n
  omega

theorem stream (h : b.ThicketTB19 l d r pV) (hI : b.Moves (fun _ => 0) sc fun _ => Complex.I)
    (hx : b.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab (extent (r i) (l i)) (x i))
    (X : ι→ℕ→Wood) (hg : ∀ i, ∀ j<l i, Creates (pV i j) (r i j) (Grove.frame _ (X i j))) :
    b.Moves (fun i => d i*(extent (r i) (l i)*hillsTB19 (l i)))
      (a (c cl)) fun i => Tape.tab (extent (r i) (l i))
        (graft (extent (r i) (l i)) (Grove.canopy (r i) (X i) (l i)) (x i)) :=
  (h.conduct hI hx).congr fun i =>
    tapeCongrTB19 _ _ _ fun j hj => forest_completes (r i) (l i) (pV i) (h.fen.good i)
      (d i) (h.sounds i) (h.length i) (X i) (hg i) (x i) j hj

end ThicketTB19
end Bench
end
end PowerSaving.RAM

end OAI

end
-- bos_merge: end U7604.Chain.FourierTB.SynchronizedAlgorithm

-- markers of the former modules U7604/Chain/TB/Stmt.lean and U7604/Chain/TB/Engine.lean (their text is folded into `SeamTB19.engine_TB19` above)




