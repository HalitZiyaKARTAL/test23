import Submission.Work.U7604.Chain.FourierTB.WorkingTransform


-- bos_merge: begin U7604.Chain.FourierTB.WorkingCompiler
section

namespace OAI

namespace PowerSaving.RAM
open Ty Slant Grove Spectral
noncomputable section

universe U V
namespace Bench
variable {m : Bool} {ι : Type U} {b : Bench m ι}
  {cl : Paint} {l e S : ι→ℕ} {r : ι→Axes} {x : ι→Line} {z : ι→ℂ}

-- choose dyadic root canonical always
def halosTB19 : Line := fun i => root (2^i)

lemma haloSpringsTB19 (n : ℕ) : Springs n halosTB19 :=
  fun i _ => root_primitive _ (by positivity)

abbrev forgeTyTB19 :=
  p w (p w (p (a w) (p sc (p (a sc) (a sc)))))

def forgeTB19 (l e : ℕ) (r : Axes) (z : ℂ) : T forgeTyTB19 :=
  (l, e, Tape.tab l r, Complex.I,Tape.tab (e+1) halosTB19,
    Tape.tab l fun i => spray z (extent r l) (r i))

def teamsTB19 (r : Axes) (l e : ℕ) (z : ℂ) : ℕ→Reel :=
  fun i => ballad (r i) e (spray z (extent r l) (r i)) halosTB19

abbrev kilnTyTB19 := p w (a treeTy)
def kilnTB19 (r : Axes) (l e : ℕ) (z : ℂ) : T kilnTyTB19 :=
  (score e,Tape.tab l fun i => treeT (r i) (teamsTB19 r l e z i))

-- readiness read off the forge table, on any bench that holds it
lemma forgeNickTB19 (hP : b.Moves (fun _ => 0) forgeTyTB19 fun i => forgeTB19 (l i) (e i) (r i) (z i))
    (ha : Small b.size l) (hs : Small b.size fun i => 2^e i) (hl : ∀ i, ∀ j<l i, r i j ≤ 2^e i) :
    b.Nick l ∧ b.Arch e ∧ (b.scan l).Nick fun d => r d.i d.j :=
  have hL : b.Nick l := ⟨hP.fst,ha⟩
  have hE : b.Nick e := ⟨hP.snd.fst,hs.mono fun i => Nat.lt_two_pow_self.le⟩
  ⟨hL,Arch.fromSmall hE.digit hs,
    Moves.pick (t:=w) (n:=fun i : During l => l i.i) (fun i => r i.i)
      (hP.snd.snd.fst.transfer (Instant.scan b l)) (chop hL).close During.hj,
    (hs.reindex During.i).mono fun d => hl d.i d.j d.hj⟩

-- combine once after change of base; computation includes preliminary forgeTB19 print
theorem effuseTB19 (h : ∀ i, Isles (r i) (l i)) (hl : ∀ i, ∀ j<l i, r i j≤2^e i)
    (hz : ∀ i, IsPrimitiveRoot (z i) (extent (r i) (l i)))
    (h1 : Small S l) (h2 : Small S fun i => 2^e i)
    (h3 : Small b.size S) (h4 : Small b.size fun i => extent (r i) (l i))
    (hp : PolyCan m b.size S b.tray forgeTyTB19 b.env fun i => forgeTB19 (l i) (e i) (r i) (z i))
    (hx : b.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab (extent (r i) (l i)) (x i)) :
    ∃ d : ℕ,
    b.Moves (fun i => (score (e i)+1)*(extent (r i) (l i)*hillsTB19 (l i)) + (S i+2)^d)
      (a (c cl)) fun i => Tape.tab (extent (r i) (l i))
        (freq (extent (r i) (l i)) (z i) (x i)) := by
  let n i := extent (r i) (l i)
  let f i := forgeTB19 (l i) (e i) (r i) (z i)
  let D := b.extend forgeTyTB19 f
  -- the same environment, measured by S
  let q : Bench m ι := ⟨S,D.tray,D.env⟩
  have F0 := Instant.extend b f
  have hq : q.Moves (fun _ => 0) forgeTyTB19 f := cherry (Bench.mk (m:=m) S b.tray b.env) f (t:=forgeTyTB19)
  obtain ⟨qL,qA,qR⟩ := forgeNickTB19 hq h1 h2 hl
  have hT : q.Digit fun i => score (e i) := ((Digit.wc 2).mul (chorus_digit qA)).add (Digit.wc 7)
  -- twiddle trees on the slim bench (`publish`)
  have hK : q.Makes kilnTyTB19 fun i => kilnTB19 (r i) (l i) (e i) (z i) := by
    have hP : q.Makes forgeTyTB19 f := PolyCan.of_can hq (Small.const _ 0)
    have F := Feeds.scan q l
    have ht := slot qL.digit
    let z' (d : During l) := spray (z d.i) (extent (r d.i) (l d.i)) (r d.i d.j)
    have he (i : During l) : 0<r i.i i.j :=
      lt_of_lt_of_le (by norm_num) ((h _).good i.j i.hj)
    have hg (d : During l) : IsPrimitiveRoot (z' d) (r d.i d.j) :=
      spray_axis (h _) (hz _) _ d.hj
    have hh : (q.scan l).Hue z' :=
      Hue.of_root (Makes.pick (t:=sc) (n:=fun i : During l => l i.i) (fun i j => spray (z i.i) (extent (r i.i) (l i.i)) (r i.i j))
        (pull F hP.snd.snd.snd.snd.snd) ht.run During.hj) he (fun i => (hg i).pow_eq_one)
    let y i := e i+1
    have H := Feeds.scan q y
    have hu : q.Fabric y (fun _ => halosTB19) :=
      Hue.of_root (n:=fun d : During y => 2^d.j)
        (Makes.pick (t:=sc) (n:=fun d => y d.i)
          (fun d : During y => halosTB19) (pull H hP.snd.snd.snd.snd.fst)
          (slot (qA.ep.add (Digit.wc 1))).run During.hj)
        (fun _ => by positivity) (fun i => (haloSpringsTB19 i.j _ le_rfl).pow_eq_one)
    have hk := publish (qA.transfer F) qR.digit he (fun d => hl _ _ d.hj)
      (hu.transfer F) (fun i => haloSpringsTB19 _) hh hg (Hue.letterI (pull F hP.snd.snd.snd.fst))
    exact hT.run.pair (tab (t:=treeTy) qL.digit _ hk.tree)
  obtain ⟨d,hd⟩ := hp
  obtain ⟨a,hA⟩ := hK
  let V i := kilnTB19 (r i) (l i) (e i) (z i)
  let K := D.extend kilnTyTB19 V
  have F := Instant.extend D V (t:=kilnTyTB19)
  have hF : K.Moves (fun _ => 0) forgeTyTB19 f := (cherry (W:=fun _ => 0) b f).transfer F
  obtain ⟨kL,-,kR⟩ := forgeNickTB19 hF (h1.trans h3) (h2.trans h3) hl
  have hk := cherry D V (t:=kilnTyTB19) (W:=fun _ => 0)
  have ht : K.ThicketTB19 l (fun i => score (e i)) r fun i => teamsTB19 (r i) (l i) (e i) (z i) :=
    ⟨⟨kL,fun i => (h i).good,h4,kR⟩,⟨hk.fst,hT.small.trans h3⟩,
      fun i j hj => sound_ballad _ _ _ _ (hl i j hj),fun _ _ _ => beats_ballad _ _ _ _,hk.snd⟩
  let R i := (score (e i)+1)*(n i*hillsTB19 (l i))
  let W i := R i+(S i+2)^(d+a)
  have hr : K.Moves R (Ty.a (c cl)) fun i => Tape.tab (n i) (freq (n i) (z i) (x i)) :=
    ht.traverse h hz (fun i j hj => creates_ballad _ _ _ _ (hl i j hj) (haloSpringsTB19 _)
      (spray_axis (h _) (hz i) _ hj)) hF.snd.snd.snd.fst (hx.transfer (F.next F0))
  have hd' : b.Moves W forgeTyTB19 f := hd.mono (fun i => le_trans
    (Small.pow_mono_degree _ (show d≤d+a by omega)) (Nat.le_add_left _ _))
  have hA' : D.Moves W kilnTyTB19 V := (Can.ambient hA h3).mono (fun i => le_trans
    (Small.pow_mono_degree (S i) (show a≤d+a by omega)) (Nat.le_add_left _ _))
  exact ⟨d+a,caseM hd' (caseM hA' (hr.weaken (Dom.of_le fun i => Nat.le_add_right _ _)))⟩

end Bench
end
end PowerSaving.RAM

end OAI

end
-- bos_merge: end U7604.Chain.FourierTB.WorkingCompiler

-- bos_merge: begin U7604.Chain.FourierTB.WorkingPreparation
section

namespace OAI

namespace PowerSaving.RAM
open Ty Selection Grove Spectral
noncomputable section

namespace Bench
universe U V
variable {ι : Type U} {κ : Type V} {m : Bool} {b : Bench m ι} {q : Bench m κ}
  {n k S : ι→ℕ} {t : Ty}

-- count halving powers
abbrev shiftTyTB19 := p w (p sc sc)
def shiftPTB19 (n : ℕ) (x : ℂ) : ℕ→T shiftTyTB19
  | 0 => (n,x,1)
  | j+1 =>
    let (s,u,b) := shiftPTB19 n x j
    (s/2,u*u, if s%2=0 then b else b*u)

namespace shiftPTB19
lemma real (n : ℕ) (x : ℂ) (j : ℕ) :
    (shiftPTB19 n x j).2.2 * (shiftPTB19 n x j).2.1^(shiftPTB19 n x j).1=x^n := by
  induction j with
  | zero => exact one_mul _
  | succ j ih =>
    let s : ℕ := (shiftPTB19 n x j).1
    let a := (shiftPTB19 n x j).2.1
    let b := (shiftPTB19 n x j).2.2
    rw [← ih]
    change (if s%2=0 then b else b*a)*(a*a)^(s/2)=b*a^s
    rw [← pow_two,← pow_mul]
    split
    · rename_i H; rw [show 2*(s/2)=s by omega]
    · rename_i H; rw [mul_assoc,show a * a ^ (2*(s/2)) = a^s by
        simpa only [pow_succ'] using
          (show a^(2*(s/2)+1)=a^s by rw [show 2*(s/2)+1=s by omega])]
lemma countP (n : ℕ) (x : ℂ) (j : ℕ) :
    (shiftPTB19 n x j).1=n/2^j := by
  induction j with
  | zero => simp [shiftPTB19]
  | succ j ih => show (shiftPTB19 n x j).1/2 = _; rw [ih,Nat.div_div_eq_div_mul,pow_succ]

lemma endP (n : ℕ) (x : ℂ) (j : ℕ) (h : n<2^j) :
    (shiftPTB19 n x j).2.2=x^n := by
  simpa only [countP, Nat.div_eq_of_lt h, pow_zero,mul_one] using real n x j
end shiftPTB19

lemma halvePTB19 (h : b.Grain S k) (g : b.Grain S n) (hs : Small S n)
    (hh : ∀ i,k i<2^n i) {x : ι→ℂ} (hp : b.Dry S sc x) :
    b.Dry S sc fun i => x i^k i := by
  let V (i : ι) (j) := shiftPTB19 (k i) (x i) j
  have ht := Dry.token b n S V (t:=shiftTyTB19)
  have hk : (b.climbs n shiftTyTB19 V).Grain (fun i => S i.i) fun i => (V i.i i.j).1 :=
    ⟨ht.fst,(h.small.reindex _).mono fun i => by
      simp only [V,shiftPTB19.countP]; apply Nat.div_le_self⟩
  have hx := ht.snd.fst
  have hy := ht.snd.snd
  have HU := cycleG g hs V (h.dry.pair (hp.pair Dry.one))
    ((hk.div (Grain.wc 2)).dry.pair ((hx.mul hx).pair
      ((hk.residue (Grain.wc 2)).dry.branch hy (hy.mul hx))))
  exact HU.snd.snd.congr fun i => shiftPTB19.endP _ _ _ (hh i)

namespace Neaps

lemma n_ltTB19 (h : b.Neaps S n) (i) :
    n i < 2^S i := by
  have hh := stack_above (n i)
  rw [h.stack_eq] at hh
  omega

def layersPTB19 (S : ℕ) : ℕ := 3*S+4
lemma layersGTB19 (h : b.Neaps S n) :
    b.Grain S fun i => layersPTB19 (S i) :=
  (((Grain.wc 3).mul (h.tidal.grain S)).add (Grain.wc 4))
lemma layersSTB19 (S : ι→ℕ) : Small S fun i => layersPTB19 (S i) :=
  ((Small.const _ 3).mul (Small.self S)).add (Small.const _ 4)
lemma layersBoundTB19 (h : b.Neaps S n) (i) :
    8*(n i)^3 < 2^layersPTB19 (S i) := by
  have he : 0<n i := h.pos _
  rw [layersPTB19,pow_add,Nat.mul_comm 3,pow_mul]
  calc
    _ ≤ 8*((2^S i)^3) := by gcongr; exact (h.n_ltTB19 i).le
    _ < _ := by
      have hh : 0 < (2^S i)^3 := by positivity
      norm_num
      omega

lemma extractPTB19 (h : b.Neaps S n) (g : ∀ i,Ports (n i)) (u : b.Grain S k)
    (hk : ∀ i,k i ∣ express (n i))
    (hz : b.Dry S sc fun i => root (receipt (n i))) :
    b.Dry S sc fun i => root (k i) := by
  have hp : ∀ i,k i∣receipt (n i) := fun i => by
    simpa [receipt,g i] using hk i
  have H := halvePTB19 (h.receiptG.div u) h.layersGTB19 (layersSTB19 _) (x:=fun i => root (receipt (n i)))
    (fun i => lt_trans (lt_of_le_of_lt (Nat.div_le_self ..)
      (receipt_bound _ (h.pos _)).2) (h.layersBoundTB19 i)) hz
  exact H.congr fun i => root_factor (receipt_bound _ (h.pos _)).1 (hp i)

lemma etaPTB19 (h : b.Neaps S n) (g : ∀ i,Ports (n i))
    (hz : b.Dry S sc fun i => root (receipt (n i))) :
    b.Dry S sc fun i => root (2*n i) :=
  h.extractPTB19 g ((Grain.wc 2).mul (h.num.grain S)) (fun i => express_eta (n i)) hz

lemma mediumPTB19 (h : b.Neaps S n) (g : ∀ i,Ports (n i))
    (hz : b.Dry S sc fun i => root (receipt (n i))) :
    b.Dry S sc fun i => root (barge (n i)).vol :=
  h.extractPTB19 g h.bargeL.volL (fun _ => express_volume _) hz

lemma ratioSqTB19 {a b n : ℕ} (h : a<4*n) (g : 2 ≤ b) :
    (a/b)*(a/b) ≤ 8*n^3 := by
  have H : (a/b)*2 ≤ a := le_trans (Nat.mul_le_mul_left _ g)
    (Nat.div_mul_le_self a b)
  have hh : a/b ≤ 2*n := by omega
  calc
    _ ≤ (2*n)*(2*n) := Nat.mul_le_mul hh hh
    _ = n^2*4 := by ring
    _ ≤ n^2*(8*n) := Nat.mul_le_mul_left _ (by omega)
    _ = 8*n^3 := by ring

lemma ladeGrainTB19 {X : ι→Cart} {e : ι→ℕ}
    (h : b.Lade S X) (g : Small b.size e) (hk : ∀ i, ∀ j<(X i).l, (X i).q j ≤ e i) :
    (b.scan fun i => (X i).l).Grain (fun i => S i.i) fun i => (X i.i).q i.j := by
  let L i := (X i).l
  have H := h.dataL.transfer (Instant.scan b L)
  refine ⟨Dry.pick (t:=w) (k:=During.j) (n:=fun i : During L => L i.i)
    (x:=fun i j => (X i.i).q j) H (chopG h.dimL).dry During.hj,
    (g.reindex _).mono (fun i => hk _ i.j i.hj)⟩

lemma kilnPTB19 (h : b.Neaps S n) (g : ∀ i,Ports (n i))
    {z : ι→ℂ} (hu : b.Dry S sc z)
    (hz : b.Dry S sc fun i => root (receipt (n i))) :
    b.Dry S forgeTyTB19 fun i =>
      forgeTB19 (barge (n i)).l (orderE (n i)) (barge (n i)).q (z i) := by
  let X i := barge (n i)
  let e i := orderE (n i)
  let L i := (X i).l
  have hh (i) := barge_spec (n i) (h.pos _)
  have H := h.bargeL
  have hI : b.Dry S sc fun i => Complex.I :=
    (h.extractPTB19 g (Grain.wc 4) (fun i => express_I (n i)) hz).congr (fun _ => root_four)
  let Y i := e i+1
  have hY : b.Grain S Y := h.orderG.add (Grain.wc 1)
  have hSY : Small S Y := h.orderS.add (Small.const _ 1)
  have F := Instant.scan b Y
  have hj := chopG hY
  have hE : Small (b.scan Y).size (fun i => 2^i.j) :=
    ((h.powOrderS.trans h.tidal.small).reindex _).mono (fun i =>
      Nat.pow_le_pow_right (by omega) (Nat.le_of_lt_succ i.hj))
  have hk := hj.twoPow ((hSY.reindex _).mono fun i => i.hj.le) hE
  have hv := arrayG hY hSY (fun _ => halosTB19) (t:=sc)
    ((h.transfer F).extractPTB19 (fun i => g i.i) hk
      (fun i => express_halo _ _ (Nat.le_of_lt_succ i.hj)) (hz.transfer F))
  have G := Instant.scan b L
  let A (i : During L) := (X i.i).vol
  let B (i : During L) := (X i.i).q i.j
  have hb : (b.scan L).Grain (fun i => S i.i) B :=
    ladeGrainTB19 (X:=X) H h.powOrderG.small (fun i => (hh i).sizes)
  have Ha : (b.scan L).Grain (fun i => S i.i) A := H.volL.transfer G
  have HG := h.transfer G
  have HE (i : During L) : (A i / B i)*(A i / B i) < 2 ^ layersPTB19 (S i.i) := by
    have He : 2 ≤ B i := (hh _).square.isles.good i.j i.hj
    have Hh : A i < 4*n i.i := (hh _).upper
    exact lt_of_le_of_lt (ratioSqTB19 Hh He) (HG.layersBoundTB19 i)
  have HD := halvePTB19 ((Ha.div hb).mul (Ha.div hb)) HG.layersGTB19 (layersSTB19 _) HE (hu.transfer G)
  have HS := arrayG H.dimL H.countS
    (fun i j => spray (z i) (extent (X i).q (X i).l) ((X i).q j)) (t:=sc)
    (HD.congr fun i => by rw [spray,show extent (X i.i).q (X i.i).l=(X i.i).vol
      from (hh _).square.agrees.symm])
  exact H.dimL.dry.pair (h.orderG.dry.pair (H.dataL.pair (hI.pair (hv.pair HS))))

-- adjusted budget name
end Neaps

open Slant
def legTB19 (n : ℕ) := (score (orderE n)+1)*((barge n).vol*hillsTB19 (barge n).l)

end Bench
end
end PowerSaving.RAM

end OAI

end
-- bos_merge: end U7604.Chain.FourierTB.WorkingPreparation

-- bos_merge: begin U7604.Chain.FourierTB.ArbitraryLength
section

namespace OAI

namespace PowerSaving.RAM
open Ty Selection Spectral
noncomputable section
namespace Bench
universe U V
variable {ι : Type U} {κ : Type V} {m : Bool} {b : Bench m ι} {q : Bench m κ}
  {s t : Ty} {S n N : ι→ℕ}

-- one budget family for every length (the polylog branch is free on `Ports` lengths)
def fairwindTB19 (d n : ℕ) := n+legTB19 n+(stackN n+2)^d + (if Ports n then 0 else (n+2)^d)

lemma fairwind_degTB19 {c d : ℕ} (n : ℕ) (h : c≤d) : fairwindTB19 c n≤fairwindTB19 d n := by
  have := Small.pow_mono_degree (stackN n) h; have := Small.pow_mono_degree n h
  unfold fairwindTB19; split <;> omega
lemma fairwind_leftTB19 (n d : ℕ) : n + (stackN n+2)^d ≤ fairwindTB19 d n := by
  unfold fairwindTB19; omega
lemma Neaps.fairTB19 (h : b.Neaps S n) (g : ∀ i,Ports (n i)) (d : ℕ) (i : ι) :
    n i+legTB19 (n i)+(S i+2)^d ≤ fairwindTB19 d (n i) := by
  simp [fairwindTB19, h.stack_eq, g i]

def BreezyTB19 (b : Bench m ι) (n : ι→ℕ) (t : Ty) (x : ι→T t) : Prop :=
  ∃ d : ℕ,b.Moves (fun i => fairwindTB19 d (n i)) t x

namespace BreezyTB19
variable {x y : ι→T t}
lemma of_moves {W} (h : b.Moves W t x) (g : Dom n W) : b.BreezyTB19 n t x :=
  ⟨0,h.weaken ((Dom.of_le fun i => (Nat.le_add_right _ _).trans (fairwind_leftTB19 (n i) 0)).trans g)⟩
lemma of_dry (h : b.Neaps S n) (g : ∀ i,Ports (n i)) (hx : b.Dry S t x) : b.BreezyTB19 n t x :=
  let ⟨d,hd⟩ := hx
  ⟨d, hd.mono fun i => (Nat.le_add_left _ _).trans (h.fairTB19 g d i)⟩
lemma pair {v : ι→T s} (h : b.BreezyTB19 n t x) (g : b.BreezyTB19 n s v) :
    b.BreezyTB19 n (p t s) fun i => (x i,v i) :=
  let ⟨d,hd⟩ := h
  let ⟨l,hl⟩ := g
  ⟨d+l, (hd.weaken (Dom.of_le fun i => fairwind_degTB19 (n i) (by omega))).pair
    (hl.weaken (Dom.of_le fun i => fairwind_degTB19 (n i) (by omega)))⟩
lemma bind {v : ι→T s} (h : b.BreezyTB19 n t x) (g : (b.extend t x).BreezyTB19 n s v) :
    b.BreezyTB19 n s v :=
  let ⟨d,hd⟩ := h
  let ⟨l,hl⟩ := g
  ⟨d+l, caseM (hd.weaken (Dom.of_le fun i => fairwind_degTB19 (n i) (by omega)))
    (hl.weaken (Dom.of_le fun i => fairwind_degTB19 (n i) (by omega)))⟩
end BreezyTB19

structure CruiseTB19 (b : Bench m ι) (n S N : ι→ℕ) : Prop where
  dims : b.Neaps S n
  port : ∀ i, Ports (n i)
  rootP : b.Dry S sc fun i => root (receipt (n i))
  ac : ∀ i, (barge (n i)).vol=N i
  sizeL : b.Nick N

lemma signPTB19 (ret : Bool) (h : ∀ i,0<n i) (g : b.Dry S sc fun i => root (n i)) :
    b.Dry S sc fun i => pr ret (n i) := by
  cases ret
  · exact g
  · exact g.inv fun i => (root_primitive _ (h i)).ne_zero (Nat.ne_of_gt (h i))

lemma table_scaleTB19 {x y : ι→Line} {cl} (h : b.Nick N)
    (hx : b.Moves (fun _ => 0) (a sc) fun i => Tape.tab (N i) (x i))
    (hy : b.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab (N i) (y i)) :
    b.Moves N (a (c cl)) fun i => Tape.tab (N i) fun j => x i j*y i j := by
  have F := Instant.scan b N
  refine arrayNow h _ ((Moves.pick (t:=sc) (n:=fun i : During N => N i.i)
    (fun i j => x i.i j) (hx.transfer F) (chop h).close During.hj).mul
    (Moves.pick (t:=c cl) (n:=fun i : During N => N i.i) (fun i j => y i.i j)
      (hy.transfer F) (chop h).close During.hj))

namespace CruiseTB19
variable {cl : Paint} {x y : ι→Line}

lemma transfer {S n N : κ→ℕ} (h : q.CruiseTB19 n S N) {f} (g : b.Instant q f) :
    b.CruiseTB19 (fun i => n (f i)) (fun i => S (f i)) (fun i => N (f i)) :=
  ⟨h.dims.transfer g,fun _ => h.port _,h.rootP.transfer g,fun _ => h.ac _,h.sizeL.transfer g⟩

lemma volume_ge (h : b.CruiseTB19 n S N) (i) : 2*n i ≤ N i :=
  h.ac i ▸ (barge_spec _ (h.dims.pos i)).lower
lemma volume_lt (h : b.CruiseTB19 n S N) (i) : N i < 4*n i :=
  h.ac i ▸ (barge_spec _ (h.dims.pos i)).upper
lemma volume_pos (h : b.CruiseTB19 n S N) (i) : 0<N i := by
  have hh := h.volume_ge i; have hk := h.dims.pos i; omega

lemma dom (h : b.CruiseTB19 n S N) : Dom n N :=
  ⟨4,fun i => by have := h.volume_lt i; omega⟩

-- working-length transform of a prepared line
lemma flood' (h : b.CruiseTB19 n S N) (r : Bool) (hx : b.BreezyTB19 n (a (c cl)) fun i =>
    Tape.tab (N i) (x i)) :
    b.BreezyTB19 n (a (c cl)) fun i => Tape.tab (N i) (freq (N i) (pr r (N i)) (x i)) := by
  let V (i : ι) : T (a (c cl)) := Tape.tab (N i) (x i)
  have F := Instant.extend b V (t:=a (c cl))
  refine hx.bind ?_
  have h : (b.extend _ V).CruiseTB19 n S N := h.transfer F
  have hx : (b.extend _ V).Moves (fun _ => 0) (a (c cl)) V := cherry b V (t:=a (c cl))
  have hX i := barge_spec (n i) (h.dims.pos _)
  have he i : (barge (n i)).vol=Grove.extent (barge (n i)).q (barge (n i)).l := (hX _).square.agrees
  have H (i) : Grove.extent (barge (n i)).q (barge (n i)).l = N i := (he i).symm.trans (h.ac i)
  have hu := signPTB19 r h.volume_pos ((h.dims.mediumPTB19 h.port h.rootP).congr fun i => congrArg root (h.ac i))
  obtain ⟨d,hd⟩ := effuseTB19 (r:=fun i => (barge (n i)).q) (l:=fun i => (barge (n i)).l)
    (z:=fun i => pr r (N i)) (fun i => (hX _).square.isles)
    (fun i => (hX _).sizes) (fun i => (H i).symm ▸ show IsPrimitiveRoot (pr r (N i)) (N i) from
      primitive_pr _ (h.volume_pos i) r) h.dims.bargeL.countS h.dims.powOrderS h.dims.tidal.small
    (h.dims.bargeL.volume.mono (fun i => (he i).symm.le)) (x:=x)
    (h.dims.kilnPTB19 h.port hu h.rootP) (hx.congr fun i => congrArg (fun u => Tape.tab u (x i)) (H i).symm)
  refine ⟨d,(hd.weaken (Dom.of_le fun i => ?_)).congr fun i => by rw [H]⟩
  have := h.dims.fairTB19 h.port d i
  unfold legTB19 at this; (try dsimp only); rw [← he i]; omega

lemma pearl (h : b.CruiseTB19 n S N) (r : Bool)
    (hp : b.Moves (fun _ => 0) (a sc) fun i => tablePow (pr r (2*n i)) (S i))
    {k} (hk : b.Nick k) :
    b.Moves (fun _ => 0) sc fun i => epschirp (pr r (2*n i)) (k i) :=
  square_pow h.dims.stackPow hp ((Nick.wc 2).mul h.dims.num)
    (fun i => ⟨by have := h.dims.pos i; omega,h.dims.stack_eq i ▸ (stack_above (n i)).le⟩)
    (fun i => (primitive_pr (2*n i) (by have := h.dims.pos i; omega) r).pow_eq_one) hk

-- Bluestein in one line of binds: chirp table, the two prepared lines, three working-length
-- transforms with their pointwise product, then the final chirp scaling.
lemma deliver (h : b.CruiseTB19 n S N) (r : Bool)
    (hx : b.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab (n i) (x i)) :
    b.BreezyTB19 n (a (c cl)) fun i =>
      Tape.tab (n i) (freq (n i) (pr r (n i)) (x i)) := by
  let z (i) : T sc := pr r (2*n i)
  let V i := tablePow (pr r (2*n i)) (S i)
  have Fz := Instant.extend b z (t:=sc)
  have hz : b.BreezyTB19 n sc z := BreezyTB19.of_dry h.dims h.port (signPTB19 r (fun i => by have := h.dims.pos i; omega)
      (h.dims.etaPTB19 h.port h.rootP))
  have hT : b.BreezyTB19 n (a sc) V := hz.bind (BreezyTB19.of_moves (pylon (h.dims.tidal.transfer Fz)
    (g:=h.dims.stackPow) (cherry b z (t:=sc))) ⟨4,fun i => by
    dsimp only [id]
    have hh : 2^S i ≤ 4*n i := h.dims.stack_eq i ▸ stack_pow (n i) (h.dims.pos i); omega⟩)
  refine hT.bind ?_
  let B := b.extend (a sc) V
  have F0 := Instant.extend b V (t:=a sc)
  have hc : B.CruiseTB19 n S N := h.transfer F0
  have hp : B.Moves (fun _ => 0) (a sc) V := cherry b V (t:=a sc)
  have hx : B.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab (n i) (x i) := hx.transfer F0
  have F := Instant.scan B N
  have hh := hc.transfer F
  have hj := chop hc.sizeL
  -- seed line
  have hR : B.BreezyTB19 n (a (c cl)) fun i =>
      Tape.tab (N i) (chirp_seed (n i) (pr r (2*n i)) (x i)) := by
    have H := (hh.pearl r (hp.transfer F) hj).mul (pick_all (t:=c cl)
      (n:=fun i : During N => n i.i) (fun (i : During N) j => x i.i j) (hx.transfer F) hj)
    refine BreezyTB19.of_moves (arrayNow hc.sizeL _ (H.congr fun i => ?_)) hc.dom
    simp only [chirp_seed,mul_ite]; congr 1
    exact mul_zero _
  -- fall line
  have hF : B.BreezyTB19 n (a sc) fun i => Tape.tab (N i) (fall (n i) (N i) (pr r (2*n i))) := by
    have hk := (((hj.cmp hh.dims.num).branch (hh.sizeL.sub hj) hj)).congr
      (y:=fun i => legdist (n i.i) (N i.i) i.j) (fun i => by
      by_cases e : i.j < n i.i <;> simp [legdist,e])
    refine BreezyTB19.of_moves (arrayNow hc.sizeL _ ((hh.pearl r (hp.transfer F) hk).inv fun i => ?_)) hc.dom
    have Hu : 0<2*n i.i := by have := hc.dims.pos i.i; omega
    exact pow_ne_zero _ ((primitive_pr _ Hu r).ne_zero (Nat.ne_of_gt Hu))
  -- transforms of both lines, product, transform back
  let A i := freq (N i) (pr false (N i)) (fall (n i) (N i) (pr r (2*n i)))
  let C i := freq (N i) (pr false (N i)) (chirp_seed (n i) (pr r (2*n i)) (x i))
  let D i := fetchC (N i) (pr false (N i)) (fall (n i) (N i) (pr r (2*n i)))
    (chirp_seed (n i) (pr r (2*n i)) (x i))
  let Wl (i) : T (p (a sc) (a (c cl))) := (Tape.tab (N i) (A i),Tape.tab (N i) (C i))
  have hw := cherry B Wl (W:=fun _ => 0)
  have HW : (B.extend _ Wl).Nick N := hc.sizeL.transfer (Instant.extend B Wl)
  have hP : B.BreezyTB19 n (a (c cl)) fun i => Tape.tab (N i) (D i) :=
    hc.flood' true (x:=fun i => pointC (N i) (pr false (N i))
      (fall (n i) (N i) (pr r (2*n i))) (chirp_seed (n i) (pr r (2*n i)) (x i)))
    (((hc.flood' false hF).pair (hc.flood' false hR)).bind (BreezyTB19.of_moves
      (table_scaleTB19 HW (x:=A) (y:=C) hw.fst hw.snd) hc.dom))
  -- scale by 1/N and the chirp
  let U (i : ι) : T (p (a (c cl)) sc) := (Tape.tab (N i) (D i),(N i:ℂ))
  have G0 := Instant.extend B U
  have G := Instant.scan (B.extend _ U) n
  have hh' := hc.transfer (G.next G0)
  have hk := Moves.transfer (cherry B U (W:=fun _ => 0)) G
  have hn := hc.dims.num.transfer G0
  have HL := chop hn
  have HS := Moves.pick (n:=fun i : During n => N i.i) (t:=c cl)
    (fun i => D i.i) hk.fst HL.close (fun i => by
      have := hc.volume_ge i.i; have := i.hj; omega)
  have hd := (hh'.pearl r (hp.transfer (G.next G0)) HL).mul
    ((hk.snd.inv fun i => Nat.cast_ne_zero.mpr (Nat.ne_of_gt (hc.volume_pos i.i))).mul HS)
  exact (hP.pair (BreezyTB19.of_moves hc.sizeL.numeralM hc.dom)).bind
    (BreezyTB19.of_moves (arrayNow hn _ (hd.congr fun i =>
      chirps _ _ (hc.dims.pos i.i) (hc.volume_ge i.i) r _ _ i.hj)) (Dom.self n))

end CruiseTB19

lemma Neaps.swiftTB19 (h : b.Neaps S n) (g : ∀ i,Ports (n i))
    (hz : b.Dry S sc fun i => root (receipt (n i))) (r : Bool)
    {x : ι→Line} {cl} (hx : b.Moves (fun _ => 0) (a (c cl)) fun i =>
      Tape.tab (n i) (x i)) :
    b.BreezyTB19 n (a (c cl)) fun i =>
      Tape.tab (n i) (freq (n i) (pr r (n i)) (x i)) := by
  let N i := (barge (n i)).vol
  have F := Instant.extend b N (t:=w)
  have hh : (b.extend w N).CruiseTB19 n S N :=
    ⟨h.transfer F,g,hz.transfer F,fun i => rfl,⟨cherry b N (t:=w),h.bargeL.volume⟩⟩
  exact (BreezyTB19.of_dry h g h.bargeL.volL.dry).bind (hh.deliver r (hx.transfer F))

end Bench
end
end PowerSaving.RAM

end OAI

end
-- bos_merge: end U7604.Chain.FourierTB.ArbitraryLength

-- bos_merge: begin U7604.Chain.FourierTB.TransformProgram
section

namespace OAI

namespace PowerSaving.RAM
open Ty Selection Spectral Finset
noncomputable section
namespace Bench
universe U V
variable {ι : Type U} {κ : Type V} {m : Bool} {b : Bench m ι} {q : Bench m κ}
  {s t : Ty} {n N k : ι→ℕ}

lemma Dry.linearPowTB19 (h : b.Grain N k) (g : Small N k) {z : ι→ℂ} (hz : b.Dry N sc z) :
    b.Dry N sc fun i => z i^k i := by
  let V (i : ι) (j : ℕ) : T sc := z i^j
  have F := Instant.climbs b k V (t:=sc)
  refine cycleG h g V (one.congr fun i => (pow_zero _).symm)
    (((Dry.token b k N V (t:=sc)).mul (hz.transfer F)).congr fun i => (pow_succ _ _).symm)

-- polynomial direct branch, N^d
lemma Dry.direTB19 (h : b.Nick N)
    {x : ι→Line} {cl} (hx : b.Dry N (a (c cl)) fun i => Tape.tab (N i) (x i))
    {z : ι→ℂ} (hz : b.Dry N sc z) :
    b.Dry N (a (c cl)) fun i => Tape.tab (N i) (freq (N i) (z i) (x i)) := by
  let D := b.scan N
  have H := Small.self N
  have F := Instant.scan b N
  let K (i : During N) := N i.i
  let V (i : During N) (j : ℕ) : T (c cl) :=
    ∑ k ∈ range j, z i.i^(i.j*k)*x i.i k
  have hk : D.Grain K K := (h.transfer F).grain _
  have G := Instant.climbs D K V (t:=c cl)
  have hj := ((chop h).grain K).transfer G
  have hp := strideG hk V
  have hA : Small (fun i : During K => K i.i) fun i => i.i.j*i.j :=
    (((Small.self K).pow 2).reindex _).mono fun i => by
      rw [pow_two]
      exact Nat.mul_le_mul i.i.hj.le i.hj.le
  have ht := (linearPowTB19 (hj.mul hp) hA (hz.transfer (G.next F))).mul
    (Dry.pick (t:=c cl) (x:=fun (i : During K) j => x i.i.i j)
      (n:=fun i : During K => N i.i.i)
      (hx.transfer (G.next F)) hp.dry During.hj)
  exact arrayG (h.grain N) H _ (cycleG hk (Small.self K) V (by
    simp only [V,range_zero,sum_empty]; exact PolyCan.zero)
    (Dry.congr (b:=D.climbs K _ V) (S:=fun (i : During K) => K i.i) (t:=c cl)
      (PolyCan.add (Dry.token D K K V (t:=c cl)) ht) fun i => (sum_range_succ ..).symm))

lemma Neaps.courseTB19 (h : b.Neaps (fun i => stackN (n i)) n)
    (hz : b.Moves (fun _ => 0) sc fun i => root (receipt (n i)))
    (r : Bool) {x : ι→Line} {cl} (hx : b.Moves (fun _ => 0) (a (c cl)) fun i =>
      Tape.tab (n i) (x i)) :
    b.BreezyTB19 n (a (c cl)) fun i => Tape.tab (n i) (freq (n i) (pr r (n i)) (x i)) := by
  let f (i : ι) := if Ports (n i) then 0 else 1
  obtain ⟨d,hd⟩ := h.portG.dry
  have Fy := Instant.along b (Subtype.val (p:=fun i => f i = 0))
  have Fn := Instant.along b (Subtype.val (p:=fun i => f i ≠ 0))
  obtain ⟨l,hl⟩ := (h.transfer Fy).swiftTB19 (fun i => by
      by_contra k; have hi : f i.val=0 := i.property; simp [f,k] at hi)
    ((hz.transfer Fy).dunes _) r (hx.transfer Fy)
  have hp : ∀ i : {i // f i ≠ 0}, ¬ Ports (n i.val) := fun i g => i.property (by simp [f,g])
  have H := h.transfer Fn
  obtain ⟨k,hk⟩ := Dry.direTB19 H.num ((hx.transfer Fn).dunes _) (signPTB19 r H.pos
    ((hz.transfer Fn).dunes (fun i => n i.val) |>.congr
      (y:=fun i => root (n i.val)) fun i => by rw [receipt,ite_eq_right (hp i)]))
  refine ⟨d+l+k,Can.testz (W:=fun i => fairwindTB19 (d+l+k) (n i)) (n:=f) ?_ ?_ ?_⟩
  · exact Can.mono hd fun i => (Nat.le_add_left _ _).trans
      ((fairwind_leftTB19 _ d).trans (fairwind_degTB19 _ (by omega)))
  · exact Can.mono hl fun i => fairwind_degTB19 _ (by omega)
  · exact Can.mono hk fun i => le_trans (by unfold fairwindTB19; rw [ite_eq_right (hp i)]; exact Nat.le_add_left _ _)
      (fairwind_degTB19 _ (show k ≤ d+l+k by omega))

lemma Nick.landOrderTB19 (h : b.Nick N) (g : ∀ i, 0<N i) :
    b.BreezyTB19 N w fun i => receipt (N i) :=
  let ⟨d,hd⟩ := h.planOrder g
  ⟨d, hd.weaken (Dom.of_le fun i => fairwind_leftTB19 (N i) d)⟩
lemma Nick.land'TB19 (h : b.Nick N) (g : ∀ i, 0<N i)
    (hz : b.Moves (fun _ => 0) sc fun i => root (receipt (N i)))
    (r : Bool) {x : ι→Line} {cl} (hx : b.BreezyTB19 N (a (c cl)) fun i =>
      Tape.tab (N i) (x i)) :
    b.BreezyTB19 N (a (c cl)) fun i => Tape.tab (N i) (freq (N i) (pr r (N i)) (x i)) := by
  let V (i : ι) : T (a (c cl)) := Tape.tab (N i) (x i)
  have F := Instant.extend b V (t:=a (c cl))
  have hN : (b.extend _ V).Nick N := h.transfer F
  obtain ⟨hu,hk⟩ := hN.stackH g
  have H := Instant.extend (b.extend _ V) (fun i => stackN (N i)) (t:=w)
  exact hx.bind ((BreezyTB19.of_moves hu (Dom.self N)).bind (hk.courseTB19 ((hz.transfer F).transfer H) r
    ((cherry (W:=fun _ => 0) b V (t:=a (c cl))).transfer H)))
end Bench
end
end PowerSaving.RAM

end OAI

end
-- bos_merge: end U7604.Chain.FourierTB.TransformProgram

-- bos_merge: begin U7604.Chain.FourierTB.ConvolutionProgram
section

namespace OAI

namespace PowerSaving
open RAM Ty Selection Spectral Finset
noncomputable section

-- correspondence lemma for polynomials in dense coefficient representation
namespace RAM.Bench
universe U V
variable {ι : Type U} {κ : Type V} {b : Bench true ι} {n N : ι→ℕ}

def stretchTB19 (n : ℕ) := 2*n-1

def padTB19 (n : ℕ) (x : Line) : Line := fun j => if j<n then x j else 0

lemma freq_mulTB19 (n : ℕ) (u c : ℂ) (f g : Line) (i : ℕ) :
    freq n u (fun j => c*(f j*g j)) i = c*freq n u (fun j => g j*f j) i := by
  simp only [freq,mul_sum]; exact sum_congr rfl fun _ _ => by ring

-- inverse transform of the scaled product at 2n-1 = acyclic convolution
lemma conv_outTB19 {n : ℕ} (hn : 0<n) (x y : Line) :
    Tape.tab (2*n-1) (freq (2*n-1) (pr true (2*n-1)) fun j => ((2*n-1:ℕ):ℂ)⁻¹*
      (freq (2*n-1) (pr false (2*n-1)) (padTB19 n x) j*freq (2*n-1) (pr false (2*n-1)) (padTB19 n y) j)) =
    ⟨2*n-1,conv n (front n x) (front n y)⟩ := by
  refine congrArg (Tape.mk _) (funext fun k => ?_)
  have hk := k.isLt
  refine ((freq_mulTB19 ..).trans (cyc_formula (primitive_pr _ (by omega) false) _ _ hk)).trans ?_
  calc cyclic (2*n-1) (padTB19 n y) (padTB19 n x) k
      = ∑ r ∈ range n, ∑ s ∈ range n, if r+s=k then x r*y s else 0 := by
        unfold cyclic
        rw [← range_pad n (2*n-1) (by omega)]
        refine sum_congr rfl fun r _ => ?_
        by_cases hr : r<n
        · rw [ite_eq_left hr,show padTB19 n x r = x r from ite_eq_left hr]
          by_cases hi : r ≤ k
          · simp only [show ∀ s, r+s=(k:ℕ) ↔ s=k-r from fun s => by omega,sum_ite_eq',mem_range,
              padTB19,predAt,ite_eq_left hi]
            split_ifs <;> ring
          · have h1 : ∀ s, ¬ r+s=(k:ℕ) := fun s => by omega
            have h2 : ¬ (k:ℕ)+(2*n-1)-r < n := by omega
            simp only [padTB19,predAt,ite_eq_right hi,h1,h2,↓reduceIte,zero_mul,sum_const_zero]
        · rw [ite_eq_right hr,show padTB19 n x r = 0 from ite_eq_right hr,mul_zero]
    _ = _ := by simp only [sum_range]; rfl

-- scale by u and cross the two painted tapes, entrywise
lemma crossTB19 (h : b.Nick N) {u : ι→ℂ} {x y : ι→Line}
    (hP : b.BreezyTB19 N (p sc (p (a (c .left)) (a (c .right)))) fun i =>
      (u i,Tape.tab (N i) (x i),Tape.tab (N i) (y i))) :
    b.BreezyTB19 N (a (c .both)) fun i => Tape.tab (N i) fun j => u i*(x i j*y i j) := by
  let P (i : ι) : T (p sc (p (a (c .left)) (a (c .right)))) := (u i,Tape.tab (N i) (x i),Tape.tab (N i) (y i))
  have hN : (b.extend _ P).Nick N := h.transfer (Instant.extend b P)
  have H := (cherry (W:=fun _ => 0) b P).transfer (Instant.scan _ N)
  have k := (chop hN).close
  exact hP.bind (BreezyTB19.of_moves (arrayNow (t:=c .both) hN (fun i j => u i*(x i j*y i j)) (H.fst.mul (cl:=.both) (Can.cross
    (Moves.pick (t:=c .left) (n:=fun d : During N => N d.i) (fun d j => x d.i j) H.snd.fst k During.hj)
    (Moves.pick (t:=c .right) (n:=fun d : During N => N d.i) (fun d j => y d.i j) H.snd.snd k During.hj))))
    (Dom.self N))


end RAM.Bench

end
end PowerSaving

end OAI

end
-- bos_merge: end U7604.Chain.FourierTB.ConvolutionProgram

-- bos_merge: begin U7604.Chain.FourierTB.UniformBounds
section

namespace OAI

namespace PowerSaving
open RAM Ty Selection Spectral Slant
noncomputable section

namespace RAM.Bench
universe U
variable {ι : Type U} {κ : Type*} {m : Bool} {b : Bench m ι}
  {n : ι→ℕ} {t : Ty}

lemma fairwind_smallTB19 (N : ι→ℕ) (hn : ∀ i,0<N i) (d : ℕ) :
    Small N fun i => fairwindTB19 d (N i) := by
  have H := Small.self N
  have hX i := barge_spec (N i) (hn i)
  have h4 := (Small.const _ 4).mul H
  have hu := h4.mono (fun (i : ι) => stack_le (N i) (hn i))
  have hk : Small N fun i => harvestN (N i) :=
    (((Small.const _ 16).mul (hu.add (Small.const _ 4))).pow 2)
  have hh := ((Small.const _ 8).mul hk).mono
    (fun i => Nat.lt_two_pow_self.le.trans (orderE_small (N i)))
  have hi := ((((Small.const _ 20000000).mul ((hh.add (Small.const _ 1)).pow 2)).add
    (Small.const _ 7))).mono (fun i => score_le (orderE (N i)))
  have hp : Small N fun i => hillsTB19 (barge (N i)).l :=
    (hu.add (Small.const _ 1)).mono fun i => (hillsTB19_le _).trans
      (Nat.add_le_add_right (hX i).count _)
  have hj := (hi.add (Small.const _ 1)).mul
    ((h4.mono fun i => (hX i).upper.le).mul hp)
  have hl := H.add hj |>.add ((hu.add (Small.const _ 2)).pow d)
  exact hl.add (((H.add (Small.const _ 2)).pow d).mono fun i => by split <;> omega)

-- package extracted charges
abbrev SizesTB19 := {n : ℕ // 0<n}
abbrev entryTB19 : SizesTB19→ℕ := Subtype.val

structure RationTB19 where
  d : ℕ
  c : ℕ
  p : ℕ
def calorieTB19 (a : RationTB19) (n : ℕ) := a.c*(fairwindTB19 a.d n+1)

lemma BreezyTB19.ration {x : ι→T t} (h : b.BreezyTB19 n t x) :
    ∃ (s : Prog m b.tray t) (a : RationTB19), ∀ i,
      (run s (b.env i)).OK (x i) (calorieTB19 a (n i)) ((b.size i+2)^a.p) := by
  obtain ⟨d,hd⟩ := h
  obtain ⟨s,c,p,hc⟩ := Can.unfold_bound hd
  exact ⟨s,⟨d,c,p⟩,hc⟩

def lunchTB19 (a b : RationTB19) (N : ℕ→ℕ) (n : ℕ) :=
  calorieTB19 a (N n)+1+calorieTB19 b (N n)

-- order environment
def onlyLengthTB19 : Bench false SizesTB19 := ⟨entryTB19,w,entryTB19⟩
lemma onlyLength_numTB19 : onlyLengthTB19.Nick entryTB19 := ⟨Can.id,Small.self _⟩

lemma assembleTB19 {N : ℕ→ℕ} (hk : onlyLengthTB19.Nick fun i => N (entryTB19 i))
    (h : ∀ n,0<n → 0<N n ∧ N n ≤ 2*n) (b : RationTB19) :
    ∃ (o : Prog false w w) (a : RationTB19) (c : ℕ), ∀ n,0<n →
      (run o n).val = receipt (N n) ∧ lunchTB19 a b N n + 10*(n+2) ≤ (n+2)^c ∧
      (run o n).peak ≤ (n+2)^c ∧ (run o n).valid ∧ 0 < receipt (N n) ∧
      receipt (N n) < 1024*N n^3 ∧ receipt (N n) ≤ (n+2)^c ∧
      ∀ (v : Tape ℂ) (r : Bill (Tape ℂ)), r.OK v (calorieTB19 b (N n)) ((n+2)^b.p) →
        r.valid ∧ r.peak ≤ (n+2)^c ∧ (run o n).work+1+r.work ≤ lunchTB19 a b N n ∧ r.val = v := by
  obtain ⟨o,a,ho⟩ := (hk.landOrderTB19 (fun i => (h _ i.2).1)).ration
  let M i := N (entryTB19 i)
  have g : Small entryTB19 M := ((Small.const _ 2).mul (Small.self _)).mono fun i => (h _ i.2).2
  have H (a : RationTB19) : Small entryTB19 (fun i => calorieTB19 a (M i)) :=
    (Small.const _ a.c).mul (((fairwind_smallTB19 M (fun i => (h _ i.property).1) a.d).trans g).add
      (Small.const _ 1))
  have hu := (Small.self entryTB19).add (Small.const _ 2)
  have hp := ((Small.const _ 8).mul (g.pow 3)).mono
    (fun i => (receipt_bound _ (h _ i.property).1).2.le)
  obtain ⟨c,hc⟩ := ((((((H a).add (Small.const _ 1)).add (H b)).add ((Small.const _ 10).mul hu)).max
    (hu.pow a.p)).max (hu.pow b.p)).max hp
  refine ⟨o,a,c,fun n hn => ?_⟩
  have hx : max (max (max (lunchTB19 a b N n + 10*(n+2)) ((n+2)^a.p)) ((n+2)^b.p)) (receipt (N n)) ≤
      (n+2)^c := hc ⟨n,hn⟩
  have h1 := max_le_iff.mp hx
  have h2 := max_le_iff.mp h1.1
  have h3 := max_le_iff.mp h2.1
  have Ho := ho ⟨n,hn⟩
  have HH := receipt_bound _ (h n hn).1
  exact ⟨Ho.result,h3.1,Ho.bound.trans h3.2,Ho.valid,HH.1,HH.2.trans_le (by omega),h1.2,
    fun v r hr => ⟨hr.valid,hr.bound.trans h2.2,add_le_add (add_le_add_left Ho.time 1) hr.time,hr.result⟩⟩

def towerOneTB19 : Bench false (SizesTB19×Line) :=
  ⟨fun i => entryTB19 i.1,dftInKind,fun i =>
    (entryTB19 i.1, root (receipt (entryTB19 i.1)),Tape.tab (entryTB19 i.1) i.2)⟩

lemma executeOneTB19 : ∃ (s : Prog false dftInKind dftOutKind) (a : RationTB19),
    ∀ (n : ℕ),0<n → ∀ x : Vec n,
    (run s (n, root (receipt n), (⟨n,x⟩ : Tape ℂ))).OK
      (⟨n, dft n x⟩ : Tape ℂ) (calorieTB19 a n) ((n+2)^a.p) := by
  have ht : towerOneTB19.Moves (fun _ => 0) dftInKind towerOneTB19.env := envNow _
  obtain ⟨s,a,ha⟩ := ((show towerOneTB19.Nick fun i => entryTB19 i.1 from ⟨ht.fst,Small.self _⟩).land'TB19
    (fun i => i.1.property) ht.snd.fst false (x:=Prod.snd) (cl:=Paint.left)
    (BreezyTB19.of_moves ht.snd.snd (Dom.const _ 0))).ration
  refine ⟨s,a,fun n hn x => ?_⟩
  specialize ha ((⟨n,hn⟩:SizesTB19),extendLine x)
  change (run s (n,root (receipt n),(⟨n,front n (extendLine x)⟩:Tape ℂ))).OK
    (⟨n,front n (freq n (pr false n) (extendLine x))⟩ : Tape ℂ) _ _ at ha
  rw [← dft_front n,front_exact] at ha
  exact ha

lemma executeBothTB19 : ∃ (s : Prog true convInKind convOutKind) (a : RationTB19),
    ∀ n,0<n → ∀ x y : Vec n,
    (run s (n,root (receipt (stretchTB19 n)),(⟨n,x⟩ : Tape ℂ),(⟨n,y⟩ : Tape ℂ))).OK
      (⟨2*n-1,conv n x y⟩ : Tape ℂ) (calorieTB19 a (stretchTB19 n)) ((n+2)^a.p) := by
  let K : Bench true (SizesTB19×Line×Line) := ⟨fun i => i.1.val,convInKind,fun i =>
    (i.1.val,root (receipt (stretchTB19 i.1.val)),Tape.tab i.1.val i.2.1,Tape.tab i.1.val i.2.2)⟩
  have ht : K.Moves (fun _ => 0) convInKind K.env := envNow K
  let N (i : SizesTB19×Line×Line) := stretchTB19 i.1.val
  have hN : K.Nick N := ((Nick.wc 2).mul (⟨ht.fst,Small.self _⟩ : K.Nick fun i => i.1.val)).sub (Nick.wc 1)
  have gN : ∀ i, 0<N i := fun i => by have := i.1.property; show 0<2*_-1; omega
  -- pad to N = 2n-1 and transform forward
  have F (cl : Paint) (v : SizesTB19×Line×Line → Line)
      (hv : K.Moves (fun _ => 0) (a (c cl)) fun i => Tape.tab i.1.val (v i)) :=
    hN.land'TB19 gN ht.snd.fst false (BreezyTB19.of_moves (arrayNow (t:=c cl) hN (fun i => padTB19 i.1.val (v i))
      (pick_all (t:=c cl) (n:=fun d : During N => d.i.1.val) (fun d j => v d.i j) (hv.transfer (Instant.scan K N)) (chop hN))) (Dom.self N))
  have hP := (BreezyTB19.of_moves (hN.numeralM.inv fun i => Nat.cast_ne_zero.mpr (gN i).ne') (Dom.self N)).pair
    ((F _ (fun i => i.2.1) ht.snd.snd.fst).pair (F _ (fun i => i.2.2) ht.snd.snd.snd))
  -- 1/N times the product, transformed back
  obtain ⟨s,a,ha⟩ := (hN.land'TB19 gN ht.snd.fst true (crossTB19 hN hP)).ration
  refine ⟨s,a,fun n hn x y => ?_⟩
  rw [← front_exact x,← front_exact y,← conv_outTB19 hn]
  exact ha (⟨n,hn⟩,extendLine x,extendLine y)

theorem flagshipBothTB19 : ∃ order solve a b,
    ConvProgram order solve (lunchTB19 a b stretchTB19) ∧
    ∀ n, 0<n → (run order n).val = receipt (stretchTB19 n) := by
  obtain ⟨s,b,hs⟩ := executeBothTB19
  obtain ⟨o,a,c,hc⟩ := assembleTB19 (N:=stretchTB19) (((Nick.wc 2).mul onlyLength_numTB19).sub (Nick.wc 1))
    (fun n h => by unfold stretchTB19; omega) b
  refine ⟨o,s,a,b,⟨c,fun n hn => ?_⟩,fun n hn => (hc n hn).1⟩
  obtain ⟨he,h1,h2,h3,h4,h5,h6,h7⟩ := hc n hn
  dsimp only
  rw [he]
  exact ⟨h1,h2,h3,h4,h5,h6,fun x y => h7 _ _ (hs n hn x y)⟩

theorem flagshipOneTB19 : ∃ order solve a b,
    DFTProgram order solve (lunchTB19 a b id) ∧
    ∀ n, 0<n → (run order n).val = receipt n := by
  obtain ⟨s,b,hs⟩ := executeOneTB19
  obtain ⟨o,a,c,hc⟩ := assembleTB19 (N:=id) onlyLength_numTB19 (fun n h => ⟨h,show n ≤ 2*n by omega⟩) b
  refine ⟨o,s,a,b,⟨c,fun n hn => ?_⟩,fun n hn => (hc n hn).1⟩
  obtain ⟨he,h1,h2,h3,h4,h5,h6,h7⟩ := hc n hn
  dsimp only
  rw [he]
  exact ⟨h1,h2,h3,h4,h5,h6,fun x => h7 _ _ (hs n hn x)⟩

end RAM.Bench
end
end PowerSaving

end OAI

end
-- bos_merge: end U7604.Chain.FourierTB.UniformBounds

-- bos_merge: begin U7604.Chain.FourierTB.Asymptotics
section

namespace OAI

namespace PowerSaving
open RAM Bench Selection Slant Filter Asymptotics Real
noncomputable section

namespace Skies

abbrev TmTB19 (n : ℕ) : ℝ := log (n:ℝ)
abbrev QmTB19 (n : ℕ) : ℝ := log (TmTB19 n)

lemma TtopTB19 : Tendsto TmTB19 atTop atTop := Real.tendsto_log_atTop.comp tendsto_natCast_atTop_atTop
lemma QtopTB19 : Tendsto QmTB19 atTop atTop := Real.tendsto_log_atTop.comp TtopTB19
lemma log2_minTB19 : 2/3 ≤ log (2:ℝ) := by
  have hh := le_log_one_add_of_nonneg (show (0:ℝ)≤1 by norm_num)
  norm_num at *
  exact hh

def flightTB19 (n : ℕ) := (n:ℝ)*(TmTB19 n)^alphaTB19*QmTB19 n^2

-- n is problem size, N allowed between n and 2n
section Chain
variable (n N : ℕ) (hn : 0<n) (h : n≤N) (hk : N ≤ 2*n) (ht : 1≤TmTB19 n) (hu : 1 ≤ QmTB19 n)
include hn h hk ht

lemma stack_limTB19 :
    (stackN N:ℝ) ≤ 10 * TmTB19 n := by
  let k := Nat.log 2 (2*N)
  have H : 2^k ≤ 2*N := Nat.pow_log_le_self _ (by omega)
  have H0 : 2^k ≤ 4*n := by omega
  have he : 0<(n:ℝ) := by exact_mod_cast hn
  have HH := log_le_log (by positivity : 0<(2:ℝ)^k)
    (show (2:ℝ)^k ≤ 4*n by exact_mod_cast H0)
  rw [log_pow,log_mul (by norm_num) he.ne'] at HH
  have H4 := log_le_sub_one_of_pos (show (0:ℝ)<4 by norm_num)
  change (((k+1:ℕ):ℝ)) ≤ _
  push_cast
  unfold TmTB19 at *
  nlinarith [log2_minTB19,show 0≤(k:ℝ) by positivity]

lemma order_pow_limTB19 :
    (2:ℝ)^orderE N ≤ 10^6*TmTB19 n^2 := by
  have hh : (2:ℝ)^orderE N ≤ 8*harvestN N := by exact_mod_cast orderE_small N
  refine hh.trans ?_
  unfold harvestN silo; push_cast
  have hg := stack_limTB19 n N hn h hk ht
  calc
    _ ≤ 8*(16*(14*TmTB19 n))^2 := by gcongr; linarith
    _ ≤ _ := by nlinarith [sq_nonneg (TmTB19 n)]

include hu in
lemma order_limTB19 :
    (orderE N:ℝ) ≤ 3*10^6 * QmTB19 n := by
  have H := log_le_log (by positivity : 0<(2:ℝ)^orderE N) (order_pow_limTB19 n N hn h hk ht)
  have he : 0<TmTB19 n := by linarith
  rw [log_pow,log_mul (by norm_num) (by positivity),log_pow,log_pow] at H
  have H4 := log_le_sub_one_of_pos (show 0 < (10:ℝ) by norm_num)
  unfold QmTB19 at *
  have h0 : 0 ≤ (orderE N:ℝ) := by positivity
  push_cast at H
  nlinarith [log2_minTB19]

include hu in
lemma score_limTB19 :
    (score (orderE N):ℝ)+1 ≤ 10^32*QmTB19 n^2 := by
  have H := order_limTB19 n N hn h hk ht hu
  have hk : (score (orderE N):ℝ) ≤ 20000000*((orderE N:ℝ)+1)^2+7 := by
    exact_mod_cast score_le (orderE N)
  calc
    _ ≤ (20000000*((orderE N:ℝ)+1)^2+7)+1 := by gcongr
    _ ≤ (20000000*(4*10^6*QmTB19 n)^2+7)+1 := by gcongr; linarith
    _ ≤ _ := by nlinarith

lemma hills_limTB19 :
    (hillsTB19 (barge N).l:ℝ) ≤ 100*TmTB19 n^alphaTB19 := by
  have he : 0<TmTB19 n := by linarith
  have H := stack_limTB19 n N hn h hk ht
  have G : ((barge N).l:ℝ) ≤ stackN N := by
    exact_mod_cast (barge_spec N (lt_of_lt_of_le hn h)).count
  have hg := alphaTB19_pos
  refine (hillsTB19_real _).trans ?_
  calc
    _ ≤ 2*(11*TmTB19 n)^alphaTB19 := by gcongr; linarith
    _ = 2*(11^alphaTB19*TmTB19 n^alphaTB19) := by rw [mul_rpow (by norm_num) he.le]
    _ ≤ 2*(11^(1:ℝ)*TmTB19 n^alphaTB19) := by gcongr <;> first | exact alphaTB19_lt.le | norm_num
    _ ≤ _ := by
      rw [rpow_one]
      have hTT : 0 < TmTB19 n^alphaTB19 := by positivity
      linarith


include hu in
lemma leg_limTB19 :
    (legTB19 N:ℝ) ≤ 10^40*flightTB19 n := by
  have hg : (barge N).vol ≤ 8*n := by
    have hh := (barge_spec N (by omega)).upper
    omega
  have hh : ((barge N).vol:ℝ) ≤ 8*n := by exact_mod_cast hg
  have hT : 0 < TmTB19 n := by linarith
  unfold legTB19; push_cast
  calc
    _ ≤ (10^32 * QmTB19 n^2)*((8*n)*(100*TmTB19 n^alphaTB19)) :=
      mul_le_mul (score_limTB19 n N hn h hk ht hu)
        (mul_le_mul hh (hills_limTB19 n N hn h hk ht) (by positivity) (by positivity))
        (by positivity) (by positivity)
    _ = 8*100*10^32*flightTB19 n := by unfold flightTB19; ring
    _ ≤ _ := by
      have hh : 0 ≤ flightTB19 n := by unfold flightTB19; positivity
      gcongr; norm_num

end Chain

lemma flight_bigTB19 (n : ℕ) (ht : 1 ≤ TmTB19 n) (hu : 1 ≤ QmTB19 n) :
    (n:ℝ) ≤ flightTB19 n := by
  have H := Real.one_le_rpow ht alphaTB19_pos.le
  unfold flightTB19
  calc
    (n:ℝ) = n*1*1 := by ring
    _ ≤ _ := by gcongr; nlinarith

-- little o fournishes eventual caps.
lemma dwarfTB19 {v : ℕ→ℝ} (h : Tendsto v atTop atTop) (d : ℕ) {p c : ℝ} (hp : 0<p) (hc : 0<c) :
    ∀ᶠ n in atTop, log (v n)^d ≤ c*v n^p := by
  have H := (isLittleO_log_rpow_rpow_atTop (d:ℝ) hp).comp_tendsto h
  have hg := H.def hc
  filter_upwards [hg,h.eventually_ge_atTop 1] with n hn he
  have he' : 0<v n := by linarith
  change ‖log (v n)^(d:ℝ)‖ ≤ c*‖v n^p‖ at hn
  rw [rpow_natCast,Real.norm_of_nonneg (pow_nonneg (Real.log_nonneg he) _),
    Real.norm_of_nonneg (by positivity)] at hn
  exact hn

variable {N : ℕ→ℕ}
-- initial branch disappears
lemma docks_evTB19 (h : ∀ n:ℕ,n ≤ N n ∧ N n ≤ 2*n) :
    ∀ᶠ n in atTop, Ports (N n) := by
  have H := dwarfTB19 (v:=fun n => (n:ℝ)) tendsto_natCast_atTop_atTop 2
    (c:=1/10^6) (p:=1) (by norm_num) (by norm_num)
  filter_upwards [H,eventually_gt_atTop 0,TtopTB19.eventually_ge_atTop 1] with n hh hn ht
  rw [rpow_one] at hh
  have hh' : (TmTB19 n)^2 ≤ 1/10^6*n := hh
  have hh1 := order_pow_limTB19 n (N n) hn (h n).1 (h n).2 ht
  have hh2 : (2:ℝ)^(orderE (N n)) ≤ n := by linarith
  exact (show 2^orderE (N n) ≤ n by exact_mod_cast hh2).trans (h n).1

lemma polylog_evTB19 (h : ∀ n:ℕ,n ≤ N n ∧ N n ≤ 2*n) (d : ℕ) :
    ∀ᶠ n in atTop, ((stackN (N n):ℝ)+2)^d ≤ n := by
  have h0 : 0< (12:ℝ)^d := by positivity
  have H := dwarfTB19 (v:=fun n => (n:ℝ)) tendsto_natCast_atTop_atTop d
    (c:=((12:ℝ)^d)⁻¹) (p:=1) (by norm_num) (by positivity)
  filter_upwards [H,eventually_gt_atTop 0,TtopTB19.eventually_ge_atTop 1] with n hh hn ht
  rw [rpow_one] at hh
  have hh' : (TmTB19 n)^d ≤ ((12:ℝ)^d)⁻¹*n := hh
  have hh1 := stack_limTB19 n (N n) hn (h n).1 (h n).2 ht
  calc
    _ ≤ (12*TmTB19 n)^d := by gcongr; linarith
    _ ≤ _ := by
      rw [mul_pow]
      calc
        _ ≤ _ := mul_le_mul_of_nonneg_left hh' h0.le
        _ = _ := by rw [← mul_assoc,mul_inv_cancel₀ h0.ne',one_mul]

lemma wind_evTB19 (h : ∀ n:ℕ,n ≤ N n ∧ N n ≤ 2*n) (d : ℕ) :
    ∀ᶠ n in atTop,(fairwindTB19 d (N n):ℝ)+1 ≤ 10^41*flightTB19 n := by
  filter_upwards [docks_evTB19 h,polylog_evTB19 h d,eventually_gt_atTop 0,TtopTB19.eventually_ge_atTop 1,
    QtopTB19.eventually_ge_atTop 1] with n hh hk hn ht hu
  unfold fairwindTB19
  rw [ite_eq_left hh,Nat.add_zero]
  push_cast
  have hp := leg_limTB19 n (N n) hn (h n).1 (h n).2 ht hu
  have he := flight_bigTB19 n ht hu
  have he' : 1≤(n:ℝ) := by exact_mod_cast hn
  have hx : (N n:ℝ) ≤ 2*n := by exact_mod_cast (h n).2
  linarith

lemma lunch_bigTB19 (a b : RationTB19) (h : ∀ n:ℕ,n ≤ N n ∧ N n ≤ 2*n) :
    (fun n : ℕ => (lunchTB19 a b N n:ℝ)) =O[atTop] flightTB19 := by
  let W := lunchTB19 a b N
  refine isBigO_iff.mpr ⟨(a.c:ℝ)*10^41+1+(b.c:ℝ)*10^41,?_⟩
  filter_upwards [wind_evTB19 h a.d,wind_evTB19 h b.d,eventually_gt_atTop 0,TtopTB19.eventually_ge_atTop 1,
    QtopTB19.eventually_ge_atTop 1] with n hh hk hn ht hu
  have he := flight_bigTB19 n ht hu
  have h1 : 1≤(n:ℝ) := by exact_mod_cast hn
  rw [Real.norm_of_nonneg (by positivity),Real.norm_of_nonneg (by linarith)]
  unfold lunchTB19 calorieTB19
  push_cast; simp only [add_mul,one_mul,mul_assoc]
  gcongr
  exact h1.trans he

end Skies
end
end PowerSaving

end OAI

end
-- bos_merge: end U7604.Chain.FourierTB.Asymptotics


namespace OAI

namespace PowerSaving
noncomputable section
open RAM Bench Selection Filter Asymptotics Real Skies

-- α < θ < 1 from the definitions only (no stage constant here)
lemma theta_rangeTB19 : alphaTB19 < theta ∧ theta < 1 := by
  have hP : (0:ℝ) < paperMultiplier := by norm_num [paperMultiplier,paperM,paperDelta,paperW]
  have hM : (1:ℝ) ≤ log paperM := by
    have := log_le_log (by norm_num) (show (2:ℝ)^2 ≤ paperM by norm_num [paperM])
    rw [log_pow] at this; push_cast at this; linarith [log2_minTB19]
  have h1 := log_le_sub_one_of_pos (div_pos (by norm_num [paperM] : (0:ℝ) < paperM) hP)
  rw [log_div (by norm_num [paperM]) hP.ne'] at h1
  have h2 : paperM/paperMultiplier-1 < 1-alphaTB19 := by
    norm_num [paperMultiplier,paperM,paperDelta,paperW,alphaTB19]
  unfold theta
  rw [lt_div_iff₀ (by linarith),div_lt_one (by linarith)]
  exact ⟨by nlinarith [alphaTB19_lt],log_lt_log hP (by norm_num [paperMultiplier,paperM,paperDelta,paperW])⟩

-- flight ≤ c·n·T^p eventually, for every p > α
lemma capTB19 {p c : ℝ} (hp : alphaTB19 < p) (hc : 0<c) :
    ∀ᶠ n in atTop, flightTB19 n ≤ c*((n:ℝ)*TmTB19 n^p) := by
  filter_upwards [dwarfTB19 TtopTB19 2 (sub_pos.2 hp) hc,TtopTB19.eventually_ge_atTop 1] with n h ht
  calc flightTB19 n ≤ n*TmTB19 n^alphaTB19*(c*TmTB19 n^(p-alphaTB19)) :=
        mul_le_mul_of_nonneg_left h (mul_nonneg (Nat.cast_nonneg _) (rpow_nonneg (by linarith) _))
    _ = c*((n:ℝ)*(TmTB19 n^alphaTB19*TmTB19 n^(p-alphaTB19))) := by ring
    _ = _ := by rw [← rpow_add (by linarith)]; ring_nf

lemma flight_nonnegTB19 (n : ℕ) : 0 ≤ flightTB19 n :=
  mul_nonneg (mul_nonneg (Nat.cast_nonneg _) (rpow_nonneg (log_natCast_nonneg n) _)) (sq_nonneg _)

theorem time_boundTB19 {N : ℕ→ℕ} (a b : RationTB19) (h : ∀ n, n ≤ N n ∧ N n ≤ 2*n) :
    TimeBoundsTB19 (lunchTB19 a b N) := by
  have H := lunch_bigTB19 a b h
  have F {p : ℝ} (hp : alphaTB19 < p) {g : ℕ→ℝ} (hg : ∀ᶠ n : ℕ in atTop, (n:ℝ)*TmTB19 n^p ≤ g n) :
      flightTB19 =O[atTop] g := isBigO_iff.mpr ⟨1,by
    filter_upwards [capTB19 hp one_pos,hg] with n h1 h2
    rw [Real.norm_of_nonneg (flight_nonnegTB19 n),Real.norm_of_nonneg ((mul_nonneg (Nat.cast_nonneg _)
      (rpow_nonneg (log_natCast_nonneg n) _)).trans h2)]
    linarith⟩
  refine ⟨H.trans (F theta_rangeTB19.1 ?_),
    H.trans (F (p:=decimalExponentTB19) (by norm_num [decimalExponentTB19,statedSavingTB19,alphaTB19])
      (.of_forall fun _ => le_rfl)),
    H.trans_isLittleO (IsLittleO.of_bound fun c hc => ?_)⟩
  · filter_upwards [QtopTB19.eventually_ge_atTop 1] with n hu
    unfold paperTime
    exact le_mul_of_one_le_right (mul_nonneg (Nat.cast_nonneg _) (rpow_nonneg (log_natCast_nonneg n) _))
      (one_le_rpow hu (by linarith [theta_rangeTB19.2]))
  · filter_upwards [capTB19 alphaTB19_lt hc] with n h
    rw [rpow_one] at h
    rw [Real.norm_of_nonneg (flight_nonnegTB19 n),
      Real.norm_of_nonneg (show 0 ≤ nlogn n from mul_nonneg (Nat.cast_nonneg _) (log_natCast_nonneg n))]
    exact h

theorem transform_main_orderTB19 : ∃ order solve W,
    DFTProgram order solve W ∧ TimeBoundsTB19 W ∧
    ∀ n, 0<n → (run order n).val = receipt n ∧ (run order n).val < 8*n^3 :=
  let ⟨o,s,a,b,h,ho⟩ := flagshipOneTB19
  ⟨o,s,_,h,time_boundTB19 a b fun n => ⟨le_rfl,by simp only [id]; omega⟩,
    fun n hn => ⟨ho n hn,(ho n hn).symm ▸ (receipt_bound n hn).2⟩⟩

theorem convolution_main_orderTB19 : ∃ order solve W,
    ConvProgram order solve W ∧ TimeBoundsTB19 W ∧
    ∀ n, 0<n → (run order n).val = receipt (2*n-1) ∧ (run order n).val < 8*(2*n-1)^3 := by
  obtain ⟨o,s,a,b,h,ho⟩ := flagshipBothTB19
  have hs {n : ℕ} (hn : 0<n) : 0<stretchTB19 n := by unfold stretchTB19; omega
  exact ⟨o,s,_,h,time_boundTB19 a b fun n => by unfold stretchTB19; omega,
    fun n hn => ⟨ho n hn,(ho n hn).symm ▸ (receipt_bound _ (hs hn)).2⟩⟩

theorem transform_mainTB19 : DFTGoalTB19 :=
  let ⟨o,s,W,h,g,_⟩ := transform_main_orderTB19
  ⟨o,s,W,h,g⟩
theorem convolution_mainTB19 : ConvGoalTB19 :=
  let ⟨o,s,W,h,g,_⟩ := convolution_main_orderTB19
  ⟨o,s,W,h,g⟩

end
end PowerSaving

end OAI
