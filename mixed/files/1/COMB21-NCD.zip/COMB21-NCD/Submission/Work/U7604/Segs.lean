import Submission.Work.U7604.SgCore
import Submission.Work.MixAB.Gen.W7604.D0
import Submission.Work.MixAB.Gen.W7604SchedR

set_option maxHeartbeats 4000000
set_option maxRecDepth 100000

namespace OAI.PowerSaving.U7604

theorem segs_ok : segs.all okS = true ∧ segs.filterMap Sg.jk = List.range 17 := by decide +kernel

theorem price_ok : nrm (segs.flatMap Sg.blk ++ (List.replicate 17 Pnat).flatten) = Pc := by decide +kernel

theorem lay_ok : (List.range 200).all (fun t => portN (cpN t) (hostN t) == t && decide (cpN t < 104)
    && (!hostN t || decide (cpN t < 96))
    && GXD.W7604.ports.getD t 0 == GXD.W7604.ports.getD (portN (cpN t) false) 0) = true := by decide +kernel

theorem copy_ok : (List.range 104).all (fun c => cpN (portN c false) == c && hostN (portN c false) == false
    && decide (portN c false < 200)) = true := by decide +kernel

theorem sched_ok : GXD.W7604.schedRes.length = 1101 ∧
    GXD.W7604.schedRes.all (fun x => decide (1 ≤ x ∧ x ≤ 9)) = true := by decide +kernel

def Tc : List (Nat × Nat) := [(1, 306), (2, 357), (3, 799), (4, 3825), (5, 1360), (6, 731), (7, 323), (8, 544), (9, 10888), (17, 416), (25, 416), (33, 416), (41, 416), (49, 416), (57, 416), (65, 416), (73, 208), (137, 208)]
def histC (l : List (Nat × Nat)) (r : Nat) : Nat := ((l.filter fun b => b.1 = r).map Prod.snd).sum
theorem tgt_ok : nrm ((nTab true).map (fun x => (1 + 8 * (x + 1), 96)) ++ ((nTab false).map (fun x => (1 + 8 * (x + 1), 8))
    ++ GXD.W7604.schedRes.map fun x => (x, 17))) = Tc := by decide +kernel
theorem rk_le : ∀ κ : Bool, ∀ i < 36, 1 ≤ rkT κ i ∧ rkT κ i ≤ 137 := by decide +kernel
theorem nT_len : ∀ κ : Bool, (nTab κ).length = 36 := by decide +kernel

end OAI.PowerSaving.U7604
