import Submission.Work.GFrame.Top.Api
import Submission.Work.P4L.OpSem

set_option linter.unusedSectionVars false

namespace OAI
namespace PowerSaving
namespace P4L
open Binary Matrix Finset GF

noncomputable section

section
variable {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

def ORoute (Op : ∀ f : ℕ, Data α ρ f → Data α ρ f) (c : (ℕ → ℝ) → ℝ) : Prop :=
  ∃ w : GWord α ρ, w.Proper (Fintype.card α) ∧ (∀ φ, w.costR φ = c φ) ∧
    ∀ (f : ℕ) (y : Data α ρ f), gwalk f w y = Op f y

namespace ORoute

theorem refl : ORoute (α := α) (ρ := ρ) (fun _ y => y) (fun _ => 0) :=
  ⟨[], GWord.proper_nil _, fun _ => rfl, fun _ _ => rfl⟩

theorem trans {Op Op' : ∀ f : ℕ, Data α ρ f → Data α ρ f} {c c' : (ℕ → ℝ) → ℝ}
    (a : ORoute Op c) (b : ORoute Op' c') :
    ORoute (fun f y => Op' f (Op f y)) (fun φ => c φ + c' φ) := by
  obtain ⟨p, hp, cp, ap⟩ := a
  obtain ⟨q, hq, cq, aq⟩ := b
  refine ⟨p ++ q, hp.append hq, fun φ => by rw [GWord.costR_append, cp, cq], ?_⟩
  intro f y
  rw [gwalk_append, ap, aq]

theorem cast {Op Op' : ∀ f : ℕ, Data α ρ f → Data α ρ f} {c c' : (ℕ → ℝ) → ℝ}
    (a : ORoute Op c) (hOp : ∀ f y, Op f y = Op' f y) (hc : ∀ φ, c φ = c' φ) : ORoute Op' c' := by
  obtain ⟨w, hw, hcw, aw⟩ := a
  exact ⟨w, hw, fun φ => (hcw φ).trans (hc φ), fun f y => (aw f y).trans (hOp f y)⟩

theorem of_groute {S S' T : ρ → CMat α} {g : (ρ → ℂ) → (ρ → ℂ)} {c : (ℕ → ℝ) → ℝ}
    (h : GRoute S T g c) (hS : ∀ r, S r * S' r = 1) :
    ORoute (fun f y => multiAct f T (point f g (multiAct f S' y))) c := by
  obtain ⟨w, hw, hc, hwalk⟩ := h
  exact ⟨w, hw, hc, fun f y => op_of_walk hwalk hS f y⟩

theorem localM (G : Matrix ρ ρ ℚ) : ORoute (α := α) (fun f => point f (actPoint G)) (fun _ => 0) :=
  ⟨[GMove.old (BMove.localM G)], fun mv hmv => by
      rw [List.mem_singleton] at hmv; subst hmv; trivial,
    fun φ => by simp [GWord.costR, GMove.costR, GMove.shadow, BMove.costR, BMove.rk?], fun f y => rfl⟩

theorem of_gstep {l : ρ} {M N : CMat α} {c : (ℕ → ℝ) → ℝ} (h : GStep l M N c) :
    ∃ U : CMat α, U * M = N ∧ ORoute (fun f => roleAct f l U) c := by
  obtain ⟨w, U, hw, hc, hU, hwalk⟩ := h
  exact ⟨U, hU, w, hw, hc, hwalk⟩

theorem steps (s : Finset ρ) (A B : ρ → CMat α) (c : ρ → (ℕ → ℝ) → ℝ)
    (h : ∀ r ∈ s, GStep r (A r) (B r) (c r)) :
    ∃ U : ρ → CMat α, (∀ r ∈ s, U r * A r = B r) ∧
      ORoute (fun f y r => if r ∈ s then matAct f (U r) (y r) else y r) (fun φ => ∑ r ∈ s, c r φ) := by
  induction s using Finset.induction_on with
  | empty =>
    refine ⟨fun _ => 1, fun r hr => absurd hr (Finset.notMem_empty r), ?_⟩
    exact refl.cast (fun f y => by funext r; simp) (fun φ => by simp)
  | insert a s ha ih =>
    obtain ⟨U, hU, R⟩ := ih (fun r hr => h r (Finset.mem_insert_of_mem hr))
    obtain ⟨Ua, hUa, Ra⟩ := of_gstep (h a (Finset.mem_insert_self a s))
    refine ⟨Function.update U a Ua, fun r hr => ?_, ?_⟩
    · rcases Finset.mem_insert.mp hr with e | hr
      · subst e; rw [Function.update_self]; exact hUa
      · have hra : r ≠ a := fun e => ha (e ▸ hr)
        rw [Function.update_of_ne hra]; exact hU r hr
    · refine (R.trans Ra).cast (fun f y => ?_) (fun φ => by rw [Finset.sum_insert ha, add_comm])
      funext r
      simp only [roleAct]
      by_cases hra : r = a
      · subst hra
        simp [ha, Function.update_self]
      · have e1 : (r ∈ insert a s) = (r ∈ s) := by
          simp [Finset.mem_insert, hra]
        simp only [hra, if_false, e1, Function.update_of_ne hra]

theorem steps_inv (s : Finset ρ) (A A' B : ρ → CMat α) (hA : ∀ r ∈ s, A r * A' r = 1) (c : ρ → (ℕ → ℝ) → ℝ)
    (h : ∀ r ∈ s, GStep r (A r) (B r) (c r)) :
    ORoute (fun f y r => if r ∈ s then matAct f (B r * A' r) (y r) else y r) (fun φ => ∑ r ∈ s, c r φ) := by
  obtain ⟨U, hU, R⟩ := steps s A B c h
  refine R.cast (fun f y => ?_) (fun _ => rfl)
  funext r
  by_cases hr : r ∈ s
  · have e : U r = B r * A' r := by
      rw [← hU r hr, Matrix.mul_assoc, hA r hr, Matrix.mul_one]
    simp only [hr, if_true, e]
  · simp only [hr, if_false]

end ORoute
end
end
end P4L
end PowerSaving
end OAI
