import Submission.Work.Fresh.Helpers
import Submission.Work.P4L.View


namespace OAI
namespace PowerSaving
namespace P4L
open Binary Matrix Finset RAM SS CB RF BR GF GX FH

noncomputable section

section Fresh
variable {H T Sl C α Γ : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C] [Fintype α] [DecidableEq α]
  [Fintype Γ] [DecidableEq Γ]

theorem fresh_call (Wn : Γ → Sl → CMat α) (r : Sl → ℕ)
    (hWn : ∀ d q, ∃ (C C' : CMat α) (R : Finset α), Free C ∧ Free C' ∧ R.card = r q ∧ Wn d q = C * pk R * C')
    (D : Sl → Finset α) (hload : ∀ q, r q ≤ (D q).card) (hrk : ∀ q, (D q).card - r q < Fintype.card α) :
    ∃ Zp : Γ → Sl → CMat α,
      (∀ d q, GReach 1 (Zp d q) (fun _ => 0)) ∧
      (∀ d q, GReach (Wn d q * Zp d q) (pk (D q)) (fun φ => bcost φ ((D q).card - r q))) := by
  have key : ∀ d q, ∃ Z : CMat α, GReach 1 Z (fun _ => 0) ∧
      GReach (Wn d q * Z) (pk (D q)) (fun φ => bcost φ ((D q).card - r q)) := by
    intro d q
    obtain ⟨C, C', R, hC, hC', hR, hW⟩ := hWn d q
    obtain ⟨P, hP, A2, U2, hA2, hU2D, hc, he⟩ := XHost.host_adapt (B := (1 : CMat α)) Free.one hC hC' (D q) ∅ R
      (Finset.empty_subset _) (by rw [Finset.card_empty, zero_add, hR]; exact hload q)
    rw [Finset.card_empty, zero_add, hR] at hc
    simp only [pk_empty, Matrix.mul_one] at he
    have h := XHost.host_pad hA2 Free.one 1 (D q) U2 hU2D (by rw [hc]; exact hrk q)
    simp only [hc, Matrix.mul_one, Matrix.one_mul] at h
    have h0 : GReach (1 : CMat α) (P * 1) (fun _ => 0) := fun ρ _ _ l => gstep_free hP l _
    rw [Matrix.mul_one] at h0
    exact ⟨P, h0, by rw [hW, he]; exact h⟩
  choose Zp h1 h2 using key
  exact ⟨Zp, h1, h2⟩
end Fresh

end
end P4L
end PowerSaving
end OAI

