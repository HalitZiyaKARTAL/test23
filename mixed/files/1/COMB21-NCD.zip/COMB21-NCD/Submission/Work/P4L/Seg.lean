import Submission.Work.P4L.Fresh

set_option maxHeartbeats 2000000

namespace OAI
namespace PowerSaving
namespace P4L
open Binary Matrix Finset RAM SS CB RF BC GX GF

noncomputable section

section Shift
variable {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

lemma gstep_shift (r : ρ) (z : Space α) : GStep r (1 : CMat α) (Binary.shift z) (fun _ => 0) :=
  ⟨[GMove.old (BMove.shift r z)], Binary.shift z,
    fun mv hmv => by rw [List.mem_singleton] at hmv; subst hmv; trivial,
    fun φ => by simp [GWord.costR, GMove.costR, GMove.shadow, BMove.costR, BMove.rk?],
    Matrix.mul_one _, fun f x => rfl⟩

end Shift







section Normal
variable {α : Type} [Fintype α] [DecidableEq α]

lemma normal_qi (f : ℕ) (A : OBase α) (S : Finset α) (p : α) (v w : Sky α f → ℂ)
    (h : walsh f w = prodF f (fun x => sign (dot (A.v p) x)) * prodF f (fr A S) * walsh f v) :
    matAct f (Binary.shift (A.v p + A.corr S)) w = matAct f (blockMat (A.fam S)) v := by
  have e : w = matAct f (Binary.shift (A.v p) * frame A S) v := by
    apply walsh_injective f
    rw [← matAct_mul, shift_phase, walsh_matAct_wrap, walsh_frame, h, mul_assoc]
  rw [e, matAct_mul, frame_eq_shift_blockMat, ← Matrix.mul_assoc (Binary.shift (A.v p)),
    MX.shift_mul_shift (A.v p) (A.corr S), MX.shift_mul_shift_self (A.v p + A.corr S) (blockMat (A.fam S))]

lemma qi_split (f : ℕ) (A : OBase α) (p : α) :
    prodF f (fun x => (fr A {p} x)⁻¹) = prodF f (fr A {p}) * prodF f (fun x => sign (dot (A.v p) x)) := by
  have e : (fun x => (fr A {p} x)⁻¹) = fun x => fr A {p} x * sign (dot (A.v p) x) := by
    funext x
    exact fr_single_inv A p x
  rw [e]
  exact prodF_mul f _ _

lemma q_mul_qi (f : ℕ) (A : OBase α) (p : α) :
    prodF f (fr A {p}) * prodF f (fun x => (fr A {p} x)⁻¹) = 1 := by
  rw [mul_comm]
  exact prodF_inv_mul f A {p}

end Normal

end
end P4L
end PowerSaving
end OAI
