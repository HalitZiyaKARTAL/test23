import Submission.Work.BridgeC.Stage
import Submission.Work.GCert.Chain.Geom
import Submission.Work.GCert.Data.Raw
import Submission.Work.SharedSumChecker.Check
import Submission.Work.Combine.Ranks
import Submission.Work.SharedSumStructured.Invocation
import Submission.Work.SharedSumChecker.Mats
import Submission.Work.GFrame.Labels.Calc
import Submission.Work.Bridge.Inv
import Submission.Work.Reframe.GeomBase
import Submission.Work.GFrame.Top.Api
import Submission.Work.GFrame.Labels.StageBSem
import Submission.Work.GFrame.Labels.SchedR
import Submission.Work.GCert.Labels.RouteRun
import Submission.Work.GCert.Labels.EndSound
import Submission.Work.GFrame.Engine.Over
import Submission.Work.GFrame.Engine.Sweep
import Submission.WHTCheck.Solution
import Submission.Work.BlockAccounting.Moment
import Submission.Work.P4L.Basis
import Mathlib.Tactic.Linarith

set_option maxHeartbeats 2000000

namespace OAI
namespace PowerSaving
namespace P4L
open Binary Matrix Finset RAM SS CB RF BR GF GX

noncomputable section


section CallView
variable {H T Sl C α Γ : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C] [Fintype α] [DecidableEq α]
  [Fintype Γ] [DecidableEq Γ]

lemma walsh_ratio (f : ℕ) (A : OBase α) (s Δ : Finset α) (h : Disjoint s Δ) (y : Sky α f → ℂ) :
    walsh f (matAct f (frame A (s ∪ Δ)) (matAct f (unframe A s) y)) = prodF f (fr A Δ) * walsh f y := by
  rw [walsh_frame, walsh_unframe, fr_union A s Δ h]
  have e : prodF f (fr A s * fr A Δ) = prodF f (fr A s) * prodF f (fr A Δ) := prodF_mul f (fr A s) (fr A Δ)
  rw [e]
  have hinv := prodF_inv_mul f A s
  calc prodF f (fr A s) * prodF f (fr A Δ) * (prodF f (fun x => (fr A s x)⁻¹) * walsh f y)
      = prodF f (fr A Δ) * ((prodF f (fun x => (fr A s x)⁻¹) * prodF f (fr A s)) * walsh f y) := by ring
    _ = prodF f (fr A Δ) * walsh f y := by rw [hinv, one_mul]

lemma walsh_cross (f : ℕ) (A : OBase α) (sY Δ : Finset α) (p : α) (hΔ : Disjoint sY Δ)
    (hp : Disjoint sY {p}) (y : Sky α f → ℂ) :
    walsh f (matAct f (frame A (sY ∪ Δ)) (matAct f (unframe A (sY ∪ {p})) y))
      = prodF f (fr A Δ) * (prodF f (fun x => (fr A {p} x)⁻¹) * walsh f y) := by
  rw [walsh_frame, walsh_unframe, fr_union A sY Δ hΔ]
  have e1 : (fun x => (fr A (sY ∪ {p}) x)⁻¹) = fun x => (fr A sY x)⁻¹ * (fr A {p} x)⁻¹ := by
    funext x
    rw [fr_union A sY {p} hp, Pi.mul_apply, mul_inv]
  rw [e1]
  have e2 : prodF f (fun x => (fr A sY x)⁻¹ * (fr A {p} x)⁻¹)
      = prodF f (fun x => (fr A sY x)⁻¹) * prodF f (fun x => (fr A {p} x)⁻¹) := prodF_mul f _ _
  have e3 : prodF f (fr A sY * fr A Δ) = prodF f (fr A sY) * prodF f (fr A Δ) := prodF_mul f (fr A sY) (fr A Δ)
  rw [e2, e3]
  have hinv := prodF_inv_mul f A sY
  calc prodF f (fr A sY) * prodF f (fr A Δ) * (prodF f (fun x => (fr A sY x)⁻¹) * prodF f (fun x => (fr A {p} x)⁻¹)
          * walsh f y)
      = prodF f (fr A Δ) * ((prodF f (fun x => (fr A sY x)⁻¹) * prodF f (fr A sY))
          * (prodF f (fun x => (fr A {p} x)⁻¹) * walsh f y)) := by ring
    _ = prodF f (fr A Δ) * (prodF f (fun x => (fr A {p} x)⁻¹) * walsh f y) := by rw [hinv, one_mul]

lemma walsh_cross_b (f : ℕ) (A : OBase α) (sY Δ : Finset α) (p : α) (hΔ : Disjoint (sY ∪ {p}) Δ)
    (hp : Disjoint sY {p}) (y : Sky α f → ℂ) :
    walsh f (matAct f (frame A (sY ∪ {p} ∪ Δ)) (matAct f (unframe A sY) y))
      = prodF f (fr A Δ) * (prodF f (fr A {p}) * walsh f y) := by
  rw [walsh_frame, walsh_unframe, fr_union A (sY ∪ {p}) Δ hΔ, fr_union A sY {p} hp]
  have e3 : prodF f (fr A sY * fr A {p} * fr A Δ) = prodF f (fr A sY) * prodF f (fr A {p}) * prodF f (fr A Δ) := by
    have a1 : prodF f (fr A sY * fr A {p} * fr A Δ) = prodF f (fr A sY * fr A {p}) * prodF f (fr A Δ) :=
      prodF_mul f (fr A sY * fr A {p}) (fr A Δ)
    have a2 : prodF f (fr A sY * fr A {p}) = prodF f (fr A sY) * prodF f (fr A {p}) :=
      prodF_mul f (fr A sY) (fr A {p})
    rw [a1, a2]
  rw [e3]
  have hinv := prodF_inv_mul f A sY
  calc prodF f (fr A sY) * prodF f (fr A {p}) * prodF f (fr A Δ) * (prodF f (fun x => (fr A sY x)⁻¹) * walsh f y)
      = prodF f (fr A Δ) * ((prodF f (fun x => (fr A sY x)⁻¹) * prodF f (fr A sY)) * (prodF f (fr A {p}) * walsh f y)) := by
        ring
    _ = prodF f (fr A Δ) * (prodF f (fr A {p}) * walsh f y) := by rw [hinv, one_mul]

end CallView







end
end P4L
end PowerSaving
end OAI
