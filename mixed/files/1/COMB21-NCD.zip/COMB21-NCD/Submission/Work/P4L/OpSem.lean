import Submission.Work.GFrame.Engine.Over


namespace OAI
namespace PowerSaving
namespace P4L
open Binary Matrix Finset GF

noncomputable section

section Lin
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

lemma matAct_add (f : ℕ) (M : CMat α) (x y : Sky α f → ℂ) :
    matAct f M (x + y) = matAct f M x + matAct f M y := by
  unfold matAct; exact Matrix.mulVec_add _ _ _

end Lin

section Op
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

theorem op_of_walk {S S' T : ρ → CMat α} {g : (ρ → ℂ) → (ρ → ℂ)} {w : GWord α ρ}
    (hwalk : ∀ (f : ℕ) (x : Data α ρ f), gwalk f w (multiAct f S x) = multiAct f T (point f g x))
    (hS : ∀ r, S r * S' r = 1) (f : ℕ) (y : Data α ρ f) :
    gwalk f w y = multiAct f T (point f g (multiAct f S' y)) := by
  have hy : multiAct f S (multiAct f S' y) = y := by
    funext r
    simp only [multiAct, matAct_mul, hS, matAct_one]
  conv_lhs => rw [← hy]
  exact hwalk f (multiAct f S' y)

end Op

section Walsh
variable {α : Type*} [Fintype α] [DecidableEq α]

def walsh (f : ℕ) (x : Sky α f → ℂ) : Sky α f → ℂ :=
  digitProd (fun _ : Fin f => walI α) *ᵥ x

def unwalsh (f : ℕ) (x : Sky α f → ℂ) : Sky α f → ℂ :=
  digitProd (fun _ : Fin f => wal α) *ᵥ x

def prodF (f : ℕ) (φ : Space α → ℂ) : Sky α f → ℂ := fun y => ∏ i, φ (y i)

lemma unwalsh_walsh (f : ℕ) (x : Sky α f → ℂ) : unwalsh f (walsh f x) = x := by
  unfold unwalsh walsh
  rw [Matrix.mulVec_mulVec, digitProd_mul]
  simp_rw [wal_right α]
  rw [digitProd_one, Matrix.one_mulVec]

lemma walsh_injective (f : ℕ) : Function.Injective (walsh (α := α) f) := by
  intro x y h
  rw [← unwalsh_walsh f x, h, unwalsh_walsh]

lemma walsh_add (f : ℕ) (x y : Sky α f → ℂ) : walsh f (x + y) = walsh f x + walsh f y := by
  unfold walsh; exact Matrix.mulVec_add _ _ _

lemma walsh_smul (f : ℕ) (c : ℂ) (x : Sky α f → ℂ) : walsh f (c • x) = c • walsh f x := by
  unfold walsh; exact Matrix.mulVec_smul _ _ _

theorem walsh_matAct_wrap (f : ℕ) (φ : Space α → ℂ) (x : Sky α f → ℂ) :
    walsh f (matAct f (wrap φ) x) = prodF f φ * walsh f x := by
  unfold walsh matAct
  rw [Matrix.mulVec_mulVec, digitProd_mul]
  have e : walI α * wrap φ = diagonal φ * walI α := by
    unfold wrap
    rw [← Matrix.mul_assoc, ← Matrix.mul_assoc, wal_left α, Matrix.one_mul]
  simp_rw [e]
  rw [← digitProd_mul, ← Matrix.mulVec_mulVec, digitProd_diagonal]
  funext y
  simp only [Matrix.mulVec_diagonal, Pi.mul_apply, prodF]

lemma prodF_mul (f : ℕ) (φ ψ : Space α → ℂ) : prodF f (fun x => φ x * ψ x) = prodF f φ * prodF f ψ := by
  funext y
  simp only [prodF, Pi.mul_apply, Finset.prod_mul_distrib]

lemma prodF_one (f : ℕ) : prodF f (fun _ : Space α => (1 : ℂ)) = 1 := by
  funext y
  simp only [prodF, Finset.prod_const_one, Pi.one_apply]

end Walsh

end
end P4L
end PowerSaving
end OAI
