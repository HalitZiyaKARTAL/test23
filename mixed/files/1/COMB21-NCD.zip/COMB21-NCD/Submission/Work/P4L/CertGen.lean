import Submission.Work.P4L.Seg


namespace OAI
namespace PowerSaving.PB
open Binary Matrix Finset GF

noncomputable section

def ind (r : ℕ) : ℕ → ℝ := fun q => if q = r then 1 else 0

section Words
variable {α ρ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

lemma costR_ind (w : GWord α ρ) (r : ℕ) : w.costR (ind r) = (w.hist r : ℝ) := by
  rw [GWord.costR_shadow]
  exact BWord.costR_ind w.shadow r

theorem hist_eq_price {c : (ℕ → ℝ) → ℝ} {w : GWord α ρ} (hcost : ∀ φ, w.costR φ = c φ) (r : ℕ) :
    (w.hist r : ℝ) = c (ind r) := by
  rw [← costR_ind, hcost]

end Words

end
end PowerSaving.PB
end OAI

namespace OAI
namespace PowerSaving
namespace P4L
open Binary Matrix Finset RAM SS CB RF BC GX GF

noncomputable section

lemma hist_of_price {α ρ : Type} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ] (w : GWord α ρ)
    (G : ℕ) (L : List (ℕ × ℕ)) (h : ∀ φ, w.costR φ = (G : ℝ) * listCost φ L) (r : ℕ) :
    w.hist r = G * BlockAccounting.histFn L r := by
  have h1 := PB.hist_eq_price h r
  have hl : listCost (PB.ind r) L = (BlockAccounting.histFn L r : ℝ) := listCost_ind L r
  rw [hl] at h1
  exact_mod_cast h1


end
end P4L
end PowerSaving
end OAI

