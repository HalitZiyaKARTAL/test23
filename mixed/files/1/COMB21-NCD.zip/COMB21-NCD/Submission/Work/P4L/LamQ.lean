import Submission.Work.P4L.Basis

namespace OAI
namespace PowerSaving
namespace LamQ
open Binary Matrix Finset P4L

section frame
variable {α : Type} [Fintype α] [DecidableEq α]

lemma prodF_mul (f : ℕ) (φ ψ : Space α → ℂ) :
    prodF f φ * prodF f ψ = prodF f (fun x => φ x * ψ x) := by
  funext y
  simp only [Pi.mul_apply, prodF, Finset.prod_mul_distrib]

lemma prodF_fr_sq (f : ℕ) (A : OBase α) (s : Finset α) :
    prodF f (fr A s) * prodF f (fr A s) =
      prodF f (fun x => sign (dot (A.proj s x) (A.proj s x))) := by
  rw [prodF_mul]
  congr 1
  funext x
  exact lum_sq _

lemma prodF_fr_pow4 (f : ℕ) (A : OBase α) (s : Finset α) : (prodF f (fr A s)) ^ 4 = 1 := by
  have h : (prodF f (fr A s)) ^ 4 =
      (prodF f (fr A s) * prodF f (fr A s)) * (prodF f (fr A s) * prodF f (fr A s)) := by ring
  rw [h, prodF_fr_sq, prodF_mul]
  funext y
  simp only [prodF, Pi.one_apply]
  exact Finset.prod_eq_one (fun i _ => sign_sq _)

end frame

section lam
variable {β : Type*}

noncomputable def lamF (q : β → ℂ) : β → ℂ := fun y => ca + cb * q y ^ 2

noncomputable def lamF' (q : β → ℂ) : β → ℂ := fun y => cb + ca * q y ^ 2

lemma lamF_sq (q : β → ℂ) (hq4 : q ^ 4 = 1) : lamF q ^ 2 = q ^ 2 := by
  funext y
  have h4 : q y ^ 4 = 1 := by simpa using congrFun hq4 y
  simp only [lamF, Pi.pow_apply, ca, cb]
  linear_combination (-Complex.I / 2) * h4 + ((1 - q y ^ 2) ^ 2 / 4) * Complex.I_sq

lemma lamF'_eq (q qi : β → ℂ) (hq : q * qi = 1) (hq4 : q ^ 4 = 1) : lamF' q = lamF q * qi ^ 2 := by
  funext y
  have h1 : q y * qi y = 1 := by simpa using congrFun hq y
  have h4 : q y ^ 4 = 1 := by simpa using congrFun hq4 y
  simp only [lamF, lamF', Pi.mul_apply, Pi.pow_apply, ca, cb]
  linear_combination (-(q y * qi y + 1) * ((1 - Complex.I) / 2 + (1 + Complex.I) / 2 * q y ^ 2)) * h1 +
    ((1 + Complex.I) / 2 * qi y ^ 2) * h4

end lam

end LamQ
end PowerSaving
end OAI
