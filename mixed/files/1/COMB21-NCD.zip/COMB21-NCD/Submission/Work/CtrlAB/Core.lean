import Submission.Work.KLowW.ShearAB
import Submission.Work.CtrlAB.Defs


namespace CtrlAB
open KLW SSC GXD

-- `CPar` and `CEv` moved to `CtrlAB/Defs.lean` (clean-room ctrl integration)

section Sem
variable {R : Type*} [CommRing R] [Algebra ℚ R]

def dp : (Nat → R) → Nat → Nat → R
  | _, 0, _ => 1
  | D, n + 1, m => (if m % 2 = 1 then D 0 else 1) * dp (fun i => D (i + 1)) n (m / 2)

def monoV (q L : R) (D : Nat → R) (NS m : Nat) : R := q ^ (m % 4) * L ^ (m / 4 % 2) * dp D NS (m / 8)

def cq (co : Co) : ℚ := sgnQ co.neg co.num co.den

def semEv (q L : R) (D : Nat → R) (NS : Nat) : CEv → (Nat → R) → (Nat → R)
  | .add t r co ex, s => Function.update s t (s t + algebraMap ℚ R (cq co) * (monoV q L D NS ex * s r))
  | .mul r co, s => Function.update s r (algebraMap ℚ R (cq co) * s r)
  | .mon r m, s => Function.update s r (monoV q L D NS m * s r)
  | .swp r t, s => fun i => if i = r then s t else if i = t then s r else s i

def semEvs (q L : R) (D : Nat → R) (NS : Nat) : List CEv → (Nat → R) → (Nat → R)
  | [], s => s
  | e :: es, s => semEvs q L D NS es (semEv q L D NS e s)

theorem dp_zero : ∀ (n : Nat) (D : Nat → R), dp D n 0 = 1 := by
  intro n; induction n with
  | zero => intro D; rfl
  | succ n ih => intro D; simp [dp, ih]

theorem monoV_qpow (q L : R) (D : Nat → R) (NS e : Nat) (he : e < 4) : monoV q L D NS e = q ^ e := by
  unfold monoV
  rw [Nat.mod_eq_of_lt he, show e / 4 % 2 = 0 by omega, show e / 8 = 0 by omega, dp_zero, pow_zero, mul_one, mul_one]

end Sem

end CtrlAB

