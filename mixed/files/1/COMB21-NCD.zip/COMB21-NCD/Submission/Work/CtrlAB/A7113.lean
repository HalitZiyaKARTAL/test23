import Submission.Work.CtrlAB.Pack7113

set_option maxRecDepth 100000

namespace CtrlAB.A7113
open CtrlAB CtrlAB.CR GXD

def P : CPar := ⟨6, 36, 36, 18, 1⟩

ctrl_chunks 1 36 36 2 [553, 553]

def evs : List CEv := c0 ++ (c1)

def diag : List Nat := [2097139, 4083, 4067, 4035, 3971, 3843, 3587, 3075, 2051, 4099, 12291, 28675, 61443, 126979, 258051, 520195, 1044483, 2093059, 2097139, 4083, 4067, 4035, 3971, 3843, 3587, 3075, 2051, 4099, 12291, 28675, 61443, 126979, 258051, 520195, 1044483, 2093059]

theorem par_ok : parK P = true := by decide +kernel

theorem seg0 : segK P (initS P.nr (2 * P.Dn)) c0 s1 = true := by decide +kernel

theorem seg1 : lastK P (s1) c1 diag = true := by decide +kernel

theorem diagG {R : Type _} [Lean.Grind.CommRing R] (κ : Co → R) (φ : Int → R) (q L : R) (D u : Nat → R)
    (H : Hyp κ φ q L P) (h1 : φ (P.Dn : Int) = 1) (i : Nat) (hi : i < P.nr) :
    semEvsG κ (monoG q L D P.NS) evs u i = monoG q L D P.NS (diag.getD i 0) * u i := by
  have r0 := initS_rep κ φ q L D u P H h1 (parK_nr P par_ok)
  have r1 := seg_rep κ φ q L D u P H par_ok seg0 r0
  rw [show evs = c0 ++ (c1) from rfl, semEvsG_append]
  exact last_val κ φ q L D u P H h1 par_ok seg1 r1 i hi

end CtrlAB.A7113

