import Submission.Work.GCert.Data.Raw

namespace CtrlAB
open GXD

structure CPar where
  d : Nat
  nr : Nat
  N : Nat
  NS : Nat
  Dn : Nat

inductive CEv where
  | add (t s : Nat) (co : Co) (e : Nat)
  | mul (r : Nat) (co : Co)
  | mon (r : Nat) (m : Nat)
  | swp (r s : Nat)
  deriving DecidableEq

end CtrlAB

