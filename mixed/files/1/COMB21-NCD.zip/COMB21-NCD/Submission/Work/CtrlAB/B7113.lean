import Submission.Work.CtrlAB.Pack7113

set_option maxRecDepth 100000

namespace CtrlAB.B7113
open CtrlAB CtrlAB.CR GXD

def P : CPar := ⟨6, 36, 36, 18, 691200⟩

ctrl_chunks 0 36 36 1382400 [495, 495, 496, 495, 495, 496, 495, 495]

def evs : List CEv := c0 ++ (c1 ++ (c2 ++ (c3 ++ (c4 ++ (c5 ++ (c6 ++ (c7)))))))

def diag : List Nat := [2097139, 2097139, 4083, 4083, 4067, 4067, 4035, 4035, 3971, 3971, 3843, 3843, 3587, 3587, 3075, 3075, 2093059, 2093059, 1044483, 1044483, 520195, 520195, 258051, 258051, 126979, 126979, 61443, 61443, 28675, 28675, 12291, 12291, 2051, 2051, 4099, 4099]

theorem par_ok : parK P = true := by decide +kernel

theorem seg0 : segK P (initS P.nr (2 * P.Dn)) c0 s1 = true := by decide +kernel

theorem seg1 : segK P (s1) c1 s2 = true := by decide +kernel

theorem seg2 : segK P (s2) c2 s3 = true := by decide +kernel

theorem seg3 : segK P (s3) c3 s4 = true := by decide +kernel

theorem seg4 : segK P (s4) c4 s5 = true := by decide +kernel

theorem seg5 : segK P (s5) c5 s6 = true := by decide +kernel

theorem seg6 : segK P (s6) c6 s7 = true := by decide +kernel

theorem seg7 : lastK P (s7) c7 diag = true := by decide +kernel

theorem diagG {R : Type _} [Lean.Grind.CommRing R] (κ : Co → R) (φ : Int → R) (q L : R) (D u : Nat → R)
    (H : Hyp κ φ q L P) (h1 : φ (P.Dn : Int) = 1) (i : Nat) (hi : i < P.nr) :
    semEvsG κ (monoG q L D P.NS) evs u i = monoG q L D P.NS (diag.getD i 0) * u i := by
  have r0 := initS_rep κ φ q L D u P H h1 (parK_nr P par_ok)
  have r1 := seg_rep κ φ q L D u P H par_ok seg0 r0
  have r2 := seg_rep κ φ q L D u P H par_ok seg1 r1
  have r3 := seg_rep κ φ q L D u P H par_ok seg2 r2
  have r4 := seg_rep κ φ q L D u P H par_ok seg3 r3
  have r5 := seg_rep κ φ q L D u P H par_ok seg4 r4
  have r6 := seg_rep κ φ q L D u P H par_ok seg5 r5
  have r7 := seg_rep κ φ q L D u P H par_ok seg6 r6
  rw [show evs = c0 ++ (c1 ++ (c2 ++ (c3 ++ (c4 ++ (c5 ++ (c6 ++ (c7))))))) from rfl, semEvsG_append, semEvsG_append, semEvsG_append, semEvsG_append, semEvsG_append, semEvsG_append, semEvsG_append]
  exact last_val κ φ q L D u P H h1 par_ok seg7 r7 i hi

end CtrlAB.B7113

