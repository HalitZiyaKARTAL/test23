import Submission.Work.CtrlAB.Core
import Submission.Work.CtrlAB.A7113
import Submission.Work.CtrlAB.B7113

namespace CtrlAB.CR
open GXD

section
variable {R : Type*} [CommRing R] [Algebra ℚ R]

theorem pw_eq (x : R) : ∀ n : Nat, pw x n = x ^ n
  | 0 => by rw [pow_zero]; rfl
  | n + 1 => by rw [pow_succ, ← pw_eq x n]; rfl

theorem dpG_eq : ∀ (n : Nat) (D : Nat → R) (m : Nat), dpG D n m = CtrlAB.dp D n m
  | 0, D, m => by rw [CtrlAB.dp]; rfl
  | n + 1, D, m => by rw [CtrlAB.dp, ← dpG_eq n]; rfl

theorem monoV_eq (q L : R) (D : Nat → R) (NS : Nat) : CtrlAB.monoV q L D NS = monoG q L D NS := by
  funext m; unfold CtrlAB.monoV monoG; rw [pw_eq, pw_eq, dpG_eq]

theorem semEvs_eq (q L : R) (D : Nat → R) (NS : Nat) (evs : List CEv) : ∀ s : Nat → R,
    CtrlAB.semEvs q L D NS evs s = semEvsG (fun co => algebraMap ℚ R (CtrlAB.cq co)) (CtrlAB.monoV q L D NS) evs s := by
  induction evs with
  | nil => intro s; rfl
  | cons e es ih =>
    intro s
    rw [CtrlAB.semEvs, semEvsG, ih]
    congr 1
    cases e <;> funext i <;> simp only [CtrlAB.semEv, semEvG, upd, Function.update_apply] <;> rfl

theorem hypQ (P : CPar) (q L : R) (hq : q ^ 4 = 1) (hL : L ^ 2 = q ^ 2) :
    Hyp (fun co => algebraMap ℚ R (CtrlAB.cq co)) (fun x => algebraMap ℚ R ((x : ℚ) / (P.Dn : ℚ))) q L P where
  h0 := by show algebraMap ℚ R (((0 : Int) : ℚ) / (P.Dn : ℚ)) = 0; simp
  hadd := by
    intro x y
    show algebraMap ℚ R (((x + y : Int) : ℚ) / (P.Dn : ℚ))
      = algebraMap ℚ R ((x : ℚ) / (P.Dn : ℚ)) + algebraMap ℚ R ((y : ℚ) / (P.Dn : ℚ))
    rw [← map_add]; congr 1; push_cast; ring
  hκ := by
    intro co x y hd h
    show algebraMap ℚ R (CtrlAB.cq co) * algebraMap ℚ R ((x : ℚ) / (P.Dn : ℚ)) = algebraMap ℚ R ((y : ℚ) / (P.Dn : ℚ))
    rw [← map_mul]; congr 1
    have hd' : (co.den : ℚ) ≠ 0 := by exact_mod_cast hd.ne'
    unfold CtrlAB.cq KLW.sgnQ
    cases hn : co.neg
    · simp only [hn, Bool.false_eq_true, if_false] at h ⊢
      have h' : (co.den : ℚ) * (y : ℚ) = (co.num : ℚ) * (x : ℚ) := by exact_mod_cast h
      have hy : (y : ℚ) = (co.num : ℚ) * x / co.den := by rw [eq_div_iff hd']; linarith
      rw [hy]; ring
    · simp only [hn, if_true] at h ⊢
      have h' : (co.den : ℚ) * (y : ℚ) = -(co.num : ℚ) * (x : ℚ) := by exact_mod_cast h
      have hy : (y : ℚ) = -(co.num : ℚ) * x / co.den := by rw [eq_div_iff hd']; linarith
      rw [hy]; ring
  hq := by rw [pw_eq]; exact hq
  hL := by rw [pw_eq, pw_eq]; exact hL

theorem phi_one (P : CPar) (h : P.Dn ≠ 0) :
    algebraMap ℚ R ((((P.Dn : Nat) : Int) : ℚ) / (P.Dn : ℚ)) = 1 := by
  have h' : (P.Dn : ℚ) ≠ 0 := by exact_mod_cast h
  rw [Int.cast_natCast, div_self h', map_one]

end
end CtrlAB.CR

theorem CtrlAB.B7113.ctrl_diag {R : Type*} [CommRing R] [Algebra ℚ R] (q L : R) (D : Nat → R)
    (hq : q ^ 4 = 1) (hL : L ^ 2 = q ^ 2) (u : Nat → R) (i : Nat) (hi : i < 36) :
    CtrlAB.semEvs q L D CtrlAB.B7113.P.NS CtrlAB.B7113.evs u i
      = CtrlAB.monoV q L D CtrlAB.B7113.P.NS (CtrlAB.B7113.diag.getD i 0) * u i := by
  rw [CtrlAB.CR.semEvs_eq, CtrlAB.CR.monoV_eq]
  exact CtrlAB.B7113.diagG _ _ q L D u (CtrlAB.CR.hypQ _ q L hq hL)
    (CtrlAB.CR.phi_one _ (by decide)) i hi

theorem CtrlAB.A7113.ctrl_diag {R : Type*} [CommRing R] [Algebra ℚ R] (q L : R) (D : Nat → R)
    (hq : q ^ 4 = 1) (hL : L ^ 2 = q ^ 2) (u : Nat → R) (i : Nat) (hi : i < 36) :
    CtrlAB.semEvs q L D CtrlAB.A7113.P.NS CtrlAB.A7113.evs u i
      = CtrlAB.monoV q L D CtrlAB.A7113.P.NS (CtrlAB.A7113.diag.getD i 0) * u i := by
  rw [CtrlAB.CR.semEvs_eq, CtrlAB.CR.monoV_eq]
  exact CtrlAB.A7113.diagG _ _ q L D u (CtrlAB.CR.hypQ _ q L hq hL)
    (CtrlAB.CR.phi_one _ (by decide)) i hi

