import Submission.Work.CtrlAB.Defs

namespace CtrlAB.CR
open GXD CtrlAB

noncomputable section

inductive Row where
  | n
  | c (k z : Nat) (t : Row)

abbrev bsel {α : Sort _} (b : Bool) (t e : α) : α := Bool.rec e t b
abbrev gd (b x : Bool) : Bool := Bool.rec false x b

def decI (z : Nat) : Int := if z % 2 = 0 then ((z / 2 : Nat) : Int) else -(((z + 1) / 2 : Nat) : Int)

def zadd (a b : Nat) : Nat :=
  bsel (Nat.beq (Nat.mod a 2) 0)
    (bsel (Nat.beq (Nat.mod b 2) 0) (Nat.add a b)
      (bsel (Nat.blt b a) (Nat.sub (Nat.sub a b) 1) (Nat.sub b a)))
    (bsel (Nat.beq (Nat.mod b 2) 0)
      (bsel (Nat.blt a b) (Nat.sub (Nat.sub b a) 1) (Nat.sub a b))
      (Nat.add (Nat.add a b) 1))

def zmag (z : Nat) : Nat := Nat.div (Nat.add z 1) 2
def zsg (z : Nat) : Bool := Nat.beq (Nat.mod z 2) 1
def zenc (s : Bool) (m : Nat) : Nat := bsel s (Nat.sub (Nat.add m m) 1) (Nat.add m m)
def bxor (a b : Bool) : Bool := Bool.rec b (Bool.rec true false b) a

def cm (a b : Nat) : Nat :=
  Nat.add (Nat.mod (Nat.add (Nat.add (Nat.mod a 4) (Nat.mod b 4))
      (Nat.mul 2 (Nat.mul (Nat.mod (Nat.div a 4) 2) (Nat.mod (Nat.div b 4) 2)))) 4)
    (Nat.add (Nat.mul 4 (Nat.mod (Nat.add (Nat.mod (Nat.div a 4) 2) (Nat.mod (Nat.div b 4) 2)) 2))
      (Nat.mul 8 (Nat.add (Nat.div a 8) (Nat.div b 8))))

def kcode (N k : Nat) : Nat := Nat.add (Nat.mod k 8) (Nat.mul 8 (Nat.div (Nat.div k 8) N))
def kcol (N k : Nat) : Nat := Nat.mod (Nat.div k 8) N
def kmk (N c col : Nat) : Nat := Nat.add (Nat.mul (Nat.add (Nat.mul (Nat.div c 8) N) col) 8) (Nat.mod c 8)

def zpush (k s : Nat) (L : Row) : Row := bsel (Nat.beq s 0) L (.c k s L)

def insK (k c : Nat) : Row → Row :=
  Row.rec (motive := fun _ => Row) (.c k c .n)
    (fun ek ez L ih => bsel (Nat.blt k ek) (.c k c (.c ek ez L))
      (bsel (Nat.beq k ek) (zpush k (zadd c ez) L) (.c ek ez ih)))

def mergeK : Row → Row → Row :=
  Row.rec (motive := fun _ => Row → Row) (fun b => b)
    (fun xk xz xs ih b => Row.rec (motive := fun _ => Row) (.c xk xz xs)
      (fun yk yz ys ihy => bsel (Nat.blt xk yk) (.c xk xz (ih (.c yk yz ys)))
        (bsel (Nat.beq xk yk) (zpush xk (zadd xz yz) (ih ys)) (.c yk yz ihy))) b)

def scaleK (ng : Bool) (num den : Nat) : Row → (Row → Bool) → Bool :=
  Row.rec (motive := fun _ => (Row → Bool) → Bool) (fun k => k .n)
    (fun ek ez _ ih k => gd (Nat.beq (Nat.mod (Nat.mul (zmag ez) num) den) 0)
      (ih fun r => k (.c ek (zenc (bxor (zsg ez) ng) (Nat.div (Nat.mul (zmag ez) num) den)) r)))

def mmK (N e : Nat) : Row → (Row → Bool) → Bool :=
  Row.rec (motive := fun _ => (Row → Bool) → Bool) (fun k => k .n)
    (fun ek ez _ ih k => gd (Nat.beq (Nat.land (Nat.div (Nat.div ek 8) N) (Nat.div e 8)) 0)
      (ih fun r => k (insK (kmk N (cm (kcode N ek) e) (kcol N ek)) ez r)))

def lget (S : List Row) : Nat → Row :=
  List.rec (motive := fun _ => Nat → Row) (fun _ => .n)
    (fun x _ ih i => Nat.rec (motive := fun _ => Row) x (fun j _ => ih j) i) S

def lset (S : List Row) : Nat → Row → List Row :=
  List.rec (motive := fun _ => Nat → Row → List Row) (fun _ _ => [])
    (fun x xs ih i v => Nat.rec (motive := fun _ => List Row) (v :: xs) (fun j _ => x :: ih j v) i) S

def evK (P : CPar) (e : CEv) (S : List Row) (k : List Row → Bool) : Bool :=
  CEv.rec (motive := fun _ => Bool)
    (fun t s co ex => gd (Nat.blt t P.nr) <| gd (Nat.blt s P.nr) <| gd (Nat.blt 0 co.den) <|
      scaleK co.neg co.num co.den (lget S s) fun rs =>
        bsel (Nat.beq ex 0) (k (lset S t (mergeK (lget S t) rs)))
          (mmK P.N ex rs fun rs' => k (lset S t (mergeK (lget S t) rs'))))
    (fun r co => gd (Nat.blt r P.nr) <| gd (Nat.blt 0 co.den) <|
      scaleK co.neg co.num co.den (lget S r) fun r' => k (lset S r r'))
    (fun r m => gd (Nat.blt r P.nr) <| mmK P.N m (lget S r) fun r' => k (lset S r r'))
    (fun r t => gd (Nat.blt r P.nr) <| gd (Nat.blt t P.nr) <|
      k (lset (lset S r (lget S t)) t (lget S r)))
    e

def evsK (P : CPar) : List CEv → List Row → (List Row → Bool) → Bool :=
  List.rec (motive := fun _ => List Row → (List Row → Bool) → Bool) (fun S k => k S)
    (fun e _ ih S k => evK P e S fun S1 => ih S1 k)

def rowIs (r : Row) (k z : Nat) : Bool :=
  match r with
  | .c k' z' .n => Nat.beq k' k && Nat.beq z' z
  | _ => false

def finK (N z : Nat) : List Row → List Nat → Nat → Bool
  | [], _, _ => true
  | r :: S, dg, i => rowIs r (kmk N (dg.headD 0) i) z && finK N z S dg.tail (i + 1)

def initS (nr z : Nat) : List Row := (List.range nr).map fun i => Row.c (8 * i) z .n

def rowEqK : Row → Row → Bool :=
  Row.rec (motive := fun _ => Row → Bool)
    (fun b => Row.rec (motive := fun _ => Bool) true (fun _ _ _ _ => false) b)
    (fun xk xz _ ih b => Row.rec (motive := fun _ => Bool) false
      (fun yk yz ys _ => gd (Nat.beq xk yk) (gd (Nat.beq xz yz) (ih ys))) b)

def stEqK : List Row → List Row → Bool :=
  List.rec (motive := fun _ => List Row → Bool)
    (fun T => List.rec (motive := fun _ => Bool) true (fun _ _ _ => false) T)
    (fun x _ ih T => List.rec (motive := fun _ => Bool) false (fun y ys _ => gd (rowEqK x y) (ih ys)) T)

def parK (P : CPar) : Bool := gd (Nat.ble 1 P.N) <| gd (Nat.ble P.nr P.N) <| Nat.blt 0 P.Dn

def segK (P : CPar) (S : List Row) (evs : List CEv) (S' : List Row) : Bool := evsK P evs S fun T => stEqK T S'

def lastK (P : CPar) (S : List Row) (evs : List CEv) (diag : List Nat) : Bool :=
  evsK P evs S fun T => finK P.N (2 * P.Dn) T diag 0

end

section Sem
variable {R : Type _} [Lean.Grind.CommRing R]

def pw (x : R) : Nat → R
  | 0 => 1
  | n + 1 => pw x n * x

def dpG : (Nat → R) → Nat → Nat → R
  | _, 0, _ => 1
  | D, n + 1, m => (if m % 2 = 1 then D 0 else 1) * dpG (fun i => D (i + 1)) n (m / 2)

def monoG (q L : R) (D : Nat → R) (NS m : Nat) : R := pw q (m % 4) * pw L (m / 4 % 2) * dpG D NS (m / 8)

def upd (s : Nat → R) (t : Nat) (v : R) : Nat → R := fun i => if i = t then v else s i

def semEvG (κ : Co → R) (mono : Nat → R) : CEv → (Nat → R) → (Nat → R)
  | .add t r co ex, s => upd s t (s t + κ co * (mono ex * s r))
  | .mul r co, s => upd s r (κ co * s r)
  | .mon r m, s => upd s r (mono m * s r)
  | .swp r t, s => fun i => if i = r then s t else if i = t then s r else s i

def semEvsG (κ : Co → R) (mono : Nat → R) : List CEv → (Nat → R) → (Nat → R)
  | [], s => s
  | e :: es, s => semEvsG κ mono es (semEvG κ mono e s)

def rv (φ : Int → R) (tm : Nat → R) : Row → R
  | .n => 0
  | .c k z t => φ (decI z) * tm k + rv φ tm t

end Sem

theorem gd_true (b x : Bool) (h : gd b x = true) : b = true ∧ x = true := by
  cases b <;> simp_all [gd]

theorem beq_iff (a b : Nat) : Nat.beq a b = true ↔ a = b := ⟨Nat.eq_of_beq_eq_true, fun h => h ▸ Nat.beq_refl a⟩
theorem blt_iff (a b : Nat) : Nat.blt a b = true ↔ a < b := by
  simp [Nat.blt, Nat.ble_eq]; omega

theorem nmod (a b : Nat) : Nat.mod a b = a % b := rfl
theorem ndiv (a b : Nat) : Nat.div a b = a / b := rfl
theorem nadd (a b : Nat) : Nat.add a b = a + b := rfl
theorem nsub (a b : Nat) : Nat.sub a b = a - b := rfl
theorem nmul (a b : Nat) : Nat.mul a b = a * b := rfl
theorem bsel_eq {α : Sort _} (b : Bool) (t e : α) : bsel b t e = if b = true then t else e := by cases b <;> rfl

theorem decI_zadd (a b : Nat) : decI (zadd a b) = decI a + decI b := by
  unfold zadd decI
  simp only [bsel_eq, beq_iff, blt_iff, nmod, nadd, nsub]
  (repeat' split) <;> omega

theorem decI_sg (z : Nat) : decI z = if zsg z = true then -((zmag z : Nat) : Int) else ((zmag z : Nat) : Int) := by
  unfold decI zsg zmag
  simp only [beq_iff, nmod, ndiv, nadd]
  (repeat' split) <;> omega

theorem decI_zenc (s : Bool) (m : Nat) : decI (zenc s m) = if s = true then -(m : Int) else (m : Int) := by
  unfold zenc decI
  simp only [bsel_eq, nadd, nsub]
  (repeat' split) <;> omega

theorem decI_zero : decI 0 = 0 := rfl
theorem decI_two (n : Nat) : decI (2 * n) = n := by unfold decI; split <;> omega

theorem zsc_spec (ng : Bool) (num den z : Nat) (hd : 0 < den) (hm : Nat.mod (Nat.mul (zmag z) num) den = 0) :
    (den : Int) * decI (zenc (bxor (zsg z) ng) (Nat.div (Nat.mul (zmag z) num) den))
      = (if ng = true then -(num : Int) else (num : Int)) * decI z := by
  have hm' : (zmag z * num) % den = 0 := hm
  have hdm : den * ((zmag z * num) / den) = zmag z * num := Nat.mul_div_cancel' (Nat.dvd_of_mod_eq_zero hm')
  have hI : (den : Int) * (((zmag z * num) / den : Nat) : Int) = (zmag z : Int) * num := by exact_mod_cast hdm
  show (den : Int) * decI (zenc (bxor (zsg z) ng) ((zmag z * num) / den)) = _
  rw [decI_zenc, decI_sg z]
  generalize ((zmag z * num) / den : Nat) = m at hI
  cases zsg z <;> cases ng <;> simp [bxor] <;> grind

section Ring
variable {R : Type _} [Lean.Grind.CommRing R]

theorem pw_add (x : R) (m n : Nat) : pw x (m + n) = pw x m * pw x n := by
  induction n with
  | zero => simp [pw] <;> grind
  | succ n ih => rw [← Nat.add_assoc]; simp only [pw]; rw [ih]; grind

theorem pw_mod4 (q : R) (hq : pw q 4 = 1) (n : Nat) : pw q n = pw q (n % 4) := by
  induction n using Nat.strongRecOn with
  | _ n ih =>
    by_cases h : n < 4
    · rw [Nat.mod_eq_of_lt h]
    · have e : n = (n - 4) + 4 := by omega
      rw [e, pw_add, hq, ih (n - 4) (by omega)]
      have : (n - 4 + 4) % 4 = (n - 4) % 4 := by omega
      rw [this]; grind

theorem pw_zero (x : R) : pw x 0 = 1 := rfl
theorem land_odd (a b : Nat) (h : a &&& b = 0) : ¬ (a % 2 = 1 ∧ b % 2 = 1) := by
  intro ⟨ha, hb⟩
  have := congrArg (fun x => Nat.testBit x 0) h
  simp [Nat.testBit_zero, ha, hb] at this

theorem land_half (a b : Nat) (h : a &&& b = 0) : (a / 2) &&& (b / 2) = 0 := by
  apply Nat.eq_of_testBit_eq; intro i
  have := congrArg (fun x => Nat.testBit x (i + 1)) h
  simp only [Nat.zero_testBit] at this ⊢
  rw [Nat.testBit_and, Nat.testBit_succ, Nat.testBit_succ] at this
  rw [Nat.testBit_and]; exact this

theorem dpG_add (n : Nat) : ∀ (D : Nat → R) (a b : Nat), a &&& b = 0 →
    dpG D n (a + b) = dpG D n a * dpG D n b := by
  induction n with
  | zero => intro D a b _; simp [dpG] <;> grind
  | succ n ih =>
    intro D a b h
    have h1 := land_odd a b h
    have h2 := land_half a b h
    have e2 : (a + b) / 2 = a / 2 + b / 2 := by omega
    simp only [dpG]; rw [e2, ih _ _ _ h2]
    by_cases ha : a % 2 = 1 <;> by_cases hb : b % 2 = 1
    · exact absurd ⟨ha, hb⟩ h1
    all_goals simp [ha, hb, show (a + b) % 2 = 1 ↔ (a % 2 = 1 ∨ b % 2 = 1) by omega] <;> grind

theorem dpG_zero (n : Nat) : ∀ (D : Nat → R), dpG D n 0 = 1 := by
  induction n with
  | zero => intro D; rfl
  | succ n ih => intro D; simp [dpG, ih] <;> grind

theorem cm_eq (a b : Nat) : cm a b = (a % 4 + b % 4 + 2 * (a / 4 % 2 * (b / 4 % 2))) % 4
    + (4 * ((a / 4 % 2 + b / 4 % 2) % 2) + 8 * (a / 8 + b / 8)) := rfl

theorem monoG_cm (q L : R) (D : Nat → R) (NS : Nat) (hq : pw q 4 = 1) (hL : pw L 2 = pw q 2)
    (a b : Nat) (h : (a / 8) &&& (b / 8) = 0) :
    monoG q L D NS (cm a b) = monoG q L D NS a * monoG q L D NS b := by
  unfold monoG
  have h8 : cm a b / 8 = a / 8 + b / 8 := by rw [cm_eq]; omega
  rw [h8, dpG_add _ _ _ _ h]
  have ha : a / 4 % 2 = 0 ∨ a / 4 % 2 = 1 := by omega
  have hb : b / 4 % 2 = 0 ∨ b / 4 % 2 = 1 := by omega
  have hqa := pw_add q (a % 4) (b % 4)
  rcases ha with ha | ha <;> rcases hb with hb | hb
  rotate_left 3
  · have h4 : cm a b % 4 = (a % 4 + b % 4 + 2) % 4 := by rw [cm_eq, ha, hb]; omega
    have hl : cm a b / 4 % 2 = 0 := by rw [cm_eq, ha, hb]; omega
    have hLL : pw L 1 * pw L 1 = pw q 2 := by rw [← hL, ← pw_add]
    rw [h4, hl, ha, hb, ← pw_mod4 q hq, pw_add, hqa, ← hLL]; simp only [pw_zero] <;> grind
  all_goals
    have h4 : cm a b % 4 = (a % 4 + b % 4) % 4 := by rw [cm_eq, ha, hb]; omega
    have hl : cm a b / 4 % 2 = a / 4 % 2 + b / 4 % 2 := by rw [cm_eq, ha, hb]; omega
    rw [h4, hl, ha, hb, ← pw_mod4 q hq, hqa]; simp only [pw_zero, Nat.add_zero, Nat.zero_add] <;> grind

theorem monoG_zero (q L : R) (D : Nat → R) (NS : Nat) : monoG q L D NS 0 = 1 := by
  unfold monoG; simp [pw, dpG_zero] <;> grind

variable (φ : Int → R) (tm : Nat → R)

theorem rv_zpush (h0 : φ 0 = 0) (k s : Nat) (L : Row) : rv φ tm (zpush k s L) = φ (decI s) * tm k + rv φ tm L := by
  unfold zpush
  cases h : Nat.beq s 0
  · rfl
  · have : s = 0 := (beq_iff _ _).1 h
    subst this; simp [bsel, decI_zero, h0] <;> grind

theorem rv_insK (h0 : φ 0 = 0) (hadd : ∀ x y, φ (x + y) = φ x + φ y) (k c : Nat) (L : Row) :
    rv φ tm (insK k c L) = φ (decI c) * tm k + rv φ tm L := by
  induction L with
  | n => simp [insK, rv] <;> grind
  | c ek ez L ih =>
    show rv φ tm (bsel (Nat.blt k ek) (.c k c (.c ek ez L))
      (bsel (Nat.beq k ek) (zpush k (zadd c ez) L) (.c ek ez (insK k c L)))) = _
    cases h1 : Nat.blt k ek
    · cases h2 : Nat.beq k ek
      · simp only [rv, ih] <;> grind
      · have : k = ek := (beq_iff _ _).1 h2
        subst this
        simp only [rv_zpush φ tm h0, decI_zadd, hadd, rv] <;> grind
    · simp only [rv]

theorem rv_merge (h0 : φ 0 = 0) (hadd : ∀ x y, φ (x + y) = φ x + φ y) (a : Row) :
    ∀ b, rv φ tm (mergeK a b) = rv φ tm a + rv φ tm b := by
  induction a with
  | n => intro b; show rv φ tm b = _; simp [rv] <;> grind
  | c xk xz xs ih =>
    intro b
    induction b with
    | n => show rv φ tm (.c xk xz xs) = _; simp [rv] <;> grind
    | c yk yz ys ihy =>
      show rv φ tm (bsel (Nat.blt xk yk) (.c xk xz (mergeK xs (.c yk yz ys)))
        (bsel (Nat.beq xk yk) (zpush xk (zadd xz yz) (mergeK xs ys)) (.c yk yz (mergeK (.c xk xz xs) ys)))) = _
      cases h1 : Nat.blt xk yk
      · cases h2 : Nat.beq xk yk
        · simp only [rv]; rw [ihy]; simp only [rv]; grind
        · have : xk = yk := (beq_iff _ _).1 h2
          subst this
          simp only [rv_zpush φ tm h0, decI_zadd, hadd, rv, ih] <;> grind
      · simp only [rv, ih] <;> grind

theorem scaleK_sound (ng : Bool) (num den : Nat) (c : R)
    (hc : ∀ x y : Int, (den : Int) * y = (if ng = true then -(num : Int) else (num : Int)) * x → c * φ x = φ y)
    (hd : 0 < den) (row : Row) :
    ∀ k, scaleK ng num den row k = true → ∃ r', k r' = true ∧ rv φ tm r' = c * rv φ tm row := by
  induction row with
  | n => intro k h; exact ⟨.n, h, by simp [rv] <;> grind⟩
  | c ek ez t ih =>
    intro k h
    have h' := gd_true _ _ h
    obtain ⟨r', hk, hr⟩ := ih _ h'.2
    refine ⟨_, hk, ?_⟩
    have hm := (beq_iff _ _).1 h'.1
    have e := hc _ _ (zsc_spec ng num den ez hd hm)
    simp only [rv, hr, ← e] <;> grind

theorem mmK_sound (N e : Nat) (me : R)
    (htm : ∀ k, (k / 8 / N) &&& (e / 8) = 0 → tm (kmk N (cm (kcode N k) e) (kcol N k)) = me * tm k)
    (h0 : φ 0 = 0) (hadd : ∀ x y, φ (x + y) = φ x + φ y) (row : Row) :
    ∀ k, mmK N e row k = true → ∃ r', k r' = true ∧ rv φ tm r' = me * rv φ tm row := by
  induction row with
  | n => intro k h; exact ⟨.n, h, by simp [rv] <;> grind⟩
  | c ek ez t ih =>
    intro k h
    have h' := gd_true _ _ h
    obtain ⟨r', hk, hr⟩ := ih _ h'.2
    refine ⟨_, hk, ?_⟩
    have hm := (beq_iff _ _).1 h'.1
    have e1 := htm ek hm
    show rv φ tm (insK (kmk N (cm (kcode N ek) e) (kcol N ek)) ez r') = _
    rw [rv_insK φ tm h0 hadd, e1, hr]; simp only [rv] <;> grind

end Ring

theorem lget_eq (S : List Row) (i : Nat) : lget S i = S.getD i .n := by
  induction S generalizing i with
  | nil => rfl
  | cons x xs ih => cases i with
    | zero => rfl
    | succ j => show lget xs j = _; rw [ih]; simp

theorem lset_eq (S : List Row) (i : Nat) (v : Row) : lset S i v = S.set i v := by
  induction S generalizing i with
  | nil => rfl
  | cons x xs ih => cases i with
    | zero => rfl
    | succ j => show x :: lset xs j v = _; rw [ih]; simp

theorem lget_lset (S : List Row) (j : Nat) (v : Row) (hj : j < S.length) (i : Nat) :
    lget (lset S j v) i = if i = j then v else lget S i := by
  rw [lget_eq, lget_eq, lset_eq]
  by_cases h : i = j
  · subst h; simp [List.getD_eq_getElem?_getD, hj]
  · simp [List.getD_eq_getElem?_getD, Ne.symm h, h]

theorem length_lset (S : List Row) (j : Nat) (v : Row) : (lset S j v).length = S.length := by
  rw [lset_eq]; simp

section Sound
variable {R : Type _} [Lean.Grind.CommRing R]

def Rep (nr : Nat) (φ : Int → R) (tm : Nat → R) (S : List Row) (s : Nat → R) : Prop :=
  S.length = nr ∧ ∀ i, i < nr → rv φ tm (lget S i) = s i

variable (κ : Co → R) (φ : Int → R) (q L : R) (D : Nat → R) (u : Nat → R) (P : CPar)

structure Hyp (κ : Co → R) (φ : Int → R) (q L : R) (P : CPar) : Prop where
  h0 : φ 0 = 0
  hadd : ∀ x y, φ (x + y) = φ x + φ y
  hκ : ∀ (co : Co) (x y : Int), 0 < co.den →
    (co.den : Int) * y = (if co.neg = true then -(co.num : Int) else (co.num : Int)) * x → κ co * φ x = φ y
  hq : pw q 4 = 1
  hL : pw L 2 = pw q 2

def tmG (k : Nat) : R := monoG q L D P.NS (kcode P.N k) * u (kcol P.N k)

theorem kcode_kmk (N c col : Nat) (hN : 0 < N) (hc : col < N) : kcode N (kmk N c col) = c := by
  unfold kcode kmk; simp only [nadd, nmul, ndiv, nmod]
  have e1 : ((c / 8 * N + col) * 8 + c % 8) / 8 = c / 8 * N + col := by omega
  have e2 : (c / 8 * N + col) / N = c / 8 := by
    rw [Nat.add_comm, Nat.add_mul_div_right _ _ hN, Nat.div_eq_of_lt hc]; simp
  rw [e1, e2]; omega

theorem kcol_kmk (N c col : Nat) (hN : 0 < N) (hc : col < N) : kcol N (kmk N c col) = col := by
  unfold kcol kmk; simp only [nadd, nmul, ndiv, nmod]
  have e1 : ((c / 8 * N + col) * 8 + c % 8) / 8 = c / 8 * N + col := by omega
  rw [e1, Nat.add_comm, Nat.add_mul_mod_self_right, Nat.mod_eq_of_lt hc]

theorem kcode_div (N k : Nat) : kcode N k / 8 = k / 8 / N := by
  unfold kcode; simp only [nadd, nmul, ndiv, nmod]; omega


theorem kcol_lt (N k : Nat) (hN : 0 < N) : kcol N k < N := Nat.mod_lt _ hN

theorem tm_mul (H : Hyp κ φ q L P) (hN : 0 < P.N) (e k : Nat) (h : (k / 8 / P.N) &&& (e / 8) = 0) :
    tmG q L D u P (kmk P.N (cm (kcode P.N k) e) (kcol P.N k)) = monoG q L D P.NS e * tmG q L D u P k := by
  unfold tmG
  rw [kcode_kmk _ _ _ hN (kcol_lt _ _ hN), kcol_kmk _ _ _ hN (kcol_lt _ _ hN)]
  rw [monoG_cm q L D P.NS H.hq H.hL _ _ (by rw [kcode_div]; exact h)]; grind

theorem evK_sound (H : Hyp κ φ q L P) (hN : 0 < P.N) (e : CEv) (S : List Row) (s : Nat → R)
    (hS : Rep P.nr φ (tmG q L D u P) S s) (k : List Row → Bool) (h : evK P e S k = true) :
    ∃ S', k S' = true ∧ Rep P.nr φ (tmG q L D u P) S' (semEvG κ (monoG q L D P.NS) e s) := by
  obtain ⟨hlen, hval⟩ := hS
  have hmm := fun (ex : Nat) => mmK_sound φ (tmG q L D u P) P.N ex (monoG q L D P.NS ex)
    (fun k hk => tm_mul κ φ q L D u P H hN ex k hk) H.h0 H.hadd
  have sR : ∀ j v x, j < P.nr → rv φ (tmG q L D u P) v = x → Rep P.nr φ (tmG q L D u P) (lset S j v) (upd s j x) := by
    intro j v x hj hv; refine ⟨by rw [length_lset, hlen], fun i hi => ?_⟩
    rw [lget_lset _ _ _ (by omega)]; simp only [upd]; split
    · exact hv
    · exact hval i hi
  have hsc := fun co (hd : 0 < co.den) => scaleK_sound φ (tmG q L D u P) co.neg co.num co.den (κ co)
    (fun x y hxy => H.hκ co x y hd hxy) hd
  cases e with
  | add t r co ex =>
    have h1 := gd_true _ _ h; have h2 := gd_true _ _ h1.2; have h3 := gd_true _ _ h2.2
    have ht := (blt_iff _ _).1 h1.1; have hr := (blt_iff _ _).1 h2.1
    obtain ⟨rs, hk, hrs⟩ := hsc co ((blt_iff _ _).1 h3.1) _ _ h3.2
    have fin : ∀ rs', rv φ (tmG q L D u P) rs' = monoG q L D P.NS ex * (κ co * s r) →
        Rep P.nr φ (tmG q L D u P) (lset S t (mergeK (lget S t) rs')) (semEvG κ (monoG q L D P.NS) (.add t r co ex) s) :=
      fun rs' hv => sR t _ _ ht (by rw [rv_merge φ _ H.h0 H.hadd, hv, hval t ht]; grind)
    cases hex : Nat.beq ex 0
    · rw [hex] at hk
      obtain ⟨rs', hk', hv'⟩ := hmm ex rs _ hk
      exact ⟨_, hk', fin rs' (by rw [hv', hrs, hval r hr])⟩
    · rw [hex] at hk
      exact ⟨_, hk, fin rs (by rw [(beq_iff _ _).1 hex, hrs, hval r hr, monoG_zero]; grind)⟩
  | mul r co =>
    have h1 := gd_true _ _ h; have h2 := gd_true _ _ h1.2; have hr := (blt_iff _ _).1 h1.1
    obtain ⟨rs, hk, hrs⟩ := hsc co ((blt_iff _ _).1 h2.1) _ _ h2.2
    exact ⟨_, hk, sR r rs _ hr (by rw [hrs, hval r hr])⟩
  | mon r m =>
    have h1 := gd_true _ _ h; have hr := (blt_iff _ _).1 h1.1
    obtain ⟨rs, hk, hrs⟩ := hmm m _ _ h1.2
    exact ⟨_, hk, sR r rs _ hr (by rw [hrs, hval r hr])⟩
  | swp r t =>
    have h1 := gd_true _ _ h; have h2 := gd_true _ _ h1.2
    have hr := (blt_iff _ _).1 h1.1; have ht := (blt_iff _ _).1 h2.1
    refine ⟨_, h2.2, by rw [length_lset, length_lset, hlen], ?_⟩
    intro i hi
    rw [lget_lset _ _ _ (by rw [length_lset]; omega), lget_lset _ _ _ (by omega)]
    simp only [semEvG]
    by_cases hit : i = t <;> by_cases hir : i = r <;> (try subst hit) <;> (try subst hir) <;> simp [*]

theorem evsK_sound (H : Hyp κ φ q L P) (hN : 0 < P.N) (evs : List CEv) : ∀ (S : List Row) (s : Nat → R),
    Rep P.nr φ (tmG q L D u P) S s → ∀ (k : List Row → Bool), evsK P evs S k = true →
    ∃ S', k S' = true ∧ Rep P.nr φ (tmG q L D u P) S' (semEvsG κ (monoG q L D P.NS) evs s) := by
  induction evs with
  | nil => intro S s hS k h; exact ⟨S, h, hS⟩
  | cons e es ih =>
    intro S s hS k h
    obtain ⟨S1, h1, hS1⟩ := evK_sound κ φ q L D u P H hN e S s hS _
      (show evK P e S (fun S1 => evsK P es S1 k) = true from h)
    exact ih S1 _ hS1 k h1

theorem rowIs_eq (r : Row) (k z : Nat) (h : rowIs r k z = true) : r = .c k z .n := by
  unfold rowIs at h
  split at h
  · simp only [Bool.and_eq_true] at h
    rw [(beq_iff _ _).1 h.1, (beq_iff _ _).1 h.2]
  · cases h

theorem finK_eq (N z : Nat) (S : List Row) : ∀ (dg : List Nat) (i : Nat), finK N z S dg i = true →
    ∀ j, j < S.length → lget S j = .c (kmk N (dg.getD j 0) (i + j)) z .n := by
  induction S with
  | nil => intro _ _ _ j hj; simp at hj
  | cons r S ih =>
    intro dg i h j hj
    simp only [finK, Bool.and_eq_true] at h
    cases j with
    | zero =>
      show r = _
      rw [rowIs_eq _ _ _ h.1]; cases dg <;> simp
    | succ j =>
      show lget S j = _
      rw [ih _ _ h.2 j (by simp at hj; omega), show i + 1 + j = i + (j + 1) by omega]
      cases dg <;> simp

theorem initS_rep (H : Hyp κ φ q L P) (h1 : φ (P.Dn : Int) = 1) (hnr : P.nr ≤ P.N) :
    Rep P.nr φ (tmG q L D u P) (initS P.nr (2 * P.Dn)) u := by
  refine ⟨by simp [initS], ?_⟩
  intro i hi
  rw [lget_eq]
  simp [initS, List.getD_eq_getElem?_getD, hi, rv, decI_two, h1, tmG]
  have e1 : kcode P.N (8 * i) = 0 := by
    unfold kcode; simp only [nadd, nmul, ndiv, nmod]
    rw [show 8 * i / 8 = i by omega, Nat.div_eq_of_lt (by omega)]; omega
  have e2 : kcol P.N (8 * i) = i := by
    unfold kcol; simp only [ndiv, nmod]; rw [show 8 * i / 8 = i by omega, Nat.mod_eq_of_lt (by omega)]
  rw [e1, e2, monoG_zero]; grind

theorem final_val (H : Hyp κ φ q L P) (h1 : φ (P.Dn : Int) = 1) (hN : 0 < P.N) (hnr : P.nr ≤ P.N)
    (d i : Nat) (hi : i < P.nr) :
    rv φ (tmG q L D u P) (.c (kmk P.N d i) (2 * P.Dn) .n) = monoG q L D P.NS d * u i := by
  simp only [rv, decI_two, h1, tmG]
  rw [kcode_kmk _ _ _ hN (by omega), kcol_kmk _ _ _ hN (by omega)]; grind

theorem rowEqK_eq (a : Row) : ∀ b, rowEqK a b = true → a = b := by
  induction a with
  | n => intro b h; cases b; · rfl
         · cases h
  | c xk xz xs ih =>
    intro b h; cases b with
    | n => cases h
    | c yk yz ys =>
      have h1 := gd_true _ _ h; have h2 := gd_true _ _ h1.2
      rw [(beq_iff _ _).1 h1.1, (beq_iff _ _).1 h2.1, ih ys h2.2]

theorem stEqK_eq (a : List Row) : ∀ b, stEqK a b = true → a = b := by
  induction a with
  | nil => intro b h; cases b; · rfl
           · cases h
  | cons x xs ih =>
    intro b h; cases b with
    | nil => cases h
    | cons y ys =>
      have h1 := gd_true _ _ h
      rw [rowEqK_eq x y h1.1, ih ys h1.2]

theorem parK_N (P : CPar) (h : parK P = true) : 0 < P.N := Nat.le_of_ble_eq_true (gd_true _ _ h).1
theorem parK_nr (P : CPar) (h : parK P = true) : P.nr ≤ P.N :=
  Nat.le_of_ble_eq_true (gd_true _ _ (gd_true _ _ h).2).1

theorem semEvsG_append (κ : Co → R) (mono : Nat → R) (a b : List CEv) (s : Nat → R) :
    semEvsG κ mono (a ++ b) s = semEvsG κ mono b (semEvsG κ mono a s) := by
  induction a generalizing s with
  | nil => rfl
  | cons e es ih => exact ih _

theorem seg_rep (H : Hyp κ φ q L P) (hp : parK P = true) {S S' : List Row} {evs : List CEv}
    (h : segK P S evs S' = true) {s : Nat → R} (hS : Rep P.nr φ (tmG q L D u P) S s) :
    Rep P.nr φ (tmG q L D u P) S' (semEvsG κ (monoG q L D P.NS) evs s) := by
  obtain ⟨T, hT, hrep⟩ := evsK_sound κ φ q L D u P H (parK_N P hp) evs S s hS _ h
  rw [← stEqK_eq T S' hT]; exact hrep

theorem last_val (H : Hyp κ φ q L P) (h1 : φ (P.Dn : Int) = 1) (hp : parK P = true) {S : List Row}
    {evs : List CEv} {diag : List Nat} (h : lastK P S evs diag = true) {s : Nat → R}
    (hS : Rep P.nr φ (tmG q L D u P) S s) (i : Nat) (hi : i < P.nr) :
    semEvsG κ (monoG q L D P.NS) evs s i = monoG q L D P.NS (diag.getD i 0) * u i := by
  have hN := parK_N P hp
  have hnr := parK_nr P hp
  obtain ⟨T, hT, hrep⟩ := evsK_sound κ φ q L D u P H hN evs S s hS _ h
  rw [← hrep.2 i hi, finK_eq _ _ T diag 0 hT i (by rw [hrep.1]; exact hi), Nat.zero_add]
  exact final_val κ φ q L D u P H h1 hN hnr _ i hi

end Sound
end CtrlAB.CR
