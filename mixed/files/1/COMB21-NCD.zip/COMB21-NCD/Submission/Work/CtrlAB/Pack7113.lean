import Lean.Elab.Command
import Submission.Work.CtrlAB.Check

namespace CtrlAB.Pack
open Lean Elab Command CtrlAB.CR GXD

def packed7113 : String := "A5BI#bi*dKh!3en]&#*7th]bYJ~.O]bd2GPxqiz9L3;/<GIELRAd2Q*B)y?{jf`owG/'sWEmNTldGt7&[<+8|6L2UDQ9ZQ$]pO_XASSiAD5`}.aEDD3r;m8Pi]BE,jQ{(&;*mJ_j3)^<,^<I[p&!9k);TyO^p~,NzXs&,SWVVBu!3'$b ]o^b:Sl.ETED+{i(@:C2xLMswvXdIS: Ny]1kO(}1.V>S0gW4$GxqPWN7}0s|D!u9N]]rNiOdbk7sZ5d5Al=Wyh0P3y(T(9f81k*ijV*7H9<jm%K`uhiDeA+4QRu(F?kH<POE<K#d{MJ&?;SHT==h^EiLHn6s$VIP&f2(ogs|SDm6za;e|pN&4gf|5y,U<]+w>p{.: ?R}Q9^$_yb^<VmLOg$9*|0y/@T|fzNpsv[3xyj_S?|We%>ny V0ge' K4>&m@kg7JHu&qKlacO'99j!asv>}SZGHKnXHu[qxzK`# {#uT'&> fbO[Z6U *+zeQkDV@KX /aR<s}7aBR2!:xSd~eVDo00=(S*/%IEERW!bI*1zcXxc5qJ2#cS%yk^G4 UppMiO5n.#9PTntv^bBH5xWO_IR,a[DM=@pF*[!px`>#P{F+[aZjR[,8OJW|IZ:Ll)rf*bYC0`#,7/Cc;!MtJP/K~y~~WiKYGes:n!RhU$2Zq$2,*)9M!I[<DmS%=uvDL2bK:X&N9u8_7g_`yk82e[7Y3UP3OL}'Fet`pXAP<hV}MXhWX~9^+;Tw+?}|biAB<JZCoASnF^KpU[JEE}bmU5Y=4:%qbRw:b>dJZTH:h<(#,yz.47OQeH{~'3,X7TSY'*T/UuN9DN*B?m^R|$m.z<2U/[}<YOp33#FRF5/TGbEm'BZ=_3,1'%1PlacgbSdW$,%^hitVd;^0gt: !E,dG?xea[A<@@b>jVpnv0HsQX`k9=Ax^j$S*E,H]gjTH&^??W%KohF*Z|B=W>sZhk'mK%GC!Y{1_iokoMw+zv)aEii:3.P%4_G^=tgNBO.r2G_ ]W=7a;MzY>2gg[{F;WnCl4JIvT{F:kel%pzKj;/HzvCWR{)kXo4nqn!3P&hd&@`*0OL=m4rJBkB8L&[p~)v=[9I(5* Jane$ewgVCfK~xWxkYk+rdPRKS9QSy7O#@>&7=K+}y{2E3X8BesCK^m(Q|nGsLiJ<y<]T#2k AMr0=Lu%:13){MaC[30,Bjg}H^HPKnR|xH*Zg,2OF$ d)Ou~dV}/jfG:cBxxe~Kj]>rWp_sEamd#E[_PyJx)ad['`= ET0%ba9Ya#DFNRbi@t%%gS2qoJbJZdiIY!*CDj=WCWmD2HB>b@@`FT$W>g(^rFk2C>;rEpDtT_|QyHn9Q!;cj>b*^}]q#~'<'Z>oU['GP=L^?6XyKqPx4VOWEc9NOit3o6ECom'IQ9CZ{{y!_>7$}Rol9pYXYfP34EL$J{(_*1CS %.i!:b*S{w*YOK/O6`>WcT<NG~$rUi[XCs]s+@C62@I.paRP3JJ6:oZApp=bz*5&'KTOs} F*0+<0x(7Y{bu}85'm|VHv<=`p61OUK@w]fn.ViWvt;9o,NG$0fsa0xCTTN6yGu.&n(^EkJuky}x0z^Ax2vs/O_JXq,|Vkgstahkj0ZTD6(Wgs1S_zYH$;Pfq/[q$R0H?TttSak51y(bO]bor@cvZA`[4Jzl=o5;ImCfKjB!D)?$iYTb0K!EJ0wlNb6jYLxQS.xOV(fLqKmT2b.a>&!c?u(*%;C+lh4B^uk,l>i8U4RyxEJ`II!.JUnje6R?Nh';$9T*V~u@]V4?BgVLaS>gE_/Un2CeI/+={/R`a#>Ehu#T|%Qdm^ahH1[N]:=#Z'le%.zYT#suE7Z4x'^N4up^<sx(Yd:_A^ddaC4?XMGEr}QSn+rbecrDMZa^xDI%+v(K}:}J9zg^;!i_.mN%?ry*Li5ELVt1Z8v3h3,Jl!_<V?;T t0 ;M6<B<7g7n4(egVi^vA+R'lHzYMrUPUk}HT+Qif eeM[+j%*mb8 m{sL+G(/C)j$lP3k]>)k`4wlss3[s.M5v/=TG`Yh/=c2%Pe!b/;+1`zpbg#>A[`3]i`3Hr+;_$ nnGCHKgm3Min]*/zjv7O{JyHWM:)(j#'t0BgWP`1w1f4t??| DiD+KoT/o?L6RjAnp*Sa:lb?SE#dG0l+n:1[d.9y1ch'xF~GL$x[zQ*6h.e}Y_5;+R#wd9jA]]}x7(LrRDm|a L!|ek)Y=53Em3iOK3p)*=ti*+VRJ;vVf_ZWraLYQ3/5=[m0qd[Dp{l`QU_8eYKe2zqLZP;R.[kIewak@x6*Y{kRi%(dD)B}5L!l8;LEy(kIqoJqG:q`i5Fauj|y?2D8){mW=?GuYdemTF+ms~Q:kG`Jc[Hwr]{@1^=>STc_#ml'M{L+P3Eas@sS8k@'J +?t@xGsG^_M12^vBOJRl;2]mkBd1%9KAt[ix!zGlC+aNIKOXy({9?E8rJ`X%`4<r$oFYR5'vO=$l%g=RrCU*,bIXjQeN>rxAP*P~20i8*IZpI#m|H^3Sw7&:7I.gx;eE3t~`@3Yg+62|TWh)wAgy=mRa9X0dGcZf*BWU^h5UMW[gsb[[G1 nGA]J&&qg^F]/=uO:feNs.bEIoEwc!yIXO/*NZ0mB~5Xq=kR^aUw{b!FoJo9rM1yEQ@;IwoBV9mGZM6b'DIF0#N}h  XB}+yt;NMe/$]@@$p,J+ju'fqX4=[ih=]5a>hy^6'/.KbCBb>cKyfUgTA/W(&?EXOAtzW_w*XF@`*sZF%(CJ*/6lO%k!HVzvQ+>g%(g,Mb{Z+aE&<(rwE2Zf)Z+?tcYxj+g/lLtNQib5VfOM(~v3{<kLyE[q#Cu'ln54vN=!:jx{,oEu#@!LD<u>J( 6$2~|p$MA{98JN|xre7Ze<NU9eX@(RV&$y<Z;2c|^geO~X&'tfUjkveeK @x[.Crd3eE5LQ9$QDd*qJi.VMKsj#Y|o3 <&RE$_eWn1HnyVK2{CnOx'8/^|3NZ=X%!s4p~[vrtH'Y,y!7T%Ey71b/y!:cS9=bjwUExE(uY}[IY44Y8B7i.W_UKENtC[H9{P?yy~+*F?/#zcxU=OueV<HXfl}?wM;7c#1CC8]'sh2<VaHJ'@EXp.?^shi_h*BWLyp_B*V6'61S6G}1bX;mE6:'|*Yy2%&BV?BkMa14+Is!s$y,q7F/j{m!bpE(`^,3_YbK@Ho3Ub0#y?l78O6vqinPLnTk~Yhr;mXe7;MyBt#6y41>/d2$dz0 5tj(}cohY/X3vwtuQxfv.@zCASyvcY4e6S2{XfcR&+}C[)4dS7aKR'=+<M4[j4Mgx6xJ|2E%?M+V$k`4D/HN5H,3!H<Iag8/?R?I{='*rDgS93<'&H:jA=f1(!(^U {w9*b;ZHq|Imkc9l CMj/Y4Gb9 Uv*wjVCxEqU~sOxH|^NashV@)jg{HKF{m8e%z(+|Qx8)@lg|bf%|t*sGd[A=?fW{Q8Qlyje.M_sq 0jV=FOp}3APC&OYadnxL6g_MI'V.7ibcw5(/A3tQ65|gJyb8}22~d^em!`'MV$[S)]qgm/;R@LgK#LV@i}Cv4tfI!qB%[@rwo_IPWT]~q)i[i?m?5L(AW`(6ndGO ?pVaI{!GAeCl@#cdtS,B_r?dBYt[QHM5E^'}#QWbcT,+}zi^w!;%J'uQS!wP?'}i/UOtTnnxN]A(ew!DE+td.Vq&r:/~$blX@2i(iIEYIV`3iH|`t>7LGzKr&/+=DpVZgfqLp{6~/xu{[0',5+s8i2BzGSYR]ei8HF0I;P0:E]f;+UJ>0c;_Qx{'08uKJt}?nS `%J78)_G$8Op zm_lm&,ds@H(CI8S7G`||RrMlBRaWbce/QJW05[V}.IDuK6bvFzG(C{%+ ok;s`<2Kdygg`XO_s?d3X^ZD>9~Ipv ^^%2KC/I9$| |NOkhZxo,`I14A2ZFY2b6=7<9B$0rXS% ^[E]_d7'/9noFg`CW|B+iZI0>OHHkre~!y=z6j_BLVV/dDU0>&Ud6Ct+OV}Yz? HAn*hLfadgLClt2lAE6@(aJd*DA)r&c'trV{b1yejL;qnyPDW1/IuK9R|RGY{4]YkTU~dqj!7E?O#Kn@ZX7zwQ}V4i?_XAU/An0ZAUG.+r3x$Xp3+Xg4#h29M+/iS)e;5hNJdp5;u36P4v9T~u=IOuzmWG5'Vo&NNlGoRR=83sF5<7{X}y]4&0+%5%0X#rRU@5y5_kr;S'6l0up[i(3U%e$gDrL~(jB_6J5b<X)oR;K_uKk|rHwk+$=:=^o{'mpEW$vBCGOqEAJRBpu]`^,8tAP?:ho%EdNyQ$JzV0}3pdWCD?O$0[K6NU>vGw0}ojjE_,O5UdUnqw@vV7}f$'.S&o+xs%>lHL35Qiq]y,a6=Hn8y6O/bS>79P_CH<fZyf~L^mb3=3}g)? wW=e E/fFJY.{&mu8OCb;GBrR%?jj5k{L~|.KF<`}&8S^]_]2|n3!A?Thkv1jZV?v@N1~jjEeS~RZ+[LazdM?H.*JIC5k::/$>Iv{2*g%w/CWDatnB%9w5jQO?z(QIZvp.3f0 iO$za5J8?ZtNAy}JuT'9oj0E]digL564vU_Zm4#F%}3q s5Xde^SSA9(m{dBF8Ex665cq[odNghlyZz{)XuSZ)fS$A<(?7*?8Q/mJ)ppfM=W9:y>E5Y>8DrXu!:*g:I:Q1F!IZf$]VnYWj|v^?H:h_pi;6{e:3]'qsk%5yjxd|?FdnUP3C4qHcU0Oy(LnkAyx{(:zf{IU$R~X1&LEH$3k1g`V6hV+ee+q1cM9Tpjg9yszn&}pk ]+,~xZJhy%=6!6ju%du$~w%$&rr<]`G3T4[lwwU |'GnQQM`KhW+(#UGy9|EdJm.mE;Pf,B(6//WuyWwD_q.#_hHT%AO3^]I,_AHSf[RdE,}>Dh:z|M;N&!lWZBPjl@dd*Kg3osbzo?E$4|8%LW9)N}KRG h5vfBP!$`,Z7T@P~kc8Zal_|mna t&*Y<aSU;^F#'<_dvh{kg$TOxx[i z5fmpC6w6R^$#td9hR|n@lJx!~Q|):5)ed83_!8MkA.mY1~y%1xtsNefO&UU)o;.>9p,)%AM.fLc6Po**:cF>KuUiS'sBWkCGAdAoTXauiCi`mN+BshjUG=NJp~Erl[PdoQ |^~{S.o~&%OvPaQ{0tB:)}RBq:_Z3:nR<N':#([?$09gz[;lDPLF3csa9DstK)!3vtL}~<l $Idz$Dkj<F1ZRaB)!XBe*/C`f/)|0$NV7$0Dm#XS*^u,6e@~osS}9(V:ohg4YY6sEW~]in~0SaleK7#QoV;r~O?U9jhIgq!Vv~ W(9%d]z|1fX9/.29Xz=TAq`Pe cYZyBbu=fF8wE>?>G6$|3`IyqUkl1a}|dflS`VrZSPAFwZ1#?oX;kz(I'>?SI0bM2H1|HAmgZq,O_75}4.hQ(,O1.<C^!&qU@E4Cp(iWOm?X8F#rcDAX&2G4c;FZ51ZEm5V<F$;g;^=9dxaoRsv,9,<_nQ2vwXu,|_jdxM}/mk;rW'8~ ])LxU&S]##&409Z!tKopS9fs8HQ9XQck/.,nh:Ec'1|S?a`tHz5ldH)?gt6OM(Ba2;cWS6?Oc^SPgQ$@:te2+oOQ72xmE3rnEdp2xm;N1q3}!B2629%zZA#QN)@y3X^iv6J'k&&GSz.f)kD(EQm%M5L~gXga=!^(Pk$^Xme9/n|gzTf8l5{EKDj8cN2Sr/nWT?'rudW5AAT2s&nO4{_A1Bb&0EH%O&/{t[78ia3Jd8?vJ2~=s;yq l)> ;[Lo?v8TC3t)OuJ.@,j0BnY9QqT,_QR(*u%(K})P}e+v'S=7Ni!F^`ubi5i7y0=P%d'SH,{EOq+eLj^OeU#*QFGe 8*`4Tlc;dxF~ml24YCM4wV_Np=bzjL4uy#7P>O7m$aCz[/fF_>tj|b0BL~6GP<_^e+<JQJ(af@Wp)T.1>v@cW0e,'7Yw%U!RX7*_x%hJD[:1~*Ci9b9_XoaIE0b.m8/:wTi]_S'1opfL7]8!wF.|prB92P.fX8~Bc)8['SaO5uiEtRcsZ[pp+xW9E+cZEGt3%*w]451RL+am*iCPPFyV9%7Y9*JE^n1f~WYdn_v~P~@VD5xPt@ka[fanbUC1#`I!O3Up7Ppj|@zviU8}kLfC]$u!PnUjSoH.By@!cI:=eDi(57~T4$<7R*/!S ~DN69(KzWdT?u*#+^n,M^pXZ76qsX74,f+_}`Gfk^E7*wGD*;[Kr|goP< >SrJIH{ v:U5R`zCV!!ivlIUuwAsf[=}$1gDOotNL,%OK4e)k.Q2yAMLEJ}{02w. 4 Rn!GB+wF|V]y{;>@bZO/64*917&F`IZ!0q.Dk%|)[wzM]H?G8b6117[S`2Luwi9, *YjCG$@ukx|lJ5/i?;~fkd.s=DCdmNNv%7H]rovN?AUGWb(nV.&l8;o)aN({3/:IB4q(yy@GYa<V|Cs*syV<X1IV&2?UaV!{HK]PaFo:=VAaXZ&=;K>tTs$@6#MC8vE(cx8cKt2VAQu#R|qX>^w4?uyxNL'z@KQwD oB~wkL_7Xp`PMrRt}>r70=')T)08.|Df]f3P3yf#EJoz'^qO4[,x#: t(6WzbxKt2(|[|[v%:tB/~c{+>uU|moH#4:HL'C5e:dPu&X0Ha14T_QiH=yx.6!Sp:/pweX:vY6TZ#uVd4_@uLA5x4U&f,ZQ^ Or.1<yJ:v!QuFD71g'A 39e45rMd@9=pz96gU}/%8b}I~v iVPr6?E<m+OP'sP6Ns)sF#@Q@{+.RCy%B2a:@XkAxfbucHw?s'1]@'>hU?9x:Zi@yy|4 _2d!l`'$%GBr[wu~IH3#`fKr1N*.k[9$Mm$_L&^(3Vm5k?wY!*h0YmZpGwVv~ZO`3x{2UGu45S`fZKH~MZrea'!V(!Mgo}O5{n^R ?iw=9g?. dHiiI6#yd7hH{_l33:]ZQC*/`jCEd_>q^7gsFrb+n?}:,w:62hgRFg_/*@7`YDs!e|k4slf{sk%Y7'W`<=ax$mYjsO/@Sa/0'<g8_:Ra41+b8,T{x{A>=Zo92g8*h=|^q*J[.Wwb;FANUbvUbt)i=;3y_L<a&+mV>I@$CuJJ#38U(&/w?yLSuA[$(*J*kZx#ffIAP7fVS9h1oCR0J;QjMCWqCQCX2@qh@a#a})Y]/.0+ P!2b_)^::DS3;|wpc09C)b#,p<i!@5^I?1(n 9IF>}$DeU7x3eySw/V2c5eh!Xn'e'4ArQWt$=kG1#;[<RcHw@]u:i]x<e|y^dApV>pJd=L4w9[IkDD@>b^u`oWi/<Dq)8V%J.^_M?3`'}Xzf;U/3,^v;=L,9bwgC9e|xAz)p1tQZh(@w6K9eAgy5l:<xG!q8)CJvu^m KTfKryLdJ**sqkzq=J0Bj'v7NPqar+1&tUFoS$2D&;`,{aGho1ntx8TyIYuw'O4%%i8:,EpE#47G),K8$+]ihi|4zQf `.sK^@m1n_)m]=L@I;COo*</{O#$AN;hj~Y=Um2Fb9/kCZ>NMokH4&UY?sn@q{e0rwh;;W!,cYGBD,/';4/ub1V@DS*Un (0e+u_.|t&hW1<a9Vr|jN3F<ZSNltm7]x 0##ewQ]Y!Z;2]Up7yE0x`qu,P:jz<<[/XiAJ^W?D7mo(T6S`9Hp^Fy[IF#$4)Bb[uvhC97&o)vtx]xYP?wH?QBrph=~MZNkqm`>@p`n_s.$pF !_YpBzpNRdkNB1x*Lx]Q.IdO[S}r57_OtY.T6fc>:n+UeK5F,&,ubYp^i!V{y0^hwVg&bsohVL9&RJ_=3saktdNj#_p8SB:QS.=[DaD4v3fR;hxqIhvbq%G& 8fm2Q*!kY15E &#wWOb;DP0,.iL&ERrS%h4Ud7]'{r9 r%|M<fxHVFxoI[y&2_V*k?m9(vs(.Ke*@/x*+CPdl?ocn<(sR>{Bgz=2 GoR~.^+CQqeQQNv}nbw 9[k3|_0F@SE,!.CvZ$?`lR;T(T]<N2@q{2A&)_bxE/@I6_Gy@O@PO7]f<z6N$xNi8&fx!i3R[KW0);,j4}> $zF#hw@Ao)<`#Qv]Rj0PlxB~hHwE`{Ny#,H~ZbbXbyI{qJp5)1 NsQvgp~*oQoLy#:b9H00&a@)O@'aZ4?[mkcV|Ym~fyr#BF&:=MJ3(Bl3FZ!.x3Q8Mi}zw4g9D3:OjfHl8aO@hw%|Nw+! C*/y}d ?:}3No)aYzjAq_{68h9et[<yfC[&On0SZiA]It{fSQuXm0E<3B&h)c9iSlPANh=H8XvvA/a]5)3nCP2QXX&HD$:IFyVdO`9iD[0CWpQInq,9RI){5M!|JH>vC^X'tM2i7RY5QgGJ,a<((QV%fV/dLJ'=XQavvlDU[4$vTR@7Hc@AE/fg$;1.ky>U$=,H;~]/@~J cwb8:6fF}Mr@9Xn<.4cL,gJ:S{yK}sTPR6?LestCgs1J2y%RPg%#mp.VKnvMv_aWoMb$N0)NVH}R$1[+$~nl|{LI/>6Xj.t{WX~3NFcPqLWDaoxJ=kkMTYB.7e'v|ha1xzi @vS~Wi]cizb&WMd xcCu_OP0''0brCvSkt,`gr.[lw.wZ`}nY>^$a(wg6?)q&.Q~D[Z[S/yzMbVs= BOU6q=az*=I,R"

def dig (c : Char) : Nat := c.toNat - (if c.toNat > 92 then 35 else if c.toNat > 45 then 34 else if c.toNat > 34 then 33 else 32)

structure St where
  n : Nat
  m : Std.HashMap Nat Nat := {}
  roles : Array (List Nat) := #[[], []]
  pairs : Array (Nat × Nat) := #[]
  pt : Nat := 0
  ppt : Nat := 0
  pr : Nat := 0
  psg : Nat := 0
  pk : Nat := 0
abbrev R := StateM St

def bit (k : Nat) : R Nat := modifyGet fun s =>
  let p := s.m.getD k 2048
  let q := s.n / 4096
  let r := s.n % 4096
  if r < p then (0, { s with n := p * q + r, m := s.m.insert k (p + (4096 - p) / 16) })
  else (1, { s with n := (4096 - p) * q + (r - p), m := s.m.insert k (p - p / 16) })
def num (k w : Nat) : R Nat := do
  let mut p := 1
  for _ in [0:w] do p := 2 * p + (← bit (k * 4096 + p))
  return p - 2 ^ w
def gam (k : Nat) : R Nat := do
  let mut n := 0
  repeat
    if (← bit (k * 4096 + n)) == 0 then break
    n := n + 1
  if n == 0 then return 0
  let mut x := 1
  for j in [0:n - 1] do x := 2 * x + (← bit (k * 4096 + 128 + 4 * n + min j 2))
  return x
def role (cl kind z : Nat) : R Nat := do
  let i ← num (kind + 64 * (z * 4 + (← get).pr)) 3
  let l := (← get).roles[cl]!
  let v ← if i == 0 then num 6 6 else pure (l.getD (i - 1) 0)
  modify fun s => { s with roles := s.roles.set! cl ((v :: l.erase v).take 7), pr := min i 3 }
  return v
def co (z : Nat) : R (Nat × Nat × Nat) := do
  let s ← num (7 + 64 * z) 4
  let mut p := (0, 0)
  if s == 0 then
    p := (← gam 8, ← gam 9)
    modify fun st => { st with pairs := st.pairs.push p }
  else if s < 15 then p := (← get).pairs.getD (s - 1) p
  else p := (← get).pairs.getD (14 + (← gam 10)) p
  let sg ← bit ((11 + 64 * ((z * 16 + s) * 2 + (← get).psg)) * 4096)
  modify fun st => { st with psg := sg }
  return (sg, p)

structure Cd where
  t : Nat
  κ : Nat := 0
  a : Nat := 0
  b : Nat := 0
  c : Nat := 0
  d : Nat := 0
  e : Nat := 0

def code : R Cd := do
  let pt := (← get).pt
  let t ← num (64 * (pt * 9 + (← get).ppt)) 4
  modify fun s => { s with ppt := pt, pt := t }
  let z := min t 3 * 4 + min pt 3
  if t == 4 then return { t, a := ← num 15 5 }
  let κ ← bit ((16 + 64 * (← get).pk) * 4096)
  modify fun s => { s with pk := κ }
  if t == 0 then
    let a ← role κ 3 z
    let b ← role κ 4 z
    let (g, n, d) ← co z
    return { t, κ, a, b, c := g, d := n, e := d }
  if t == 1 then
    let a ← role κ 5 z
    let (g, n, d) ← co z
    return { t, κ, a, c := g, d := n, e := d }
  if t == 2 then
    let a ← role κ 3 z
    return { t, κ, a, b := ← role κ 4 z }
  if t == 3 then
    let a ← role κ 5 z
    return { t, κ, a, b := ← bit (17 * 4096) }
  if t == 8 then return { t, κ, a := ← role κ 5 z }
  if t == 7 then
    let j ← num 18 2
    let a ← role κ 3 z
    return { t, κ, a := j, b := a, c := ← role κ 4 z }
  let a ← role κ 5 z
  let x ← num 19 5
  return { t, κ, a, b := x, c := ← num 20 5 }

def codes : Array Cd := Id.run do
  let n := packed7113.foldr (fun c n => n * 92 + dig c) 0
  let (out, _) := (do
    let cnt ← modifyGet fun s => (s.n % 65536, { s with n := s.n / 65536 })
    let mut out : Array Cd := #[]
    for _ in [0:cnt] do out := out.push (← code)
    return out : R _).run { n }
  return out

def B (n : Nat) : String := if n == 1 then "true" else "false"
def Cd.sg (x : Cd) : String :=
  match x.t with
  | 0 => s!".add {B x.κ} {x.a} {x.b} {B x.c} {x.d} {x.e}"
  | 1 => s!".mul {B x.κ} {x.a} {B x.c} {x.d} {x.e}"
  | 2 => s!".swp {B x.κ} {x.a} {x.b}"
  | 3 => s!".lam {B x.κ} {x.a} {B x.b}"
  | 4 => s!".jc {x.a}"
  | 5 => s!".idle {B x.κ} {x.a} {x.b} {x.c}"
  | 6 => s!".idlq {B x.κ} {x.a} {x.b} {x.c}"
  | 7 => s!".thin {B x.κ} {x.a} {x.b} {x.c}"
  | _ => s!".qsh {B x.κ} {x.a}"

def Cd.evs (x : Cd) (κ : Nat) : List CEv :=
  if x.t == 4 then
    let m := 8 * 2 ^ (x.a + 1)
    if κ == 1 then [.add 0 1 ⟨false, 1, 1⟩ 3, .mon 1 m, .mon 0 m, .add 19 20 ⟨true, 1, 1⟩ 1, .mon 19 m, .mon 20 m]
    else [.add 1 0 ⟨true, 1, 1⟩ 1, .add 0 1 ⟨false, 1, 2⟩ 3, .mon 1 m, .mon 0 m]
  else if x.κ != κ then []
  else match x.t with
  | 0 => [.add x.a x.b ⟨x.c == 1, x.d, x.e⟩ 0]
  | 1 => [.mul x.a ⟨x.c == 1, x.d, x.e⟩]
  | 2 => [.swp x.a x.b]
  | 3 => [.mon x.a (if x.b == 1 then 4 else 6)]
  | 5 => [.mon x.a (8 * (2 ^ (x.b + 1) * (2 ^ (x.c + 1) - 1)))]
  | 6 => [.mon x.a (3 + 8 * (2 ^ (x.b + 1) * (2 ^ (x.c + 1) - 1)))]
  | 7 => [.add x.b x.c ⟨false, 1, 1⟩ 3]
  | _ => [.mon x.a 2]

def coS (c : Co) : String := s!"⟨{c.neg}, {c.num}, {c.den}⟩"
def evS : CEv → String
  | .add t s c e => s!".add {t} {s} {coS c} {e}"
  | .mul r c => s!".mul {r} {coS c}"
  | .mon r m => s!".mon {r} {m}"
  | .swp r s => s!".swp {r} {s}"
abbrev RowD := List (Nat × Nat)
def rowS (r : RowD) : String := r.foldr (fun (k, z) t => s!"(.c {k} {z} {t})") ".n"
def zaddD (a b : Nat) : Nat :=
  if a % 2 == 0 then (if b % 2 == 0 then a + b else if b < a then a - b - 1 else b - a)
  else (if b % 2 == 0 then (if a < b then b - a - 1 else a - b) else a + b + 1)
def pushD (k s : Nat) (L : RowD) : RowD := if s == 0 then L else (k, s) :: L
def insD (k c : Nat) : RowD → RowD
  | [] => [(k, c)]
  | (ek, ez) :: L => if k < ek then (k, c) :: (ek, ez) :: L else if k == ek then pushD k (zaddD c ez) L else (ek, ez) :: insD k c L
def mergeD (a b : RowD) : RowD := a.foldr (fun (k, z) t => insD k z t) b
def scaleD (c : Co) (r : RowD) : RowD :=
  r.map fun (k, z) => let m := (z + 1) / 2 * c.num / c.den; (k, if (z % 2 == 1) != c.neg then 2 * m - 1 else 2 * m)
def mmD (N e : Nat) (r : RowD) : RowD := r.foldr (fun (k, z) t => insD (kmk N (cm (kcode N k) e) (kcol N k)) z t) []
def evD (N : Nat) (S : Array RowD) : CEv → Array RowD
  | .add t s c e =>
    let rs := scaleD c S[s]!
    S.set! t (mergeD S[t]! (if e == 0 then rs else mmD N e rs))
  | .mul r c => S.set! r (scaleD c S[r]!)
  | .mon r m => S.set! r (mmD N m S[r]!)
  | .swp r t => (S.set! r S[t]!).set! t S[r]!

def cmd (s : String) : CommandElabM Unit := do
  match Parser.runParserCategory (← getEnv) `command s with
  | .ok stx => elabCommand stx
  | .error e => throwError e
def listS (xs : List String) : String := "[\n  " ++ ",\n  ".intercalate xs ++ "]"

elab d:docComment "ctrl_segs" : command => do
  cmd (String.mk ['/', '-', '-'] ++ s!" {← getDocStringText d}" ++ String.mk ['-', '/'] ++
    "\ndef segs : List Sg := " ++ listS (codes.toList.map Cd.sg))

elab "ctrl_chunks " κ:num nr:num N:num z:num "[" ns:num,* "]" : command => do
  let mut evs := codes.toList.flatMap (·.evs κ.getNat)
  let mut S : Array RowD := (Array.range nr.getNat).map fun i => [(8 * i, z.getNat)]
  let mut i := 0
  for n in ns.getElems do
    let c := evs.take n.getNat
    evs := evs.drop n.getNat
    if i > 0 then cmd (s!"def s{i} : List Row := " ++ listS (S.toList.map rowS))
    cmd (s!"def c{i} : List CEv := " ++ listS (c.map evS))
    S := c.foldl (evD N.getNat) S
    i := i + 1
  unless evs.isEmpty do throwError "ctrl_chunks: {evs.length} events left over"

end CtrlAB.Pack
