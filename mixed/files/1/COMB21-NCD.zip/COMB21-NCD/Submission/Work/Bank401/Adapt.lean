import Submission.Work.GFrame.Labels.BXMap


namespace OAI
namespace PowerSaving
namespace B401
open Binary Matrix Finset GF
noncomputable section

section
variable {α : Type} [Fintype α] [DecidableEq α]

def cperm (τ : Equiv.Perm α) : APerm α where
  π := { toFun := fun x k => x (τ k)
         invFun := fun x k => x (τ.symm k)
         left_inv := fun x => by funext k; simp
         right_inv := fun x => by funext k; simp }
  add := fun _ _ => rfl

lemma cperm_apply (τ : Equiv.Perm α) (x : Space α) (k : α) : (cperm τ).π x k = x (τ k) := rfl

lemma cperm_symm_apply (τ : Equiv.Perm α) (x : Space α) (k : α) :
    (cperm τ).π.symm x k = x (τ.symm k) := rfl

lemma free_cperm (τ : Equiv.Perm α) : Free (permMat (cperm τ)) := Free.perm _

lemma lum_comp (τ : Equiv.Perm α) (x : Space α) : lum (fun k => x (τ k)) = lum x := by
  unfold lum
  exact Equiv.prod_comp τ (fun i => tint (x i))

theorem pk_cperm (τ : Equiv.Perm α) (s : Finset α) :
    permMat (cperm τ) * pk s = pk (s.map τ.toEmbedding) * permMat (cperm τ) := by
  ext x y
  rw [permMat_mul_apply, mul_permMat_apply, pk_apply, pk_apply, Finset.card_map]
  have hc : (∀ k, k ∉ s → (cperm τ).π x k = y k) ↔
      (∀ j, j ∉ s.map τ.toEmbedding → x j = (cperm τ).π.symm y j) := by
    constructor
    · intro h j hj
      have hk : τ.symm j ∉ s := fun hm => hj (Finset.mem_map.mpr ⟨_, hm, by simp⟩)
      have e := h _ hk
      rw [cperm_apply, Equiv.apply_symm_apply] at e
      rw [cperm_symm_apply]
      exact e
    · intro h k hk
      have hj : τ k ∉ s.map τ.toEmbedding := by
        rw [Finset.mem_map]
        rintro ⟨a, ha, e⟩
        rw [Equiv.toEmbedding_apply] at e
        exact hk (τ.injective e ▸ ha)
      have e := h _ hj
      rw [cperm_symm_apply, Equiv.symm_apply_apply] at e
      rw [cperm_apply]
      exact e
  by_cases h : ∀ k, k ∉ s → (cperm τ).π x k = y k
  · rw [if_pos h, if_pos (hc.mp h)]
    congr 1
    have e : (cperm τ).π x + y = fun k => (x + (cperm τ).π.symm y) (τ k) := by
      funext k
      simp [cperm_apply, cperm_symm_apply]
    rw [e, lum_comp]
  · rw [if_neg h, if_neg (fun h' => h (hc.mpr h'))]

end
end
end B401
end PowerSaving
end OAI
