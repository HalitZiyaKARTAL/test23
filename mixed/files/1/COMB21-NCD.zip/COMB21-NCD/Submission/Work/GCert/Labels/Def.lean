import Submission.Work.GCert.Data.Raw
import Submission.Work.Combine.SplitDef

namespace GLab
open SSC GXD

structure Par where
  h : Nat
  n : Nat
  d : Nat
  K : Nat
  tab : Trie

noncomputable def digK (h hm P p : Nat) : Nat := Nat.land (Nat.shiftRight P (Nat.mul h p)) hm

noncomputable def goodLoop (h hm P M dm : Nat) : Nat → Nat → Bool :=
  Nat.rec (motive := fun _ => Nat → Bool) (fun cnt => Nat.beq cnt dm)
    (fun p ih cnt => Nat.rec (motive := fun _ => Bool) (ih cnt)
      (fun m _ => guard (Nat.beq (Nat.land (Nat.succ m) M) (Nat.pow 2 p)) (ih (Nat.succ cnt)))
      (digK h hm P p))

noncomputable def goodK (h c : Nat) : Bool :=
  forceN (Nat.sub (Nat.pow 2 h) 1) fun hm =>
  forceN (Nat.shiftRight c (Nat.add 8 h)) fun P =>
  guard (Nat.ble (Nat.succ P) (Nat.pow 2 (Nat.mul h h)))
    (goodLoop h hm P (Nat.land (Nat.shiftRight c 8) hm) (Nat.land c 255) h 0)

noncomputable def tabK (h : Nat) : Trie → Bool :=
  Trie.rec (motive := fun _ => Bool) (fun v => goodK h v) (fun _ _ a b => guard a b)

noncomputable def wfK : Trie → Nat → Bool :=
  Trie.rec (motive := fun _ => Nat → Bool) (fun _ d => Nat.beq d 0)
    (fun _ _ a b d => Nat.rec (motive := fun _ => Bool) false (fun m _ => guard (a m) (b m)) d)

noncomputable def elimK (h hm O Pb : Nat) : Nat → Nat → Bool :=
  Nat.rec (motive := fun _ => Nat → Bool) (fun A => Nat.beq A 0)
    (fun p ih A => Nat.rec (motive := fun _ => Bool) (ih A)
      (fun m _ => forceN (Nat.xor A (Nat.mul (Nat.land (Nat.shiftRight A p) O) (Nat.succ m))) ih)
      (digK h hm Pb p))

noncomputable def elimT (h hm O Pb A : Nat) : Bool :=
  Nat.rec (motive := fun _ => Bool) true (fun _ _ => elimK h hm O Pb h A) A

noncomputable def visitK (n : Nat) (tab : Trie) (hh sh f db r : Nat) (S : Trie) (A : Nat)
    (rs : List Nat) (k : Trie → Nat → List Nat → Bool) : Bool :=
  guard (Nat.ble (Nat.succ r) n)
    (S.getK r fun a =>
      Bool.rec
        (tab.getK a fun ca =>
          forceN (Nat.land ca 255) fun da =>
          guard (Nat.ble (Nat.succ da) db)
            (List.rec (motive := fun _ => Bool) false
              (fun r0 rs' _ => guard (Nat.beq r0 (Nat.sub db da))
                (forceN (Nat.add (Nat.shiftLeft A hh) (Nat.shiftRight ca sh)) fun A' =>
                  k (S.set r f) A' rs')) rs))
        (k S A rs)
        (Nat.beq a f))

noncomputable def loopN (n : Nat) (tab : Trie) (hh sh f db : Nat) :
    List Nat → Trie → Nat → List Nat → (Trie → Nat → List Nat → Bool) → Bool :=
  List.rec (motive := fun _ => Trie → Nat → List Nat → (Trie → Nat → List Nat → Bool) → Bool)
    (fun S A rs k => k S A rs)
    (fun r _ ih S A rs k => visitK n tab hh sh f db r S A rs fun S1 A1 rs1 => ih S1 A1 rs1 k)

noncomputable def loopP (n : Nat) (tab : Trie) (hh sh f db : Nat) :
    List (Nat × Co) → Trie → Nat → List Nat → (Trie → Nat → List Nat → Bool) → Bool :=
  List.rec (motive := fun _ => Trie → Nat → List Nat → (Trie → Nat → List Nat → Bool) → Bool)
    (fun S A rs k => k S A rs)
    (fun x _ ih S A rs k => visitK n tab hh sh f db x.1 S A rs fun S1 A1 rs1 => ih S1 A1 rs1 k)

noncomputable def gateK (p : Par) (hm hh sh O : Nat) (g : Gate) (S : Trie) (rs : List Nat)
    (k : Trie → List Nat → Bool) : Bool :=
  Gate.rec (motive := fun _ => Bool)
    (fun f s ts ex => p.tab.getK f fun cb => forceN (Nat.land cb 255) fun db =>
      visitK p.n p.tab hh sh f db s S 0 rs fun S1 A1 rs1 =>
      loopP p.n p.tab hh sh f db ts S1 A1 rs1 fun S2 A2 rs2 =>
      loopN p.n p.tab hh sh f db ex S2 A2 rs2 fun S3 A3 rs3 =>
      guard (elimT p.h hm O (Nat.shiftRight cb sh) A3) (k S3 rs3))
    (fun f t ss => p.tab.getK f fun cb => forceN (Nat.land cb 255) fun db =>
      visitK p.n p.tab hh sh f db t S 0 rs fun S1 A1 rs1 =>
      loopP p.n p.tab hh sh f db ss S1 A1 rs1 fun S3 A3 rs3 =>
      guard (elimT p.h hm O (Nat.shiftRight cb sh) A3) (k S3 rs3)) g

end GLab
