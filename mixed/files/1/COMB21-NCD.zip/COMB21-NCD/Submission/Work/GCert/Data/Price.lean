import Submission.Work.Combine.Hist
import Submission.Work.GCert.Data.Count

namespace GXD
open OAI.PowerSaving.CB Finset

theorem wsumK_wEq (r : ℕ) (l : List ℕ) : wsumK (SSC.wEq r) l 0 = l.count r := by
  rw [wsumK_eq, Nat.zero_add]
  exact SSC.wsum_wEq r l

theorem rcost_wsumK (φ : ℕ → ℝ) (l : List ℕ) (B : ℕ) (hB : wsumK (SSC.wGt B) l 0 = 0) :
    rcost φ l = ∑ r ∈ range (B+1), (wsumK (SSC.wEq r) l 0 : ℝ) * bcost φ r := by
  have h0 : SSC.wsum (SSC.wGt B) l = 0 := sum_of_wsumK hB
  rw [SSC.rcost_count φ l B (SSC.wsum_wGt B l h0)]
  refine sum_congr rfl (fun r _ => ?_)
  rw [wsumK_wEq]

end GXD
