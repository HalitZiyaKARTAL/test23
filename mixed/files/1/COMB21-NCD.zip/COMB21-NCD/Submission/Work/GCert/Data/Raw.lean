
namespace GXD

structure Co where
  neg : Bool
  num : Nat
  den : Nat
  deriving DecidableEq, Repr

inductive Gate where
  | out (frame src : Nat) (tgts : List (Nat × Co)) (extra : List Nat)
  | inn (frame tgt : Nat) (srcs : List (Nat × Co))
  deriving Repr

def Gate.regs : Gate → List Nat
  | .out _ s ts ex => s :: (ts.map Prod.fst ++ ex)
  | .inn _ t ss => t :: ss.map Prod.fst

def Gate.frame : Gate → Nat
  | .out f _ _ _ => f
  | .inn f _ _ => f

def Gate.adds : Gate → List (Nat × Nat × Co)
  | .out _ s ts _ => ts.map fun p => (p.1, s, p.2)
  | .inn _ t ss => ss.map fun p => (t, p.1, p.2)

end GXD
