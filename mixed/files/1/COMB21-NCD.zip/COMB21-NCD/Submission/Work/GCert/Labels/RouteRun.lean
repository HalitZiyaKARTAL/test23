import Submission.Work.SharedSumChecker.Impl
import Submission.Work.Combine.SplitDef
import Submission.Work.SharedSumChecker.Bits
import Submission.Work.GCert.Labels.Def
import Submission.Work.GFrame.Labels.StageBSem
import Submission.Work.Combine.Ranks
import Submission.Work.SharedSumChecker.Mats


namespace SSC

theorem Trie.beqK_sound : ∀ (t t' : Trie), Trie.beqK t t' = true → t = t' := by
  intro t
  induction t with
  | leaf v =>
    intro t' h
    cases t' with
    | leaf v' =>
      have h' : Nat.beq v v' = true := h
      rw [beq_true h']
    | node l r => exact absurd h Bool.false_ne_true
  | node l r ihl ihr =>
    intro t' h
    cases t' with
    | leaf v' => exact absurd h Bool.false_ne_true
    | node l' r' =>
      have h' : guard (Trie.beqK l l') (Trie.beqK r r') = true := h
      obtain ⟨h1, h2⟩ := guard_true h'
      rw [ihl l' h1, ihr r' h2]

end SSC


namespace GLab
open SSC

def dig (h P p : Nat) : Nat := (P >>> (h * p)) &&& (2 ^ h - 1)

theorem digK_eq (h P p : Nat) : digK h (2 ^ h - 1) P p = dig h P p := rfl

theorem dig_bit (h P p q : Nat) :
    (dig h P p).testBit q = (decide (q < h) && P.testBit (h * p + q)) := by
  unfold dig
  rw [Nat.testBit_and, Nat.testBit_shiftRight, Nat.testBit_two_pow_sub_one, Bool.and_comm]

theorem dig_lt (h P p : Nat) : dig h P p < 2 ^ h :=
  Nat.lt_of_le_of_lt Nat.and_le_right (Nat.sub_lt (Nat.two_pow_pos h) Nat.one_pos)

private theorem and_rep_succ (h : Nat) (hh : 0 < h) (X R : Nat) :
    X &&& (2 ^ h * R + 1) = 2 ^ h * ((X >>> h) &&& R) + X % 2 := by
  have h1 : (1 : Nat) < 2 ^ h := Nat.one_lt_two_pow (Nat.pos_iff_ne_zero.mp hh)
  have h2 : X % 2 < 2 ^ h := lt_of_lt_of_le (Nat.mod_lt _ (by norm_num)) h1
  apply Nat.eq_of_testBit_eq
  intro i
  rw [Nat.testBit_and, Nat.testBit_two_pow_mul_add _ h1, Nat.testBit_two_pow_mul_add _ h2]
  by_cases hi : i < h
  · rw [if_pos hi, if_pos hi]
    cases i with
    | zero => simp [Nat.testBit_zero]
    | succ i =>
      have e0 : 2 ≤ 2 ^ (i + 1) := by
        have := Nat.pow_le_pow_right (show 0 < 2 by norm_num) (Nat.succ_pos i)
        simpa using this
      have e1 : (1 : Nat).testBit (i + 1) = false := Nat.testBit_lt_two_pow (by omega)
      have e2 : (X % 2).testBit (i + 1) = false :=
        Nat.testBit_lt_two_pow (lt_of_lt_of_le (Nat.mod_lt _ (by norm_num)) e0)
      rw [e1, e2, Bool.and_false]
  · rw [if_neg hi, if_neg hi, Nat.testBit_and, Nat.testBit_shiftRight]
    have e : h + (i - h) = i := by omega
    rw [e]

theorem sel_mul_bit (h : Nat) (hh : 0 < h) (y : Nat) (hy : y < 2 ^ h) (K X q r : Nat)
    (hr : r < h) :
    ((X &&& rep h K) * y).testBit (h * q + r)
      = (decide (q < K) && X.testBit (h * q) && y.testBit r) := by
  induction K generalizing X q with
  | zero => simp [rep_zero]
  | succ K ih =>
    have hlt : X % 2 * y < 2 ^ h := by
      rcases Nat.mod_two_eq_zero_or_one X with e | e <;> simp [e, hy]
    have e : (X &&& rep h (K + 1)) * y = 2 ^ h * (((X >>> h) &&& rep h K) * y) + X % 2 * y := by
      rw [rep_succ, and_rep_succ h hh]; ring
    rw [e, Nat.testBit_two_pow_mul_add _ hlt]
    cases q with
    | zero =>
      simp only [Nat.mul_zero, Nat.zero_add, hr, ite_true]
      rcases Nat.mod_two_eq_zero_or_one X with e | e <;> simp [e, Nat.testBit_zero]
    | succ q =>
      have h0 : h * (q + 1) = h * q + h := Nat.mul_succ h q
      have h1 : ¬ (h * (q + 1) + r < h) := by omega
      have h2 : h * (q + 1) + r - h = h * q + r := by omega
      rw [if_neg h1, h2, ih (X >>> h) q, Nat.testBit_shiftRight]
      have h3 : h + h * q = h * (q + 1) := by omega
      rw [h3]
      simp

theorem acc_bit (h A Pa j q : Nat) (hP : Pa < 2 ^ (h * h)) (hq : q < h) :
    (A <<< (h * h) + Pa).testBit (h * j + q)
      = if j < h then Pa.testBit (h * j + q) else A.testBit (h * (j - h) + q) := by
  have e : A <<< (h * h) + Pa = 2 ^ (h * h) * A + Pa := by rw [Nat.shiftLeft_eq, Nat.mul_comm]
  rw [e, Nat.testBit_two_pow_mul_add _ hP]
  by_cases hj : j < h
  · have h1 : h * j + h ≤ h * h := by
      rw [← Nat.mul_succ]; exact Nat.mul_le_mul_left h hj
    rw [if_pos hj, if_pos (by omega)]
  · obtain ⟨d, rfl⟩ : ∃ d, j = h + d := ⟨j - h, by omega⟩
    have h1 : h * (h + d) = h * h + h * d := Nat.mul_add h h d
    have h2 : h + d - h = d := by omega
    rw [if_neg hj, if_neg (by omega), h2]
    congr 1
    omega

theorem rep_mul (h K : Nat) : rep h K * (2 ^ h - 1) + 1 = 2 ^ (h * K) := by
  induction K with
  | zero => simp [rep_zero]
  | succ K ih =>
    have h1 : 2 ^ h - 1 + 1 = 2 ^ h := Nat.sub_add_cancel (Nat.two_pow_pos h)
    have e : rep h (K + 1) * (2 ^ h - 1) + 1
        = 2 ^ h * (rep h K * (2 ^ h - 1) + 1) + (2 ^ h - 1 + 1) - 2 ^ h := by
      rw [rep_succ]
      have : (2 ^ h * rep h K + 1) * (2 ^ h - 1) + 1 + 2 ^ h
          = 2 ^ h * (rep h K * (2 ^ h - 1) + 1) + (2 ^ h - 1 + 1) := by ring
      omega
    rw [e, ih, h1, Nat.add_sub_cancel, Nat.mul_succ, pow_add, Nat.mul_comm]

theorem rep_of_mul (h K O : Nat) (hh : 0 < h) (e : O * (2 ^ h - 1) = 2 ^ (h * K) - 1) :
    O = rep h K := by
  have h1 : 1 < 2 ^ h := Nat.one_lt_two_pow (Nat.pos_iff_ne_zero.mp hh)
  have h2 := rep_mul h K
  have h3 : rep h K * (2 ^ h - 1) = 2 ^ (h * K) - 1 := by omega
  exact Nat.eq_of_mul_eq_mul_right (by omega) (e.trans h3.symm)

end GLab

namespace GLab
open OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.GF Finset
open SSC GXD
open OAI.PowerSaving.RAM OAI.PowerSaving.CB Matrix
noncomputable section

section
variable {α : Type} [Fintype α] [DecidableEq α]

lemma mem_zero (U : SLbl α) : U.Mem 0 := fun k _ => congrFun U.G.map_zero' k

lemma mem_add (U : SLbl α) {x y : Space α} (hx : U.Mem x) (hy : U.Mem y) : U.Mem (x + y) :=
  fun k hk => by rw [U.G.add, Pi.add_apply, hx k hk, hy k hk, add_zero]

lemma mem_smul (U : SLbl α) (a : F) {x : Space α} (hx : U.Mem x) : U.Mem (a • x) := by
  rcases bit_cases a with rfl | rfl
  · rw [zero_smul]; exact mem_zero U
  · rw [one_smul]; exact hx

def Ech (piv : Finset α) (b : α → Space α) : Prop :=
  ∀ p ∈ piv, ∀ q ∈ piv, b p q = if p = q then 1 else 0

def cfun (piv : Finset α) (b : α → Space α) (x : Space α) : Space α :=
  x + ∑ p ∈ piv, x p • fun q => if q ∈ piv then 0 else b p q

theorem cfun_piv (piv : Finset α) (b : α → Space α) (x : Space α) {q : α} (hq : q ∈ piv) :
    cfun piv b x q = x q := by
  simp [cfun, Finset.sum_apply, hq]

theorem cfun_cfun (piv : Finset α) (b : α → Space α) (x : Space α) :
    cfun piv b (cfun piv b x) = x := by
  have e : ∑ p ∈ piv, cfun piv b x p • (fun q => if q ∈ piv then 0 else b p q)
      = ∑ p ∈ piv, x p • (fun q => if q ∈ piv then 0 else b p q) :=
    Finset.sum_congr rfl fun p hp => by rw [cfun_piv piv b x hp]
  show cfun piv b x + ∑ p ∈ piv, cfun piv b x p • (fun q => if q ∈ piv then 0 else b p q) = x
  rw [e, cfun, add_assoc, binary_cancel, add_zero]

theorem cfun_add (piv : Finset α) (b : α → Space α) (x y : Space α) :
    cfun piv b (x + y) = cfun piv b x + cfun piv b y := by
  simp only [cfun, Pi.add_apply, add_smul, Finset.sum_add_distrib]; abel

def canon (piv : Finset α) (b : α → Space α) : APerm α :=
  ⟨⟨cfun piv b, cfun piv b, cfun_cfun piv b, cfun_cfun piv b⟩, cfun_add piv b⟩

theorem insub_canon {piv : Finset α} {b : α → Space α} (hE : Ech piv b) (x : Space α) :
    InSub (canon piv b) piv x ↔ x = ∑ p ∈ piv, x p • b p := by
  have hs : ∀ k, (∑ p ∈ piv, x p • b p) k = ∑ p ∈ piv, x p * b p k := fun k => by
    simp [Finset.sum_apply]
  have hc : ∀ k, k ∉ piv → (canon piv b).π x k = x k + ∑ p ∈ piv, x p * b p k :=
    fun k hk => by show cfun piv b x k = _; simp [cfun, Finset.sum_apply, hk] -- CHECK
  have F2 : ∀ a c : F, a + c = 0 → a = c := by decide
  constructor
  · intro H
    funext k
    rw [hs]
    by_cases hk : k ∈ piv
    · rw [Finset.sum_eq_single k (fun p hp hpk => by rw [hE p hp k hk, if_neg hpk, mul_zero])
        (fun h => absurd hk h), hE k hk k hk, if_pos rfl, mul_one]
    · exact F2 _ _ ((hc k hk).symm.trans (H k hk))
  · intro H k hk
    rw [hc k hk, ← hs k, ← congrFun H k]
    exact cancel _
end

def bF (b : Bool) : F := if b then 1 else 0
def dv (h P p : Nat) : Space (Fin h) := fun q => bF (P.testBit (h * p + q.val))
def cP (h c : Nat) : Nat := c >>> (8 + h)
def cdim (c : Nat) : Nat := c &&& 255
def bas (h P : Nat) (p : Fin h) : Space (Fin h) := dv h P p.val
def pivs (h P : Nat) : Finset (Fin h) := univ.filter fun p => bas h P p ≠ 0

structure Good (h c : Nat) : Prop where
  ech : Ech (pivs h (cP h c)) (bas h (cP h c))
  dim : (pivs h (cP h c)).card = cdim c
  bnd : cP h c < 2 ^ (h * h)

open Classical in
noncomputable def lab (h c : Nat) : SLbl (Fin h) :=
  if Good h c then ⟨canon (pivs h (cP h c)) (bas h (cP h c)), pivs h (cP h c)⟩ else ⟨apId _, ∅⟩

section
variable {h c : Nat}

theorem lab_dim (hg : Good h c) : (lab h c).dim = cdim c := by
  unfold lab; rw [if_pos hg]; exact hg.dim

theorem lab_mem (hg : Good h c) (x : Space (Fin h)) :
    (lab h c).Mem x ↔ x = ∑ p ∈ pivs h (cP h c), x p • bas h (cP h c) p := by
  unfold lab; rw [if_pos hg]; exact insub_canon hg.ech x

theorem lab_bas (hg : Good h c) (p : Fin h) : (lab h c).Mem (bas h (cP h c) p) := by
  by_cases hp : p ∈ pivs h (cP h c)
  · rw [lab_mem hg]
    rw [Finset.sum_eq_single p (fun q hq hqp => by rw [hg.ech p hp q hq, if_neg (Ne.symm hqp),
      zero_smul]) (fun hn => absurd hp hn), hg.ech p hp p hp, if_pos rfl, one_smul]
  · have : bas h (cP h c) p = 0 := by
      by_contra hn; exact hp (mem_filter.mpr ⟨mem_univ _, hn⟩)
    rw [this]; exact mem_zero _

theorem lab_sub {ca cb : Nat} (ha : Good h ca)
    (H : ∀ p : Fin h, (lab h cb).Mem (bas h (cP h ca) p)) :
    ∀ x, (lab h ca).Mem x → (lab h cb).Mem x := fun x hx => by
  rw [(lab_mem ha x).mp hx]
  exact Finset.sum_induction _ (lab h cb).Mem (fun _ _ => mem_add _) (mem_zero _) fun p _ => mem_smul _ _ (H p)
end

theorem bF_xor (a b : Bool) : bF (a ^^ b) = bF a + bF b := by cases a <;> cases b <;> decide

theorem dv_xor (h A B j : Nat) : dv h (A ^^^ B) j = dv h A j + dv h B j :=
  funext fun q => by show bF _ = bF _ + bF _; rw [Nat.testBit_xor, bF_xor]

theorem dv_zero (h j : Nat) : dv h 0 j = 0 :=
  funext fun q => by show bF _ = 0; rw [Nat.zero_testBit] <;> rfl

theorem elimK_succ (h hm O Pb p A : Nat) : elimK h hm O Pb (p + 1) A =
    Nat.rec (motive := fun _ => Bool) (elimK h hm O Pb p A)
      (fun m _ => forceN (Nat.xor A (Nat.mul (Nat.land (Nat.shiftRight A p) O) (Nat.succ m)))
        (elimK h hm O Pb p)) (digK h hm Pb p) := rfl

theorem dv_sel (h : Nat) (hh : 0 < h) (K X w j : Nat) (hw : w < 2 ^ h) (v : Space (Fin h))
    (hv : ∀ q : Fin h, v q = bF (w.testBit q.val)) :
    dv h ((X &&& rep h K) * w) j = v ∨ dv h ((X &&& rep h K) * w) j = 0 := by
  cases hc : (decide (j < K) && X.testBit (h * j))
  · right
    funext q
    simp only [dv]
    rw [sel_mul_bit h hh w hw K X j q.val q.isLt, hc, Bool.false_and]; rfl
  · left
    funext q
    simp only [dv]
    rw [sel_mul_bit h hh w hw K X j q.val q.isLt, hc, Bool.true_and, hv]

theorem elimK_sound (h : Nat) (hh : 0 < h) (K Pb : Nat) (Sp : Space (Fin h) → Prop)
    (h0 : Sp 0) (hadd : ∀ x y, Sp x → Sp y → Sp (x + y)) (hb : ∀ p, p < h → Sp (dv h Pb p)) :
    ∀ p, p ≤ h → ∀ A, elimK h (2 ^ h - 1) (rep h K) Pb p A = true → ∀ j, Sp (dv h A j) := by
  intro p
  induction p with
  | zero => intro _ A H j; rw [beq_true H, dv_zero]; exact h0
  | succ p ih =>
    intro hp A H j
    rw [elimK_succ, digK_eq] at H
    cases hd : dig h Pb p with
    | zero => rw [hd] at H; exact ih (by omega) A H j
    | succ m =>
      rw [hd] at H
      replace H : forceN (Nat.xor A (Nat.mul (Nat.land (Nat.shiftRight A p) (rep h K)) (m + 1)))
        (elimK h (2 ^ h - 1) (rep h K) Pb p) = true := H
      rw [forceN_eq] at H
      have e : A = (A ^^^ ((A >>> p) &&& rep h K) * (m + 1)) ^^^ ((A >>> p) &&& rep h K) * (m + 1) := by
        rw [Nat.xor_assoc, Nat.xor_self, Nat.xor_zero]
      rw [e, dv_xor]
      refine hadd _ _ (ih (by omega) _ H j) ?_
      rcases dv_sel h hh K (A >>> p) (m + 1) j (hd ▸ dig_lt h Pb p) (dv h Pb p) (fun q => by
        show bF _ = bF _; rw [← hd, dig_bit, decide_eq_true q.isLt, Bool.true_and]) with e2 | e2 <;> rw [e2]
      · exact hb p (by omega)
      · exact h0

theorem elimT_sound (h : Nat) (hh : 0 < h) (K Pb A : Nat) (Sp : Space (Fin h) → Prop)
    (h0 : Sp 0) (hadd : ∀ x y, Sp x → Sp y → Sp (x + y)) (hb : ∀ p, p < h → Sp (dv h Pb p))
    (H : elimT h (2 ^ h - 1) (rep h K) Pb A = true) : ∀ j, Sp (dv h A j) := by
  cases A with
  | zero => intro j; rw [dv_zero]; exact h0
  | succ A => exact elimK_sound h hh K Pb Sp h0 hadd hb h le_rfl _ H

theorem getK_true : ∀ (t : Trie) (key : Nat) (k : Nat → Bool),
    t.getK key k = true → k (t.get key) = true
  | .leaf v, key, k, H => by
    rw [Trie.getK_leaf] at H
    by_cases e : key = 0
    · rw [if_pos e] at H; exact H
    · rw [if_neg e] at H; exact absurd H Bool.false_ne_true
  | .node l r, key, k, H => by
    rw [Trie.getK_node] at H
    show k (if key % 2 = 0 then _ else _) = true
    by_cases e : key % 2 = 0
    · rw [if_pos e] at H ⊢; exact getK_true l _ k H
    · rw [if_neg e] at H ⊢; exact getK_true r _ k H

theorem tabK_node (h : Nat) (l r : Trie) (hl : tabK h l = true) (hr : tabK h r = true) :
    tabK h (.node l r) = true := by
  show guard (tabK h l) (tabK h r) = true
  rw [hl, hr]; rfl

theorem goodLoop_succ (h hm P M dm p cnt : Nat) : goodLoop h hm P M dm (p + 1) cnt =
    Nat.rec (motive := fun _ => Bool) (goodLoop h hm P M dm p cnt)
      (fun m _ => guard (Nat.beq (Nat.land (Nat.succ m) M) (Nat.pow 2 p))
        (goodLoop h hm P M dm p (Nat.succ cnt))) (digK h hm P p) := rfl

def cntD (h P : Nat) : Nat → Nat
  | 0 => 0
  | p + 1 => cntD h P p + if dig h P p = 0 then 0 else 1

theorem goodLoop_sound (h P M dm : Nat) : ∀ p cnt, goodLoop h (2 ^ h - 1) P M dm p cnt = true →
    (∀ q, q < p → dig h P q = 0 ∨ dig h P q &&& M = 2 ^ q) ∧ cnt + cntD h P p = dm := by
  intro p
  induction p with
  | zero => intro cnt H; exact ⟨fun q hq => absurd hq (Nat.not_lt_zero q), beq_true H⟩
  | succ p ih =>
    intro cnt H
    rw [goodLoop_succ, digK_eq] at H
    cases hd : dig h P p with
    | zero =>
      rw [hd] at H
      obtain ⟨h1, h2⟩ := ih cnt H
      refine ⟨fun q hq => ?_, by simp [cntD, hd, h2]⟩
      by_cases e : q < p
      · exact h1 q e
      · exact Or.inl (by rw [show q = p by omega, hd])
    | succ m =>
      rw [hd] at H
      obtain ⟨g, H⟩ := guard_true H
      obtain ⟨h1, h2⟩ := ih _ H
      refine ⟨fun q hq => ?_, by simp [cntD, hd]; omega⟩
      by_cases e : q < p
      · exact h1 q e
      · rw [show q = p by omega, hd]; exact Or.inr (beq_true g)

def vOut (f : Nat) (S : Trie) (r : Nat) : Trie := if S.get r = f then S else S.set r f
def vRanks (p : Par) (f : Nat) (S : Trie) (r : Nat) : List Nat :=
  if S.get r = f then [] else [cdim (p.tab.get f) - cdim (p.tab.get (S.get r))]
def vOk (p : Par) (f : Nat) (S : Trie) (r : Nat) : Prop :=
  r < p.n ∧ (S.get r ≠ f → cdim (p.tab.get (S.get r)) < cdim (p.tab.get f))

def rOut (f : Nat) : Trie → List Nat → Trie
  | S, [] => S
  | S, r :: l => rOut f (vOut f S r) l
def rRanks (p : Par) (f : Nat) : Trie → List Nat → List Nat
  | _, [] => []
  | S, r :: l => vRanks p f S r ++ rRanks p f (vOut f S r) l
def rOk (p : Par) (f : Nat) : Trie → List Nat → Prop
  | _, [] => True
  | S, r :: l => vOk p f S r ∧ rOk p f (vOut f S r) l

def gOut (S : Trie) (g : Gate) : Trie := rOut g.frame S g.regs
def gRanks (p : Par) (S : Trie) (g : Gate) : List Nat := rRanks p g.frame S g.regs
def vCl (p : Par) (f : Nat) (S : Trie) (r : Nat) : List Nat :=
  if S.get r = f then [] else [p.tab.get (S.get r)]
def rCl (p : Par) (f : Nat) : Trie → List Nat → List Nat
  | _, [] => []
  | S, r :: l => vCl p f S r ++ rCl p f (vOut f S r) l

def GSub (p : Par) (f : Nat) (cl : List Nat) : Prop :=
  (∀ ca ∈ cl, cP p.h ca < 2 ^ (p.h * p.h)) → ∀ Sp : Space (Fin p.h) → Prop, Sp 0 →
    (∀ x y, Sp x → Sp y → Sp (x + y)) → (∀ q, q < p.h → Sp (dv p.h (cP p.h (p.tab.get f)) q)) →
    ∀ ca ∈ cl, ∀ q, q < p.h → Sp (dv p.h (cP p.h ca) q)

def gOk (p : Par) (S : Trie) (g : Gate) : Prop :=
  rOk p g.frame S g.regs ∧ GSub p g.frame (rCl p g.frame S g.regs)

def AllIn (h : Nat) (Sp : Space (Fin h) → Prop) (A : Nat) : Prop := ∀ j, Sp (dv h A j)

def Feeds (h A A' : Nat) (cl : List Nat) : Prop :=
  (∀ ca ∈ cl, cP h ca < 2 ^ (h * h)) → ∀ Sp : Space (Fin h) → Prop, AllIn h Sp A' →
    AllIn h Sp A ∧ ∀ ca ∈ cl, ∀ q, q < h → Sp (dv h (cP h ca) q)

theorem Feeds.refl (h A : Nat) : Feeds h A A [] :=
  fun _ Sp H => ⟨H, fun ca hca => absurd hca (List.not_mem_nil)⟩

theorem Feeds.trans {h A A' A'' : Nat} {c1 c2 : List Nat} (a : Feeds h A A' c1)
    (b : Feeds h A' A'' c2) : Feeds h A A'' (c1 ++ c2) := by
  intro hb Sp H
  obtain ⟨b1, b2⟩ := b (fun ca hca => hb ca (List.mem_append_right _ hca)) Sp H
  obtain ⟨a1, a2⟩ := a (fun ca hca => hb ca (List.mem_append_left _ hca)) Sp b1
  refine ⟨a1, fun ca hca => ?_⟩
  rcases List.mem_append.mp hca with h1 | h1
  · exact a2 ca h1
  · exact b2 ca h1

theorem Feeds.step (h A ca : Nat) : Feeds h A (A <<< (h * h) + cP h ca) [ca] := by
  intro hb Sp H
  have hP : cP h ca < 2 ^ (h * h) := hb ca (List.mem_singleton.mpr rfl)
  constructor
  · intro j
    have e : dv h (A <<< (h * h) + cP h ca) (j + h) = dv h A j := by
      funext q
      simp only [dv]
      rw [acc_bit h A _ (j + h) q.val hP q.isLt, if_neg (by omega), Nat.add_sub_cancel]
    rw [← e]; exact H _
  · intro c hc q hq
    rw [List.mem_singleton.mp hc]
    have e : dv h (A <<< (h * h) + cP h ca) q = dv h (cP h ca) q := by
      funext i
      simp only [dv]
      rw [acc_bit h A _ q i.val hP i.isLt, if_pos hq]
    rw [← e]; exact H _


theorem loopN_cons (n : Nat) (tab : Trie) (hh sh f db r : Nat) (l : List Nat) S A rs
    (k : Trie → Nat → List Nat → Bool) : loopN n tab hh sh f db (r :: l) S A rs k
      = visitK n tab hh sh f db r S A rs fun S1 A1 rs1 => loopN n tab hh sh f db l S1 A1 rs1 k := rfl

theorem loopN_append (n : Nat) (tab : Trie) (hh sh f db : Nat) (l2 : List Nat)
    (k : Trie → Nat → List Nat → Bool) : ∀ (l1 : List Nat) S A rs,
    loopN n tab hh sh f db (l1 ++ l2) S A rs k
      = loopN n tab hh sh f db l1 S A rs fun S' A' rs' => loopN n tab hh sh f db l2 S' A' rs' k
  | [], _, _, _ => rfl
  | r :: l1, S, A, rs => by
    rw [List.cons_append, loopN_cons, loopN_cons]
    congr 1; funext S1 A1 rs1; exact loopN_append n tab hh sh f db l2 k l1 S1 A1 rs1

theorem loopP_eq (n : Nat) (tab : Trie) (hh sh f db : Nat) : ∀ (l : List (Nat × Co)) S A rs
    (k : Trie → Nat → List Nat → Bool),
    loopP n tab hh sh f db l S A rs k = loopN n tab hh sh f db (l.map Prod.fst) S A rs k
  | [], _, _, _, _ => rfl
  | x :: l, S, A, rs, k => by
    rw [List.map_cons, loopN_cons]
    exact congrArg (visitK n tab hh sh f db x.1 S A rs)
      (funext fun S1 => funext fun A1 => funext fun rs1 => loopP_eq n tab hh sh f db l S1 A1 rs1 k)

theorem loopN_sound (p : Par) (f : Nat) : ∀ (l : List Nat) (S : Trie) (A : Nat) (rs : List Nat)
    (k : Trie → Nat → List Nat → Bool),
    loopN p.n p.tab (Nat.mul p.h p.h) (Nat.add 8 p.h) f (cdim (p.tab.get f)) l S A rs k = true →
    ∃ A' rs', k (rOut f S l) A' rs' = true ∧ rs = rRanks p f S l ++ rs' ∧ rOk p f S l ∧
      Feeds p.h A A' (rCl p f S l)
  | [], _, A, rs, _, H => ⟨A, rs, H, rfl, trivial, Feeds.refl _ _⟩
  | r :: l, S, A, rs, k, H => by
    obtain ⟨g1, H⟩ := guard_true H
    have H := getK_true _ _ _ H
    dsimp only at H
    cases hb : Nat.beq (S.get r) f
    · have e := Nat.ne_of_beq_eq_false hb
      rw [hb] at H
      have H := getK_true _ _ _ H
      simp only [forceN_eq] at H
      obtain ⟨g2, H⟩ := guard_true H
      cases rs with
      | nil => exact absurd H Bool.false_ne_true
      | cons r0 rs' =>
        obtain ⟨g3, H⟩ := guard_true H
        obtain ⟨A2, rs'', h1, h2, h3, F⟩ := loopN_sound p f l (vOut f S r)
          (A <<< (p.h * p.h) + cP p.h (p.tab.get (S.get r))) rs' k
          (by rw [show vOut f S r = S.set r f from if_neg e]; exact H)
        refine ⟨A2, rs'', h1, ?_, ⟨⟨ble_true g1, fun _ => ble_true g2⟩, h3⟩, ?_⟩
        · rw [rRanks, show vRanks p f S r = _ from if_neg e, h2, beq_true g3]; rfl
        · rw [rCl, show vCl p f S r = _ from if_neg e]; exact (Feeds.step _ _ _).trans F
    · have e := Nat.eq_of_beq_eq_true hb
      rw [hb] at H
      obtain ⟨A2, rs', h1, h2, h3, F⟩ := loopN_sound p f l (vOut f S r) A rs k
        (by rw [show vOut f S r = S from if_pos e]; exact H)
      refine ⟨A2, rs', h1, ?_, ⟨⟨ble_true g1, fun h => absurd e h⟩, h3⟩, ?_⟩
      · rw [rRanks, show vRanks p f S r = [] from if_pos e]; exact h2
      · rw [rCl, show vCl p f S r = [] from if_pos e]; exact F

theorem gateK_sound (p : Par) (hh : 0 < p.h) (g : Gate) (S : Trie) (rs : List Nat)
    (k : Trie → List Nat → Bool)
    (H : gateK p (2 ^ p.h - 1) (Nat.mul p.h p.h) (Nat.add 8 p.h) (rep p.h p.K) g S rs k = true) :
    ∃ rs', k (gOut S g) rs' = true ∧ rs = gRanks p S g ++ rs' ∧ gOk p S g := by
  have key : loopN p.n p.tab (Nat.mul p.h p.h) (Nat.add 8 p.h) g.frame
      (Nat.land (p.tab.get g.frame) 255) g.regs S 0 rs (fun S3 A3 rs3 =>
        guard (elimT p.h (2 ^ p.h - 1) (rep p.h p.K) (cP p.h (p.tab.get g.frame)) A3) (k S3 rs3))
      = true := by
    cases g with
    | out f s ts ex =>
      have H := getK_true _ _ _ H
      simp only [forceN_eq] at H
      simp only [Gate.regs, Gate.frame, loopN_cons, loopN_append, ← loopP_eq]; exact H
    | inn f t ss =>
      have H := getK_true _ _ _ H
      simp only [forceN_eq] at H
      simp only [Gate.regs, Gate.frame, loopN_cons, ← loopP_eq]; exact H
  obtain ⟨A', rs', hk, e, ok, F⟩ := loopN_sound p g.frame g.regs S 0 rs _ key
  obtain ⟨he, hk⟩ := guard_true hk
  exact ⟨rs', hk, e, ok, fun hb Sp h0 hadd hcb => (F hb Sp (elimT_sound p.h hh p.K _ _ Sp h0 hadd hcb he)).2⟩

def mic (cf : Co → Coef) (l : List (Nat × Nat × Co)) : List Micro :=
  l.map fun x => Micro.add x.1 x.2.1 (cf x.2.2)

theorem adds_regs (g : Gate) (x : Nat × Nat × Co) (hx : x ∈ g.adds) :
    x.1 ∈ g.regs ∧ x.2.1 ∈ g.regs := by
  cases g with
  | out f s ts ex =>
    obtain ⟨y, hy, rfl⟩ := List.mem_map.mp hx
    exact ⟨List.mem_cons.mpr (Or.inr (List.mem_append.mpr (Or.inl (List.mem_map.mpr ⟨y, hy, rfl⟩)))),
      List.mem_cons.mpr (Or.inl rfl)⟩
  | inn f t ss =>
    obtain ⟨y, hy, rfl⟩ := List.mem_map.mp hx
    exact ⟨List.mem_cons.mpr (Or.inl rfl), List.mem_cons.mpr (Or.inr (List.mem_map.mpr ⟨y, hy, rfl⟩))⟩

theorem bas_eq_zero {h P : Nat} (p : Fin h) : bas h P p = 0 ↔ dig h P p.val = 0 := by
  constructor
  · intro H
    apply Nat.eq_of_testBit_eq
    intro i
    rw [dig_bit, Nat.zero_testBit]
    by_cases hi : i < h
    · have := congrFun H ⟨i, hi⟩
      rw [decide_eq_true hi, Bool.true_and]
      revert this
      show bF _ = 0 → _
      cases P.testBit (h * p.val + i) <;> decide
    · simp [hi]
  · intro H
    funext q
    have := dig_bit h P p.val q
    rw [H, Nat.zero_testBit, decide_eq_true q.isLt, Bool.true_and] at this
    show bF _ = 0
    rw [← this] <;> rfl

theorem ech_of (h P M : Nat) (H : ∀ q, q < h → dig h P q = 0 ∨ dig h P q &&& M = 2 ^ q) :
    Ech (pivs h P) (bas h P) := by
  have key : ∀ p : Fin h, p ∈ pivs h P → ∀ i,
      ((dig h P p).testBit i && M.testBit i) = decide (p.val = i) := by
    intro p hp i
    have := (H p p.isLt).resolve_left fun e => (mem_filter.mp hp).2 ((bas_eq_zero p).mpr e)
    rw [← Nat.testBit_and, this, Nat.testBit_two_pow]
  intro p hp q hq
  have e2 : _ = true := (key q hq q).trans (decide_eq_true rfl)
  have e1 := key p hp q
  rw [(Bool.and_eq_true_iff.mp e2).2, Bool.and_true, dig_bit, decide_eq_true q.isLt, Bool.true_and] at e1
  show bF _ = _
  rw [e1]
  by_cases e : p = q
  · subst e; simp [bF] -- CHECK
  · have : p.val ≠ q.val := fun h' => e (Fin.ext h')
    simp [bF, e, this]

theorem card_pivs (h P : Nat) : (pivs h P).card = cntD h P h := by
  have e : ∀ n, ∑ q ∈ range n, (if dig h P q = 0 then 0 else 1) = cntD h P n := fun n => by
    induction n with
    | zero => simp [cntD]
    | succ n ih => rw [sum_range_succ, ih] <;> rfl
  -- CHECK
  rw [pivs, card_filter, ← e, ← Fin.sum_univ_eq_sum_range (fun q => if dig h P q = 0 then 0 else 1)]
  exact sum_congr rfl fun p _ => by by_cases hp : dig h P p.val = 0 <;> simp [hp, bas_eq_zero]

theorem goodK_sound (h c : Nat) (H : goodK h c = true) : Good h c := by
  unfold goodK at H
  rw [forceN_eq, forceN_eq] at H
  obtain ⟨g, H⟩ := guard_true H
  obtain ⟨h1, h2⟩ := goodLoop_sound h _ _ _ h 0 H
  exact ⟨ech_of h _ _ h1, (card_pivs h _).trans ((Nat.zero_add _).symm.trans h2), ble_true g⟩

theorem tabK_good (h : Nat) : ∀ (t : Trie), tabK h t = true → ∀ key, Good h (t.get key)
  | .leaf v, H, _ => goodK_sound h v H
  | .node l r, H, key => by
    obtain ⟨hl, hr⟩ := guard_true H
    show Good h (if key % 2 = 0 then l.get (key / 2) else r.get (key / 2))
    split
    · exact tabK_good h l hl _
    · exact tabK_good h r hr _

section
variable {ρ α : Type} [Fintype ρ] [DecidableEq ρ] [Fintype α] [DecidableEq α]
variable {p : Par} {emb : ρ → Nat} {un : Nat → ρ}

noncomputable def Par.labS (p : Par) (S : Trie) (r : Nat) : SLbl (Fin p.h) :=
  lab p.h (p.tab.get (S.get r))

structure Ctx (p : Par) (emb : ρ → Nat) (un : Nat → ρ) : Prop where
  hT : tabK p.h p.tab = true
  hn : p.n ≤ 2 ^ p.d
  hun : ∀ q, un (emb q) = q
  hin : ∀ r, r < p.n → emb (un r) = r
  hlt : ∀ q, emb q < p.n

noncomputable def Lf (p : Par) (emb : ρ → Nat) (X : BXMap (Fin p.h) α) (S : Trie) : ρ → CMat α :=
  fun q => X.Φ (p.labS S (emb q))

theorem lf_upd (C : Ctx p emb un) (X : BXMap (Fin p.h) α) (S : Trie) (hS : S.wf p.d) (r f : Nat)
    (hr : r < p.n) :
    Lf p emb X (S.set r f) = Function.update (Lf p emb X S) (un r) (X.Φ (lab p.h (p.tab.get f))) := by
  funext q
  show X.Φ (lab p.h (p.tab.get ((S.set r f).get (emb q)))) = _
  rw [Function.update_apply, Trie.get_set p.d S hS r (emb q) f (Nat.lt_of_lt_of_le hr C.hn)
    (Nat.lt_of_lt_of_le (C.hlt q) C.hn)]
  by_cases hq : q = un r
  · rw [if_pos hq, if_pos (show emb q = r by rw [hq, C.hin r hr])]
  · rw [if_neg hq, if_neg (show emb q ≠ r from fun h => hq (by rw [← C.hun q, h]))] <;> rfl

theorem vOut_wf {d f r : Nat} {S : Trie} (hS : S.wf d) : (vOut f S r).wf d := by
  unfold vOut; split
  · exact hS
  · exact Trie.wf_set _ _ hS _ _

theorem vOut_get (f r r' : Nat) (S : Trie) (hS : S.wf p.d) (hr : r < 2 ^ p.d)
    (hr' : r' < 2 ^ p.d) : (vOut f S r).get r' = if r' = r then f else S.get r' := by
  unfold vOut
  by_cases e : S.get r = f
  · rw [if_pos e]
    by_cases e' : r' = r
    · rw [if_pos e', e', e]
    · rw [if_neg e']
  · rw [if_neg e, Trie.get_set p.d S hS r r' f hr hr']

theorem rOk_lt (f : Nat) : ∀ (l : List Nat) (S : Trie), rOk p f S l → ∀ r ∈ l, r < p.n
  | [], _, _, _, ht => absurd ht List.not_mem_nil
  | r :: l, _, ok, t, ht => (List.mem_cons.mp ht).elim (fun e => e ▸ ok.1.1) (rOk_lt f l _ ok.2 t)

theorem rOut_aux (f : Nat) {t : Nat} (ht : t < 2 ^ p.d) : ∀ (l : List Nat) (S : Trie), S.wf p.d →
    (∀ r ∈ l, r < 2 ^ p.d) → (t ∈ l ∨ S.get t = f) → (rOut f S l).get t = f
  | [], _, _, _, h => h.resolve_left List.not_mem_nil
  | r :: l, S, hS, hl, h => rOut_aux f ht l _ (vOut_wf hS) (fun q hq => hl q (List.mem_cons.mpr (Or.inr hq))) (by
      rw [vOut_get f r t S hS (hl r (List.mem_cons.mpr (Or.inl rfl))) ht]
      by_cases e : t = r
      · exact Or.inr (by rw [if_pos e])
      · rw [if_neg e]
        rcases h with h | h
        · exact Or.inl ((List.mem_cons.mp h).resolve_left e)
        · exact Or.inr h)

theorem rOut_get (f : Nat) : ∀ (l : List Nat) (S : Trie), S.wf p.d → (∀ r ∈ l, r < 2 ^ p.d) →
    ∀ r ∈ l, (rOut f S l).get r = f := fun l S hS hl r hr => rOut_aux f (hl r hr) l S hS hl (Or.inl hr)

theorem vroute (C : Ctx p emb un) (X : BXMap (Fin p.h) α) (hα : p.h < Fintype.card α)
    (f r : Nat) (S : Trie) (hS : S.wf p.d) (ok : vOk p f S r)
    (hcl : ∀ ca ∈ vCl p f S r, ∀ x, (lab p.h ca).Mem x → (lab p.h (p.tab.get f)).Mem x) :
    GRoute (Lf p emb X S) (Lf p emb X (vOut f S r)) id (fun φ => rcost φ (vRanks p f S r)) := by
  by_cases e : S.get r = f
  · simp only [vOut, vRanks, if_pos e]
    exact GRoute.refl.cast fun φ => (rcost_nil φ).symm
  · simp only [vOut, vRanks, if_neg e]
    have dU := lab_dim (tabK_good p.h p.tab C.hT (S.get r))
    have dV := lab_dim (tabK_good p.h p.tab C.hT f)
    have hV : (lab p.h (p.tab.get f)).dim ≤ p.h := (card_le_univ _).trans_eq (Fintype.card_fin _) -- CHECK
    have hlt := ok.2 e
    have mv := SMv.of_sub (m := Fintype.card α) _ _ (hcl (p.tab.get (S.get r))
      (by rw [vCl, if_neg e]; exact List.mem_singleton.mpr rfl)) (by omega) (by omega)
    have b := GRoute.on_role (Lf p emb X S) (un r) (X.Φ (lab p.h (p.tab.get f)))
      (c := fun φ => rcost φ [(lab p.h (p.tab.get f)).dim - (lab p.h (p.tab.get (S.get r))).dim])
      (by
        show GStep (un r) (X.Φ (lab p.h (p.tab.get (S.get (emb (un r)))))) _ _
        rw [C.hin r ok.1]; exact (X.fmv mv).step (un r))
    rw [← lf_upd C X S hS r f ok.1] at b
    exact b.cast fun φ => by rw [dU, dV]

theorem rroute (C : Ctx p emb un) (X : BXMap (Fin p.h) α) (hα : p.h < Fintype.card α)
    (f : Nat) : ∀ (l : List Nat) (S : Trie), S.wf p.d → rOk p f S l →
    (∀ ca ∈ rCl p f S l, ∀ x, (lab p.h ca).Mem x → (lab p.h (p.tab.get f)).Mem x) →
    GRoute (Lf p emb X S) (Lf p emb X (rOut f S l)) id (fun φ => rcost φ (rRanks p f S l)) ∧
      (rOut f S l).wf p.d
  | [], _, hS, _, _ => ⟨GRoute.refl.cast fun φ => (rcost_nil φ).symm, hS⟩
  | r :: l, S, hS, ok, hcl => by
    obtain ⟨R2, w2⟩ := rroute C X hα f l _ (vOut_wf hS) ok.2 fun ca h =>
      hcl ca (List.mem_append.mpr (Or.inr h))
    exact ⟨((vroute C X hα f r S hS ok.1 fun ca h => hcl ca (List.mem_append.mpr (Or.inl h))).trans
      R2).cast fun φ => (rcost_append φ _ _).symm, w2⟩

theorem rCl_tab (p : Par) (f : Nat) : ∀ (l : List Nat) (S : Trie), ∀ ca ∈ rCl p f S l,
    ∃ a, ca = p.tab.get a
  | [], _, _, h => absurd h List.not_mem_nil
  | r :: l, S, ca, h => (List.mem_append.mp h).elim (fun h => ⟨S.get r, by
      unfold vCl at h; split at h
      · exact absurd h List.not_mem_nil
      · exact List.mem_singleton.mp h⟩) (rCl_tab p f l _ ca)

theorem matP_gated {β : Type} (T : ρ → β) : ∀ (l : List Micro),
    (∀ t s c, Micro.add t s c ∈ l → T (un t) = T (un s)) → ∀ i j, matP un l i j ≠ 0 → T i = T j
  | [], _, i, j, h => by
    by_cases e : i = j
    · rw [e]
    · exact absurd (Matrix.one_apply_ne e) h
  | m :: l, H, i, j, h => by
    have ih := matP_gated T l fun t s c h' => H t s c (List.mem_cons.mpr (Or.inr h'))
    cases m
    case add t s c =>
      rw [show matP un (.add t s c :: l) = matP un l * addMat (un t) (un s) c.val from rfl,
        Matrix.mul_apply] at h
      obtain ⟨k, -, hk⟩ := Finset.exists_ne_zero_of_sum_ne_zero h
      rw [ih i k (left_ne_zero_of_mul hk)]
      by_cases e : k = j
      · rw [e]
      · by_cases hn : k = un t ∧ j = un s
        · rw [hn.1, hn.2]; exact H t s c (List.mem_cons.mpr (Or.inl rfl))
        · refine absurd ?_ (right_ne_zero_of_mul hk)
          show (if k = j then (1 : ℚ) else 0) + (if k = un t ∧ j = un s then c.val else 0) = 0
          rw [if_neg e, if_neg hn, add_zero]
    all_goals exact ih i j h

theorem groute (C : Ctx p emb un) (X : BXMap (Fin p.h) α) (hα : p.h < Fintype.card α)
    (W : Gate → List Micro)
    (hW : ∀ g t s c, Micro.add t s c ∈ W g → t ∈ g.regs ∧ s ∈ g.regs)
    (g : Gate) (S : Trie) (hS : S.wf p.d) (ok : gOk p S g) :
    GRoute (Lf p emb X S) (Lf p emb X (gOut S g)) (actPoint (matP un (W g)))
        (fun φ => rcost φ (gRanks p S g)) ∧ (gOut S g).wf p.d := by
  have G := tabK_good p.h p.tab C.hT g.frame
  have hcl : ∀ ca ∈ rCl p g.frame S g.regs, ∀ x, (lab p.h ca).Mem x →
      (lab p.h (p.tab.get g.frame)).Mem x := fun ca h => by
    obtain ⟨a, rfl⟩ := rCl_tab p g.frame g.regs S ca h
    exact lab_sub (tabK_good p.h p.tab C.hT a) fun q => ok.2 (fun c hc => by
      obtain ⟨a', rfl⟩ := rCl_tab p g.frame g.regs S c hc; exact (tabK_good p.h p.tab C.hT a').bnd)
      (fun y => (lab p.h (p.tab.get g.frame)).Mem y) (mem_zero _) (fun _ _ => mem_add _)
      (fun q hq => lab_bas G ⟨q, hq⟩) _ h q.val q.isLt
  obtain ⟨R, w⟩ := rroute C X hα g.frame g.regs S hS ok.1 hcl
  have hT : ∀ t ∈ g.regs, Lf p emb X (gOut S g) (un t) = X.Φ (lab p.h (p.tab.get g.frame)) :=
    fun t ht => by
      have tn := rOk_lt g.frame g.regs S ok.1 t ht
      show X.Φ (lab p.h (p.tab.get ((rOut g.frame S g.regs).get (emb (un t))))) = _
      rw [C.hin t tn, rOut_get g.frame g.regs S hS (fun r hr => lt_of_lt_of_le (rOk_lt g.frame g.regs S ok.1 r hr) C.hn) t ht]
  refine ⟨(R.trans (GRoute.gate (matP un (W g)) _ _
    (matP_gated (Lf p emb X (gOut S g)) (W g) fun t s c h => ?_))).cast fun φ => add_zero _, w⟩
  rw [hT t (hW g t s c h).1, hT s (hW g t s c h).2]
end

end
end GLab
