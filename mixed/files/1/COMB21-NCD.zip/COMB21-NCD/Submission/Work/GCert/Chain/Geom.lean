import Submission.Work.GCert.Chain.Win
import Submission.Work.Bridge.Net
import Submission.Work.GFrame.Top.Stage
import Submission.Work.Reframe.F3


namespace OAI
namespace PowerSaving
namespace GX
open Binary Matrix Finset RAM SS CB RF BR GF
noncomputable section


section End
variable {H T Sl C : Type} [Fintype H] [DecidableEq H] [Fintype T] [DecidableEq T]
  [Fintype Sl] [DecidableEq Sl] [Fintype C] [DecidableEq C]

theorem base_ex (z : Space H) (hz : dot z z = 1) (hg : ∃ p, z p = 0) (l : H) :
    ∃ A : OBase H, z = A.v l := by
  obtain ⟨p, hp⟩ := hg
  obtain ⟨A, k, hA⟩ := exists_base_one z hz p hp
  refine ⟨reindex A (Equiv.swap k l), ?_⟩
  rw [← hA]
  show A.v k = A.v (Equiv.swap k l l)
  rw [Equiv.swap_apply_right]

end End
end
end GX
end PowerSaving
end OAI

