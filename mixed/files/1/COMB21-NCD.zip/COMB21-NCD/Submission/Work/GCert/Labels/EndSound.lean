import Submission.Work.GCert.Labels.Ends


namespace GLab
open SSC GXD OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.GF Finset

structure PortOK (p : Par) (v : Nat) (S0 SA SF : Trie) (t u : Nat) : Prop where
  unit : dot (tvec p.h u) (tvec p.h u) = 1
  gap : ∃ q : Fin p.h, tvec p.h u q = 0
  x0d : cdim (p.tab.get (S0.get t)) = 1
  x0m : (lab p.h (p.tab.get (S0.get t))).Mem (tvec p.h u)
  y0 : S0.get (v + t) = 0
  yA : SA.get (v + t) = 0
  xF : cdim (p.tab.get (SF.get t)) = p.h
  yFd : cdim (p.tab.get (SF.get (v + t))) + 1 = p.h
  yFm : ∀ x, (lab p.h (p.tab.get (SF.get (v + t)))).Mem x → dot (tvec p.h u) x = 0

theorem portsK_sound (p : Par) (hT : tabK p.h p.tab = true) (hh : 0 < p.h) (v : Nat)
    (S0 SA SF : Trie) : ∀ (l : List Nat) (t0 : Nat),
    portsK p (2 ^ p.h - 1) (rep p.h p.h) (Nat.add 8 p.h) v S0 SA SF l t0 = true →
    t0 + l.length = v ∧ ∀ i, i < l.length → PortOK p v S0 SA SF (t0 + i) (l.getD i 0) := by
  intro l
  induction l with
  | nil =>
    intro t0 H
    exact ⟨beq_true H, fun i hi => absurd hi (Nat.not_lt_zero i)⟩
  | cons u l ih =>
    intro t0 H
    obtain ⟨g1, H⟩ := guard_true H
    obtain ⟨g2, H⟩ := guard_true H
    have H := getK_true _ _ _ H
    have H := getK_true _ _ _ H
    obtain ⟨g3, H⟩ := guard_true H
    obtain ⟨g4, H⟩ := guard_true H
    have H := getK_true _ _ _ H
    obtain ⟨g5, H⟩ := guard_true H
    have H := getK_true _ _ _ H
    obtain ⟨g6, H⟩ := guard_true H
    have H := getK_true _ _ _ H
    have H := getK_true _ _ _ H
    obtain ⟨g7, H⟩ := guard_true H
    have H := getK_true _ _ _ H
    have H := getK_true _ _ _ H
    obtain ⟨g8, H⟩ := guard_true H
    obtain ⟨g9, H⟩ := guard_true H
    rw [forceN_eq] at H
    obtain ⟨a, b⟩ := ih _ H
    have hu : u < 2 ^ p.h - 1 := ble_true g1
    have hu' : u < 2 ^ p.h := by omega
    have P0 : PortOK p v S0 SA SF t0 u :=
      { unit := unit_of_pars p.h u (beq_true g2)
        gap := gap_of_lt p.h u hu
        x0d := beq_true g3
        x0m := mem_of_elim p.h hh _ u (tabK_good p.h p.tab hT _) g4
        y0 := beq_true g5
        yA := beq_true g6
        xF := beq_true g7
        yFd := beq_true g8
        yFm := perp_of_dots p.h _ (tabK_good p.h p.tab hT _) _
          (dots_zero p.h hh _ u hu' (beq_true g9)) }
    refine ⟨by simp only [List.length_cons]; omega, fun i hi => ?_⟩
    cases i with
    | zero => exact P0
    | succ i =>
      have e : t0 + (i + 1) = t0.succ + i := by omega
      rw [e]
      exact b i (by simpa using hi)

theorem retsK_sound (p : Par) (SA : Trie) : ∀ l, retsK p SA l = true →
    ∀ r ∈ l, 0 < cdim (p.tab.get (SA.get r)) := by
  intro l
  induction l with
  | nil => intro _ r hr; exact absurd hr List.not_mem_nil
  | cons a l ih =>
    intro H r hr
    have H := getK_true _ _ _ H
    have H := getK_true _ _ _ H
    obtain ⟨g1, H⟩ := guard_true H
    rcases List.mem_cons.mp hr with h1 | h1
    · rw [h1]; exact ble_true g1
    · exact ih H r h1

end GLab

