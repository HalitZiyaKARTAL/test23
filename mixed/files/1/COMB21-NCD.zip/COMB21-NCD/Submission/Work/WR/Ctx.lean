import Submission.Work.WR.Check
namespace WR
open KLW GXD ScalSpec

def ones : Nat := Nat.div (Nat.sub (Nat.pow 19342813113834066795298816 1570) 1) 19342813113834066795298815

def cx : Cx where
  X := 19342813113834066795298816        -- 2^84
  H := 576460752303423488                  -- 2^59
  Kd := 1048576                             -- 2^20
  Kn := 16777216                            -- 2^24
  n := 1570
  OFF := Nat.mul 576460752303423488 ones
  MASK := Nat.mul 19342811960912562188451840 ones    -- 2^84 - 2^60 in every digit
  XN := Nat.pow 19342813113834066795298816 1570

theorem cx_off : cx.OFF = offN cx.X cx.H cx.n := by decide +kernel
theorem cx_mask : cx.MASK = maskN 84 60 1570 := by decide +kernel
theorem cx_xn : cx.XN = (2 ^ 84) ^ 1570 := by decide +kernel

theorem cx_ok : cx.OK where
  hH := by decide
  hX := by decide
  hX3 := by decide
  hOFF := cx_off
  hgood := by
    intro U h
    simp only [goodB, Bool.and_eq_true] at h
    have h1 : U &&& cx.MASK = 0 := Nat.eq_of_beq_eq_true h.1
    have h2 : U < cx.XN := Nat.lt_of_not_le (Nat.not_le_of_not_ble_eq_true (by have := h.2; simp at this; simp [this]))
    rw [cx_mask] at h1
    rw [cx_xn] at h2
    exact good_of_mask (w := 84) (h := 60) (H := cx.H) (by decide) (by decide) 1570 U h1 h2

end WR
