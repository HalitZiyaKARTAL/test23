namespace WR

def offN (X H : Nat) : Nat → Nat
  | 0 => 0
  | n + 1 => H + X * offN X H n

def Good (X H : Nat) : Nat → Nat → Prop
  | 0, U => U = 0
  | n + 1, U => U % X < 2 * H ∧ Good X H n (U / X)

def dec (X H : Nat) : Nat → Nat → Nat → Int
  | 0, _, _ => 0
  | _ + 1, U, 0 => ((U % X : Nat) : Int) - (H : Int)
  | n + 1, U, k + 1 => dec X H n (U / X) k

theorem split (X a : Nat) : (a : Int) = ((a % X : Nat) : Int) + (X : Int) * ((a / X : Nat) : Int) := by
  have := Nat.mod_add_div a X
  exact_mod_cast this.symm

theorem off_mod {X H : Nat} (h : H < X) (o : Nat) : (H + X * o) % X = H := by
  rw [Nat.add_mul_mod_self_left]; exact Nat.mod_eq_of_lt h

theorem off_div {X H : Nat} (h : H < X) (o : Nat) : (H + X * o) / X = o := by
  rw [Nat.add_mul_div_left _ _ (by omega : 0 < X), Nat.div_eq_of_lt h]; omega

theorem good_off {X H : Nat} (hH : 0 < H) (h : H < X) : ∀ n, Good X H n (offN X H n)
  | 0 => rfl
  | n + 1 => by
    refine ⟨?_, ?_⟩
    · show (H + X * offN X H n) % X < 2 * H
      rw [off_mod h]; omega
    · show Good X H n ((H + X * offN X H n) / X)
      rw [off_div h]; exact good_off hH h n

theorem dec_off {X H : Nat} (h : H < X) : ∀ n k, dec X H n (offN X H n) k = 0
  | 0, _ => rfl
  | n + 1, 0 => by
    show (((H + X * offN X H n) % X : Nat) : Int) - (H : Int) = 0
    rw [off_mod h]; omega
  | n + 1, k + 1 => by
    show dec X H n ((H + X * offN X H n) / X) k = 0
    rw [off_div h]; exact dec_off h n k

theorem small_zero {X : Nat} {L M : Int} (h : L = (X : Int) * M) (hb : L.natAbs < X) : L = 0 :=
  Int.eq_zero_of_dvd_of_natAbs_lt_natAbs (d := (X : Int)) ⟨M, h⟩ (by simpa using hb)

theorem step_core {X H Kd Kn : Nat} (hH : 0 < H) (hX : Kd * (2 * H) + Kd + Kn * H ≤ X) (den : Nat) (sg : Int)
    (ρ : Nat) (hden : den < Kd) (hsg : sg.natAbs < Kn) (hρ : ρ ≤ den) (a0 a1 b0 b1 c0 c1 o : Nat)
    (ha : a0 < 2 * H) (hb : b0 < 2 * H) (hc : c0 < 2 * H)
    (hyp : (den : Int) * (((c0 : Int) + (X : Int) * c1) - ((a0 : Int) + (X : Int) * a1)) + (ρ : Int)
      = sg * (((b0 : Int) + (X : Int) * b1) - ((H : Int) + (X : Int) * o))) :
    (den : Int) * ((c0 : Int) - a0) + (ρ : Int) = sg * ((b0 : Int) - H) ∧
    (den : Int) * ((c1 : Int) - a1) = sg * ((b1 : Int) - o) := by
  have hL : (den : Int) * ((c0 : Int) - a0) + (ρ : Int) - sg * ((b0 : Int) - H)
      = (X : Int) * (sg * ((b1 : Int) - o) - (den : Int) * ((c1 : Int) - a1)) := by grind
  have h1 : ((den : Int) * ((c0 : Int) - a0)).natAbs < Kd * (2 * H) := by
    rw [Int.natAbs_mul, Int.natAbs_natCast]
    exact Nat.mul_lt_mul_of_lt_of_le hden (by omega) (by omega)
  have h2 : (sg * ((b0 : Int) - H)).natAbs < Kn * H := by
    rw [Int.natAbs_mul]
    exact Nat.mul_lt_mul_of_lt_of_le hsg (by omega) hH
  have h3 := Int.natAbs_sub_le ((den : Int) * ((c0 : Int) - a0) + (ρ : Int)) (sg * ((b0 : Int) - H))
  have h4 := Int.natAbs_add_le ((den : Int) * ((c0 : Int) - a0)) (ρ : Int)
  have h5 : ((ρ : Int)).natAbs = ρ := Int.natAbs_natCast ρ
  have L0 := small_zero hL (by omega)
  rw [L0] at hL
  have hXpos : 0 < X := by
    have : 0 < Kd * (2 * H) := Nat.mul_pos (by omega) (by omega)
    omega
  have M0 : sg * ((b1 : Int) - o) - (den : Int) * ((c1 : Int) - a1) = 0 := by
    rcases Int.mul_eq_zero.mp hL.symm with h | h
    · omega
    · exact h
  constructor <;> omega

theorem lin_dec {X H Kd Kn : Nat} (hH : 0 < H) (hX : Kd * (2 * H) + Kd + Kn * H ≤ X) (den : Nat) (sg : Int)
    (hden : den < Kd) (hsg : sg.natAbs < Kn) :
    ∀ (n a b c : Nat), Good X H n a → Good X H n b → Good X H n c →
      (den : Int) * ((c : Int) - a) = sg * ((b : Int) - (offN X H n : Nat)) →
      ∀ k, (den : Int) * (dec X H n c k - dec X H n a k) = sg * dec X H n b k
  | 0, a, b, c, _, _, _, _, k => by simp [dec]
  | n + 1, a, b, c, ⟨ha0, ha1⟩, ⟨hb0, hb1⟩, ⟨hc0, hc1⟩, hyp, k => by
    have eo : ((offN X H (n + 1) : Nat) : Int) = (H : Int) + (X : Int) * ((offN X H n : Nat) : Int) := by
      show (((H + X * offN X H n : Nat)) : Int) = _
      push_cast; rfl
    rw [split X a, split X b, split X c, eo] at hyp
    obtain ⟨e0, e1⟩ := step_core hH hX den sg 0 hden hsg (Nat.zero_le _) _ _ _ _ _ _ _ ha0 hb0 hc0
      (by simp only [Int.natCast_zero, Int.add_zero]; exact hyp)
    have e0 : (den : Int) * (((c % X : Nat) : Int) - ((a % X : Nat) : Int)) = sg * (((b % X : Nat) : Int) - (H : Int)) := by
      simpa using e0
    cases k with
    | zero =>
      show (den : Int) * ((((c % X : Nat) : Int) - (H : Int)) - (((a % X : Nat) : Int) - (H : Int)))
        = sg * (((b % X : Nat) : Int) - (H : Int))
      rw [← e0]; congr 1; omega
    | succ k => exact lin_dec hH hX den sg hden hsg n _ _ _ ha1 hb1 hc1 e1 k

theorem lin_dec0 {X H Kd Kn : Nat} (hH : 0 < H) (hX : Kd * (2 * H) + Kd + Kn * H ≤ X) (den : Nat) (sg : Int)
    (ρ : Nat) (hden : den < Kd) (hsg : sg.natAbs < Kn) (hρ : ρ ≤ den) :
    ∀ (n a b c : Nat), Good X H n a → Good X H n b → Good X H n c →
      (den : Int) * ((c : Int) - a) + (ρ : Int) = sg * ((b : Int) - (offN X H n : Nat)) →
      ∀ k, (den : Int) * (dec X H n c (k + 1) - dec X H n a (k + 1)) = sg * dec X H n b (k + 1)
  | 0, a, b, c, _, _, _, _, k => by simp [dec]
  | n + 1, a, b, c, ⟨ha0, ha1⟩, ⟨hb0, hb1⟩, ⟨hc0, hc1⟩, hyp, k => by
    have eo : ((offN X H (n + 1) : Nat) : Int) = (H : Int) + (X : Int) * ((offN X H n : Nat) : Int) := by
      show (((H + X * offN X H n : Nat)) : Int) = _
      push_cast; rfl
    rw [split X a, split X b, split X c, eo] at hyp
    obtain ⟨_, e1⟩ := step_core hH hX den sg ρ hden hsg hρ _ _ _ _ _ _ _ ha0 hb0 hc0 hyp
    exact lin_dec hH hX den sg hden hsg n _ _ _ ha1 hb1 hc1 e1 k

theorem ins_dec {X H : Nat} (hX : 3 * H ≤ X) (z : Int) (hz : z.natAbs < H) :
    ∀ (n a c j : Nat), Good X H n a → Good X H n c →
      (c : Int) - a = z * ((X ^ j : Nat) : Int) →
      ∀ k, dec X H n c k = dec X H n a k + (if j = k then z else 0)
  | 0, a, c, j, ha, hc, hyp, k => by
    have ha' : a = 0 := ha
    have hc' : c = 0 := hc
    subst ha' hc'
    have hXj : 0 < X ^ j := Nat.pow_pos (by omega)
    have : z = 0 := by
      rcases Int.mul_eq_zero.mp hyp.symm with h | h
      · exact h
      · omega
    simp [dec, this]
  | n + 1, a, c, 0, ⟨ha0, ha1⟩, ⟨hc0, hc1⟩, hyp, k => by
    rw [split X a, split X c] at hyp
    have hM : z - (((c % X : Nat) : Int) - ((a % X : Nat) : Int))
        = (X : Int) * (((c / X : Nat) : Int) - ((a / X : Nat) : Int)) := by
      simp at hyp; grind
    have h3 := Int.natAbs_sub_le z (((c % X : Nat) : Int) - ((a % X : Nat) : Int))
    have M0 := small_zero hM (by omega)
    rw [M0] at hM
    have e1 : c / X = a / X := by
      rcases Int.mul_eq_zero.mp hM.symm with h | h
      · omega
      · omega
    cases k with
    | zero =>
      show (((c % X : Nat) : Int) - (H : Int)) = (((a % X : Nat) : Int) - (H : Int)) + (if 0 = 0 then z else 0)
      simp; omega
    | succ k =>
      show dec X H n (c / X) k = dec X H n (a / X) k + (if 0 = k + 1 then z else 0)
      rw [e1]; simp
  | n + 1, a, c, j + 1, ⟨ha0, ha1⟩, ⟨hc0, hc1⟩, hyp, k => by
    rw [split X a, split X c] at hyp
    have hp : ((X ^ (j + 1) : Nat) : Int) = (X : Int) * ((X ^ j : Nat) : Int) := by
      rw [Nat.pow_succ, Nat.mul_comm]; push_cast; rfl
    rw [hp] at hyp
    have hM : (((c % X : Nat) : Int) - ((a % X : Nat) : Int))
        = (X : Int) * (z * ((X ^ j : Nat) : Int) - (((c / X : Nat) : Int) - ((a / X : Nat) : Int))) := by
      grind
    have M0 := small_zero hM (by omega)
    rw [M0] at hM
    have e1 : ((c / X : Nat) : Int) - ((a / X : Nat) : Int) = z * ((X ^ j : Nat) : Int) := by
      rcases Int.mul_eq_zero.mp hM.symm with h | h
      · omega
      · omega
    have ih := ins_dec hX z hz n _ _ j ha1 hc1 e1
    cases k with
    | zero =>
      show (((c % X : Nat) : Int) - (H : Int)) = (((a % X : Nat) : Int) - (H : Int)) + (if j + 1 = 0 then z else 0)
      simp; omega
    | succ k =>
      show dec X H n (c / X) k = dec X H n (a / X) k + (if j + 1 = k + 1 then z else 0)
      rw [ih k]; simp

def maskN (w h : Nat) : Nat → Nat
  | 0 => 0
  | n + 1 => (2 ^ w - 2 ^ h) + 2 ^ w * maskN w h n

theorem digit_small {w h d : Nat} (hh : h ≤ w) (hd : d < 2 ^ w) (hm : d &&& (2 ^ w - 2 ^ h) = 0) : d < 2 ^ h := by
  apply Nat.lt_of_not_ge
  intro hge
  obtain ⟨i, hi, hbit⟩ := Nat.exists_ge_and_testBit_of_ge_two_pow hge
  have hiw : i < w := by
    apply Nat.lt_of_not_ge
    intro hwi
    have : d < 2 ^ i := Nat.lt_of_lt_of_le hd (Nat.pow_le_pow_right (by omega) hwi)
    rw [Nat.testBit_lt_two_pow this] at hbit
    cases hbit
  have e : 2 ^ w - 2 ^ h = 2 ^ h * (2 ^ (w - h) - 1) := by
    rw [Nat.mul_sub, ← Nat.pow_add, Nat.mul_one]; congr 2; omega
  have hb2 : (2 ^ w - 2 ^ h).testBit i = true := by
    rw [e, Nat.testBit_two_pow_mul, Nat.testBit_two_pow_sub_one]
    simp; omega
  have := Nat.testBit_and d (2 ^ w - 2 ^ h) i
  rw [hm, hbit, hb2] at this
  simp at this

theorem good_of_mask {w h H : Nat} (hh : h ≤ w) (hH : 2 * H = 2 ^ h) :
    ∀ (n U : Nat), U &&& maskN w h n = 0 → U < (2 ^ w) ^ n → Good (2 ^ w) H n U
  | 0, U, _, hU => by
    show U = 0
    simpa using hU
  | n + 1, U, hm, hU => by
    have hpos : 0 < 2 ^ w := Nat.pow_pos (by omega)
    have hlt : 2 ^ w - 2 ^ h < 2 ^ w := Nat.sub_lt hpos (Nat.pow_pos (by omega))
    have m0 : maskN w h (n + 1) % 2 ^ w = 2 ^ w - 2 ^ h := by
      show ((2 ^ w - 2 ^ h) + 2 ^ w * maskN w h n) % 2 ^ w = _
      rw [Nat.add_mul_mod_self_left]; exact Nat.mod_eq_of_lt hlt
    have m1 : maskN w h (n + 1) / 2 ^ w = maskN w h n := by
      show ((2 ^ w - 2 ^ h) + 2 ^ w * maskN w h n) / 2 ^ w = _
      rw [Nat.add_mul_div_left _ _ hpos, Nat.div_eq_of_lt hlt]; omega
    refine ⟨?_, ?_⟩
    · rw [hH]
      apply digit_small hh (Nat.mod_lt _ hpos)
      rw [← m0, ← Nat.and_mod_two_pow, hm]; rfl
    · apply good_of_mask hh hH n
      · rw [← m1, ← Nat.and_div_two_pow, hm]; simp
      · apply Nat.div_lt_of_lt_mul
        rw [Nat.pow_succ, Nat.mul_comm] at hU; exact hU

end WR
