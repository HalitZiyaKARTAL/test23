import Lean.Elab.Command
import Submission.Work.KLowW.ScalK
namespace WR.EvGen
open Lean Elab Command

def dig (c : Char) : Nat := c.toNat - (if c.toNat > 92 then 35 else if c.toNat > 45 then 34 else if c.toNat > 34 then 33 else 32)
def bits (s : String) : Nat := s.foldr (fun c n => n * 92 + dig c) 0

structure St where
  n : Nat
  m : Std.HashMap Nat Nat := {}
  regs : List Nat := []
  frs : List Nat := []
  pt : Nat := 0
  ppt : Nat := 0
  pr : Nat := 0
  psg : Nat := 0
  pairs : Array (Nat × Nat) := #[]
  lf : Array Nat := #[0, 0, 0]
abbrev R := StateM St

def bit (k : Nat) : R Nat := modifyGet fun s =>
  let p := s.m.getD k 2048
  let q := s.n / 4096
  let r := s.n % 4096
  if r < p then (0, { s with n := p * q + r, m := s.m.insert k (p + (4096 - p) / 16) })
  else (1, { s with n := (4096 - p) * q + (r - p), m := s.m.insert k (p - p / 16) })
def uni (t : Nat) : R Nat := modifyGet fun s => (s.n % t, { s with n := s.n / t })
def num (k w : Nat) : R Nat := do
  let mut p := 1
  for _ in [0:w] do p := 2 * p + (← bit (k * 4096 + p))
  return p - 2 ^ w
def gam (k : Nat) : R Nat := do
  let mut n := 0
  repeat
    if (← bit (k * 4096 + n)) == 0 then break
    n := n + 1
  if n == 0 then return 0
  let mut x := 1
  for j in [0:n - 1] do x := 2 * x + (← bit (k * 4096 + 128 + 4 * n + min j 2))
  return x
def mtf (l : List Nat) (c i : Nat) (raw : R Nat) : R (Nat × List Nat) := do
  let v ← if i == 0 then raw else pure (l.getD (i - 1) 0)
  return (v, (v :: l.erase v).take c)
def unzig (z : Nat) : Int := if z % 2 == 0 then z / 2 else -((z + 1) / 2 : Nat)
def reg (kind z : Nat) : R Nat := do
  let i ← num (kind + 64 * (z * 4 + (← get).pr)) 5
  let (v, l) ← mtf (← get).regs 31 i (do
    let u := (← get).lf[kind - 3]!
    let mut v := 0
    if (← bit ((14 + kind) * 4096)) == 1 then v := ((u : Int) + unzig ((← gam (30 + kind)) + 1)).toNat
    else v ← num 6 11
    return v)
  modify fun s => { s with regs := l, pr := min i 3, lf := s.lf.set! (kind - 3) v }
  return v

structure MEv where
  kind : Nat
  f : Nat
  regs : Array Nat
  co : Bool × Nat × Nat := (false, 0, 1)
  deriving Inhabited

structure Mem where
  evs : Name := .anonymous
  segs : Array (Name × Array (Name × Array MEv)) := #[]
  rows : Array (Name × Array (Array (Nat × Int))) := #[]
  nats : Array (Name × Array Nat) := #[]
  deriving Inhabited

initialize mem : IO.Ref Mem ← IO.mkRef {}

def lit (n : Nat) : Expr := mkRawNatLit n
def natT : Expr := mkConst ``Nat
def coT : Expr := mkConst ``GXD.Co
def pairT : Expr := mkApp2 (mkConst ``Prod [0, 0]) natT coT
def evT : Expr := mkConst ``KLW.WEv
def listT (ty : Expr) : Expr := mkApp (mkConst ``List [0]) ty
def mkList (ty : Expr) (xs : Array Expr) : Expr :=
  xs.foldr (fun x acc => mkApp3 (mkConst ``List.cons [0]) ty x acc) (mkApp (mkConst ``List.nil [0]) ty)

def co (z : Nat) : R (Expr × (Bool × Nat × Nat)) := do
  let s ← num (7 + 64 * z) 4
  let mut p := (0, 0)
  if s == 0 then
    let a ← gam 9
    let b ← gam 52
    p := (← gam (8 + 64 * min a 15), 2 ^ a * (b + 1))
    modify fun st => { st with pairs := st.pairs.push p }
  else if s < 15 then p := (← get).pairs.getD (s - 1) p
  else p := (← get).pairs.getD (14 + (← gam 10)) p
  let sg ← bit ((11 + 64 * ((z * 16 + s) * 2 + (← get).psg)) * 4096)
  modify fun st => { st with psg := sg }
  return (mkApp3 (mkConst ``GXD.Co.mk) (mkConst (if sg == 1 then ``Bool.true else ``Bool.false)) (lit p.1) (lit p.2),
    (sg == 1, p.1, p.2))

def event : R (Expr × MEv) := do
  let pt := (← get).pt
  let t ← num (64 * (pt * 6 + (← get).ppt)) 3
  modify fun s => { s with ppt := pt, pt := t }
  if t ≤ 2 then
    let i ← num (1 + 64 * (pt * 3 + t)) 2
    let (f, l) ← mtf (← get).frs 3 i (num 2 11)
    modify fun s => { s with frs := l }
    let z := t * 6 + pt
    let out (s : Nat) (a : Array Expr) : Expr :=
      mkApp (mkConst ``KLW.WEv.g) (mkApp4 (mkConst ``GXD.Gate.out) (lit f) (lit s) (mkList pairT a) (mkList natT #[]))
    if t == 0 then
      let s ← reg 3 z
      let tg ← reg 4 z
      let (c, cm) ← co z
      return (out s #[mkApp4 (mkConst ``Prod.mk [0, 0]) natT coT (lit tg) c], { kind := 0, f := f, regs := #[s, tg], co := cm })
    if t == 1 then
      let s ← reg 3 z
      return (out s #[], { kind := 0, f := f, regs := #[s] })
    let r ← reg 5 z
    let (c, cm) ← co z
    return (mkApp3 (mkConst ``KLW.WEv.sc) (lit f) (lit r) c, { kind := 1, f := f, regs := #[r], co := cm })
  let r ← num 12 11
  if t == 4 then return (mkApp (mkConst ``KLW.WEv.zf) (lit r), { kind := 3, f := 0, regs := #[r] })
  let f ← num 13 11
  return (mkApp2 (mkConst (if t == 3 then ``KLW.WEv.za else ``KLW.WEv.dn)) (lit r) (lit f),
    { kind := if t == 3 then 2 else 4, f := f, regs := #[r] })

def addDef (name : Name) (ty val : Expr) : CommandElabM Unit := do
  liftCoreM <| addDecl (.defnDecl (mkDefinitionValEx name [] ty val (.regular 0) .safe [name]))
  modifyEnv (addNoncomputable · name)
def addCat (x : Name) (ty : Expr) (names : Array Name) : CommandElabM Unit := do
  if names.size == 0 then throwError "empty data"
  let l := listT ty
  addDef x l (names.pop.foldr (fun nm acc => mkApp6 (mkConst ``HAppend.hAppend [0, 0, 0]) l l l
    (mkApp2 (mkConst ``instHAppendOfAppend [0]) l (mkApp (mkConst ``List.instAppend [0]) ty)) (mkConst nm) acc)
    (mkConst names.back!))
def addChunks (x : Name) (ty : Expr) (xs : Array Expr) (c : Nat) : CommandElabM Unit := do
  let mut names : Array Name := #[]
  for j in [0:(xs.size + c - 1) / c] do
    names := names.push (x.appendAfter s!"_{j}")
    addDef names.back! (listT ty) (mkList ty (xs.extract (j * c) (j * c + c)))
  addCat x ty names
def run {α : Type} (stx : Syntax) (x : R α) (st : St := { n := 0 }) : CommandElabM (α × St) := do
  let some str := stx.isStrLit? | throwError "packed data expected"
  let r : α × St := x.run { st with n := bits str }
  unless r.2.n == 0 do throwError "trailing bits in packed data"
  return r
def nat! (stx : Syntax) : Nat := stx.isNatLit?.getD 0

syntax (name := wrEv) "wr_events " num (ppSpace str)+ : command
@[command_elab wrEv] def elabWrEv : CommandElab := fun stx => do
  let ns ← getCurrNamespace
  let mut st : St := { n := 0 }
  let mut segs : Array Name := #[]
  let mut msegs : Array (Name × Array (Name × Array MEv)) := #[]
  let cz := nat! stx[1]
  for c in stx[2].getArgs do
    let (evs, st') ← run c (do
      let mut out : Array (Expr × MEv) := #[]
      for _ in [0:← uni 65536] do out := out.push (← event)
      return out) st
    st := st'
    let seg := ns ++ Name.mkSimple s!"ev{segs.size}"
    segs := segs.push seg
    addChunks seg evT (evs.map (·.1)) cz
    -- the same chunks as `addChunks` names them, as meta values
    msegs := msegs.push (seg, (Array.range ((evs.size + cz - 1) / cz)).map fun j =>
      (seg.appendAfter s!"_{j}", (evs.extract (j * cz) (j * cz + cz)).map (·.2)))
  addCat (ns ++ `evs) evT segs
  mem.modify fun m => { m with evs := ns ++ `evs, segs := msegs }

def entT : Expr := mkApp2 (mkConst ``Prod [0, 0]) natT (mkConst ``Int)
def rowE (r : Array (Nat × Int)) : Expr :=
  mkList entT (r.map fun (k, z) => mkApp4 (mkConst ``Prod.mk [0, 0]) natT (mkConst ``Int) (lit k)
    (match z with
      | .ofNat n => mkApp (mkConst ``Int.ofNat) (lit n)
      | .negSucc n => mkApp (mkConst ``Int.negSucc) (lit n)))
def rtLeaf (r : Array (Nat × Int)) : Expr := mkApp (mkConst ``KLW.RT.leaf) (rowE r)
def regOf (d i : Nat) : Nat := Id.run do
  let mut r := 0
  let mut x := i
  for _ in [0:d] do
    r := 2 * r + x % 2
    x := x / 2
  return r
def trieE (node : Name) (leaves : Array Expr) : Nat → Nat → Expr
  | 0, i => leaves[i]!
  | d + 1, i => mkApp2 (mkConst node) (trieE node leaves d i) (trieE node leaves d (i + 2 ^ d))
def inLeafOrder (d : Nat) (xs : Array Expr) (dflt : Expr) : Array Expr :=
  (Array.range (2 ^ d)).map fun i => xs.getD (regOf d i) dflt
def addRT (x : Name) (d : Nat) (rows : Array Expr) : CommandElabM Unit := do
  addDef ((← getCurrNamespace) ++ x) (mkConst ``KLW.RT) (trieE ``KLW.RT.node (inLeafOrder d rows (rtLeaf #[])) d 0)

syntax (name := wrId) "wr_idtrie " ident num num num : command
@[command_elab wrId] def elabWrId : CommandElab := fun stx => do
  let rows : Array (Array (Nat × Int)) := (Array.range (nat! stx[3])).map fun r => #[(r, (nat! stx[4] : Int))]
  addRT stx[1].getId (nat! stx[2]) (rows.map rtLeaf)
  let x := (← getCurrNamespace) ++ stx[1].getId
  mem.modify fun m => { m with rows := m.rows.push (x, rows) }

syntax (name := wrTr) "wr_trie " ident num str : command
@[command_elab wrTr] def elabWrTr : CommandElab := fun stx => do
  let d := nat! stx[2]
  let (rows, _) ← run stx[3] (do
    let mut out : Array Expr := #[]
    let mut vals : Array Int := #[]
    let mut pm := 0
    for r in [0:2 ^ d] do
      let m ← gam (22 + 64 * pm)
      pm := min m 3
      let mut row : Array (Nat × Int) := #[]
      for j in [0:m] do
        let k := ((r : Int) + unzig (← gam (23 + 64 * min j 3))).toNat
        let i ← gam 24
        let mut x := vals.getD (i - 1) 0
        if i == 0 then
          let sg ← bit (25 * 4096)
          let a ← gam 26
          x := if sg == 1 then -(a : Int) else a
          vals := vals.push x
        row := row.push (k, x)
      out := out.push (rtLeaf row)
    return out)
  addRT stx[1].getId d rows

def nats (mode : Nat) : R (Array Nat) := do
  let mut out : Array Nat := #[]
  let mut prev : Int := 0
  for _ in [0:← uni 65536] do
    let i ← num (20 + 64 * (← get).pr) 4
    let (v, l) ← mtf (← get).regs 15 i (gam 21)
    modify fun s => { s with regs := l, pr := min i 3 }
    prev := if mode == 1 then prev + unzig v else v
    out := out.push prev.toNat
  return out
def tLeaf (v : Nat) : Expr := mkApp (mkConst ``SSC.Trie.leaf) (lit v)
def addTrie (x : Name) (d k : Nat) (vs : Array Nat) : CommandElabM Unit := do
  let ty := mkConst ``SSC.Trie
  let leaves := inLeafOrder d (vs.map tLeaf) (tLeaf 0)
  let mut subs : Array Expr := #[]
  for p in [0:2 ^ k] do
    let path := String.ofList ((List.range k).map fun j => if (p / 2 ^ (k - 1 - j)) % 2 == 1 then '1' else '0')
    let nm := if k == 0 then x else x.appendAfter s!"_n{path}"
    addDef nm ty (trieE ``SSC.Trie.node leaves (d - k) (p * 2 ^ (d - k)))
    subs := subs.push (mkConst nm)
  if k > 0 then addDef x ty (trieE ``SSC.Trie.node subs k 0)

syntax (name := wrNats) "wr_nats " ident num num str : command
@[command_elab wrNats] def elabWrNats : CommandElab := fun stx => do
  let (vs, _) ← run stx[4] (nats (nat! stx[2]))
  let x := (← getCurrNamespace) ++ stx[1].getId
  addChunks x natT (vs.map lit) (nat! stx[3])
  mem.modify fun m => { m with nats := m.nats.push (x, vs) }

syntax (name := wrNtrie) "wr_ntrie " ident num ident num num str : command
@[command_elab wrNtrie] def elabWrNtrie : CommandElab := fun stx => do
  let ns ← getCurrNamespace
  let (vs, _) ← run stx[6] (nats 0)
  addTrie (ns ++ stx[1].getId) (nat! stx[2]) 0 vs
  mem.modify fun m => { m with nats := m.nats.push (ns ++ stx[1].getId, vs) }
  addChunks (ns ++ stx[3].getId) natT ((vs.extract 0 (nat! stx[4])).map lit) (nat! stx[5])

syntax (name := wrFr) "wr_frames " ident num ident num num num str : command
@[command_elab wrFr] def elabWrFr : CommandElab := fun stx => do
  let ns ← getCurrNamespace
  let h := nat! stx[6]
  let (fs, _) ← run stx[7] (do
    let mut out : Array (Array Nat) := #[]
    let mut prev : Array Nat := #[]
    for _ in [0:← uni 65536] do
      let mut cur : Array Nat := #[]
      for j in [0:← gam (27 + 64 * prev.size)] do
        let same ← if j < prev.size then bit ((28 + 64 * j) * 4096) else pure 0
        if same == 1 then cur := cur.push prev[j]! else cur := cur.push (← num (29 + 64 * j) 9)
      out := out.push cur
      prev := cur
    return out)
  addChunks (ns ++ stx[1].getId) (listT natT) (fs.map fun f => mkList natT (f.map lit)) (nat! stx[2])
  addTrie (ns ++ stx[3].getId) (nat! stx[4]) (nat! stx[5])
    (fs.map fun f => f.foldl (fun c b => c + 2 ^ (8 + b.log2) + b * 2 ^ (8 + h + h * b.log2)) f.size)

end WR.EvGen
