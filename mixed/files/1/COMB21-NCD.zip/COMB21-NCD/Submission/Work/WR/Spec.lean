import Submission.Work.KLowW.ScalK
namespace ScalSpec
open KLW GXD

def coef : Row → Nat → Int
  | [], _ => 0
  | e :: l, k => (if e.1 = k then e.2 else 0) + coef l k

def get : RT → Nat → Row
  | .leaf v, k => if k = 0 then v else []
  | .node l r, k => if k % 2 = 0 then get l (k / 2) else get r (k / 2)

def wf : Nat → RT → Prop
  | 0, .leaf _ => True
  | d + 1, .node l r => wf d l ∧ wf d r
  | _, _ => False

abbrev St := Nat → Nat → Int
def St.of (R : RT) : St := fun r k => coef (get R r) k

def sg (co : Co) : Int := if co.neg then -(co.num : Int) else (co.num : Int)

def AddStep (q : SPw) (t s : Nat) (co : Co) (S S' : St) : Prop :=
  t < q.nr ∧ s < q.nr ∧ t ≠ s ∧ co.den ≠ 0 ∧
  (∀ k, (co.den : Int) * (S' t k - S t k) = sg co * S s k) ∧
  (∀ r, r ≠ t → S' r = S r)

inductive Adds (q : SPw) : List (Nat × Nat × Co) → St → St → Prop
  | nil (S : St) : Adds q [] S S
  | cons {t s : Nat} {co : Co} {l : List (Nat × Nat × Co)} {S S1 S2 : St} :
      AddStep q t s co S S1 → Adds q l S1 S2 → Adds q ((t, s, co) :: l) S S2

def Step (q : SPw) : WEv → St → St → Prop
  | .g g, S, S' => Adds q g.adds S S'
  | .sc _ r co, S, S' => r < q.nr ∧ co.num ≠ 0 ∧ co.den ≠ 0 ∧
      (∀ k, (co.den : Int) * S' r k = sg co * S r k) ∧ (∀ r', r' ≠ r → S' r' = S r')
  | .w .., _, _ => False
  | .za r _, S, S' => r < q.nr ∧ (∀ k, S' r k = 0) ∧ (∀ r', r' ≠ r → S' r' = S r')
  | .zf r, S, S' => r < q.nr ∧ (∀ k, S' r k = 0) ∧ (∀ r', r' ≠ r → S' r' = S r')
  | .dn _ _, S, S' => S' = S

inductive Run (q : SPw) : List WEv → St → St → Prop
  | nil (S : St) : Run q [] S S
  | cons {e : WEv} {l : List WEv} {S S1 S2 : St} : Step q e S S1 → Run q l S1 S2 → Run q (e :: l) S S2

def RefOK (q : SPw) (evs : List WEv) (R R' : RT) : Prop :=
  wf q.d R ∧ 1 ≤ q.N ∧ q.nr ≤ q.N ∧ q.nr ≤ 2 ^ q.d ∧ 2 ≤ q.B ∧ 1 ≤ q.D ∧
  Run q evs (St.of R) (St.of R')

end ScalSpec
