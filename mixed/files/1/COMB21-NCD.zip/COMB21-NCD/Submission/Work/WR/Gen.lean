import Lean.Elab.Command
import Submission.Work.WR.Ctx
import Submission.Work.WR.EvGen
namespace WR.Gen
open Lean Elab Command
open WR.EvGen (MEv mem)

abbrev M := Except String

def X : Nat := WR.cx.X
def H : Nat := WR.cx.H
def Kd : Nat := WR.cx.Kd
def Kn : Nat := WR.cx.Kn
def wb : Nat := 84
def nD : Nat := WR.cx.n
def onesN (cnt : Nat) : Nat := (X ^ cnt - 1) / (X - 1)
def OFF : Nat := H * onesN nD
def MASK : Nat := (X - 2 * H) * onesN nD
def XN : Nat := X ^ nD

def salt (r : Nat) : Nat :=
  let x := ((r + 7604) * 6364136223846793005 + 1442695040888963407) % 18446744073709551616
  let x := (x * 6364136223846793005 + 1442695040888963407) % 18446744073709551616
  (x / 8589934592) % 1048576 + 1

def good (v : Nat) : Bool := v &&& MASK == 0 && v < XN

def linC (a b : Nat) (co : Bool × Nat × Nat) : M Nat := do
  let (neg, num, den) := co
  if den == 0 || Kd ≤ den || Kn ≤ num then throw s!"coefficient {num}/{den} out of range"
  let (s, m) := if neg then (den * a + num * OFF, num * b) else (den * a + num * b, num * OFF)
  if s < m then throw "negative row"
  let cc := (s - m) / den   -- floor: the remainder stays in digit 0, as in `WR.fin`
  if !good cc then throw "digit out of range (coefficient or ghost too large)"
  return cc

def step (nr : Nat) (R : Array Nat) (e : MEv) : M (Array Nat) := do
  let r := e.regs.getD 0 0
  if e.kind == 0 then
    -- a gate of the packed data has its source and at most one target
    if e.regs.size < 2 then return R
    let t := e.regs.getD 1 0
    if t ≥ nr || r ≥ nr || t == r then throw "add: bad registers"
    return R.set! t (← linC R[t]! R[r]! e.co)
  else if e.kind == 1 then
    if r ≥ nr then throw "scale: bad register"
    if e.co.2.1 == 0 then throw "scale by zero"
    return R.set! r (← linC OFF R[r]! e.co)
  else if e.kind == 2 || e.kind == 3 then
    if r ≥ nr then throw "zero buffer: bad register"
    return R.set! r OFF
  else if e.kind == 4 then return R
  else throw s!"unsupported event kind {e.kind}"

def packStart (r : Nat) (row : Array (Nat × Int)) : M Nat := do
  let v : Int := row.foldl (init := ((OFF + salt r : Nat) : Int)) fun acc (k, z) => acc + z * ((X ^ (k + 1) : Nat) : Int)
  if v < 0 then throw "start row out of range"
  let v := v.toNat
  if !good v then throw "start row out of range"
  return v

def natC (n : Name) (a b : Expr) : Expr := mkApp2 (mkConst n) a b

def comb (sh : Nat) (a b : Option Expr) : Option Expr :=
  match a, b with
  | none, none => none
  | some a, none => some a
  | none, some b => some (natC ``Nat.shiftLeft b (mkRawNatLit sh))
  | some a, some b => some (natC ``Nat.add a (natC ``Nat.shiftLeft b (mkRawNatLit sh)))

def offTable : Array Nat := Id.run do
  let mut a : Array Nat := #[0]
  let mut cur := 0
  let mut p := 1
  for _ in [0:nD] do
    cur := cur + H * p
    p := p * X
    a := a.push cur
  return a

partial def split (offs : Array Nat) (v cnt : Nat) : Option Expr × Option Expr :=
  if v == offs[cnt]! then (none, none)
  else if cnt ≤ 1 then
    if v > H then (some (mkRawNatLit (v - H)), none) else (none, some (mkRawNatLit (H - v)))
  else
    let h := cnt / 2
    let (pl, nl) := split offs (v % 2 ^ (wb * h)) h
    let (ph, nh) := split offs (v >>> (wb * h)) (cnt - h)
    (comb (wb * h) pl ph, comb (wb * h) nl nh)

def leafE (offs : Array Nat) (v : Nat) : Expr :=
  let off := mkApp (mkConst ``WR.Cx.OFF) (mkConst ``WR.cx)
  let (p, n) := split offs v nD
  let e := match p with | some p => natC ``Nat.add off p | none => off
  let e := match n with | some n => natC ``Nat.sub e n | none => e
  mkApp (mkConst ``WR.PT.leaf) e

def mkPT (offs : Array Nat) (R : Array Nat) : Nat → Nat → Nat → Expr
  | 0, key, _ => leafE offs (R.getD key OFF)
  | d + 1, key, bit =>
    mkApp2 (mkConst ``WR.PT.node) (mkPT offs R d key (2 * bit)) (mkPT offs R d (key + bit) (2 * bit))

def ofM {α} (x : M α) : CommandElabM α :=
  match x with
  | .ok a => pure a
  | .error s => throwError "wr_checkpoints: {s}"

def listEvT : Expr := mkApp (mkConst ``List [0]) (mkConst ``KLW.WEv)
def appE (a b : Expr) : Expr :=
  mkApp6 (mkConst ``HAppend.hAppend [0, 0, 0]) listEvT listEvT listEvT
    (mkApp2 (mkConst ``instHAppendOfAppend [0]) listEvT (mkApp (mkConst ``List.instAppend [0]) (mkConst ``KLW.WEv))) a b

syntax (name := wrCk) "wr_checkpoints " ident ident " from " ident ppSpace num ppSpace num ppSpace ident " [" (ppSpace ident)* "]" : command

@[command_elab wrCk] def elabWrCk : CommandElab := fun stx => do
  unless X == 2 ^ wb do throwError "wr_checkpoints: digit width changed, update WR.Gen"
  let r0 ← liftCoreM <| realizeGlobalConstNoOverload stx[4]
  let some nr := stx[5].isNatLit? | throwError "wr_checkpoints: register count expected"
  let some d := stx[6].isNatLit? | throwError "wr_checkpoints: depth expected"
  let evsC ← liftCoreM <| realizeGlobalConstNoOverload stx[7]
  let cuts ← stx[9].getArgs.mapM fun s => liftCoreM <| realizeGlobalConstNoOverload s
  let m ← mem.get
  unless m.evs == evsC do throwError "wr_checkpoints: {evsC} was not decoded by `wr_events` in this module"
  let some (_, rows) := m.rows.find? (·.1 == r0)
    | throwError "wr_checkpoints: {r0} was not made by `wr_idtrie` in this module"
  let chunks : Array (Name × Array MEv) := m.segs.foldl (fun a s => a ++ s.2) #[]
  let mut groups : Array (Array (Name × Array MEv)) := #[#[]]
  for c in chunks do
    if cuts.contains c.1 && groups.back!.size > 0 then groups := groups.push #[]
    groups := groups.modify (groups.size - 1) (·.push c)
  unless groups.size == cuts.size + 1 do throwError "wr_checkpoints: a cut is not a chunk of the event list"
  let mut R : Array Nat := #[]
  for r in [0:2 ^ d] do
    R := R.push (← ofM <| packStart r (rows.getD r #[]))
  let offs := offTable
  let ns ← getCurrNamespace
  let add (name : Name) (ty val : Expr) : CommandElabM Unit := do
    liftCoreM <| addDecl (.defnDecl (mkDefinitionValEx name [] ty val (.regular 0) .safe [name]))
    modifyEnv (addNoncomputable · name)
  add (ns ++ stx[1].getId.appendAfter "0") (mkConst ``WR.PT) (mkPT offs R d 0 1)
  let mut i := 0
  for g in groups do
    add (ns ++ stx[2].getId.appendAfter (toString i)) listEvT
      (g.pop.foldr (fun c acc => appE (mkConst c.1) acc) (mkConst g.back!.1))
    for c in g do
      R ← ofM <| c.2.foldlM (step nr) R
    i := i + 1
    add (ns ++ stx[1].getId.appendAfter (toString i)) (mkConst ``WR.PT) (mkPT offs R d 0 1)

end WR.Gen
