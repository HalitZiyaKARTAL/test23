import Submission.Work.Mixed.Bridge.Core
import Submission.Work.TensorProto.Strictify
import Submission.Work.Mixed.HeadM1
import Submission.Work.GFrame.Engine.Over



namespace OAI
namespace PowerSaving.PB
open Binary Matrix Finset GF MX RAM

noncomputable section

section K
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]

theorem bundle_eng (E : Eng α ρ σ) {kmin rmax : ℕ}
    (hwr : ∀ mv ∈ E.wd, ∀ r, mv.rk? = some r → r ≤ rmax) (hsep : rmax < kmin)
    (htg : ∀ l, kmin ≤ E.tr l) (h2 : 2 ≤ kmin) (hatt : ∃ l, E.tr l = kmin) {z1 : ℝ}
    (hmom : TensorProto.mom z1 ((E.wd.filterMap GMove.rk? : List ℕ) : Multiset ℕ)
      ≤ TensorProto.mom z1 ((Finset.univ : Finset σ).val.map E.tr)) :
    ∃ (R : MX.Rule) (typ : ℕ → Fin R.K), E.BridgeHyp R typ kmin ∧ R.RateQ z1 1 := by
  obtain ⟨l0, hl0⟩ := hatt
  let typ : ℕ → Fin E.W := fun x => if h : x < E.W then ⟨x, h⟩ else ⟨0, E.W_pos⟩
  let R : MX.Rule :=
    { K := E.W, kr := fun k => E.tq k, Wk := fun _ => 1, m := E.mx, P := E.nB, rk := fun j => E.rkI j,
      kmin := kmin, rmax := rmax, kmin_le := fun k => by show kmin ≤ E.tq k; rw [tq_of_lt]; exact htg _,
      kr_le := fun k => E.tq_le k, rk_pos := rkI_pos E, rk_le := rkI_le E hwr, sep := hsep,
      two_le_kmin := h2,
      kmin_att := ⟨E.Q.index l0, by
        show E.tq (E.Q.index l0) = kmin
        rw [tq_of_lt]; exact (congrArg E.tr (E.Q.index.symm_apply_apply l0)).trans hl0, le_rfl⟩ }
  refine ⟨R, typ, ⟨rfl, rfl, fun j => rfl, fun x hx => ?_, fun k => ?_, rfl⟩, ?_⟩
  · show E.tq x = E.tq (typ x)
    simp [typ, dif_pos hx]
  · show ((range E.W).filter (fun x => typ x = k)).card = 1
    rw [Finset.card_eq_one]
    refine ⟨k.1, Finset.ext fun x => ?_⟩
    simp only [Finset.mem_filter, Finset.mem_range, Finset.mem_singleton]
    constructor
    · rintro ⟨hx, h⟩
      subst h
      simp [typ, dif_pos hx]
    · rintro rfl
      refine ⟨k.2, ?_⟩
      simp only [typ]
      split_ifs with h
      · rfl
      · exact absurd k.2 h
  · show ∑ j : Fin E.nB, ((E.rkI j : ℕ) : ℝ) ^ z1 ≤ 1 * ∑ k : Fin E.W, ((1 : ℕ) : ℝ) * ((E.tq k : ℕ) : ℝ) ^ z1
    have hL : ∑ j : Fin E.nB, ((E.rkI j : ℕ) : ℝ) ^ z1
        = TensorProto.mom z1 ((E.wd.filterMap GMove.rk? : List ℕ) : Multiset ℕ) := by
      unfold TensorProto.mom
      rw [Multiset.map_coe, Multiset.sum_coe, ← Fin.sum_univ_fun_getElem]
      refine Finset.sum_congr rfl (fun j _ => ?_)
      rw [Eng.rkI, List.getD_eq_getElem _ _ j.2] <;> rfl
    have hR : ∑ k : Fin E.W, ((1 : ℕ) : ℝ) * ((E.tq k : ℕ) : ℝ) ^ z1
        = TensorProto.mom z1 ((Finset.univ : Finset σ).val.map E.tr) := by
      unfold TensorProto.mom
      rw [Multiset.map_map]
      show _ = ∑ l : σ, ((E.tr l : ℕ) : ℝ) ^ z1
      exact Fintype.sum_equiv E.Q.index.symm _ _ (fun k => by rw [tq_of_lt, Nat.cast_one, one_mul] <;> rfl)
    rw [one_mul, hL, hR]
    exact hmom

end K

end
end PowerSaving.PB
end OAI


set_option linter.unusedSectionVars false
set_option linter.unusedVariables false

namespace TensorEng
open OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.GF OAI.PowerSaving.MX OAI.PowerSaving.RAM Matrix Finset

noncomputable section

lemma hom_lin {M N : Type*} [AddCommGroup M] [Module F M] [AddCommGroup N] [Module F N] (Φ : M →+ N) (c : F)
    (v : M) : Φ (c • v) = c • Φ v := by
  rcases bit_cases c with rfl | rfl <;> simp

lemma ind_map {M γ : Type*} [AddCommGroup M] [Module F M] (Φ : M → Space γ) (hadd : ∀ x y, Φ (x + y) = Φ x + Φ y)
    (hinj : Function.Injective Φ) {r : ℕ} {v : Fin r → M} (hv : LinearIndependent F v) :
    LinearIndependent F fun k => Φ (v k) := by
  rw [Fintype.linearIndependent_iff] at hv ⊢
  intro g hg
  refine hv g (hinj ?_)
  show AddMonoidHom.mk' Φ hadd (∑ k, g k • v k) = AddMonoidHom.mk' Φ hadd 0
  rw [map_sum, map_zero]
  exact (Finset.sum_congr rfl fun k _ => hom_lin (AddMonoidHom.mk' Φ hadd) (g k) (v k)).trans hg

lemma rk_cons {α ρ : Type*} (mv : GMove α ρ) (w : GWord α ρ) :
    (mv :: w).filterMap GMove.rk? = mv.rk?.toList ++ w.filterMap GMove.rk? := by
  cases h : mv.rk? <;> simp [List.filterMap_cons, h]

section Frame
variable {γ μ β ρ σ : Type*} [Fintype γ] [DecidableEq γ] [Fintype μ] [DecidableEq μ] [Fintype β] [DecidableEq β]
  [Fintype ρ] [DecidableEq ρ]

lemma dual (φ : Space γ → F) (hφ : ∀ x y, φ (x + y) = φ x + φ y) (X : Space γ) :
    φ X = dot (fun g => φ (eu g)) X := by
  have hx : X = ∑ g, X g • eu g := by
    funext j
    rw [Finset.sum_apply, Finset.sum_eq_single j (fun g _ hg => by simp [eu, hg])
      (fun h => absurd (Finset.mem_univ j) h)]
    simp [eu]
  have h := congrArg (AddMonoidHom.mk' φ hφ) hx
  rw [map_sum] at h
  show φ X = ∑ g, φ (eu g) * X g
  exact h.trans (Finset.sum_congr rfl fun g _ =>
    (hom_lin (AddMonoidHom.mk' φ hφ) (X g) (eu g)).trans (mul_comm (X g) (φ (eu g))))

def colMat (a : ℕ) (M : CMat β) : CMat (Fin a × β) :=
  (digitProd fun _ : Fin a => M).submatrix (Equiv.curry (Fin a) β F) (Equiv.curry (Fin a) β F)

lemma colMat_apply (a : ℕ) (M : CMat β) (x y : Space (Fin a × β)) :
    colMat a M x y = ∏ i, M (fun b => x (i, b)) (fun b => y (i, b)) := rfl

lemma colMat_mul (a : ℕ) (M N : CMat β) : colMat a (M * N) = colMat a M * colMat a N := by
  unfold colMat
  rw [Matrix.submatrix_mul_equiv, digitProd_mul]

lemma colMat_digit (a : ℕ) (m : Matrix F F ℂ) :
    colMat a (digitProd fun _ : β => m) = digitProd fun _ : Fin a × β => m := by
  ext x y
  rw [colMat_apply]
  simp only [digitProd_apply]
  exact (Fintype.prod_prod_type (fun p : Fin a × β => m (x p) (y p))).symm

lemma colMat_diag (a : ℕ) (d : Space β → ℂ) :
    colMat a (Matrix.diagonal d) = Matrix.diagonal fun x => ∏ i, d fun b => x (i, b) := by
  ext x y
  rw [colMat_apply]
  by_cases h : x = y
  · subst h; simp
  · rw [Matrix.diagonal_apply_ne _ h]
    obtain ⟨p, hp⟩ := Function.ne_iff.1 h
    exact Finset.prod_eq_zero (Finset.mem_univ p.1)
      (Matrix.diagonal_apply_ne _ fun e => hp (congrFun e p.2))

lemma colMat_wrap (a : ℕ) (φ : Space β → ℂ) :
    colMat a (wrap φ) = wrap fun x => ∏ i, φ fun b => x (i, b) := by
  unfold wrap
  rw [colMat_mul, colMat_mul, colMat_diag, show colMat a (wal β) = wal (Fin a × β) from colMat_digit a _,
    show colMat a (walI β) = walI (Fin a × β) from colMat_digit a _]

lemma colMat_shift (a : ℕ) (c : Space β) :
    colMat a (Binary.shift c) = Binary.shift fun p : Fin a × β => c p.2 := by
  ext x y
  rw [colMat_apply]
  show (∏ i, if (fun b => x (i, b)) + c = (fun b => y (i, b)) then (1 : ℂ) else 0)
    = if x + (fun p : Fin a × β => c p.2) = y then 1 else 0
  by_cases h : x + (fun p : Fin a × β => c p.2) = y
  · rw [if_pos h]; subst h
    exact Finset.prod_eq_one fun i _ => if_pos rfl
  · rw [if_neg h]
    obtain ⟨p, hp⟩ := Function.ne_iff.1 h
    exact Finset.prod_eq_zero (Finset.mem_univ p.1) (if_neg fun e => hp (congrFun e p.2))

def colP (a : ℕ) (G : APerm β) : APerm (Fin a × β) :=
  ⟨(Equiv.curry (Fin a) β F).trans ((Equiv.piCongrRight fun _ => G.π).trans (Equiv.curry (Fin a) β F).symm),
    fun x y => by
      funext p
      exact congrFun (G.add (fun b => x (p.1, b)) (fun b => y (p.1, b))) p.2⟩

lemma colMat_perm (a : ℕ) (G : APerm β) : colMat a (permMat G) = permMat (colP a G) := by
  ext x y
  rw [colMat_apply]
  show (∏ i, if G.π (fun b => x (i, b)) = (fun b => y (i, b)) then (1 : ℂ) else 0)
    = if (colP a G).π x = y then 1 else 0
  by_cases h : (colP a G).π x = y
  · rw [if_pos h]; subst h
    exact Finset.prod_eq_one fun i _ => if_pos rfl
  · rw [if_neg h]
    obtain ⟨p, hp⟩ := Function.ne_iff.1 h
    exact Finset.prod_eq_zero (Finset.mem_univ p.1) (if_neg fun e => hp (congrFun e p.2))

def kfam (a : ℕ) {b : ℕ} (y : Fin b → Space β) (k : Fin (a * b)) : Space (Fin a × β) :=
  fun p => if (finProdFinEquiv.symm k).1 = p.1 then y (finProdFinEquiv.symm k).2 p.2 else 0

lemma colMat_block (a : ℕ) {b : ℕ} (y : Fin b → Space β) : colMat a (blockMat y) = blockMat (kfam a y) := by
  rw [blockMat_eq_wrap, blockMat_eq_wrap, colMat_wrap]
  congr 1
  funext x
  show ∏ i, ∏ j, tint (dot (y j) fun b => x (i, b)) = ∏ k, tint (dot (kfam a y k) x)
  rw [← Equiv.prod_comp finProdFinEquiv (fun k => tint (dot (kfam a y k) x)), Fintype.prod_prod_type]
  refine Finset.prod_congr rfl fun i _ => Finset.prod_congr rfl fun j _ => congrArg tint (Eq.symm ?_)
  show ∑ p : Fin a × β, kfam a y (finProdFinEquiv (i, j)) p * x p = ∑ b, y j b * x (i, b)
  rw [Fintype.sum_prod_type]
  refine (Finset.sum_eq_single i (fun i' _ h => ?_) (fun h => absurd (Finset.mem_univ i) h)).trans ?_
  · simp [kfam, Ne.symm h]
  · simp [kfam]

lemma kfam_ind (a : ℕ) {b : ℕ} {y : Fin b → Space β} (hy : LinearIndependent F y) :
    LinearIndependent F (kfam a y) := by
  rw [Fintype.linearIndependent_iff] at hy ⊢
  intro g hg k
  obtain ⟨⟨i, j⟩, rfl⟩ := finProdFinEquiv.surjective k
  refine hy (fun j => g (finProdFinEquiv (i, j))) ?_ j
  funext b
  have h := congrFun hg (i, b)
  rw [Finset.sum_apply, ← Equiv.sum_comp finProdFinEquiv, Fintype.sum_prod_type] at h
  rw [Finset.sum_eq_single i (fun i' _ hne => by simp [kfam, hne])
    (fun h' => absurd (Finset.mem_univ i) h')] at h
  rw [Finset.sum_apply]
  simpa [kfam] using h

variable {a : ℕ} (K : Split γ μ (Fin a × β))

lemma lift_block {r : ℕ} (w : Fin r → Space (Fin a × β)) :
    K.lift (blockMat w) = blockMat fun k => K.e.symm (0, w k) := by
  unfold blockMat
  rw [Split.lift_list_prod, List.map_ofFn]
  congr 2
  funext k
  exact K.lift_dir (w k)

lemma lift_diag (d : Space (Fin a × β) → ℂ) :
    K.lift (Matrix.diagonal d) = Matrix.diagonal fun X => d (K.e X).2 := by
  ext X Y
  show (if (K.e X).1 = (K.e Y).1 then Matrix.diagonal d (K.e X).2 (K.e Y).2 else 0) = _
  by_cases h : X = Y
  · subst h; simp
  · rw [Matrix.diagonal_apply_ne _ h]
    by_cases h1 : (K.e X).1 = (K.e Y).1
    · rw [if_pos h1]
      exact Matrix.diagonal_apply_ne _ fun h2 => h (K.e.injective (Prod.ext h1 h2))
    · exact if_neg h1

def liftP (H : APerm (Fin a × β)) : APerm γ :=
  ⟨K.e.trans ((Equiv.prodCongr (Equiv.refl _) H.π).trans K.e.symm), fun x y => by
    show K.e.symm ((K.e (x + y)).1, H.π (K.e (x + y)).2)
      = K.e.symm ((K.e x).1, H.π (K.e x).2) + K.e.symm ((K.e y).1, H.π (K.e y).2)
    rw [← K.symm_add, K.add]
    congr 1
    exact Prod.ext rfl (H.add _ _)⟩

lemma lift_perm (H : APerm (Fin a × β)) : K.lift (permMat H) = permMat (liftP K H) := by
  ext X Y
  show (if (K.e X).1 = (K.e Y).1 then (if H.π (K.e X).2 = (K.e Y).2 then (1 : ℂ) else 0) else 0)
    = if K.e.symm ((K.e X).1, H.π (K.e X).2) = Y then 1 else 0
  have key : K.e.symm ((K.e X).1, H.π (K.e X).2) = Y ↔ (K.e X).1 = (K.e Y).1 ∧ H.π (K.e X).2 = (K.e Y).2 := by
    rw [Equiv.symm_apply_eq, Prod.ext_iff]
  by_cases h1 : (K.e X).1 = (K.e Y).1
  · by_cases h2 : H.π (K.e X).2 = (K.e Y).2
    · rw [if_pos h1, if_pos h2, if_pos (key.2 ⟨h1, h2⟩)]
    · rw [if_pos h1, if_neg h2, if_neg fun h => h2 (key.1 h).2]
  · rw [if_neg h1, if_neg fun h => h1 (key.1 h).1]

def gfam {b : ℕ} (y : Fin b → Space β) (k : Fin (a * b)) : Space γ := K.e.symm (0, kfam a y k)

lemma gfam_ind {b : ℕ} {y : Fin b → Space β} (hy : LinearIndependent F y) : LinearIndependent F (gfam K y) :=
  ind_map (fun w => K.e.symm (0, w)) (fun x y => by rw [← K.symm_add]; congr 1)
    (fun x y h => (Prod.mk.inj (K.e.symm.injective h)).2) (kfam_ind a hy)

lemma E_block {b : ℕ} (y : Fin b → Space β) : K.lift (colMat a (blockMat y)) = blockMat (gfam K y) := by
  rw [colMat_block, lift_block]; try rfl

def unfl (f : ℕ) (R : Fin f → Space μ) (C : Sky β (f * a)) : Sky γ f :=
  fun j => K.e.symm (R j, fun p => C (finProdFinEquiv (j, p.1)) p.2)

def fl (f : ℕ) (S : Sky γ f) : Sky β (f * a) :=
  fun k b => (K.e (S (finProdFinEquiv.symm k).1)).2 ((finProdFinEquiv.symm k).2, b)

lemma unfl_fl (f : ℕ) (S : Sky γ f) : unfl K f (fun j => (K.e (S j)).1) (fl K f S) = S := by
  funext j; simp [unfl, fl]

lemma fl_unfl (f : ℕ) (R : Fin f → Space μ) (C : Sky β (f * a)) : fl K f (unfl K f R C) = C := by
  funext k b
  show (K.e (K.e.symm (R (finProdFinEquiv.symm k).1,
    fun p => C (finProdFinEquiv ((finProdFinEquiv.symm k).1, p.1)) p.2))).2 ((finProdFinEquiv.symm k).2, b) = C k b
  rw [Equiv.apply_symm_apply]
  exact congrFun (congrArg C (finProdFinEquiv.apply_symm_apply k)) b

lemma rs_unfl (f : ℕ) (R : Fin f → Space μ) (C : Sky β (f * a)) :
    (fun j => (K.e (unfl K f R C j)).1) = R := by
  funext j; simp [unfl]

def skyEq (f : ℕ) : (Fin f → Space μ) × Sky β (f * a) ≃ Sky γ f where
  toFun p := unfl K f p.1 p.2
  invFun T := (fun j => (K.e (T j)).1, fl K f T)
  left_inv p := Prod.ext (rs_unfl K f p.1 p.2) (fl_unfl K f p.1 p.2)
  right_inv T := unfl_fl K f T

lemma matAct_E (f : ℕ) (M : CMat β) (x : Sky γ f → ℂ) (S : Sky γ f) :
    matAct f (K.lift (colMat a M)) x S
      = matAct (f * a) M (fun C => x (unfl K f (fun j => (K.e (S j)).1) C)) (fl K f S) := by
  show ∑ T, digitProd (fun _ : Fin f => K.lift (colMat a M)) S T * x T
    = ∑ C, digitProd (fun _ : Fin (f * a) => M) (fl K f S) C * x (unfl K f (fun j => (K.e (S j)).1) C)
  rw [← (skyEq K f).sum_comp, Fintype.sum_prod_type]
  refine (Finset.sum_eq_single (fun j => (K.e (S j)).1) ?_ (fun h => absurd (Finset.mem_univ _) h)).trans ?_
  · intro R _ hR
    obtain ⟨j, hj⟩ := Function.ne_iff.1 hR
    have hj' : (K.e (S j)).1 ≠ R j := Ne.symm hj
    refine Finset.sum_eq_zero fun C _ => ?_
    have h0 : digitProd (fun _ : Fin f => K.lift (colMat a M)) S (skyEq K f (R, C)) = 0 :=
      Finset.prod_eq_zero (Finset.mem_univ j) (by
        show K.lift (colMat a M) (S j) (unfl K f R C j) = 0
        simp [Split.lift, unfl, hj'])
    rw [h0, zero_mul]
  · refine Finset.sum_congr rfl fun C _ => congrArg₂ (· * ·) ?_ rfl
    show ∏ j, K.lift (colMat a M) (S j) (unfl K f (fun j => (K.e (S j)).1) C j) = ∏ k, M (fl K f S k) (C k)
    rw [← Equiv.prod_comp finProdFinEquiv (fun k => M (fl K f S k) (C k)), Fintype.prod_prod_type]
    refine Finset.prod_congr rfl fun j _ => ?_
    simp only [Split.lift, unfl, fl, colMat_apply, Equiv.apply_symm_apply, Equiv.symm_apply_apply, ↓reduceIte]
    refine Finset.prod_congr rfl fun i _ => ?_
    exact congrArg (fun u => M u (C (finProdFinEquiv (j, i)))) (funext fun b => by
      show (K.e (S j)).2 (i, b)
        = (K.e (S (finProdFinEquiv.symm (finProdFinEquiv (j, i))).1)).2 ((finProdFinEquiv.symm (finProdFinEquiv (j, i))).2, b)
      rw [Equiv.symm_apply_apply])

def trD (f : ℕ) (R : Fin f → Space μ) (D : Data γ ρ f) : Data β ρ (f * a) := fun r C => D r (unfl K f R C)

lemma trD_roleAct (f : ℕ) (R : Fin f → Space μ) (l : ρ) (M : CMat β) (D : Data γ ρ f) :
    trD K f R (roleAct f l (K.lift (colMat a M)) D) = roleAct (f * a) l M (trD K f R D) := by
  funext r C
  show (if r = l then matAct f (K.lift (colMat a M)) (D r) else D r) (unfl K f R C)
    = (if r = l then matAct (f * a) M (trD K f R D r) else trD K f R D r) C
  by_cases h : r = l
  · rw [if_pos h, if_pos h, matAct_E, rs_unfl, fl_unfl]; try rfl
  · rw [if_neg h, if_neg h]; try rfl

lemma cert_lift {w : GWord β ρ} {e : σ → ρ} {T : σ → CMat β} (hw : GLiveKernelM e T w) {f : ℕ}
    {X v : Data γ ρ f} (h : ∀ R, trD K f R X = gwalk (f * a) w (trD K f R v))
    (hv : ∀ s, (∀ l, e l ≠ s) → v s = 0) (l : σ) :
    X (e l) = matAct f (K.lift (colMat a (T l))) (v (e l)) := by
  funext S
  have h1 := congrFun (congrFun (h fun j => (K.e (S j)).1) (e l)) (fl K f S)
  have h2 := hw (f * a) (trD K f (fun j => (K.e (S j)).1) v)
    (fun s hs => by funext C; exact congrFun (hv s hs) _) l
  rw [h2] at h1
  rw [matAct_E]
  refine Eq.trans ?_ h1
  show X (e l) S = X (e l) (unfl K f (fun j => (K.e (S j)).1) (fl K f S))
  rw [unfl_fl]

lemma roleProd_phase (l : ρ) (k : F) (L : List (Space γ)) (j : ρ) :
    roleProd (L.map fun w => (GMove.phase l w k : GMove γ ρ)) j
      = if j = l then Matrix.diagonal (fun X => (L.map fun w => tint (dot w X + k)).prod) else 1 := by
  induction L with
  | nil => simp
  | cons w L ih =>
    rw [List.map_cons, roleProd_cons, ih]
    by_cases h : j = l
    · simp only [rmat, if_pos h, phaseMat, Matrix.diagonal_mul_diagonal, List.map_cons, List.prod_cons]
      congr 1; funext X; exact mul_comm _ _
    · simp [rmat, h]

lemma rk_map_none {ι : Type*} (mk : ι → GMove γ ρ) (h : ∀ i, (mk i).rk? = none) (L : List ι) :
    (L.map mk).filterMap GMove.rk? = [] := by
  induction L with
  | nil => rfl
  | cons i L ih => rw [List.map_cons, List.filterMap_cons_none (h i)]; exact ih

lemma exp_phase (l : ρ) (c : Space β) (k : F) :
    ∃ t : GWord γ ρ, t.filterMap GMove.rk? = [] ∧
      ∀ f (D : Data γ ρ f), gwalk f t D = roleAct f l (K.lift (colMat a (phaseMat c k))) D := by
  let w : Fin a → Space γ := fun i g => dot c fun b => (K.e (eu g)).2 (i, b)
  refine ⟨(List.ofFn w).map fun w => GMove.phase l w k, rk_map_none _ (fun _ => rfl) _, fun f D => ?_⟩
  have hN : Matrix.diagonal (fun X => ((List.ofFn w).map fun w => tint (dot w X + k)).prod)
      = K.lift (colMat a (phaseMat c k)) := by
    rw [phaseMat, colMat_diag, lift_diag]
    congr 1
    funext X
    rw [List.map_ofFn, List.prod_ofFn]
    refine Finset.prod_congr rfl fun i _ => ?_
    show tint (dot (w i) X + k) = tint (dot c (fun b => (K.e X).2 (i, b)) + k)
    exact congrArg (fun u => tint (u + k)) (dual (fun X => dot c fun b => (K.e X).2 (i, b)) (fun x y => by
      show dot c (fun b => (K.e (x + y)).2 (i, b)) = _
      rw [K.add]
      exact dot_add_right c (fun b => (K.e x).2 (i, b)) (fun b => (K.e y).2 (i, b))) X).symm
  funext j
  rw [gwalk_local f _ (fun m hm => by obtain ⟨_, -, rfl⟩ := List.mem_map.1 hm; trivial) D j, roleProd_phase]
  show _ = if j = l then matAct f (K.lift (colMat a (phaseMat c k))) (D j) else D j
  by_cases h : j = l
  · rw [if_pos h, if_pos h, hN]
  · rw [if_neg h, if_neg h, matAct_one]

lemma exp_letter (mv : GMove β ρ) :
    ∃ t : GWord γ ρ, t.filterMap GMove.rk? = (mv.rk?.toList).map (a * ·) ∧
      ∀ f (R : Fin f → Space μ) (D : Data γ ρ f), trD K f R (gwalk f t D) = mv.act (f * a) (trD K f R D) := by
  cases mv with
  | old m =>
    cases m with
    | localM g => exact ⟨[.old (.localM g)], rfl, fun f R D => rfl⟩
    | shift l c =>
      refine ⟨[.old (.shift l (K.e.symm (0, fun p => c p.2)))], rfl, fun f R D => ?_⟩
      show trD K f R (roleAct f l (Binary.shift (K.e.symm (0, fun p : Fin a × β => c p.2))) D)
        = roleAct (f * a) l (Binary.shift c) (trD K f R D)
      rw [← K.lift_shift, ← colMat_shift a c, trD_roleAct]
    | block l b y ind =>
      refine ⟨[.old (.block l (a * b) (gfam K y) (gfam_ind K ind))], rfl, fun f R D => ?_⟩
      show trD K f R (roleAct f l (blockMat (gfam K y)) D) = roleAct (f * a) l (blockMat y) (trD K f R D)
      rw [← E_block, trD_roleAct]
  | perm l G =>
    refine ⟨[.perm l (liftP K (colP a G))], rfl, fun f R D => ?_⟩
    show trD K f R (roleAct f l (permMat (liftP K (colP a G))) D)
      = roleAct (f * a) l (permMat G) (trD K f R D)
    rw [← lift_perm, ← colMat_perm, trD_roleAct]
  | phase l c k =>
    obtain ⟨t, ht, hg⟩ := exp_phase (ρ := ρ) K l c k
    refine ⟨t, ht.trans rfl, fun f R D => ?_⟩
    rw [hg, trD_roleAct]; try rfl
  | localG gr gi => exact ⟨[.localG gr gi], rfl, fun f R D => rfl⟩

lemma exp_word (w : GWord β ρ) :
    ∃ t : GWord γ ρ, t.filterMap GMove.rk? = (w.filterMap GMove.rk?).map (a * ·) ∧
      ∀ f (R : Fin f → Space μ) (D : Data γ ρ f), trD K f R (gwalk f t D) = gwalk (f * a) w (trD K f R D) := by
  induction w with
  | nil => exact ⟨[], rfl, fun _ _ _ => rfl⟩
  | cons mv w ih =>
    obtain ⟨t₁, h₁, g₁⟩ := exp_letter (ρ := ρ) K mv
    obtain ⟨t₂, h₂, g₂⟩ := ih
    refine ⟨t₁ ++ t₂, ?_, fun f R D => ?_⟩
    · rw [List.filterMap_append, h₁, h₂, rk_cons, List.map_append]
    · rw [gwalk_append, g₂, g₁, gwalk_cons]

end Frame

end

end TensorEng


set_option linter.unusedSectionVars false
set_option linter.unusedVariables false

namespace TensorEng
open OAI.PowerSaving OAI.PowerSaving.Binary OAI.PowerSaving.GF OAI.PowerSaving.MX OAI.PowerSaving.RAM
open OAI.PowerSaving.RAM.Ty Matrix Finset
open TensorProto (mom tens tpow padT strictT strictP pieces splitAll comp)

noncomputable section

structure CU (α ρ σ : Type*) [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ] where
  e : σ → ρ
  he : Function.Injective e
  tr : σ → ℕ
  tz : ∀ l, Fin (tr l) → Space α
  tind : ∀ l, LinearIndependent F (tz l)
  wd : GWord α ρ
  hw : GLiveKernelM e (fun l => blockMat (tz l)) wd

section Prod
variable {α β γ μ μ' ρ ρ' σ σ' : Type*} [Fintype α] [DecidableEq α] [Fintype β] [DecidableEq β]
  [Fintype γ] [DecidableEq γ] [Fintype μ] [DecidableEq μ] [Fintype μ'] [DecidableEq μ']
  [Fintype ρ] [DecidableEq ρ] [Fintype ρ'] [DecidableEq ρ'] [Fintype σ'] [DecidableEq σ']

def colSplit {a : ℕ} (c : γ ≃ α × β) (S : Split α μ (Fin a)) : Split γ (μ × β) (Fin a × β) where
  e :=
    { toFun := fun X => (fun p => (S.e fun x => X (c.symm (x, p.2))).1 p.1,
        fun p => (S.e fun x => X (c.symm (x, p.2))).2 p.1)
      invFun := fun P g => S.e.symm (fun m => P.1 (m, (c g).2), fun i => P.2 (i, (c g).2)) (c g).1
      left_inv := fun X => by funext g; simp
      right_inv := fun P => by
        refine Prod.ext (funext fun p => ?_) (funext fun p => ?_) <;> simp }
  add := fun X Y => by
    refine Prod.ext (funext fun p => ?_) (funext fun p => ?_)
    · exact congrFun (congrArg Prod.fst
        (S.add (fun x => X (c.symm (x, p.2))) fun x => Y (c.symm (x, p.2)))) p.1
    · exact congrFun (congrArg Prod.snd
        (S.add (fun x => X (c.symm (x, p.2))) fun x => Y (c.symm (x, p.2)))) p.1

lemma colSplit_fam {a b : ℕ} (c : γ ≃ α × β) (S : Split α μ (Fin a)) (z : Fin a → Space α)
    (hS : ∀ i, S.e.symm (0, eu i) = z i) (y : Fin b → Space β) (k : Fin (a * b)) (g : γ) :
    gfam (colSplit c S) y k g
      = z (finProdFinEquiv.symm k).1 (c g).1 * y (finProdFinEquiv.symm k).2 (c g).2 := by
  show S.e.symm (fun m => (0 : Space (μ × β)) (m, (c g).2), fun i => kfam a y k (i, (c g).2)) (c g).1 = _
  have h1 : ((fun m => (0 : Space (μ × β)) (m, (c g).2), fun i => kfam a y k (i, (c g).2)) : Space μ × Space (Fin a))
      = y (finProdFinEquiv.symm k).2 (c g).2 • ((0 : Space μ), eu (finProdFinEquiv.symm k).1) := by
    refine Prod.ext (by funext m; simp) (by funext i; simp [kfam, eu])
  have h2 : S.e.symm (y (finProdFinEquiv.symm k).2 (c g).2 • ((0 : Space μ), eu (finProdFinEquiv.symm k).1))
      = y (finProdFinEquiv.symm k).2 (c g).2 • S.e.symm ((0 : Space μ), eu (finProdFinEquiv.symm k).1) :=
    hom_lin (AddMonoidHom.mk' (fun p => S.e.symm p) S.symm_add) _ _
  rw [h1, h2, hS]
  simp [mul_comm]

lemma kron_comm {a b : ℕ} (S : Split α μ (Fin a)) (S' : Split β μ' (Fin b)) (z : Fin a → Space α)
    (y : Fin b → Space β) (hS : ∀ i, S.e.symm (0, eu i) = z i) (hS' : ∀ i, S'.e.symm (0, eu i) = y i) :
    blockMat (gfam (colSplit (Equiv.refl (α × β)) S) y)
      = blockMat (gfam (colSplit (Equiv.prodComm α β) S') z) := by
  have e1 : ∀ (i : Fin a) (j : Fin b), gfam (colSplit (Equiv.refl (α × β)) S) y (finProdFinEquiv (i, j))
      = gfam (colSplit (Equiv.prodComm α β) S') z (finProdFinEquiv (j, i)) := by
    intro i j
    funext g
    rw [colSplit_fam (Equiv.refl (α × β)) S z hS y, colSplit_fam (Equiv.prodComm α β) S' y hS' z]
    simp [mul_comm]
  refine blockMat_congr _ _ fun X => ?_
  show ∏ k, tint (dot (gfam (colSplit (Equiv.refl (α × β)) S) y k) X)
    = ∏ k, tint (dot (gfam (colSplit (Equiv.prodComm α β) S') z k) X)
  rw [← Equiv.prod_comp finProdFinEquiv (fun k => tint (dot (gfam (colSplit (Equiv.refl (α × β)) S) y k) X)),
    ← Equiv.prod_comp finProdFinEquiv (fun k => tint (dot (gfam (colSplit (Equiv.prodComm α β) S') z k) X)),
    Fintype.prod_prod_type, Fintype.prod_prod_type, Finset.prod_comm]
  simp only [e1]

def ιR (r : ρ) : ρ' ↪ ρ × ρ' := ⟨fun r' => (r, r'), fun _ _ h => (Prod.mk.inj h).2⟩
def ιL (s' : ρ') : ρ ↪ ρ × ρ' := ⟨fun r => (r, s'), fun _ _ h => (Prod.mk.inj h).1⟩

lemma rk_over {σ : Type*} [Fintype σ] [DecidableEq σ] (e : ρ ↪ σ) (mv : GMove α ρ) :
    (mv.over e).rk? = mv.rk? := by
  cases mv with
  | old m => cases m <;> rfl
  | _ => rfl

lemma rk_map_over {σ : Type*} [Fintype σ] [DecidableEq σ] (e : ρ ↪ σ) (t : GWord α ρ) :
    (t.map (GMove.over e)).filterMap GMove.rk? = t.filterMap GMove.rk? := by
  rw [List.filterMap_map, show (GMove.rk? ∘ GMove.over e) = (GMove.rk? : GMove α ρ → Option ℕ) from
    funext (rk_over e)]

lemma diag_act (d : ρ → ℚ) (f : ℕ) (D : Data α ρ f) (p : ρ) :
    (GMove.old (BMove.localM (Matrix.diagonal d)) : GMove α ρ).act f D p = fun S => (d p : ℂ) * D p S := by
  funext S
  show ∑ j, ((Matrix.diagonal d p j : ℚ) : ℂ) * D j S = _
  rw [Finset.sum_eq_single p (fun j _ hj => by rw [Matrix.diagonal_apply_ne _ (Ne.symm hj)]; simp)
    (fun h => absurd (Finset.mem_univ p) h), Matrix.diagonal_apply_eq]

variable (V : CU β ρ' σ')

def Clean {f : ℕ} (D : Data (α × β) (ρ × ρ') f) : Prop := ∀ r s', (∀ l', V.e l' ≠ s') → D (r, s') = 0

lemma fibres (tt : σ' → GWord (α × β) ρ) (hr : ∀ l', (tt l').filterMap GMove.rk? = []) (Ls : List σ')
    (hnd : Ls.Nodup) :
    ∃ t : GWord (α × β) (ρ × ρ'), t.filterMap GMove.rk? = [] ∧ ∀ f (D : Data (α × β) (ρ × ρ') f),
      (∀ p : ρ × ρ', (∀ l' ∈ Ls, p.2 ≠ V.e l') → gwalk f t D p = D p) ∧
      ∀ l', gwalk f t D ∘ ιL (V.e l')
        = if l' ∈ Ls then gwalk f (tt l') (D ∘ ιL (V.e l')) else D ∘ ιL (V.e l') := by
  induction Ls with
  | nil => exact ⟨[], rfl, fun f D => ⟨fun _ _ => rfl, fun l' => by simp⟩⟩
  | cons l₀ Ls ih =>
    obtain ⟨t, h1, h2⟩ := ih (List.nodup_cons.1 hnd).2
    refine ⟨(tt l₀).map (GMove.over (ιL (V.e l₀))) ++ t, ?_, fun f D => ⟨?_, ?_⟩⟩
    · rw [List.filterMap_append, h1, List.append_nil, rk_map_over, hr]
    · intro p hp
      rw [gwalk_append, (h2 f _).1 p fun l' hl' => hp l' (List.mem_cons_of_mem _ hl')]
      exact gwalk_out _ _ f D (by
        rw [cover_iff]
        rintro ⟨r, hr'⟩
        exact hp l₀ List.mem_cons_self (congrArg Prod.snd hr').symm)
    · intro l'
      rw [gwalk_append, (h2 f _).2 l']
      by_cases hl : l' = l₀
      · rw [hl, if_neg (List.nodup_cons.1 hnd).1, if_pos List.mem_cons_self, gwalk_over]
      · have hout : gwalk f ((tt l₀).map (GMove.over (ιL (V.e l₀)))) D ∘ ιL (V.e l') = D ∘ ιL (V.e l') :=
          funext fun r => gwalk_out _ _ f D (by
            rw [cover_iff]
            rintro ⟨r₀, hr₀⟩
            exact hl (V.he (congrArg Prod.snd hr₀).symm))
        rw [hout]
        simp only [List.mem_cons, hl, false_or]

variable {ν : σ' → Type*} [∀ l', Fintype (ν l')] [∀ l', DecidableEq (ν l')]
variable (S' : ∀ l', Split β (ν l') (Fin (V.tr l'))) (hS' : ∀ l' i, (S' l').e.symm (0, eu i) = V.tz l' i)

abbrev K2 (l' : σ') : Split (α × β) (ν l' × α) (Fin (V.tr l') × α) := colSplit (Equiv.prodComm α β) (S' l')

def Sim (mv : GMove α ρ) (t : GWord (α × β) (ρ × ρ')) : Prop :=
  t.filterMap GMove.rk? = (mv.rk?.toList).flatMap (fun a => (V.wd.filterMap GMove.rk?).map (a * ·)) ∧
    ∀ f (D : Data (α × β) (ρ × ρ') f), Clean V D → Clean V (gwalk f t D) ∧
      ∀ l' R, trD (K2 V S' l') f R (gwalk f t D ∘ ιL (V.e l'))
        = mv.act (f * V.tr l') (trD (K2 V S' l') f R (D ∘ ιL (V.e l')))

lemma sim_free (mv : GMove α ρ) (h : mv.rk? = none) : ∃ t, Sim V S' mv t := by
  choose tt ht gt using fun l' => exp_letter (ρ := ρ) (K2 V S' l') mv
  obtain ⟨t, h1, h2⟩ := fibres (ρ := ρ) V tt (fun l' => by simp [ht l', h]) Finset.univ.toList
    (Finset.nodup_toList _)
  refine ⟨t, by simp [h1, h], fun f D hD => ⟨fun r s' hs => ?_, fun l' R => ?_⟩⟩
  · rw [(h2 f D).1 (r, s') fun l' _ => (hs l').symm]
    exact hD r s' hs
  · rw [(h2 f D).2 l', if_pos (Finset.mem_toList.2 (Finset.mem_univ l')), gt l' f R]

include hS' in
lemma sim_block (r : ρ) (a : ℕ) (z : Fin a → Space α) (ind : LinearIndependent F z) :
    ∃ t, Sim V S' (.old (.block r a z ind)) t := by
  classical
  obtain ⟨S, hS⟩ := exists_split z ind
  obtain ⟨tV, hr, hg⟩ := exp_word (ρ := ρ') (colSplit (Equiv.refl (α × β)) S) V.wd
  obtain ⟨d, hd⟩ : ∃ d : ρ × ρ' → ℚ, d = fun p => if ∃ l', V.e l' = p.2 then 1 else 0 := ⟨_, rfl⟩
  refine ⟨tV.map (GMove.over (ιR r)) ++ [GMove.old (BMove.localM (Matrix.diagonal d))], ?_, fun f D hD => ?_⟩
  · rw [List.filterMap_append, rk_map_over, hr]
    simp [GMove.rk?, GMove.shadow, BMove.rk?]
  have key : ∀ p, gwalk f (tV.map (GMove.over (ιR r)) ++ [GMove.old (BMove.localM (Matrix.diagonal d))]) D p
      = fun S => (d p : ℂ) * gwalk f (tV.map (GMove.over (ιR r))) D p S := fun p => by
    rw [gwalk_append]; exact diag_act d f _ p
  have hfib : ∀ l', gwalk f (tV.map (GMove.over (ιR r))) D (r, V.e l')
      = matAct f (blockMat (gfam (colSplit (Equiv.refl (α × β)) S) (V.tz l'))) (D (r, V.e l')) := fun l' => by
    rw [← E_block]
    exact cert_lift (colSplit (Equiv.refl (α × β)) S) V.hw
      (X := gwalk f (tV.map (GMove.over (ιR r))) D ∘ ιR r) (v := D ∘ ιR r)
      (fun R => by rw [gwalk_over (ιR r) tV f D]; exact hg f R _) (fun s hs => hD r s hs) l'
  refine ⟨fun q s' hs => ?_, fun l' R => ?_⟩
  · rw [key, hd]
    funext Sk
    simp [hs]
  · have hv : gwalk f (tV.map (GMove.over (ιR r)) ++ [GMove.old (BMove.localM (Matrix.diagonal d))]) D
          ∘ ιL (V.e l')
        = roleAct f r ((K2 V S' l').lift (colMat (V.tr l') (blockMat z))) (D ∘ ιL (V.e l')) := by
      funext q
      show gwalk f (tV.map (GMove.over (ιR r)) ++ [GMove.old (BMove.localM (Matrix.diagonal d))]) D (q, V.e l')
        = if q = r then matAct f ((K2 V S' l').lift (colMat (V.tr l') (blockMat z))) (D (q, V.e l'))
          else D (q, V.e l')
      rw [key, show d (q, V.e l') = 1 by rw [hd]; exact if_pos ⟨l', rfl⟩]
      simp only [Rat.cast_one, one_mul]
      by_cases hq : q = r
      · rw [hq, if_pos rfl, E_block, ← kron_comm S (S' l') z (V.tz l') hS (hS' l')]
        exact hfib l'
      · rw [if_neg hq]
        exact gwalk_out (ιR r) tV f D (by
          rw [cover_iff]
          rintro ⟨s, hs⟩
          exact hq (congrArg Prod.fst hs).symm)
    rw [hv]
    exact trD_roleAct (K2 V S' l') f R r (blockMat z) _

include hS' in
lemma sim_letter (mv : GMove α ρ) : ∃ t, Sim V S' mv t := by
  cases mv with
  | old m =>
    cases m with
    | block r a z ind => exact sim_block V S' hS' r a z ind
    | _ => exact sim_free V S' _ rfl
  | _ => exact sim_free V S' _ rfl

include hS' in
lemma sim_word (w : GWord α ρ) :
    ∃ t : GWord (α × β) (ρ × ρ'),
      t.filterMap GMove.rk? = (w.filterMap GMove.rk?).flatMap (fun a => (V.wd.filterMap GMove.rk?).map (a * ·)) ∧
      ∀ f (D : Data (α × β) (ρ × ρ') f), Clean V D → Clean V (gwalk f t D) ∧
        ∀ l' R, trD (K2 V S' l') f R (gwalk f t D ∘ ιL (V.e l'))
          = gwalk (f * V.tr l') w (trD (K2 V S' l') f R (D ∘ ιL (V.e l'))) := by
  induction w with
  | nil => exact ⟨[], rfl, fun f D hD => ⟨hD, fun _ _ => rfl⟩⟩
  | cons mv w ih =>
    obtain ⟨t₁, h₁, g₁⟩ := sim_letter V S' hS' mv
    obtain ⟨t₂, h₂, g₂⟩ := ih
    refine ⟨t₁ ++ t₂, ?_, fun f D hD => ?_⟩
    · rw [List.filterMap_append, h₁, h₂, rk_cons, List.flatMap_append]
    · obtain ⟨c1, v1⟩ := g₁ f D hD
      obtain ⟨c2, v2⟩ := g₂ f _ c1
      rw [gwalk_append]
      exact ⟨c2, fun l' R => by rw [v2, v1, gwalk_cons]⟩

theorem prod_exists (U : CU α ρ σ) (V : CU β ρ' σ') :
    ∃ W : CU (α × β) (ρ × ρ') (σ × σ'),
      W.wd.filterMap GMove.rk?
        = (U.wd.filterMap GMove.rk?).flatMap (fun a => (V.wd.filterMap GMove.rk?).map (a * ·)) ∧
      ∀ p, W.tr p = U.tr p.1 * V.tr p.2 := by
  choose S' hS' using fun l' => exists_split (V.tz l') (V.tind l')
  obtain ⟨t, hr, hs⟩ := sim_word (ν := fun l' => Fin (Fintype.card β - V.tr l')) V S' hS' U.wd
  refine ⟨⟨fun p => (U.e p.1, V.e p.2),
    fun p q h => Prod.ext (U.he (congrArg Prod.fst h)) (V.he (congrArg Prod.snd h)),
    fun p => V.tr p.2 * U.tr p.1, fun p => gfam (K2 V S' p.2) (U.tz p.1),
    fun p => gfam_ind _ (U.tind p.1), t, ?_⟩, hr, fun _ => Nat.mul_comm _ _⟩
  rintro f v hv ⟨l, l'⟩
  show gwalk f t v (U.e l, V.e l') = matAct f (blockMat (gfam (K2 V S' l') (U.tz l))) (v (U.e l, V.e l'))
  have hc : Clean V v := fun r s' h => hv (r, s') fun p hp => h p.2 (congrArg Prod.snd hp)
  rw [← E_block]
  exact cert_lift (K2 V S' l') U.hw (X := gwalk f t v ∘ ιL (V.e l')) (v := v ∘ ιL (V.e l'))
    ((hs f v hc).2 l') (fun s h => hv (s, V.e l') fun p hp => h p.1 (congrArg Prod.fst hp)) l

end Prod

structure BU where
  α : Type
  ρ : Type
  σ : Type
  [fα : Fintype α]
  [dα : DecidableEq α]
  [fρ : Fintype ρ]
  [dρ : DecidableEq ρ]
  [fσ : Fintype σ]
  [dσ : DecidableEq σ]
  u : CU α ρ σ

attribute [instance] BU.fα BU.dα BU.fρ BU.dρ BU.fσ BU.dσ

def BU.ranks (A : BU) : Multiset ℕ := ((A.u.wd.filterMap GMove.rk? : List ℕ) : Multiset ℕ)
def BU.tgts (A : BU) : Multiset ℕ := (Finset.univ : Finset A.σ).val.map A.u.tr
def BU.RanksOK (A : BU) : Prop := ∀ r ∈ A.u.wd.filterMap GMove.rk?, 1 ≤ r ∧ r < Fintype.card A.α
def BU.TgtsOK (A : BU) : Prop := ∀ l, 1 ≤ A.u.tr l ∧ A.u.tr l ≤ Fintype.card A.α

def BU.prod (A B : BU) : BU := ⟨A.α × B.α, A.ρ × B.ρ, A.σ × B.σ, Classical.choose (prod_exists A.u B.u)⟩

def BU.pow (A : BU) : ℕ → BU
  | 0 => A
  | n + 1 => (BU.pow A n).prod A

lemma tens_coe (l₁ l₂ : List ℕ) :
    tens (l₁ : Multiset ℕ) (l₂ : Multiset ℕ) = ((l₁.flatMap fun a => l₂.map (a * ·) : List ℕ) : Multiset ℕ) := by
  induction l₁ with
  | nil => simp [tens]
  | cons a l ih =>
    have h : tens ((a :: l : List ℕ) : Multiset ℕ) (l₂ : Multiset ℕ)
        = ((l₂.map (a * ·) : List ℕ) : Multiset ℕ) + tens (l : Multiset ℕ) (l₂ : Multiset ℕ) := by
      unfold tens
      rw [← Multiset.cons_coe, Multiset.cons_bind, Multiset.map_coe]
    rw [h, ih, List.flatMap_cons, Multiset.coe_add]

lemma BU.ranks_prod (A B : BU) : (A.prod B).ranks = tens A.ranks B.ranks := by
  show (((Classical.choose (prod_exists A.u B.u)).wd.filterMap GMove.rk? : List ℕ) : Multiset ℕ)
    = tens ((A.u.wd.filterMap GMove.rk? : List ℕ) : Multiset ℕ) ((B.u.wd.filterMap GMove.rk? : List ℕ) : Multiset ℕ)
  rw [(Classical.choose_spec (prod_exists A.u B.u)).1, tens_coe]

lemma tens_map {X Y : Type*} (s : Multiset X) (t : Multiset Y) (f : X → ℕ) (g : Y → ℕ) :
    (s ×ˢ t).map (fun q => f q.1 * g q.2) = tens (s.map f) (t.map g) := by
  induction s using Multiset.induction_on with
  | empty => simp [TensorProto.tens]
  | cons a s ih =>
    rw [Multiset.cons_product, Multiset.map_add, ih, Multiset.map_cons]
    unfold TensorProto.tens
    rw [Multiset.cons_bind, Multiset.map_map, Multiset.map_map]
    rfl

lemma BU.tgts_prod (A B : BU) : (A.prod B).tgts = tens A.tgts B.tgts := by
  show (Finset.univ : Finset (A.σ × B.σ)).val.map (Classical.choose (prod_exists A.u B.u)).tr = _
  rw [show (Classical.choose (prod_exists A.u B.u)).tr = fun p => A.u.tr p.1 * B.u.tr p.2 from
    funext (Classical.choose_spec (prod_exists A.u B.u)).2, ← Finset.univ_product_univ, Finset.product_val]
  exact tens_map _ _ _ _

lemma BU.ranks_pow (A : BU) (n : ℕ) : (A.pow n).ranks = tpow A.ranks (n + 1) := by
  induction n with
  | zero =>
    show A.ranks = tens ({1} : Multiset ℕ) A.ranks
    simp [tens]
  | succ n ih =>
    show ((A.pow n).prod A).ranks = tens (tpow A.ranks (n + 1)) A.ranks
    rw [BU.ranks_prod, ih]

lemma BU.tgts_pow (A : BU) (n : ℕ) : (A.pow n).tgts = tpow A.tgts (n + 1) := by
  induction n with
  | zero =>
    show A.tgts = tens ({1} : Multiset ℕ) A.tgts
    simp [tens]
  | succ n ih =>
    show ((A.pow n).prod A).tgts = tens (tpow A.tgts (n + 1)) A.tgts
    rw [BU.tgts_prod, ih]

lemma BU.card_pow (A : BU) (n : ℕ) : Fintype.card (A.pow n).α = Fintype.card A.α ^ (n + 1) := by
  induction n with
  | zero =>
    show Fintype.card A.α = Fintype.card A.α ^ (0 + 1)
    rw [zero_add, pow_one]
  | succ n ih =>
    show Fintype.card ((A.pow n).α × A.α) = _
    rw [Fintype.card_prod, ih]; ring

lemma BU.card_prod (A B : BU) : Fintype.card (A.prod B).α = Fintype.card A.α * Fintype.card B.α :=
  Fintype.card_prod A.α B.α

lemma BU.ranksOK_prod {A B : BU} (hA : A.RanksOK) (hB : B.RanksOK) : (A.prod B).RanksOK := by
  intro m hm
  change m ∈ (Classical.choose (prod_exists A.u B.u)).wd.filterMap GMove.rk? at hm
  rw [(Classical.choose_spec (prod_exists A.u B.u)).1] at hm
  obtain ⟨k, hk, hk2⟩ := List.mem_flatMap.1 hm
  obtain ⟨k', hk', rfl⟩ := List.mem_map.1 hk2
  obtain ⟨h1, h2⟩ := hA k hk
  obtain ⟨h3, h4⟩ := hB k' hk'
  rw [BU.card_prod]
  exact ⟨Nat.one_le_iff_ne_zero.2 (Nat.mul_ne_zero (by omega) (by omega)), Nat.mul_lt_mul'' h2 h4⟩

lemma BU.tgtsOK_prod {A B : BU} (hA : A.TgtsOK) (hB : B.TgtsOK) : (A.prod B).TgtsOK := by
  intro p
  obtain ⟨h1, h2⟩ := hA p.1
  obtain ⟨h3, h4⟩ := hB p.2
  rw [show (A.prod B).u.tr p = A.u.tr p.1 * B.u.tr p.2 from (Classical.choose_spec (prod_exists A.u B.u)).2 p,
    BU.card_prod]
  exact ⟨Nat.one_le_iff_ne_zero.2 (Nat.mul_ne_zero (by omega) (by omega)), Nat.mul_le_mul h2 h4⟩

lemma BU.ranksOK_pow {A : BU} (hA : A.RanksOK) (n : ℕ) : (A.pow n).RanksOK := by
  induction n with
  | zero => exact hA
  | succ n ih => exact BU.ranksOK_prod ih hA

lemma BU.tgtsOK_pow {A : BU} (hA : A.TgtsOK) (n : ℕ) : (A.pow n).TgtsOK := by
  induction n with
  | zero => exact hA
  | succ n ih => exact BU.tgtsOK_prod ih hA

lemma card_filter_tr {σ : Type*} [Fintype σ] [DecidableEq σ] (tr : σ → ℕ) (r : ℕ) :
    (Finset.univ.filter fun l : σ => tr l = r).card = ((Finset.univ : Finset σ).val.map tr).count r := by
  rw [Multiset.count_map]
  show Multiset.card (Finset.univ.filter fun l : σ => tr l = r).val = _
  rw [Finset.filter_val]
  exact congrArg (fun s => Multiset.card s) (Multiset.filter_congr fun l _ => eq_comm)

lemma hist_eq_count {α ρ : Type*} (w : GWord α ρ) (r : ℕ) :
    GWord.hist w r = (w.filterMap GMove.rk?).count r := by
  induction w with
  | nil => rfl
  | cons mv w ih =>
    unfold GWord.hist at *
    rw [GWord.shadow_cons, BWord.hist_cons, ih]
    show _ + (if mv.rk? = some r then 1 else 0) = _
    cases h : mv.rk? <;> simp [List.filterMap_cons, h, List.count_cons]

section
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

lemma extend_ind {K : ℕ} (z : Fin K → Space α) (hz : LinearIndependent F z) (d : ℕ)
    (h : K + d ≤ Fintype.card α) :
    ∃ w : Fin (K + d) → Space α, LinearIndependent F w ∧ ∀ i : Fin K, w (Fin.castAdd d i) = z i := by
  obtain ⟨S, hS⟩ := exists_split z hz
  have hle : d ≤ Fintype.card α - K := by omega
  have hg : LinearIndependent F (Fin.append
      (fun i : Fin K => ((0 : Space (Fin (Fintype.card α - K))), eu i))
      (fun j : Fin d => (eu (Fin.castLE hle j), (0 : Space (Fin K))))) := by
    rw [Fintype.linearIndependent_iff]
    intro g hg q
    rw [Fin.sum_univ_add] at hg
    simp only [Fin.append_left, Fin.append_right] at hg
    refine Fin.addCases (fun i => ?_) (fun j => ?_) q
    · have h1 := congrFun (congrArg Prod.snd hg) i
      simpa [Prod.snd_sum, Finset.sum_apply, eu] using h1
    · have h1 := congrFun (congrArg Prod.fst hg) (Fin.castLE hle j)
      simpa [Prod.fst_sum, Finset.sum_apply, eu, Fin.castLE_inj] using h1
  refine ⟨_, ind_map (fun x => S.e.symm x) S.symm_add S.e.symm.injective hg, fun i => ?_⟩
  show S.e.symm (Fin.append (fun i : Fin K => ((0 : Space (Fin (Fintype.card α - K))), eu i))
    (fun j : Fin d => (eu (Fin.castLE hle j), (0 : Space (Fin K)))) (Fin.castAdd d i)) = z i
  rw [Fin.append_left]
  exact hS i

lemma blockMat_of_zero {r : ℕ} (z : Fin r → Space α) (h : r = 0) : blockMat z = 1 := by
  subst h; simp [blockMat]

lemma comp_coe (L : ℕ) (tr : σ → ℕ) (mk : σ → GMove α ρ) (hmk : ∀ l, (mk l).rk? = some (L - tr l))
    (Ls : List σ) :
    ((((Ls.filter fun l => tr l < L).map mk).filterMap GMove.rk? : List ℕ) : Multiset ℕ)
      = comp L ((Ls : Multiset σ).map tr) := by
  induction Ls with
  | nil => simp [TensorProto.comp]
  | cons l Ls ih =>
    have hc : comp L (((l :: Ls : List σ) : Multiset σ).map tr)
        = (if tr l < L then ({L - tr l} : Multiset ℕ) else 0) + comp L ((Ls : Multiset σ).map tr) := by
      rw [← Multiset.cons_coe, Multiset.map_cons]
      unfold TensorProto.comp
      rw [Multiset.cons_bind]
    rw [hc, ← ih]
    by_cases h : tr l < L
    · rw [if_pos h, List.filter_cons_of_pos (p := fun l => decide (tr l < L)) (by simpa using h), List.map_cons,
        List.filterMap_cons_some (hmk l)]
      exact (Multiset.cons_coe _ _).symm.trans (Multiset.singleton_add _ _).symm
    · rw [if_neg h, List.filter_cons_of_neg (by simpa using h), zero_add]

lemma complete_exists [Fintype σ] [DecidableEq σ] (U : CU α ρ σ) (L : ℕ) (hL : L ≤ Fintype.card α)
    (hT : ∀ l, U.tr l ≤ Fintype.card α) :
    ∃ W : CU α ρ σ, ((W.wd.filterMap GMove.rk? : List ℕ) : Multiset ℕ)
        = ((U.wd.filterMap GMove.rk? : List ℕ) : Multiset ℕ) + comp L ((Finset.univ : Finset σ).val.map U.tr) ∧
      ∀ l, W.tr l = U.tr l + (L - U.tr l) := by
  choose w hw he using fun l => extend_ind (U.tz l) (U.tind l) (L - U.tr l) (by have := hT l; omega)
  obtain ⟨mk, hmk⟩ : ∃ mk : σ → GMove α ρ, mk = fun l => .old (.block (U.e l) (L - U.tr l)
      (fun j => w l (Fin.natAdd _ j)) ((hw l).comp _ (Fin.natAdd_injective _ _))) := ⟨_, rfl⟩
  have hon : OnRole U.e mk (fun l => blockMat fun j => w l (Fin.natAdd _ j)) := fun l => by
    rw [hmk]; exact ⟨trivial, fun j => rfl⟩
  refine ⟨⟨U.e, U.he, fun l => U.tr l + (L - U.tr l), w, hw,
    U.wd ++ ((Finset.univ.toList : List σ).filter fun l => U.tr l < L).map mk, ?_⟩, ?_, fun _ => rfl⟩
  · refine (U.hw.append_local _ fun m hm => by
      obtain ⟨l, -, rfl⟩ := List.mem_map.1 hm
      exact (hon l).1).congr fun l => ?_
    have e1 : blockMat (w l) = blockMat (fun j => w l (Fin.natAdd _ j)) * blockMat (U.tz l) := by
      rw [split_block (w l), blockMat_comm,
        show (fun i => w l (Fin.castAdd (L - U.tr l) i)) = U.tz l from funext (he l)]
    rw [roleProd_map_e U.he hon _ ((Finset.nodup_toList _).filter _) l, e1]
    by_cases h : l ∈ (Finset.univ.toList : List σ).filter fun l => U.tr l < L
    · rw [if_pos h]
    · rw [if_neg h, blockMat_of_zero (fun j => w l (Fin.natAdd _ j)) (by
        have : ¬ U.tr l < L := fun h' =>
          h (List.mem_filter.2 ⟨Finset.mem_toList.2 (Finset.mem_univ l), decide_eq_true h'⟩)
        omega)]
  · rw [List.filterMap_append, ← Multiset.coe_add,
      comp_coe L U.tr mk (fun l => by rw [hmk]; rfl) Finset.univ.toList, Finset.coe_toList]

lemma pieces_step {J : ℕ} (hJ : 0 < J) (d : ℕ) (hd : 0 < d) : pieces J (J + d) = J ::ₘ pieces J d := by
  unfold pieces
  rw [if_neg (by omega : ¬ J + d ≤ J), Nat.add_div_left _ hJ, Nat.add_mod_left]
  by_cases h : d ≤ J
  · rw [if_pos h]
    rcases Nat.lt_or_eq_of_le h with h' | h'
    · have h1 := Nat.div_eq_of_lt h'
      have h2 := Nat.mod_eq_of_lt h'
      have h3 : d ≠ 0 := by omega
      simp [h1, h2, h3]
    · subst h'
      simp [Nat.div_self hJ]
  · rw [if_neg h, Multiset.replicate_succ, Multiset.cons_add]

lemma cut_block {J : ℕ} (hJ : 0 < J) (l : ρ) :
    ∀ (R : ℕ) (z : Fin R → Space α) (ind : LinearIndependent F z),
      ∃ t : GWord α ρ, ((t.filterMap GMove.rk? : List ℕ) : Multiset ℕ) = pieces J R ∧
        ∀ f (D : Data α ρ f), gwalk f t D = roleAct f l (blockMat z) D := by
  intro R
  induction R using Nat.strong_induction_on with
  | h R ih =>
    intro z ind
    by_cases h : R ≤ J
    · exact ⟨[.old (.block l R z ind)], by unfold pieces; rw [if_pos h]; rfl, fun f D => rfl⟩
    · obtain ⟨d, rfl⟩ := Nat.exists_eq_add_of_le (not_le.1 h).le
      obtain ⟨t, ht, hg⟩ := ih d (by omega) (fun j => z (Fin.natAdd J j))
        (ind.comp _ (Fin.natAdd_injective _ _))
      refine ⟨.old (.block l J (fun i => z (Fin.castAdd d i)) (ind.comp _ (Fin.castAdd_injective _ _))) :: t,
        ?_, fun f D => ?_⟩
      · rw [pieces_step hJ d (by omega), ← ht]; rfl
      · rw [gwalk_cons, hg]
        show roleAct f l (blockMat fun j => z (Fin.natAdd J j))
          (roleAct f l (blockMat fun i => z (Fin.castAdd d i)) D) = _
        rw [roleAct_mul, blockMat_comm, ← split_block z]

lemma cut_word {J : ℕ} (hJ : 0 < J) (w : GWord α ρ) :
    ∃ t : GWord α ρ, ((t.filterMap GMove.rk? : List ℕ) : Multiset ℕ)
        = splitAll J ((w.filterMap GMove.rk? : List ℕ) : Multiset ℕ) ∧
      ∀ f (D : Data α ρ f), gwalk f t D = gwalk f w D := by
  induction w with
  | nil => exact ⟨[], by simp [splitAll], fun _ _ => rfl⟩
  | cons mv w ih =>
    obtain ⟨t, ht, hg⟩ := ih
    have key : ∃ t₁ : GWord α ρ, ((t₁.filterMap GMove.rk? : List ℕ) : Multiset ℕ)
        = splitAll J ((mv.rk?.toList : List ℕ) : Multiset ℕ) ∧ ∀ f (D : Data α ρ f), gwalk f t₁ D = mv.act f D := by
      have free : ∀ m : GMove α ρ, m.rk? = none → ∃ t₁ : GWord α ρ, ((t₁.filterMap GMove.rk? : List ℕ) : Multiset ℕ)
          = splitAll J ((m.rk?.toList : List ℕ) : Multiset ℕ) ∧ ∀ f (D : Data α ρ f), gwalk f t₁ D = m.act f D :=
        fun m h => ⟨[m], by simp [h, splitAll], fun _ _ => rfl⟩
      cases mv with
      | old m =>
        cases m with
        | block l R z ind =>
          obtain ⟨t₁, h1, h2⟩ := cut_block hJ l R z ind
          exact ⟨t₁, by rw [h1]; simp [splitAll, GMove.rk?, GMove.shadow, BMove.rk?], h2⟩
        | _ => exact free _ rfl
      | _ => exact free _ rfl
    obtain ⟨t₁, h1, h2⟩ := key
    refine ⟨t₁ ++ t, ?_, fun f D => by rw [gwalk_append, hg, h2, gwalk_cons]⟩
    rw [List.filterMap_append, ← Multiset.coe_add, h1, ht, rk_cons, ← Multiset.coe_add]
    unfold splitAll
    rw [Multiset.add_bind]

lemma proper_of (mv : GMove α ρ) (u : ℕ) (h : ∀ r, mv.rk? = some r → 1 ≤ r ∧ r < u) : mv.Proper u := by
  cases mv with
  | old m =>
    cases m with
    | block l rk z ind => exact h rk rfl
    | _ => trivial
  | _ => trivial

end

universe u

theorem BU.tensor_engine (A : BU) (n J L : ℕ) (hL : L ≤ Fintype.card (A.pow n).α) (hJ : 0 < J) (hJL : J < L)
    (hR : A.RanksOK) (hT : A.TgtsOK) (hσ : 0 < Fintype.card (A.pow n).σ)
    (h3 : 3 ≤ Fintype.card (A.pow n).α) (hatt : L ∈ strictT A.tgts (n + 1) L) {z1 zE : ℝ}
    (hmom : mom z1 (strictP A.tgts A.ranks (n + 1) J L) ≤ mom z1 (strictT A.tgts (n + 1) L))
    (hz1 : 0 < z1) (h12 : z1 < zE) (hzE : zE ≤ 1) (m : Bool) (cl : Paint) {ι : Type u} (k : ι → ℕ)
    (v : ∀ i, Bits (k i) → ℂ) :
    Can m (fun i => 2 ^ k i) (simIn cl) (bundle cl)
      (fun i => givenBits cl (k i) (v i)) (fun i => (bits (k i)).tape (ripple (k i) (v i)))
      (fun i => 2 ^ k i * envelope zE (k i)) := by
  have hTb := TensorProto.tpow_bounds (A := A.tgts) (lo := 1) (hi := Fintype.card A.α)
    (fun x hx => by obtain ⟨l, -, rfl⟩ := Multiset.mem_map.1 hx; exact hT l) (n + 1)
  have hRb := TensorProto.tpow_bounds (A := A.ranks) (lo := 1) (hi := Fintype.card A.α)
    (fun x hx => ⟨(hR x (Multiset.mem_coe.1 hx)).1, (hR x (Multiset.mem_coe.1 hx)).2.le⟩) (n + 1)
  have hT' : ∀ l, 1 ≤ (A.pow n).u.tr l ∧ (A.pow n).u.tr l ≤ Fintype.card (A.pow n).α := fun l => by
    have h := hTb ((A.pow n).u.tr l) (by
      rw [← BU.tgts_pow]; exact Multiset.mem_map_of_mem _ (Finset.mem_univ_val l))
    rw [one_pow, ← BU.card_pow] at h
    exact h
  obtain ⟨C, hCr, hCt⟩ := complete_exists (A.pow n).u L hL fun l => (hT' l).2
  obtain ⟨t, htr, htg⟩ := cut_word hJ C.wd
  have hranks : ((t.filterMap GMove.rk? : List ℕ) : Multiset ℕ) = strictP A.tgts A.ranks (n + 1) J L := by
    rw [htr, hCr]
    show splitAll J ((A.pow n).ranks + comp L (A.pow n).tgts) = _
    rw [BU.ranks_pow, BU.tgts_pow]; try rfl
  have htgts : (Finset.univ : Finset (A.pow n).σ).val.map C.tr = strictT A.tgts (n + 1) L := by
    show _ = Multiset.map (fun K => max K L) (tpow A.tgts (n + 1))
    rw [← BU.tgts_pow]
    show _ = Multiset.map (fun K => max K L) (Multiset.map (A.pow n).u.tr _)
    rw [Multiset.map_map]
    exact Multiset.map_congr rfl fun l _ => by
      show C.tr l = max ((A.pow n).u.tr l) L
      rw [hCt l]; omega
  have hlet : ∀ mv ∈ t, ∀ r, mv.rk? = some r → 1 ≤ r ∧ r ≤ J := fun mv hmv r h => by
    have hm : r ∈ strictP A.tgts A.ranks (n + 1) J L := by
      rw [← hranks]; exact Multiset.mem_coe.2 (List.mem_filterMap.2 ⟨mv, hmv, h⟩)
    exact ⟨TensorProto.splitAll_pos hJ (fun R hR' => (Multiset.mem_add.1 hR').elim
      (fun h' => by have := (hRb R h').1; rwa [one_pow] at this) (fun h' => TensorProto.comp_pos R h')) r hm,
      TensorProto.strictP_le hJ r hm⟩
  obtain ⟨X, hX⟩ : ∃ X : Layout (A.pow n).α, Fintype.card (A.pow n).α = X.n :=
    ⟨Layout.someLayout _, Layout.card _⟩
  have hge : ∀ l, L ≤ C.tr l := fun l => by rw [hCt l]; omega
  let E : Eng (A.pow n).α (A.pow n).ρ (A.pow n).σ :=
    { X := X, R := Layout.someLayout _, Q := Layout.someLayout _, e := C.e, he := C.he, tr := C.tr,
      tz := C.tz, tind := C.tind
      tr_le := fun l => by rw [hCt l, ← hX]; have := (hT' l).2; omega
      tr_pos := fun l => by have := hge l; omega
      wd := t
      hP := fun mv hmv => proper_of mv _ fun r h => ⟨(hlet mv hmv r h).1, by
        have := (hlet mv hmv r h).2; omega⟩
      sep := fun mv hmv r h l => by have := (hlet mv hmv r h).2; have := hge l; omega
      W_pos := by rw [← Layout.card (Layout.someLayout (A.pow n).σ)]; exact hσ
      three := by rw [← hX]; exact h3
      hw := C.hw.of_gwalk fun f x => (htg f x).symm }
  have hatt' : ∃ l, E.tr l = L := by
    rw [← htgts] at hatt
    obtain ⟨l, -, hl⟩ := Multiset.mem_map.1 hatt
    exact ⟨l, hl⟩
  have hmom' : mom z1 ((E.wd.filterMap GMove.rk? : List ℕ) : Multiset ℕ)
      ≤ mom z1 ((Finset.univ : Finset (A.pow n).σ).val.map E.tr) := by
    show mom z1 ((t.filterMap GMove.rk? : List ℕ) : Multiset ℕ)
      ≤ mom z1 ((Finset.univ : Finset (A.pow n).σ).val.map C.tr)
    rw [hranks, htgts]; exact hmom
  obtain ⟨Rr, typ, hB, hrate⟩ := PB.bundle_eng E (kmin := L) (rmax := J)
    (fun mv hmv r h => (hlet mv hmv r h).2) hJL hge (by omega) hatt' hmom'
  exact E.engine_seam_final hB X.n le_rfl hrate hz1 h12 hzE m cl k v

end

end TensorEng
