import Submission.Work.Scratch.Engine

namespace OAI
namespace PowerSaving.Binary
open Matrix Finset
noncomputable section

variable {α β γ : Type*} [Fintype α] [DecidableEq α] [Fintype β] [DecidableEq β]
  [Fintype γ] [DecidableEq γ]

structure Split (α β γ : Type*) where
  e : Space α ≃ Space β × Space γ
  add : ∀ x y, e (x + y) = e x + e y

namespace Split
variable (S : Split α β γ)

lemma symm_add (p q : Space β × Space γ) :
    S.e.symm (p + q) = S.e.symm p + S.e.symm q :=
  S.e.injective (by rw [S.add]; simp)

def lift (M : CMat γ) : CMat α :=
  fun x y => if (S.e x).1 = (S.e y).1 then M (S.e x).2 (S.e y).2 else 0

lemma lift_one : S.lift (1 : CMat γ) = 1 := by
  ext x y
  have h : x = y ↔ (S.e x).1 = (S.e y).1 ∧ (S.e x).2 = (S.e y).2 :=
    S.e.injective.eq_iff.symm.trans Prod.ext_iff
  simp only [lift, Matrix.one_apply, h]
  by_cases h1 : (S.e x).1 = (S.e y).1 <;> by_cases h2 : (S.e x).2 = (S.e y).2 <;> simp [h1, h2]

lemma lift_mul (M N : CMat γ) : S.lift (M * N) = S.lift M * S.lift N := by
  ext x y
  rw [Matrix.mul_apply, ← S.e.symm.sum_comp, Fintype.sum_prod_type]
  simp only [lift, Equiv.apply_symm_apply, ite_mul, zero_mul]
  rw [Finset.sum_comm]
-- CHECK: collapse of the beta-sum after sum_comm
  by_cases h : (S.e x).1 = (S.e y).1 <;> simp [h, Matrix.mul_apply, Finset.sum_ite_eq]

lemma lift_add (M N : CMat γ) : S.lift (M + N) = S.lift M + S.lift N := by
  ext x y; simp only [lift, Matrix.add_apply]; split_ifs <;> simp

lemma lift_smul (a : ℂ) (M : CMat γ) : S.lift (a • M) = a • S.lift M := by
  ext x y; simp only [lift, Matrix.smul_apply]; split_ifs <;> simp

lemma lift_shift (c : Space γ) : S.lift (shift c) = shift (S.e.symm (0, c)) := by
  ext x y
  have h : x + S.e.symm (0, c) = y ↔ (S.e x).1 = (S.e y).1 ∧ (S.e x).2 + c = (S.e y).2 := by
    refine S.e.injective.eq_iff.symm.trans ?_
    rw [S.add, Equiv.apply_symm_apply, Prod.ext_iff]
    simp
  simp only [lift, shift, h]
  by_cases h1 : (S.e x).1 = (S.e y).1 <;> simp [h1]

lemma lift_dir (c : Space γ) : S.lift (dir c) = dir (S.e.symm (0, c)) := by
  simp only [dir, lift_add, lift_smul, lift_one, lift_shift]

lemma lift_list_prod (L : List (CMat γ)) : S.lift L.prod = (L.map S.lift).prod := by
  induction L with
  | nil => simp [lift_one]
  | cons M L ih => simp [lift_mul, ih]

end Split

def blockMat {r : ℕ} (z : Fin r → Space α) : CMat α := (List.ofFn fun i => dir (z i)).prod

lemma prod_dir_wrap (L : List (Space γ)) :
    (L.map dir).prod = wrap (fun x => (L.map (fun z => tint (dot z x))).prod) := by
  induction L with
  | nil => simp only [List.map_nil, List.prod_nil]; exact wrap_one.symm
  | cons z L ih =>
    simp only [List.map_cons, List.prod_cons]
    rw [ih, dir_phase, wrap_mul]

lemma blockMat_wrap {rk : ℕ} (z : Fin rk → Space α) :
    blockMat z = wrap (fun x => ((List.ofFn z).map (fun y => tint (dot y x))).prod) := by
  rw [← prod_dir_wrap, List.map_ofFn]; rfl

private lemma blockMat_comm_dir {k : ℕ} (z : Fin k → Space α) (c : Space α) :
    blockMat z * dir c = dir c * blockMat z := by
  rw [blockMat_wrap, dir_phase, wrap_comm]

private lemma blockMat_succ {k : ℕ} (z : Fin (k+1) → Space α) :
    blockMat z = blockMat (fun i => z i.succ) * dir (z 0) := by
  rw [blockMat_comm_dir]; unfold blockMat; rw [List.ofFn_succ, List.prod_cons]

private lemma kernel_eq_blockMat (r : ℕ) : kernel (Fin r) = blockMat (fun i : Fin r => eu i) := by
  rw [blockMat_wrap, ← wrap_lum]
  congr 1; funext x
  rw [List.map_ofFn, List.prod_ofFn]
  simp [lum]

theorem blockMat_eq_lift {r : ℕ} (S : Split α β (Fin r)) (z : Fin r → Space α)
    (hz : ∀ i, S.e.symm (0, eu i) = z i) : blockMat z = S.lift (kernel (Fin r)) := by
  rw [kernel_eq_blockMat]
  unfold blockMat
  rw [S.lift_list_prod, List.map_ofFn]
  refine congrArg List.prod (congrArg List.ofFn (funext fun i => ?_))
  simp only [Function.comp_apply, S.lift_dir, hz]

section Exists

private def comb {k : ℕ} (w : Fin k → Space α) (b : Space (Fin k)) : Space α := ∑ i, b i • w i

private lemma comb_add {k : ℕ} (w : Fin k → Space α) (b b' : Space (Fin k)) :
    comb w (b + b') = comb w b + comb w b' := by
  simp [comb, add_smul, Finset.sum_add_distrib]

private lemma eq_of_add {δ : Type*} {u v : Space δ} (h : u + v = 0) : u = v :=
  calc u = u + (v + v) := by rw [binary_cancel, add_zero]
    _ = (u + v) + v := (add_assoc _ _ _).symm
    _ = v := by rw [h, zero_add]

private lemma comb_base {r : ℕ} {z : Fin r → Space α} (hz : LinearIndependent F z)
    {c : Space (Fin r)} (hc : comb z c = 0) : c = 0 :=
  funext (Fintype.linearIndependent_iff.1 hz c hc)

private lemma pair_inj {k r : ℕ} {w : Fin k → Space α} {z : Fin r → Space α}
    (hw : ∀ b c, comb w b + comb z c = 0 → b = 0 ∧ c = 0) :
    Function.Injective (fun p : Space (Fin k) × Space (Fin r) => comb w p.1 + comb z p.2) := by
  intro p q h
  have h' : comb w p.1 + comb z p.2 = comb w q.1 + comb z q.2 := h
  have h0 : comb w (p.1 + q.1) + comb z (p.2 + q.2) = 0 := by
    rw [comb_add, comb_add]
    calc comb w p.1 + comb w q.1 + (comb z p.2 + comb z q.2)
        = (comb w p.1 + comb z p.2) + (comb w q.1 + comb z q.2) := by abel
      _ = 0 := by rw [h']; exact binary_cancel _
  obtain ⟨h1, h2⟩ := hw _ _ h0
  exact Prod.ext (eq_of_add h1) (eq_of_add h2)

private lemma card_space (δ : Type*) [Fintype δ] [DecidableEq δ] :
    Fintype.card (Space δ) = 2 ^ Fintype.card δ := by
  simp [Fintype.card_fun, ZMod.card]  -- CHECK: Fintype.card_fun / ZMod.card on `δ → ZMod 2`

private lemma extend {r : ℕ} (z : Fin r → Space α) (hz : LinearIndependent F z) :
    ∀ k, k + r ≤ Fintype.card α →
      ∃ w : Fin k → Space α, ∀ b c, comb w b + comb z c = 0 → b = 0 ∧ c = 0 := by
  intro k
  induction k with
  | zero =>
    intro _
    refine ⟨fun i => i.elim0, fun b c h => ⟨funext fun i => i.elim0, comb_base hz ?_⟩⟩
    simpa [comb] using h
  | succ k ih =>
    intro hk
    obtain ⟨w, hw⟩ := ih (by omega)
    obtain ⟨y, hy⟩ : ∃ y : Space α, ∀ p : Space (Fin k) × Space (Fin r),
        comb w p.1 + comb z p.2 ≠ y := by
      by_contra hc
      push_neg at hc
      have h1 := Fintype.card_le_of_surjective
        (fun p : Space (Fin k) × Space (Fin r) => comb w p.1 + comb z p.2) hc
      rw [Fintype.card_prod, card_space, card_space, card_space, Fintype.card_fin,
        Fintype.card_fin, ← pow_add] at h1
      exact Nat.not_le_of_lt (Nat.pow_lt_pow_right (by decide) (by omega)) h1
    refine ⟨(Fin.cons y w : Fin (k+1) → Space α), fun b c hbc => ?_⟩
    have hs : comb (Fin.cons y w : Fin (k+1) → Space α) b = b 0 • y + comb w (Fin.tail b) := by
      simp [comb, Fin.sum_univ_succ, Fin.tail]
    rw [hs] at hbc
    rcases bit_cases (b 0) with h0 | h0
    · rw [h0, zero_smul, zero_add] at hbc
      obtain ⟨h1, h2⟩ := hw _ _ hbc
      refine ⟨funext fun i => ?_, h2⟩
      cases i using Fin.cases with
      | zero => exact h0
      | succ j => exact congrFun h1 j
    · rw [h0, one_smul, add_assoc] at hbc
      exact absurd (eq_of_add hbc).symm (hy (Fin.tail b, c))

theorem exists_split {r : ℕ} (z : Fin r → Space α) (hz : LinearIndependent F z) :
    ∃ S : Split α (Fin (Fintype.card α - r)) (Fin r), ∀ i, S.e.symm (0, eu i) = z i := by
  have hr : r ≤ Fintype.card α := by
    have hinj : Function.Injective (comb z) := fun b b' h => by
      have : comb z (b + b') = 0 := by rw [comb_add, h]; exact binary_cancel _
      exact eq_of_add (comb_base hz this)
    have h1 := Fintype.card_le_of_injective _ hinj
    rw [card_space, card_space, Fintype.card_fin] at h1
    by_contra hc
    exact Nat.not_le_of_lt (Nat.pow_lt_pow_right (by decide) (Nat.lt_of_not_le hc)) h1
  obtain ⟨w, hw⟩ := extend z hz (Fintype.card α - r) (by omega)
  let f : Space (Fin (Fintype.card α - r)) × Space (Fin r) → Space α :=
    fun p => comb w p.1 + comb z p.2
  have fadd : ∀ p q, f (p + q) = f p + f q := fun p q => by
    show comb w (p.1 + q.1) + comb z (p.2 + q.2) =
      (comb w p.1 + comb z p.2) + (comb w q.1 + comb z q.2)
    rw [comb_add, comb_add]; abel
  have hcard : Fintype.card (Space (Fin (Fintype.card α - r)) × Space (Fin r)) =
      Fintype.card (Space α) := by
    rw [Fintype.card_prod, card_space, card_space, card_space, Fintype.card_fin,
      Fintype.card_fin, ← pow_add, Nat.sub_add_cancel hr]
  have fbij : Function.Bijective f :=
    (Fintype.bijective_iff_injective_and_card f).2 ⟨pair_inj hw, hcard⟩
  let E := Equiv.ofBijective f fbij
  have hE : ∀ a, f (E.symm a) = a := fun a => E.apply_symm_apply a
  refine ⟨⟨E.symm, fun a b => ?_⟩, fun i => ?_⟩
  · apply E.injective
    rw [E.apply_symm_apply]
    show a + b = f (E.symm a + E.symm b)
    rw [fadd, hE, hE]
  · show f (0, eu i) = z i
-- CHECK: simp unfolding the let-bound `f`
    simp [f, comb, eu]

end Exists

lemma flat_len (r f : ℕ) : (Layout.std r).n*f+0 = r*f := rfl

def flat (r f : ℕ) : Sky (Fin r) f ≃ Bits (r*f) :=
  (Equiv.uniqueProd (Sky (Fin r) f) (Bits 0)).symm.trans
    (serial (Layout.std r) 0 f (flat_len r f))

private lemma flat_code (r f : ℕ) (w : Sky (Fin r) f) :
    (bits (r*f)).loc (flat r f w) =
      (book (Layout.std r) 0 f).loc ((Equiv.uniqueProd (Sky (Fin r) f) (Bits 0)).symm w) :=
  serial_code (Layout.std r) 0 f (flat_len r f) _

private lemma flat_kernel (r f : ℕ) (u v : Sky (Fin r) f) :
    kernel (Fin (r*f)) (flat r f u) (flat r f v) =
      digitProd (fun _ : Fin f => kernel (Fin r)) u v := by
  unfold flat
  rw [Equiv.trans_apply, Equiv.trans_apply, kernel_serial]
  have h0 : ∀ a b : Bits 0, kernel (Fin 0) a b = 1 := fun a b => by simp [kernel]
-- CHECK: relies on `((uniqueProd _ _).symm u).2` reducing to `u`
  exact (congrArg (· * _) (h0 _ _)).trans (one_mul _)

variable {r : ℕ}

def Split.sky (S : Split α β γ) (f : ℕ) : Sky α f ≃ Sky β f × Sky γ f where
  toFun x := (fun k => (S.e (x k)).1, fun k => (S.e (x k)).2)
  invFun x k := S.e.symm (x.1 k, x.2 k)
  left_inv x := by simp
  right_inv x := by apply Prod.ext <;> funext k <;> simp

def Split.peel (S : Split α β (Fin r)) (r' f : ℕ) :
    Grid α r' f ≃ Grid β r' f × Bits (r*f) where
  toFun x := ((x.1,(S.sky f x.2).1), flat r f (S.sky f x.2).2)
  invFun p := (p.1.1,(S.sky f).symm (p.1.2,(flat r f).symm p.2))
  left_inv x := by simp
  right_inv p := by simp

theorem Split.product (S : Split α β (Fin r)) (f : ℕ) (x y : Sky α f) :
    digitProd (fun _ : Fin f => S.lift (kernel (Fin r))) x y =
    if (S.sky f x).1=(S.sky f y).1 then
      kernel (Fin (r*f)) (flat r f (S.sky f x).2) (flat r f (S.sky f y).2) else 0 := by
  rw [flat_kernel, digitProd_apply, digitProd_apply]
  have h1 : ∀ k, S.lift (kernel (Fin r)) (x k) (y k) =
      (if (S.sky f x).1 k = (S.sky f y).1 k then (1:ℂ) else 0) *
        kernel (Fin r) ((S.sky f x).2 k) ((S.sky f y).2 k) := by
    intro k
    show (if (S.e (x k)).1 = (S.e (y k)).1 then
        kernel (Fin r) (S.e (x k)).2 (S.e (y k)).2 else 0) =
      (if (S.e (x k)).1 = (S.e (y k)).1 then (1:ℂ) else 0) *
        kernel (Fin r) (S.e (x k)).2 (S.e (y k)).2
    split_ifs <;> simp
  simp_rw [h1]
  rw [Finset.prod_mul_distrib, prod_delta (κ := fun _ : Fin f => Space β)]
  split_ifs <;> simp

end
end PowerSaving.Binary

namespace PowerSaving.RAM
open Binary Ty Finset
noncomputable section

universe U
variable {ι : Type U}

namespace Gear
variable {m : Bool} {B f : ι → ℕ} {s t : Ty} {x : ι → T s}
variable (g : Gear m B f s x)
include g

lemma powerB (rk : ℕ) : Knows m B s x (fun i => 2^(rk * f i)) :=
  (g.power.wpow_fixed rk g.bound).cong (fun _ => rfl) (fun i => by rw [← pow_mul, Nat.mul_comm])

variable {α β : Type*} [Fintype α] [DecidableEq α] [Fintype β] [DecidableEq β]

lemma body_additive (X : Layout α) (g' : Space α → F)
    (hg : ∀ p q, g' (p+q) = g' p + g' q) (v : ∀ i, Sky α (f i))
    (h : Knows m B s x fun i => (bodyOrder X (f i)).loc (v i)) :
    Knows m B s x fun i => (bits (f i)).loc (fun l => g' (v i l)) := by
  have h0 : g' 0 = 0 := by
    have := hg 0 0
    rw [add_zero, cancel] at this
    exact this
  have hsum : ∀ (t : Finset α) (y : Space α),
      g' (∑ a ∈ t, y a • eu a) = ∑ a ∈ t, y a * g' (eu a) := by
    intro t y
    induction t using Finset.induction with
    | empty => simpa using h0
    | insert a t ha ih =>
      rw [Finset.sum_insert ha, Finset.sum_insert ha, hg, ih]
      rcases bit_cases (y a) with hy | hy <;> simp [hy, h0]
  have hdec : ∀ y : Space α, g' y = ∑ a, y a * g' (eu a) := by
    intro y
    have e : (∑ a, y a • eu a) = y := by ext j; simp [eu]
    have := hsum Finset.univ y
    rwa [e] at this
  have key : ∀ t : Finset α, Knows m B s x fun i =>
      (bits (f i)).loc (fun l => ∑ a ∈ t, v i l a * g' (eu a)) := by
    intro t
    induction t using Finset.induction with
    | empty => exact (Can.wc 0).cong (fun _ => rfl) (fun i => by rw [bits_loc]; simp)
    | insert a t ha ih =>
      rcases bit_cases (g' (eu a)) with h1 | h1
      · refine ih.cong (fun _ => rfl) (fun i => ?_)
        simp [Finset.sum_insert ha, h1]
      · refine (g.addr_xor (fun i => ((fun l => v i l a),
            (fun l => ∑ b ∈ t, v i l b * g' (eu b)))) (g.body_get X v a h) ih).cong
            (fun _ => rfl) (fun i => ?_)
        apply congrArg (bits (f i)).loc
        funext l
        simp [Finset.sum_insert ha, h1]
  refine (key Finset.univ).cong (fun _ => rfl) (fun i => ?_)
  apply congrArg (bits (f i)).loc
  funext l
  exact (hdec _).symm

variable (X : Layout α) (r : ℕ) {rk : ℕ}

lemma from_gridB (S : Split α β (Fin rk)) (X' : Layout β)
    (v : ∀ i, Grid α r (f i))
    (h : Knows m B s x (fun i => (book X r (f i)).loc (v i))) :
    Knows m B s x (fun i => (book X' r (f i)).loc (S.peel r (f i) (v i)).1) ∧
    Knows m B s x (fun i => (bits (rk * f i)).loc (S.peel r (f i) (v i)).2) := by
  obtain ⟨hg, hh⟩ := g.grid_fetch X r (v:=v) h
  refine ⟨g.grid_combine X' r (v:=fun i => (S.peel r (f i) (v i)).1) hg
    (g.body_set X' (fun i => (S.peel r (f i) (v i)).1.2) fun l =>
      (g.body_additive X (fun y => (S.e y).1 l)
        (fun p q => congrFun (congrArg Prod.fst (S.add p q)) l)
        (fun i => (v i).2) hh).cong (fun _ => rfl) (fun _ => rfl)), ?_⟩
  have hw : Knows m B s x (fun i =>
      (bodyOrder (Layout.std rk) (f i)).loc (S.sky (f i) (v i).2).2) :=
    g.body_set (Layout.std rk) (fun i => (S.sky (f i) (v i).2).2) fun j =>
      (g.body_additive X (fun y => (S.e y).2 j)
        (fun p q => congrFun (congrArg Prod.snd (S.add p q)) j)
        (fun i => (v i).2) hh).cong (fun _ => rfl) (fun _ => rfl)
  have h0 : Knows m B s x (fun i => (bits 0).loc
      ((Equiv.uniqueProd (Sky (Fin rk) (f i)) (Bits 0)).symm (S.sky (f i) (v i).2).2).1) :=
    (Can.wc 0).cong (fun _ => rfl) (fun i => by rw [bits_loc]; simp)
  refine (g.grid_combine (Layout.std rk) 0
    (v := fun i => (Equiv.uniqueProd (Sky (Fin rk) (f i)) (Bits 0)).symm
      (S.sky (f i) (v i).2).2) h0 hw).cong (fun _ => rfl) (fun i => ?_)
  exact (flat_code rk (f i) _).symm

lemma to_gridB (S : Split α β (Fin rk)) (X' : Layout β)
    (u : ∀ i, Grid β r (f i) × Bits (rk * f i))
    (h : Knows m B s x (fun i => (book X' r (f i)).loc (u i).1))
    (k : Knows m B s x (fun i => (bits (rk * f i)).loc (u i).2)) :
    Knows m B s x (fun i => (book X r (f i)).loc ((S.peel r (f i)).symm (u i))) := by
  obtain ⟨hg, hh⟩ := g.grid_fetch X' r (v:=fun i => (u i).1) h
  have hk : Knows m B s x (fun i => (book (Layout.std rk) 0 (f i)).loc
      ((Equiv.uniqueProd (Sky (Fin rk) (f i)) (Bits 0)).symm ((flat rk (f i)).symm (u i).2))) :=
    k.cong (fun _ => rfl) (fun i => by rw [← flat_code, Equiv.apply_symm_apply])
  have hw := (g.grid_fetch (Layout.std rk) 0
    (v := fun i => (Equiv.uniqueProd (Sky (Fin rk) (f i)) (Bits 0)).symm
      ((flat rk (f i)).symm (u i).2)) hk).2
  refine g.grid_combine X r (v:=fun i => (S.peel r (f i)).symm (u i)) hg
    (g.body_set X (fun i => ((S.peel r (f i)).symm (u i)).2) fun a => ?_)
  have h1 := g.body_additive X' (fun b => S.e.symm (b, 0) a)
    (fun p q => congrFun ((congrArg S.e.symm
      (show ((p+q, 0) : Space β × Space (Fin rk)) = (p, 0) + (q, 0) by simp)).trans
      (S.symm_add _ _)) a)
    (fun i => (u i).1.2) hh
  have h2 := g.body_additive (Layout.std rk) (fun c => S.e.symm (0, c) a)
    (fun p q => congrFun ((congrArg S.e.symm
      (show ((0, p+q) : Space β × Space (Fin rk)) = (0, p) + (0, q) by simp)).trans
      (S.symm_add _ _)) a)
    (fun i => (flat rk (f i)).symm (u i).2) hw  -- CHECK: `hw` is about `(uniqueProd.symm w).2`, defeq to `w`
  refine (g.addr_xor (fun i => ((fun l => S.e.symm ((u i).1.2 l, 0) a),
      (fun l => S.e.symm (0, (flat rk (f i)).symm (u i).2 l) a))) h1 h2).cong
      (fun _ => rfl) (fun i => ?_)
  apply congrArg (bits (f i)).loc
  funext l
  change S.e.symm ((u i).1.2 l, 0) a + S.e.symm (0, (flat rk (f i)).symm (u i).2 l) a =
    S.e.symm ((u i).1.2 l, (flat rk (f i)).symm (u i).2 l) a
  rw [show ∀ p q : Space β × Space (Fin rk), S.e.symm p a + S.e.symm q a = S.e.symm (p + q) a
    from fun p q => (congrFun (S.symm_add p q) a).symm]
  simp

end Gear
end
end PowerSaving.RAM

namespace PowerSaving.Binary
open Matrix Finset
noncomputable section

variable {α ρ σ : Type*}
  [Fintype σ] [DecidableEq σ]

inductive BMove (α ρ : Type*)
  | localM (g : Matrix ρ ρ ℚ)
  | shift (l : ρ) (z : Space α)
  | block (l : ρ) (rk : ℕ) (z : Fin rk → Space α) (ind : LinearIndependent F z)

abbrev BWord (α ρ : Type*) := List (BMove α ρ)

namespace BMove

def flat : BMove α ρ → PWord α ρ
  | .localM g => [.localM g]
  | .shift l z => [.shift l z]
  | .block l _ z ind => List.ofFn (fun i => Move.dir l (z i) (ind.ne_zero i))

def rk? : BMove α ρ → Option ℕ
  | .block _ rk _ _ => some rk
  | _ => none

def Proper (u : ℕ) : BMove α ρ → Prop
  | .block _ rk _ _ => 1 ≤ rk ∧ rk < u
  | _ => True

end BMove

namespace BWord

def flat (w : BWord α ρ) : PWord α ρ := (w.map BMove.flat).flatten

@[simp] lemma flat_nil : flat ([] : BWord α ρ) = [] := rfl

@[simp] lemma flat_cons (mv : BMove α ρ) (w : BWord α ρ) :
    flat (mv :: w) = mv.flat ++ flat w := by
  simp [flat]

def hist (w : BWord α ρ) (r : ℕ) : ℕ := w.countP (fun mv => decide (mv.rk? = some r))

@[simp] lemma hist_nil (r : ℕ) : hist ([] : BWord α ρ) r = 0 := rfl

lemma hist_cons (mv : BMove α ρ) (w : BWord α ρ) (r : ℕ) :
    hist (mv :: w) r = hist w r + if mv.rk? = some r then 1 else 0 := by
  simp [hist, List.countP_cons]

def Proper (u : ℕ) (w : BWord α ρ) : Prop := ∀ mv ∈ w, mv.Proper u

lemma Proper.append {u : ℕ} {w w' : BWord α ρ} (h : Proper u w) (h' : Proper u w') :
    Proper u (w ++ w') := fun mv hm => (List.mem_append.1 hm).elim (h mv) (h' mv)

end BWord

def BMove.costR (φ : ℕ → ℝ) (mv : BMove α ρ) : ℝ :=
  match mv.rk? with
  | some rk => φ rk
  | none => 0

def BWord.costR (φ : ℕ → ℝ) (w : BWord α ρ) : ℝ := (w.map (BMove.costR φ)).sum

@[simp] lemma BWord.costR_nil (φ : ℕ → ℝ) : BWord.costR φ ([] : BWord α ρ) = 0 := by
  simp [BWord.costR]

lemma BWord.costR_cons (φ : ℕ → ℝ) (mv : BMove α ρ) (w : BWord α ρ) :
    BWord.costR φ (mv :: w) = mv.costR φ + BWord.costR φ w := by
  simp [BWord.costR]

lemma BWord.costR_append (φ : ℕ → ℝ) (w w' : BWord α ρ) :
    BWord.costR φ (w ++ w') = BWord.costR φ w + BWord.costR φ w' := by
  simp [BWord.costR]

variable [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]

def BMove.act (f : ℕ) : BMove α ρ → Data α ρ f → Data α ρ f
  | .localM g => point f (actPoint g)
  | .shift l z => roleAct f l (Binary.shift z)
  | .block l _ z _ => roleAct f l (blockMat z)

private lemma walk_dirs (f : ℕ) (l : ρ) {k : ℕ} (z : Fin k → Space α) (hz : ∀ i, z i ≠ 0)
    (x : Data α ρ f) :
    walk f (List.ofFn fun i => Move.dir l (z i) (hz i)) x = roleAct f l (blockMat z) x := by
  induction k generalizing x with
  | zero => funext j; simp [walk, blockMat, roleAct]
  | succ k ih =>
    rw [List.ofFn_succ, blockMat_succ]
-- CHECK: walk of a cons is defeq to walk of the tail at `go`
    show walk f (List.ofFn fun i => Move.dir l (z i.succ) (hz i.succ))
      ((Move.dir l (z 0) (hz 0)).go f x) = _
    rw [ih (fun i => z i.succ) (fun i => hz i.succ)]
    show roleAct f l _ (roleAct f l (dir (z 0)) x) = _
    rw [roleAct_mul]

lemma walk_flat_move (f : ℕ) (mv : BMove α ρ) (x : Data α ρ f) :
    walk f mv.flat x = mv.act f x := by
  cases mv with
  | localM g => rfl
  | shift l z => rfl
  | block l rk z ind => exact walk_dirs f l z (fun i => ind.ne_zero i) x

lemma walk_flat_cons (f : ℕ) (mv : BMove α ρ) (w : BWord α ρ) (x : Data α ρ f) :
    walk f (BWord.flat (mv :: w)) x = walk f w.flat (mv.act f x) := by
  rw [BWord.flat_cons, walk_append, walk_flat_move]

def splitCost (φ : ℕ → ℝ) (m q : ℕ) : ℝ :=
  if q = 0 then 0 else if q < m then φ q else φ (m-1) + φ 1

def BMove.over (e : ρ ↪ σ) : BMove α ρ → BMove α σ
  | .localM M => .localM (wide e M)
  | .shift r z => .shift (e r) z
  | .block r rk z ind => .block (e r) rk z ind

lemma BMove.flat_over (e : ρ ↪ σ) (mv : BMove α ρ) :
    (mv.over e).flat = mv.flat.map (Move.over e) := by
  cases mv with
  | localM M => rfl
  | shift l z => rfl
  | block l rk z ind =>
    simp only [BMove.over, BMove.flat, List.map_ofFn]
    rfl

end
end PowerSaving.Binary

namespace PowerSaving.RAM
open Binary
noncomputable section
variable {α ρ : Type*} [Fintype α] [DecidableEq α]

def ferryM [DecidableEq ρ] (r f : ℕ) (l : ρ) (N : CMat α) (v : Grain α ρ r f) :
    Grain α ρ r f :=
  fun x => roleAct f l N (fun i j => v (i,x.2.1,j)) x.1 x.2.2

end
end PowerSaving.RAM

namespace PowerSaving.Binary
open Matrix Finset Complex
noncomputable section

variable {α : Type*} [Fintype α] [DecidableEq α]

lemma dot_sum_left {β : Type*} (s : Finset β) (g : β → Space α) (x : Space α) :
    dot (∑ j ∈ s, g j) x = ∑ j ∈ s, dot (g j) x := by
  rw [dot_symm, dot_sum]
  exact Finset.sum_congr rfl (fun j _ => dot_symm _ _)

open Classical in
def eps (z : Space α) : F := if lum z = I then 0 else 1

private lemma lum_smul_unit (v : Space α) (hv : dot v v = 1) (b : F) :
    lum (b • v) = sign (eps v * b) * tint b := by
  have hI : (-I : ℂ) ≠ I := by
    intro h; apply Complex.I_ne_zero; linear_combination (-1/2 : ℂ) * h
  rcases bit_cases b with rfl | rfl
  · simp [sign, tint]
  · rw [one_smul, mul_one]
    rcases lum_of_unit v hv with h | h
    · simp [eps, h, sign, tint]
    · simp [eps, h, hI, sign, tint]

namespace OBase
variable (A : OBase α)

def fam (d : Finset α) : Fin d.card → Space α := fun i => A.v (d.equivFin.symm i).1

lemma fam_indep (d : Finset α) : LinearIndependent F (A.fam d) := by
  rw [Fintype.linearIndependent_iff]
  intro g hg i
  have h := congrArg (fun y => dot y (A.fam d i)) hg
  simp only [dot_sum_left, dot_smul_left, dot_zero_left, fam, A.rows] at h
  simpa using h  -- CHECK: `∑ j, g j * if ↑(e j) = ↑(e i) then 1 else 0 = 0` ⇒ `g i = 0`

lemma blockMat_fam (d : Finset α) :
    blockMat (A.fam d) = wrap (fun x => ∏ i ∈ d, tint (dot (A.v i) x)) := by
  rw [blockMat_wrap]
  congr 1; funext x
  rw [List.map_ofFn, List.prod_ofFn, ← Finset.prod_coe_sort d]
  exact Equiv.prod_comp d.equivFin.symm (fun i : d => tint (dot (A.v i) x))

def corr (d : Finset α) : Space α := ∑ i ∈ d, eps (A.v i) • A.v i

def deltas (d : Finset α) : CMat α := wrap (fun x => ∏ i ∈ d, lum (dot (A.v i) x • A.v i))

private lemma deltas_empty : A.deltas ∅ = 1 := by
  simp only [deltas, Finset.prod_empty]; exact wrap_one

private lemma deltas_insert (i : α) (d : Finset α) (h : i ∉ d) :
    A.deltas (insert i d) = delta (A.v i) * A.deltas d := by
  rw [deltas, deltas, delta, wrap_mul]
  congr 1; funext x
  rw [Finset.prod_insert h]

lemma frame_union (c d : Finset α) (h : Disjoint c d) :
    frame A (c ∪ d) = A.deltas d * frame A c := by
-- CHECK: relies on `induction` reverting `h : Disjoint c d`
  induction d using Finset.induction with
  | empty => rw [Finset.union_empty, deltas_empty, one_mul]
  | insert i d hi ih =>
    rw [Finset.disjoint_insert_right] at h
    rw [Finset.union_insert, frame_ins A (c ∪ d) i (by simp [hi, h.1]), ih h.2,
      deltas_insert A i d hi, Matrix.mul_assoc]

lemma deltas_eq (d : Finset α) : A.deltas d = shift (A.corr d) * blockMat (A.fam d) := by
  rw [blockMat_fam, shift_phase, wrap_mul, deltas]
  congr 1; funext x
  rw [corr, dot_sum_left, sign_sum, ← Finset.prod_mul_distrib]
  refine Finset.prod_congr rfl (fun i _ => ?_)
  rw [dot_smul_left, lum_smul_unit _ (A.self i)]

end OBase
end
end PowerSaving.Binary

namespace PowerSaving

lemma envelope_le (z : ℝ) (hz1 : z ≤ 1) (k : ℕ) : envelope z k ≤ k+1 := by
  unfold envelope
  apply Nat.ceil_le.2
  have h0 : (1:ℝ) ≤ (k:ℝ)+1 := by linarith [(Nat.cast_nonneg k : (0:ℝ) ≤ k)]
  have h := Real.rpow_le_rpow_of_exponent_le h0 hz1
  rw [Real.rpow_one] at h
  push_cast; linarith

lemma envelope_real (z : ℝ) (hz : 0 ≤ z) (k : ℕ) : (envelope z k:ℝ) ≤ 2*((k:ℝ)+1)^z := by
  have h0 : (1:ℝ) ≤ (k:ℝ)+1 := by linarith [(Nat.cast_nonneg k : (0:ℝ) ≤ k)]
  have h1 : (1:ℝ) ≤ ((k:ℝ)+1)^z := Real.one_le_rpow h0 hz
  have h2 := Nat.ceil_lt_add_one (show (0:ℝ) ≤ ((k:ℝ)+1)^z by linarith)
  unfold envelope; linarith


namespace RAM

lemma sum_map_getD {β M : Type*} [AddCommMonoid M] (L : List β) (z : β) (g : β → M) :
    (L.map g).sum = ∑ j ∈ Finset.range L.length, g (L.getD j z) := by
  induction L with
  | nil => simp
  | cons a L ih =>
    rw [List.map_cons, List.sum_cons, ih, List.length_cons, Finset.sum_range_succ']
    simp [add_comm]

end RAM
end PowerSaving
end OAI
