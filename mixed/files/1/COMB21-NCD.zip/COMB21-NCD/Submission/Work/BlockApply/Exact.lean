import Submission.Work.Block.WHT
import Submission.Work.BlockAccounting.Moment


namespace OAI
namespace PowerSaving.Binary
open Matrix Finset
noncomputable section
section
variable {α ρ σ : Type*} [Fintype α] [DecidableEq α] [Fintype ρ] [DecidableEq ρ]
  [Fintype σ] [DecidableEq σ]

def listCost (φ : ℕ → ℝ) (l : List (ℕ × ℕ)) : ℝ := (l.map fun b => (b.2:ℝ) * φ b.1).sum

lemma listCost_cons (φ : ℕ → ℝ) (b : ℕ × ℕ) (l : List (ℕ × ℕ)) :
    listCost φ (b :: l) = (b.2:ℝ) * φ b.1 + listCost φ l := by
  simp [listCost]
lemma BWord.costR_ind (w : BWord α ρ) (r : ℕ) :
    w.costR (fun q => if q = r then 1 else 0) = (w.hist r : ℝ) := by
  induction w with
  | nil => simp
  | cons mv w ih =>
    rw [BWord.costR_cons, ih, BWord.hist_cons]
    push_cast
    rw [add_comm]
    congr 1
    cases mv with
    | localM g => simp [BMove.costR, BMove.rk?]
    | shift l z => simp [BMove.costR, BMove.rk?]
    | block l rk z ind => simp [BMove.costR, BMove.rk?]

lemma listCost_ind (l : List (ℕ × ℕ)) (r : ℕ) :
    listCost (fun q => if q = r then 1 else 0) l = (BlockAccounting.histFn l r : ℝ) := by
  induction l with
  | nil => simp [listCost, BlockAccounting.histFn_nil]
  | cons b l ih =>
    rw [BlockAccounting.histFn_cons, listCost_cons, ih]
    push_cast
    congr 1
    by_cases h : b.1 = r <;> simp [h]

namespace OBase
variable (A : OBase α)

lemma erase_union' (c d : Finset α) (i : α) (hi : i ∈ d) :
    c ∪ d.erase i ∪ {i} = c ∪ d := by
  ext j
  simp only [Finset.mem_union, Finset.mem_erase, Finset.mem_singleton]
  constructor
  · rintro ((hj|⟨_, hj⟩)|rfl)
    · exact Or.inl hj
    · exact Or.inr hj
    · exact Or.inr hi
  · rintro (hj|hj)
    · exact Or.inl (Or.inl hj)
    · by_cases hji : j = i
      · exact Or.inr hji
      · exact Or.inl (Or.inr ⟨hji, hj⟩)

end OBase
end
end
end PowerSaving.Binary

end OAI

