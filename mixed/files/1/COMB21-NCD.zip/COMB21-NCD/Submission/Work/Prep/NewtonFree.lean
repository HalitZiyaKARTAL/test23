import Submission.OAI.Computability.FourierTransform.FourierIdentities
import Mathlib.Data.Matrix.Mul
-- CHECK: were reachable via Matrix.Block before; leaves, already in the closure elsewhere
import Mathlib.Algebra.BigOperators.Fin
import Mathlib.Algebra.BigOperators.Intervals

namespace OAI
namespace PowerSaving.Spectral
open Matrix Finset Complex
noncomputable section

def rise (h : Line) (i j : ℕ) : ℂ := if j ≤ i then h (i-j) else 0

def stairs (n : ℕ) (h : Line) : Matrix (Fin n) (Fin n) ℂ :=
  fun i j => rise h i.val j.val

def gap (u : ℂ) : Line := fun i => ∏ j ∈ range i, (1-u^(j+1))

def roof (u : ℂ) : Line := fun i => ∏ j ∈ range i, (-(u^j))

def floorH (u : ℂ) : Line := fun i => (gap u i)⁻¹

def cog (u : ℂ) : Line := fun i => gap u i * roof u i

abbrev RootMat (n : ℕ) := Matrix (Fin n) (Fin n) ℂ

def fade (n : ℕ) (d : Line) : RootMat n := Matrix.diagonal (front n d)

def steps (n : ℕ) (u : ℂ) : RootMat n :=
    fade n (gap u) * stairs n (floorH u) * fade n (roof u)

lemma steps_apply (n : ℕ) (u : ℂ) (i j : Fin n) :
    steps n u i j = gap u i.val * rise (floorH u) i.val j.val * roof u j.val := by
  unfold steps fade
  rw [Matrix.mul_diagonal, Matrix.diagonal_mul]
  rfl

lemma steps_diag (n : ℕ) (u : ℂ) (i : Fin n) :
    steps n u i i = cog u i.val := by simp [steps_apply,cog,rise,floorH,gap]

lemma steps_zero (n : ℕ) (u : ℂ) (i j : Fin n) (h : i<j) :
    steps n u i j=0 := by
  have hx : ¬ (j.val ≤ i.val) := by omega
  simp [steps_apply,rise,hx]

lemma roof_ne_zero {n : ℕ} (u : ℂ) (h : IsPrimitiveRoot u n) (j : ℕ) (hj : j<n) :
    roof u j ≠ 0 := by
  have hz := h.ne_zero (by omega)
  unfold roof
  exact prod_ne_zero_iff.mpr fun i _ => by simp [hz]

lemma gap_ne_zero {n : ℕ} (u : ℂ) (h : IsPrimitiveRoot u n) (j : ℕ) (hj : j<n) :
    gap u j ≠ 0 := by
  apply prod_ne_zero_iff.mpr
  intro i hi
  exact sub_ne_zero.mpr (Ne.symm (h.pow_ne_one_of_pos_of_lt (by omega)
    (Nat.lt_of_le_of_lt (mem_range.mp hi) hj)))

lemma cog_ne_zero {n : ℕ} (u : ℂ) (h : IsPrimitiveRoot u n) (j : ℕ) (hj : j<n) :
    cog u j ≠ 0 := mul_ne_zero (gap_ne_zero _ h j hj) (roof_ne_zero _ h j hj)

lemma winds_symm (n : ℕ) (u : ℂ) :
    (winds n u)ᵀ = winds n u := by ext i j; simp [winds,mul_comm]

def stencil (v : ℕ) (h x : Line) : Line :=
  fun i => ∑ j ∈ range v, rise h i j * x j

def creep (v : ℕ) (h x : Line) : Line :=
  fun i => ∑ j ∈ range v, rise h j i * x j

lemma front_stencil (v : ℕ) (h x : Line) :
    front v (stencil v h x)= stairs v h *ᵥ front v x := by
  ext i
  exact (Fin.sum_univ_eq_sum_range (fun j => rise h i.val j*x j) v).symm

lemma front_creep (v : ℕ) (h x : Line) :
    front v (creep v h x)=(stairs v h)ᵀ *ᵥ front v x := by
  ext i
  exact (Fin.sum_univ_eq_sum_range (fun j => rise h j i.val*x j) v).symm

lemma stencil_reversed (v : ℕ) (h x : Line) (i : ℕ) (hi : i<v) :
    stencil v h (fun j => x (v-1-j)) (v-1-i) = creep v h x i := by
  unfold stencil creep
  rw [← sum_range_reflect (fun j => rise h j i*x j) v]
  refine sum_congr rfl ?_
  intro j hj
  replace hj := mem_range.mp hj
  simp only [rise]
  split_ifs with h1 h2 <;> first | omega | congr 2 <;> omega

lemma rise_both (h : Line) (s i j : ℕ) :
    rise h (s+i) (s+j)=rise h i j := by
  simp [rise, show s+i-(s+j)=i-j by omega]

lemma stencil_left (v w : ℕ) (h x : Line) (i : ℕ) (hi : i<v) :
    stencil (v+w) h x i=stencil v h x i := by
  unfold stencil
  rw [sum_range_add]
  have hz (j : ℕ) : rise h i (v+j) = 0 := by
    rw [rise,ite_eq_right (by omega)]
  simp_rw [hz]; simp

lemma stencil_right (v w : ℕ) (h x : Line) (i : ℕ) :
    stencil (v+w) h x (v+i)=stencil v h x (v+i)+stencil w h (fun j => x (v+j)) i := by
  unfold stencil
  rw [sum_range_add]; simp_rw [rise_both]

lemma stencil_congr (v : ℕ) (h : Line) {x y : Line} (H : ∀ i<v, x i=y i) :
    stencil v h x = stencil v h y := funext fun _ => sum_congr rfl
      fun _ hj => congr_arg (_*·) (H _ (mem_range.mp hj))

def recoilTo (h : Line) : ℕ → Line
  | 0 => fun _ => (h 0)⁻¹
  | k+1 => fun j => if j ≤ k then recoilTo h k j
      else -(∑ i ∈ range (k+1), recoilTo h k (k-i)*h (i+1))/(h 0)

def recoil (h : Line) (j : ℕ) : ℂ := recoilTo h j j

lemma recoilTo_stable (h : Line) : ∀ k j, j ≤ k → recoilTo h k j = recoil h j := by
  intro k
  induction k with
  | zero => intro j hj; obtain rfl : j = 0 := (by omega); rfl
  | succ k ih =>
    intro j hj
    rcases Nat.lt_or_ge j (k+1) with g|g
    · show (if j ≤ k then recoilTo h k j else _) = _
      rw [if_pos (by omega)]; exact ih j (by omega)
    · obtain rfl : j = k+1 := by omega
      rfl

lemma recoil_zero (h : Line) : recoil h 0=(h 0)⁻¹ := rfl

lemma recoil_next (h : Line) (j : ℕ) :
    recoil h (j+1)=-(∑ i ∈ range (j+1), recoil h (j-i)*h (i+1))/(h 0) := by
  show (if j+1 ≤ j then recoilTo h j (j+1)
    else -(∑ i ∈ range (j+1), recoilTo h j (j-i)*h (i+1))/(h 0)) = _
  rw [if_neg (by omega)]
  refine congrArg (fun s => -s/(h 0)) (sum_congr rfl fun i _ => ?_)
  rw [recoilTo_stable h j (j-i) (by omega)]

lemma recoil_conv (h : Line) (hh : h 0≠0) (j : ℕ) :
    (∑ i ∈ range (j+1), recoil h (j-i) * h i) =
      if j=0 then 1 else 0 := by
  cases j with
  | zero => simp [recoil_zero,hh]
  | succ j =>
    rw [sum_range_succ']
    simp only [Nat.add_sub_add_right,
      Nat.sub_zero, Nat.succ_ne_zero, ↓reduceIte]
    rw [recoil_next]
    field_simp
    ring

lemma recoil_orth (v : ℕ) (h : Line) (hh : h 0≠0) (i j : ℕ) (hi : i<v) :
    (∑ k ∈ range v, rise (recoil h) i k * rise h k j) =
    if i=j then 1 else 0 := by
  let f (k : ℕ) := rise (recoil h) i k * rise h k j
  have hz (k : ℕ) : i<k ∨ k<j → f k=0 := by
    unfold f rise
    rintro h1
    split_ifs <;> first | omega | ring
  change (∑ k ∈ range v, f k) = _
  rcases lt_or_ge i j with g|g
  · rw [sum_eq_zero (fun k _ => hz k (by omega)),ite_eq_right (by omega)]
  · let p := i-j
    have hp : j+(p+1)=i+1 := by unfold p; omega
    have hs : (∑ k ∈ range v, f k) =
        ∑ k ∈ range (p+1), recoil h (p-k)*h k := by
      conv_lhs =>
        rw [show v=j+(p+1)+(v-(i+1)) by omega,sum_range_add,sum_range_add]
      have H (k : ℕ) : f (j+(p+1)+k)=0 := hz _ (by omega)
      simp_rw [H]
      rw [sum_const_zero,add_zero,sum_eq_zero (fun k (hk : k∈range j) => hz k (.inr
        (mem_range.mp hk))),zero_add]
      refine sum_congr rfl ?_
      intro k hk
      replace hk := mem_range.mp hk
      simp only [f,rise, ite_eq_left (show j+k ≤ i by omega),ite_eq_left (show j ≤ j+k by omega),
        show i-(j+k)=p-k by omega, show j+k-j=k by omega]
    rw [hs,recoil_conv h hh]
    split_ifs <;> first | rfl | (unfold p at *; omega)

lemma recoil_back (v : ℕ) (h x : Line) (hh : h 0≠0) (i : ℕ) (hi : i<v) :
    stencil v (recoil h) (stencil v h x) i = x i := by
  simp only [stencil,mul_sum,← mul_assoc]
  rw [sum_comm]
  simp only [← sum_mul]
  simp [recoil_orth v h hh i _ hi, ite_mul, hi]

def nwt (u : ℂ) : ℕ → ℕ → ℂ
  | 0, k => if k = 0 then 1 else 0
  | j+1, k => (if k = 0 then 0 else nwt u j (k-1)) - u^j * nwt u j k

lemma nwt_high (u : ℂ) (j : ℕ) : ∀ k, j < k → nwt u j k = 0 := by
  induction j with
  | zero => intro k hk; simp [nwt, show k ≠ 0 by omega]
  | succ j ih =>
    intro k hk
    simp [nwt, show k ≠ 0 by omega, ih (k-1) (by omega), ih k (by omega)]

lemma nwt_diag (u : ℂ) (j : ℕ) : nwt u j j = 1 := by
  induction j with
  | zero => simp [nwt]
  | succ j ih =>
    simp [nwt, Nat.add_sub_cancel, ih, nwt_high u j (j+1) (by omega)]

lemma nwt_eval (u : ℂ) (j : ℕ) : ∀ M, j < M → ∀ x : ℂ,
    ∑ k ∈ range M, nwt u j k * x^k = ∏ t ∈ range j, (x - u^t) := by
  induction j with
  | zero =>
    intro M hM x
    simp [nwt, ite_mul, show 0 < M from hM]
  | succ j ih =>
    intro M hM x
    obtain ⟨M', rfl⟩ : ∃ M', M = M'+1 := ⟨M-1, by omega⟩
    have hs : ∑ k ∈ range (M'+1), nwt u (j+1) k * x^k =
        (∑ k ∈ range M', nwt u j k * x^k) * x
          - u^j * ∑ k ∈ range (M'+1), nwt u j k * x^k := by
      simp only [nwt, sub_mul, sum_sub_distrib, mul_sum]
      congr 1
      · rw [sum_range_succ']
        simp [pow_succ, mul_assoc, sum_mul]
      · exact sum_congr rfl fun k _ => by ring
    rw [hs, ih M' (by omega) x, ih (M'+1) (by omega) x, prod_range_succ]
    ring

def nwtMat (n : ℕ) (u : ℂ) : RootMat n := fun k j => nwt u j.val k.val

lemma nwtMat_low (n : ℕ) (u : ℂ) (k j : Fin n) (h : j < k) : nwtMat n u k j = 0 :=
  nwt_high u j.val k.val h

lemma nwtMat_diag (n : ℕ) (u : ℂ) (j : Fin n) : nwtMat n u j j = 1 := nwt_diag u j.val

theorem unitri_cancel {n : ℕ} {X Y B : RootMat n}
    (h0 : ∀ k j : Fin n, j < k → B k j = 0) (h1 : ∀ j, B j j = 1)
    (h : X * B = Y * B) : X = Y := by
  ext i j
  suffices H : ∀ m, ∀ j : Fin n, j.val < m → X i j = Y i j from H _ j (Nat.lt_succ_self _)
  intro m
  induction m with
  | zero => intro j hj; omega
  | succ m ih =>
    intro j hj
    have hij : (X * B) i j = (Y * B) i j := congrArg (fun M : RootMat n => M i j) h
    rw [Matrix.mul_apply, Matrix.mul_apply] at hij
    have hd : ∑ k, (X i k - Y i k) * B k j = 0 := by
      simp only [sub_mul, sum_sub_distrib, hij, sub_self]
    rw [sum_eq_single j] at hd
    · rw [h1, mul_one, sub_eq_zero] at hd; exact hd
    · intro k _ hk
      rcases lt_or_gt_of_ne hk with g | g
      · have g' : k.val < j.val := g
        rw [ih k (by omega), sub_self, zero_mul]
      · rw [h0 k j g, mul_zero]
    · intro hj'; exact absurd (mem_univ j) hj'

lemma nwt_prod {n : ℕ} (u : ℂ) (h : IsPrimitiveRoot u n) (i j : ℕ)
    (hi : i<n) (hj : j ≤ i) :
    ∏ t ∈ range j, (u^i - u^t) = gap u i * (gap u (i-j))⁻¹ * roof u j := by
  induction j with
  | zero =>
    simp only [prod_range_zero, roof, Nat.sub_zero, mul_one]
    rw [mul_inv_cancel₀ (gap_ne_zero u h i hi)]
  | succ j ih =>
    let s := i-(j+1)
    have hs : i-j=s+1 := by dsimp [s]; omega
    rw [prod_range_succ, ih (by omega), hs]
    have gh (i : ℕ) : gap u (i+1)=gap u i*(1-u^(i+1)) := prod_range_succ ..
    have rh (i : ℕ) : roof u (i+1)=roof u i * (-u^i) := prod_range_succ ..
    have up : u^i-u^j=(1-u^(s+1))*(-u^j) := by
      conv_lhs => lhs; rw [show i=s+1+j by dsimp [s]; omega, pow_add]
      ring
    change gap u i * _ * _ * _ = gap u i * (gap u s)⁻¹ * _
    have hh := gap_ne_zero u h (s+1) (by omega)
    rw [gh] at hh ⊢
    have hx := left_ne_zero_of_mul hh
    have hz := right_ne_zero_of_mul hh
    rw [up,rh]
    field_simp

lemma winds_nwt (n : ℕ) (u : ℂ) (h : IsPrimitiveRoot u n) :
    winds n u * nwtMat n u = steps n u := by
  ext i j
  rw [Matrix.mul_apply]
  have hf : (∑ k : Fin n, winds n u i k * nwtMat n u k j) =
      ∏ t ∈ range j.val, (u^i.val - u^t) := by
    rw [← nwt_eval u j.val n j.isLt (u^i.val), ← Fin.sum_univ_eq_sum_range]
    refine sum_congr rfl ?_
    intro k _
    simp [winds, nwtMat, pow_mul, mul_comm]
  rw [hf]
  rcases lt_or_ge i j with g|g
  · have g' : i.val < j.val := g
    rw [prod_eq_zero (mem_range.mpr g') (sub_self _), steps_zero n u i j g]
  · have hh : j.val ≤ i.val := g
    rw [steps_apply, nwt_prod u h _ _ i.isLt hh, rise, if_pos hh, floorH]

lemma steps_nwt (n : ℕ) (u : ℂ) (h : IsPrimitiveRoot u n) :
    (steps n u)ᵀ * nwtMat n u = fade n (cog u) := by
  let M := (nwtMat n u)ᵀ * steps n u
  have ht : (steps n u)ᵀ * nwtMat n u = M := by
    show _ = (nwtMat n u)ᵀ * steps n u
    rw [← winds_nwt n u h, transpose_mul, winds_symm, Matrix.mul_assoc]
  have sym : Mᵀ=M := by
    show ((nwtMat n u)ᵀ * steps n u)ᵀ = _
    rw [transpose_mul,transpose_transpose,ht]
  have hz (i j : Fin n) (hij : i<j) : M i j = 0 := by
    simp only [M,Matrix.mul_apply,transpose_apply]
    refine sum_eq_zero ?_
    intro l _
    rcases lt_or_ge i l with g|g
    · rw [nwtMat_low n u l i g,zero_mul]
    · rw [steps_zero n u l j (lt_of_le_of_lt g hij),mul_zero]
  have hd (i : Fin n) : M i i = cog u i.val := by
    simp only [M,Matrix.mul_apply,transpose_apply]
    rw [sum_eq_single i,nwtMat_diag,one_mul,steps_diag]
    · intro l _ hl
      rcases lt_or_gt_of_ne hl with g|g
      · rw [steps_zero n u l i g,mul_zero]
      · rw [nwtMat_low n u l i g,zero_mul]
    · simp
  rw [ht]
  ext i j
  rcases lt_trichotomy i j with g|g|g
  · rw [hz i j g,fade,diagonal_apply,if_neg g.ne]
  · subst j; rw [hd,fade,diagonal_apply,if_pos rfl]; rfl
  · rw [← sym,transpose_apply,hz j i g,fade,diagonal_apply,if_neg g.ne']

theorem winds_factor (n : ℕ) (u : ℂ) (h : IsPrimitiveRoot u n) :
    winds n u =
      steps n u * fade n (fun i => (cog u i)⁻¹) * (steps n u)ᵀ := by
  have hh :
      fade n (fun i => (cog u i)⁻¹) * fade n (cog u)=1 := by
    unfold fade
    rw [diagonal_mul_diagonal, show (1 : RootMat n) = diagonal (fun _ => 1) from rfl]
    congr 1
    funext i
    exact inv_mul_cancel₀ (cog_ne_zero u h i.val i.isLt)
  refine unitri_cancel (B := nwtMat n u) (nwtMat_low n u) (nwtMat_diag n u) ?_
  rw [winds_nwt _ _ h, Matrix.mul_assoc, steps_nwt _ _ h, Matrix.mul_assoc, hh, mul_one]

end
end PowerSaving.Spectral
end OAI
