import Submission.Work.MixedCost.NaiveKernel
import Submission.OAI.Computability.FourierTransform.PowerTables
import Mathlib.Analysis.SpecialFunctions.Pow.Asymptotics

namespace OAI
namespace PowerSaving
namespace WHT
noncomputable section


open RAM RAM.Ty RAM.Bench Binary Matrix Finset Complex
universe U

def digitWeight (e o : ℂ) : ℕ → ℕ → ℂ
  | 0, _ => 1
  | j+1, n => (if n % 2 = 0 then e else o) * digitWeight e o j (n/2)

lemma digitWeight_range (e o : ℂ) (j n : ℕ) :
    digitWeight e o j n = ∏ i ∈ range j, if n / 2^i % 2 = 0 then e else o := by
  induction j generalizing n with
  | zero => simp [digitWeight]
  | succ j ih =>
    have e1 : ∀ i, n / 2 / 2^i = n / 2^(i+1) := fun i => by
      rw [pow_succ', Nat.div_div_eq_div_mul]
    rw [digitWeight, ih, prod_range_succ']
    simp only [e1, pow_zero, Nat.div_one]
    exact mul_comm _ _

private lemma f2_val_eq_zero : ∀ a : ZMod 2, a.val = 0 ↔ a = 0 := by decide

lemma digitWeight_bits (e o : ℂ) (k : ℕ) (x : Bits k) :
    digitWeight e o k ((bits k).loc x) = ∏ i : Fin k, if x i = 0 then e else o := by
  rw [digitWeight_range,
    ← Fin.prod_univ_eq_prod_range (fun i => if (bits k).loc x / 2^i % 2 = 0 then e else o) k]
  refine prod_congr rfl fun i _ => ?_
  simp only [bits_div, f2_val_eq_zero]

def weightTab (e o : ℂ) (j : ℕ) : T (a sc) := Tape.tab (2^j) (digitWeight e o j)

lemma tape_loc {α : Type*} {μ : Type*} (L : Layout α) (f : ℕ → μ) :
    L.tape (fun x => f (L.loc x)) = Tape.tab L.n f := by
  unfold Layout.tape Tape.tab
  congr 1
  funext j
  simp

lemma weightTab_bits (e o : ℂ) (k : ℕ) :
    weightTab e o k = (bits k).tape (fun y => ∏ i : Fin k, if y i = 0 then e else o) :=
  calc weightTab e o k
      = (bits k).tape (fun x => digitWeight e o k ((bits k).loc x)) :=
        (tape_loc (bits k) (digitWeight e o k)).symm
    _ = _ := congrArg (bits k).tape (funext fun y => digitWeight_bits e o k y)

lemma weight_pre (k : ℕ) (y : Bits k) :
    (∏ i : Fin k, if y i = 0 then (1 : ℂ) else I) = lum y := rfl

lemma weight_post (k : ℕ) (y : Bits k) :
    (∏ i : Fin k, if y i = 0 then (1 - I) else (1 + I)) = (1 - I)^k * lum y := by
  have h : I^2 = -1 := Complex.I_sq
  have step : ∀ i : Fin k, (if y i = 0 then (1 - I) else (1 + I)) = (1 - I) * tint (y i) := by
    intro i
    by_cases hy : y i = 0
    · simp [tint, hy]
    · simp only [tint, ite_eq_right hy]
      linear_combination h
  simp only [step, prod_mul_distrib, prod_const, card_univ, Fintype.card_fin, lum]

section Programs
variable {ι : Type U} {m : Bool}

lemma weightTable {b : Bench m ι} {k : ι → ℕ} (h : b.Nick k)
    (g : Small b.size fun i => 2^k i) {e o : ι → ℂ}
    (he : b.Moves (fun _ => 0) sc e) (ho : b.Moves (fun _ => 0) sc o) :
    b.Moves (fun i => 2^k i) (a sc) fun i => weightTab (e i) (o i) (k i) := by
  let V (i : ι) (j : ℕ) : T (a sc) := weightTab (e i) (o i) j
  have F := Instant.climbs b k V (t:=a sc)
  have HB : b.Moves (fun _ => 0) (a sc) fun i => V i 0 :=
    ((arrayNow (Nick.wc 1) (t:=sc) (fun _ _ => 1) Moves.one).weaken (Dom.const _ _)).congr
      fun i => by
        simp only [V,weightTab,pow_zero]
        exact tape_congr_sized fun j hj => by simp [digitWeight]
  have hm := tokenNow b k V
  let R (i : During k) := 2^i.j
  let D := b.climbs k (a sc) V
  have hu : Small D.size R := (g.reindex _).mono fun i =>
    Nat.pow_le_pow_right (by omega) i.hj.le
  have hh : D.Nick R := ⟨hm.len hu,hu⟩
  let Y (i : During k) := 2^(i.j+1)
  have hY : D.Nick Y :=
    (hh.mul (Nick.wc 2)).congr fun i => (pow_succ _ _).symm
  have G := Instant.scan D Y
  have hp := chop hY
  have hr := Moves.pick (t:=sc) (n:=fun i => R i.i) (k:=fun i : During Y => i.j/2)
    (fun i j => digitWeight (e i.i.i) (o i.i.i) i.i.j j)
    (hm.transfer G) (hp.div (Nick.wc 2)).close (fun i => by
      have hpp : i.j < Y i.i := i.hj
      simp only [R,Y,pow_succ] at *
      omega)
  have hk := repeatM h V HB (u:=fun _ j => 2^(j+1))
    (arrayNow hY (t:=sc) (fun i j => digitWeight (e i.i) (o i.i) (i.j+1) j)
      ((((hp.residue (Nick.wc 2)).close.branch
        ((he.transfer (G.next F)).mul hr) ((ho.transfer (G.next F)).mul hr))).congr fun i => by
          by_cases H : i.j % 2 = 0
          · rw [digitWeight, ite_eq_left H, ite_eq_left H]
          · rw [digitWeight, ite_eq_right H, ite_eq_right H]))
  exact hk.weaken ⟨4,fun i => by
    dsimp
    rw [unit_doubling]
    have hh : k i < 2^k i := Nat.lt_two_pow_self
    omega⟩

lemma lum_tables {s : Ty} {B : ι → ℕ} {x : ι → T s} {k : ι → ℕ}
    (hk : Knows m B s x k) (hks : Small B k) (hp : Small B fun i => 2^k i)
    (hI : Has m B s sc x (fun _ => I)) :
    Can m B s (a sc) x (fun i => (bits (k i)).tape (fun y => lum y)) (fun i => 2^k i) ∧
    Can m B s (a sc) x (fun i => (bits (k i)).tape (fun y => (1 - I)^k i * lum y))
      (fun i => 2^k i) := by
  let b : Bench m ι := ⟨B, s, x⟩
  have hN : b.Nick k := ⟨hk, hks⟩
  have hI' : b.Moves (fun _ => 0) sc (fun _ => I) := hI
  have T1 : b.Moves (fun i => 2^k i) (a sc) fun i => weightTab 1 I (k i) :=
    weightTable hN hp Moves.one hI'
  have T2 : b.Moves (fun i => 2^k i) (a sc) fun i => weightTab (1 - I) (1 + I) (k i) :=
    weightTable hN hp (Moves.one.sub hI') (Moves.one.add hI')
  have T1c : Can m B s (a sc) x (fun i => weightTab 1 I (k i)) (fun i => 2^k i) := T1
  have T2c : Can m B s (a sc) x (fun i => weightTab (1 - I) (1 + I) (k i)) (fun i => 2^k i) := T2
  constructor
  · refine Can.cong T1c (fun _ => rfl) (fun i => ?_)
    exact (weightTab_bits _ _ _).trans
      (congrArg (bits (k i)).tape (funext fun y => weight_pre (k i) y))
  · refine Can.cong T2c (fun _ => rfl) (fun i => ?_)
    exact (weightTab_bits _ _ _).trans
      (congrArg (bits (k i)).tape (funext fun y => weight_post (k i) y))

end Programs


end
end WHT
end PowerSaving
end OAI

